#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long get_last_tidy_number(long long n) {
    long long result = n;
    while (!is_tidy(result)) {
        result--;
    }
    return result;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long last_tidy_number = get_last_tidy_number(N);
        cout << "Case #" << i << ": " << last_tidy_number << endl;
    }
    return 0;
}
