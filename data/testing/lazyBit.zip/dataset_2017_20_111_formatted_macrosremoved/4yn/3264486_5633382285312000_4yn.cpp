#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef pair<int, int> pii;
typedef vector<int> VI;
typedef vector<pii> vii;
typedef long long LL;
const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void xewksdrlae(std::string &s, int &i, VI &k) {
  char m = s[i];
  k.push_back(m - '0');
}

bool check(int a) {
  string s = to_string(a);
  VI k;
  for (int i = (0); i < (s.size()); i++)
    xewksdrlae(s, i, k);
  VI ne = k;
  sort(ne.begin(), ne.end());
  int i;
  for (i = (0); i < (k.size()); i++)
    if (k[i] != ne[i])
      return false;
  return true;
}

int main() {
  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/lazyBit/bennikartefla/A-small-practice.in",
          "r", stdin);
  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int m;
    cin >> m;
    for (int a = m; a >= 0; a--) {
      if (check(a)) {
        cout << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return ret_val;
}
