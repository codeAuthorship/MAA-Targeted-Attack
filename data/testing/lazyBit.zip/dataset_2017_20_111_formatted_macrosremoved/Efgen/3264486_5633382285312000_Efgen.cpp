#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
typedef unsigned long long ull;
typedef vector<int> VI;
typedef long double ld;
typedef vector<vector<int>> vvi;

ofstream ans("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/lazyBit/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      string b = "";
      if (s[0] > minc)
        if (s[0] > '1')
          b += (char)(s[0] - 1);
      for (int i = 1; i < s.size(); i++)
        b += '9';
      return b;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  cin >> s;
  ans << solves(s, '0') << '\n';
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/lazyBit/sammyMaX/A-small-practice.in", "r", stdin);

  int t;
  cin >> t;
  for (int i = 0; i < t; i++)
    ans << "Case #" << i + 1 << ": ", solve();
}
