#include <iostream>
#include <string>

using namespace std;

long long find_last_tidy_number(long long N) {
    string s = to_string(N);
    int n = s.length();
    int last = n - 1;
    for (int i = last; i > 0; i--) {
        if (s[i] < s[i-1]) {
            s[i-1]--;
            last = i - 1; 
        }
    }
    for (int i = last + 1; i < n; i++) {
        s[i] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long last_tidy_number = find_last_tidy_number(N);
        cout << "Case #" << t << ": " << last_tidy_number << endl;
    }
    return 0;
}
