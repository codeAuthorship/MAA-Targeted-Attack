#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long findLargestTidy(long long n) {
    if (isTidy(n)) {
        return n;
    }
    string s = to_string(n);
    int idx = 0;
    while (s[idx+1] >= s[idx]) {
        idx++;
    }
    while (idx > 0 && s[idx] == s[idx-1]) {
        idx--;
    }
    s[idx] -= 1;
    for (int i = idx+1; i < s.length(); i++) {
        s[i] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long lastTidy = findLargestTidy(N);
        cout << "Case #" << t << ": " << lastTidy << endl;
    }
    return 0;
}
