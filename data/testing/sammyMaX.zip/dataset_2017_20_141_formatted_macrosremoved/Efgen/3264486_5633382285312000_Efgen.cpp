#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <utility>
#include <vector>
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
typedef pair<int, int> PII;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef long double LD;

ofstream fout;

ifstream fin("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/gultai4ukr/sammyMaX/A-small-practice.in");

inline void otvxbfzxsh(std::string &res, int &i) {
  res += '9';
  i++;
}

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      string res = "";
      if (s[0] > minc && s[0] > '1')
        res += (char)(s[0] - 1);
      int i;
      {
        i = 1;
        while (i < s.size())
          otvxbfzxsh(res, i);
      }
      return res;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void get() {
  string s;
  fin >> s;
  fout << solves(s, '0') << '\n';
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/gultai4ukr/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

  int t;
  fin >> t;
  {
    int i = 0;
    while (i < t) {
      fout << "Case #" << i + 1 << ": ", get();
      i++;
    }
  }
  return 0;
}
