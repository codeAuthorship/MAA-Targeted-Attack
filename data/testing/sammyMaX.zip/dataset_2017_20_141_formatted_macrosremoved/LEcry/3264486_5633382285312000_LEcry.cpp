#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 0; i < len - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long left = 1, right = n, mid, ans = -1;
        while (left <= right) {
            mid = (left + right) / 2;
            if (is_tidy(mid)) {
                ans = mid;
                left = mid + 1;
            }
            else {
                right = mid - 1;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
