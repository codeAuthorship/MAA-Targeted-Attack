#include <iostream>
#include <string>

using namespace std;

long long getTidyNumber(long long n) {
    string str = to_string(n);
    int len = str.length();
    int pos = len;

    for (int i = len - 1; i >= 0; i--) {
        if (str[i] < str[pos - 1]) {
            for (int j = i + 1; j < len; j++) {
                str[j] = '9';
            }
            str[i] -= 1;
            pos = i + 1;
        }
        else {
            pos = i;
        }
    }

    return stoll(str);
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = getTidyNumber(n);
        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
