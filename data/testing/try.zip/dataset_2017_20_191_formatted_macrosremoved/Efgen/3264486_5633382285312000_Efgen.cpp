#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;

ifstream tc("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/try/sammyMaX/A-small-practice.in");

inline void ueddxfbcyt(std::string &s, std::string &b) {
  int i = 1;
  while (i < s.size()) {
    b += '9';
    i++;
  }
}

string get(string s, char y) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0])
      return s[0] + get(s.substr(1), s[0]);
    else {
      string b = "";
      if (s[0] > minc)
        if (s[0] > '1')
          b += (char)(s[0] - 1);
      ueddxfbcyt(s, b);
      return b;
    }
  }
  return minc + get(s.substr(1), minc);
}

void solve() {
  string s;
  tc >> s;
  cout << get(s, '0') << '\n';
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/try/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  tc >> t;
  {
    int i = 0;
    while (i < t) {
      cout << "Case #" << i + 1 << ": ", solve();
      i++;
    }
  }
  return 0;
}
