#include <bits/stdc++.h>
#include <cassert>
#include <complex>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

typedef unsigned long long ull;
typedef long double LD;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<PII> vii;

bool check(int get) {
  string s = to_string(get);
  VI k;
  {
    int i = (0);
    while (i < (s.size())) {
      char d = s[i];
      k.push_back(d - '0');
      i++;
    }
  }
  VI solve = k;
  sort(solve.begin(), solve.end());
  for (int i = (0); i < (k.size()); i++) {
    if (k[i] != solve[i])
      return false;
  }
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/try/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/try/bennikartefla/A-small-practice.in",
          "r", stdin);

  int n;
  scanf("%d ", &n);
  for (int i = (0); i < (n); i++) {
    int d;
    scanf("%d ", &d);
    for (int get = d; get >= 0; get--) {
      if (check(get)) {
        printf("Case #%d: %d\n", i + 1, get);
        break;
      }
    }
  }
  return 0;
}
