#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef set<int> si;
typedef long double LD;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ull; 
typedef unsigned uint;


struct debugger {};

char N[50];

bool containszero(int l) {
  int i = 0;
  while (N[i] == '0') {
    i++;
  }
  while (i < l) {
    if (N[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void dlhohwnnps(int &i, int &l, int &j) {
  j = i;
  while (j < l) {
    N[j] = '9';
    j++;
  }
}

inline void cuhzjglgaj(int &l, int &j, int &i) {
  for (j = i; j < l; j++)
    N[j] = '9';
  N[i - 1] = (char)(N[i - 1] - 1);
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/try/lazyBit/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/try/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);


  int n, i, j, k, l, m, t, s = 0, d;
  scanf("%d", &t);
  ;
  int c = 1;
  while (t--) {
    scanf("%s ", N);
    int p = 0;
    l = strlen(N);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (N[i] < N[i - 1]) {
          dlhohwnnps(i, l, j);
          N[i - 1] = (char)(N[i - 1] - 1);
        }
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (N[i] == '0') {
          for (j = i; j < l; j++)
            N[j] = '9';
          N[i - 1] = (char)(N[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (N[i] < N[i - 1])
            cuhzjglgaj(l, j, i);
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (N[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      printf("%c", N[i++]);
    }
    printf("\n");
  }
  return (0);
}
