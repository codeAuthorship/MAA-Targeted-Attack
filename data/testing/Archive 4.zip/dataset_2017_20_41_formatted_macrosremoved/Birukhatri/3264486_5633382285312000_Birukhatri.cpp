#include <bits/stdc++.h>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;          
typedef unsigned long long ULL; 
typedef unsigned uint;


struct debugger {};

char ans[50];

bool containszero(int l) {
  int i = 0;
  while (ans[i] == '0') {
    i++;
  }
  for (; i < l;) {
    if (ans[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void zfmueoxglb(int &j) { ans[j] = '9'; }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_17_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_17_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/lazyBit/A-small-practice.in",
          "r", stdin);


  int n, i, j, k, l, m, tt, s = 0, d;
  scanf("%d", &tt);
  ;
  int c = 1;
  for (; tt--;) {
    scanf("%s ", ans);
    bool p = 0;
    l = strlen(ans);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (ans[i] < ans[i - 1]) {
          for (j = i; j < l; j++)
            ans[j] = '9';
          ans[i - 1] = (char)(ans[i - 1] - 1);
        }
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (ans[i] == '0') {
          for (j = i; j < l; j++)
            ans[j] = '9';
          ans[i - 1] = (char)(ans[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (ans[i] < ans[i - 1]) {
            for (j = i; j < l; j++)
              zfmueoxglb(j);
            ans[i - 1] = (char)(ans[i - 1] - 1);
          }
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (ans[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      printf("%c", ans[i++]);
    }
    printf("\n");
  }
  return (0);
}
