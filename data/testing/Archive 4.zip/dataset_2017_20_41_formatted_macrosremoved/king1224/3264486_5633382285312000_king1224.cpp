#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int prev = -1;
    for (char c : s) {
        int d = c - '0';
        if (d < prev) {
            return false;
        }
        prev = d;
    }
    return true;
}

long long last_tidy_number(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long last = last_tidy_number(n);
        cout << "Case #" << i << ": " << last << endl;
    }
    return 0;
}
