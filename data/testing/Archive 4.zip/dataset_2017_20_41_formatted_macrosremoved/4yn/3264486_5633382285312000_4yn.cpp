#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

typedef pair<int, int> ii;

typedef vector<ii> vii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int a) {
  string s = to_string(a);
  vector<int> k;
  for (int i = (0); i < (s.size()); i++) {
    char m = s[i];
    k.push_back(m - '0');
  }
  vector<int> ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i]) {
      return false;
    }
  return true;
}

int main() {
  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/bennikartefla/A-small-practice.in",
          "r", stdin);
  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int ans;
  scanf("%d ", &ans);
  for (int i = (0); i < (ans); i++) {
    int m;
    scanf("%d ", &m);
    for (int a = m; a >= 0; a--) {
      if (check(a)) {
        fout << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return ret_val;
}
