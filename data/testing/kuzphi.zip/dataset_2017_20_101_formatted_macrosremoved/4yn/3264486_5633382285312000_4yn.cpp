#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const double EPS = 1e-9;
const int MOD = 1000000007;

const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int a) {
  string s = to_string(a);
  vector<int> k;

  for (int i = (0); i < (s.size()); i++) {
    char m = s[i];
    k.push_back(m - '0');
  }
  vector<int> ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i]) {
      return 0;
    }
  return true;
}

int main() {

  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int m;
    cin >> m;
    for (int a = m; a >= 0; a--) {
      if (check(a)) {
        printf("Case #%d: %d\n", i + 1, a);
        break;
      }
    }
  }
  return 0;
}
