#include <bitset>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
const double EPS = 1e-9;

const int mod = 1000000007;

typedef long long LL;             
typedef unsigned long long ULL;  

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

char str[50];

bool containszero(int ans) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  while (i < ans) {
    if (str[i] == '0')
      return 1;
    i++;
  }
  return false;
}
int main() {

 
  int n, i, j, x, ans, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    bool p = 0;
    ans = strlen(str);
    if (!containszero(ans)) {
      for (i = ans - 1; i > 0; i--) {
        if (str[i] < str[i - 1]) {
          for (j = i; j < ans; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
        }
      }
    }
    while (containszero(ans)) {
      for (i = 0; i < ans; i++) {
        if (str[i] == '0') {
          for (j = i; j < ans; j++) {
            str[j] = '9';
          }
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(ans)) {
        for (i = ans - 1; i > 0; i--) {
          if (str[i] < str[i - 1]) {
            for (j = i; j < ans; j++)
              str[j] = '9';
            str[i - 1] = (char)(str[i - 1] - 1);
          }
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < ans) {
      cout << str[i++];
    }
    printf("\n");
  }
  return (0);
}
