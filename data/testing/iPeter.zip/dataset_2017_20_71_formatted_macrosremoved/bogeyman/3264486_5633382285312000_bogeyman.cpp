#include <iostream>
#include <string>

using namespace std;

long long largestTidyNumber(long long n) {
    string digits = to_string(n);
    int len = digits.length();

    for (int i = len - 1; i > 0; i--) {
        if (digits[i] < digits[i-1]) {
            digits[i-1]--;
            for (int j = i; j < len; j++) {
                digits[j] = '9';
            }
        }
    }

    return stoll(digits);
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;

        long long lastTidy = largestTidyNumber(N);

        cout << "Case #" << i << ": " << lastTidy << endl;
    }

    return 0;
}
