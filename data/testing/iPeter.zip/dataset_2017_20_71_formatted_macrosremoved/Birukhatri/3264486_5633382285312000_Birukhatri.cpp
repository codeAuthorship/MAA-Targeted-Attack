#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           // NOTES:int64
typedef unsigned long long ULL; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {};

void debugarr(int *tt, int n) {
  printf("[");
  int i;
  for (i = 0; i < n; i++)
    printf("%d ", tt[i]);
  printf("]\n");
}

char str[50];

bool containszero(int l) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  while (i < l) {
    if (str[i] == '0')
      return 1;
    i++;
  }
  return false;
}
inline void gtrvxufcaj(int &l, int &j, int &i) {
  for (j = i; j < l; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

inline void ofwyxjsree(int &i, int &l, int &j) {
  j = i;
  while (j < l) {
    str[j] = '9';
    j++;
  }
}

inline void ctqncttvjw(int &l, int &j, int &i) {
  ofwyxjsree(i, l, j);
  str[i - 1] = (char)(str[i - 1] - 1);
}

int main() {
  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, k, l, m, t, s = 0, ans;
  scanf("%d", &t);
  ;
  int c = 1;
  for (; t--;) {
    scanf("%s ", str);
    int p = 0;
    l = strlen(str);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (str[i] < str[i - 1])
          ctqncttvjw(l, j, i);
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (str[i] == '0') {
          for (j = i; j < l; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (str[i] < str[i - 1])
            gtrvxufcaj(l, j, i);
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      printf("%c", str[i++]);
    }
    printf("\n");
  }
  return (0);
}
