#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <stdio.h>
#include <vector>
using namespace std;

typedef vector<int> vi;

const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int a) {
  string s = to_string(a);
  vi k;
  for (int i = (0); i < (s.size()); i++) {
    char m = s[i];
    k.push_back(m - '0');
  }
  vi ne = k;
  sort(ne.begin(), ne.end());
  {
    int i = (0);
    while (i < (k.size())) {
      if (k[i] != ne[i])
        return 0;
      i++;
    }
  }
  return 1;
}

int main() {

  ofstream tt("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/iPeter/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  scanf("%d ", &t);
  for (int i = (0); i < (t); i++) {
    int m;
    scanf("%d ", &m);
    for (int a = m; a >= 0; a--) {
      if (check(a)) {
        tt << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return 0;
}
