#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
using namespace std;

ifstream fin("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/iPeter/sammyMaX/A-small-practice.in");
ofstream tt("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/iPeter/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline void movermdfpt(std::string &res, std::string &s) {
  if (s[0] > '1')
    res += (char)(s[0] - 1);
}

inline bool ylsnftaokl(char &minc, std::string &s, std::string &ylsnf) {
  string res = "";
  if (s[0] > minc)
    movermdfpt(res, s);
  for (int wzhi_Var = 1; wzhi_Var < s.size(); wzhi_Var++)
    res += '9';
  ylsnf = res;
  return true;
  return false;
}

inline bool lbuglzftzr(char &minc, std::string &s, std::string &lbugl) {
  std::string ylsnf;
  if (ylsnftaokl(minc, s, ylsnf)) {
    lbugl = ylsnf;
    return true;
  }
  return 0;
}

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char ans : s)
    minc = min(minc, ans);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0])
      return s[0] + solves(s.substr(1), s[0]);
    else {
      std::string lbugl;
      if (lbuglzftzr(minc, s, lbugl)) {
        return lbugl;
      }
    }
  }
  return minc + solves(s.substr(1), minc);
}

void do_voieyg_fct() {
  string s;
  fin >> s;
  tt << solves(s, '0') << '\n';
}

int main() {
  int t;
  fin >> t;
  int wzhi_Var;
  {
    wzhi_Var = 0;
    while (wzhi_Var < t) {
      tt << "Case #" << wzhi_Var + 1 << ": ", do_voieyg_fct();
      wzhi_Var++;
    }
  }
  return 0;
}
