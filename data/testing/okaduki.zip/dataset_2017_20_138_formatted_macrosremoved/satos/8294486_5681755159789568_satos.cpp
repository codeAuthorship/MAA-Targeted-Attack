#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;

const ll INF = 1e18;

int n, q;
vector<int> e, s;
vector<vector<int>> d;

ll dijkstra(int u, int v) {
    vector<ll> dist(n, INF);
    priority_queue<pli, vector<pli>, greater<pli>> pq;
    dist[u] = 0;
    pq.push({0, u});
    while (!pq.empty()) {
        int u = pq.top().second;
        ll du = pq.top().first;
        pq.pop();
        if (du != dist[u])
            continue;
        for (int v = 0; v < n; ++v) {
            if (d[u][v] == -1)
                continue;
            ll w = d[u][v];
            ll t = ceil((double) w / s[u]);
            if (dist[u] + t < dist[v]) {
                dist[v] = dist[u] + t;
                pq.push({dist[v], v});
            }
        }
    }
    return dist[v];
}

void solve() {
    cin >> n >> q;
    e.resize(n);
    s.resize(n);
    d.assign(n, vector<int>(n));
    for (int i = 0; i < n; ++i)
        cin >> e[i] >> s[i];
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            cin >> d[i][j];
    for (int i = 0; i < q; ++i) {
        int u, v;
        cin >> u >> v;
        --u; --v;
        ll ans = dijkstra(u, v);
        cout << fixed << setprecision(9) << ans << " ";
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        cout << "Case #" << i << ": ";
        solve();
    }
    return 0;
}
