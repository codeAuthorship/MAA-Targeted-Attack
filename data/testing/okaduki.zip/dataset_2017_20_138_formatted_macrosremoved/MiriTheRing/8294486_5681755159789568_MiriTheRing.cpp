#include <bits/stdc++.h>
using namespace std;

typedef long double ld;
const ld eps = 1e-8;

int T, n, q;
ld max_dist[105], speed[105], dist[105][105];

ld calc_time(ld len, ld spd) {
    return len / spd;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> n >> q;
        for (int i = 1; i <= n; i++) {
            cin >> max_dist[i] >> speed[i];
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                cin >> dist[i][j];
            }
        }
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (dist[i][k] >= 0 && dist[k][j] >= 0) {
                        ld len = dist[i][k] + dist[k][j];
                        ld spd = min(speed[i], speed[j]);
                        ld time = calc_time(len, spd);
                        if (dist[i][j] < 0 || time < dist[i][j] - eps) {
                            dist[i][j] = time;
                        }
                    }
                }
            }
        }
        cout << "Case #" << t << ": ";
        for (int i = 1; i <= q; i++) {
            int u, v;
            cin >> u >> v;
            ld ans = dist[u][v];
            for (int j = 1; j <= n; j++) {
                for (int k = 1; k <= n; k++) {
                    if (dist[u][j] >= 0 && dist[k][v] >= 0) {
                        ld len = dist[u][j] + dist[j][k] + dist[k][v];
                        ld spd = min(speed[j], min(speed[u], speed[v]));
                        ld time = calc_time(len, spd);
                        if (max_dist[j] >= len - eps && max_dist[u] >= dist[u][j] - eps && max_dist[v] >= dist[k][v] - eps) {
                            ans = min(ans, time);
                        }
                    }
                }
            }
            cout << fixed << setprecision(10) << ans << " ";
        }
        cout << endl;
    }
    return 0;
}
