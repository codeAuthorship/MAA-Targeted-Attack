#include<bits/stdc++.h>
using namespace std;
#define inf 1e18

int main() {
    int t, n, q;
    cin >> t;

    for(int z = 1; z <= t; z++) {
        cin >> n >> q;

        vector<long double> E(n), S(n);
        vector<vector<long double>> D(n, vector<long double>(n));

        for(int i = 0; i < n; i++) cin >> E[i] >> S[i];
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                cin >> D[i][j];
                if(D[i][j] == -1) D[i][j] = inf;
            }
        }

        for(int k = 0; k < n; k++) {
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++) {
                    D[i][j] = min(D[i][j], D[i][k] + D[k][j]);
                }
            }
        }

        cout << "Case #" << z << ": ";

        while(q--) {
            int u, v;
            cin >> u >> v;
            u--; v--;

            long double ans = D[u][v];

            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++) {
                    if(D[u][i] + D[i][j] + D[j][v] <= E[i] && S[i] >= D[u][i] / E[i] + (D[i][j] + D[j][v]) / E[j]) {
                        ans = min(ans, D[u][i] / S[i] + (D[i][j] + D[j][v]) / S[j]);
                    }
                }
            }

            cout << fixed << setprecision(10) << ans << " ";
        }

        cout << endl;
    }

    return 0;
}
