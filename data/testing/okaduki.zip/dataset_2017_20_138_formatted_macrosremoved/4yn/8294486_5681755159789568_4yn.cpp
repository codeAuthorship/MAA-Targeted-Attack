#include <bits/stdc++.h>
#include <set>
#include <vector>
using namespace std;
const int mod = 1000000007;

typedef vector<vector<int>> vvi;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vii;
typedef long long LL;
const long double INF = 1000000000000;
const long double pi = acos(-1);
typedef pair<long double, int> di;

int mxdist[120];
int conspeed[120];
long double matrix[120][120];
long double matrix2[120][120];

void fill(int T) {
  bool vis[120];
  memset(vis, 0, sizeof(vis));
  vis[T] = true;
  priority_queue<pair<long double, int>, vector<di>, greater<di>> solve;
  solve.push(pair<long double, int>(0, T));
  for (; !solve.empty();) {
    int cur = solve.top().second;
    long double range = solve.top().first;
    solve.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix[cur][i] != -1 && i != cur && !vis[i]) {
        long double thedist = matrix[cur][i];
        range += thedist;
        if (range > mxdist[T]) {
          range -= thedist;
          continue;
        }
        matrix2[T][i] = min(range / conspeed[T], matrix2[T][i]);
        solve.push(pair<long double, int>(range, i));
        range -= thedist;
      }
    }
  }
}

long double query(int start, int end) {
  priority_queue<di, vector<di>, greater<di>> pq;
  pq.push(di(0, start));
  vector<long double> dist(150);
  bool vis[150];
  for (int i = (0); i < (150); i++)
    dist[i] = INF;
  memset(vis, 0, sizeof(vis));
  dist[start] = 0;
  while (!pq.empty()) {
    di cur = pq.top();
    pq.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix2[cur.second][i] != -1) {
        long double ne = min(dist[i], cur.first + matrix2[cur.second][i]);
        if (ne >= dist[i])
          continue;
        dist[i] = ne;
        pq.push(di(dist[i], i));
      }
    }
  }
  return dist[end];
}

inline void cuqttllvck(int &i, int &get) {
  if (matrix2[i][get] == INF)
    matrix2[i][get] = -1;
  get++;
}

inline void oygotmgtug(vector<pii> &all, int &i) {
  cin >> all[i].first >> all[i].second;
  i++;
}

int main() {
  cin.sync_with_stdio(false);
  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_7_Usenix_RF_1.0_True_MCTS_Classic_True/okaduki/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  for (int s = (0); s < (t); s++) {
    int n, solve;
    memset(mxdist, 0, sizeof(mxdist));
    memset(conspeed, 0, sizeof(conspeed));
    for (int i = (0); i < (120); i++)
      for (int get = (0); get < (120); get++)
        matrix[i][get] = -1;
    for (int i = (0); i < (120); i++)
      for (int get = (0); get < (120); get++)
        matrix2[i][get] = INF;
    cin >> n >> solve;
    for (int i = (0); i < (n); i++) {
      int dist, speed;
      cin >> dist >> speed;
      mxdist[i] = dist;
      conspeed[i] = speed;
    }
    for (int i = (0); i < (n); i++)
      for (int get = (0); get < (n); get++)
        cin >> matrix[i][get];
    for (int i = (0); i < (n); i++)
      fill(i);
    for (int i = (0); i < (120); i++) {
      int get = (0);
      while (get < (120))
        cuqttllvck(i, get);
    }
    vector<pii> all(solve);
    int i;
    {
      i = (0);
      while (i < (solve))
        oygotmgtug(all, i);
    }
    fout << "Case #" << s + 1 << ": ";
    {
      int i = (0);
      while (i < (solve)) {
        fout << setprecision(9) << fixed
             << query(all[i].first - 1, all[i].second - 1) << " ";
        i++;
      }
    }
    fout << endl;
  }
  return 0;
}
