#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
#define db double
#define FOR(i, a, b) for(int i=(a); i<=(b); i++)
#define ROF(i, a, b) for(int i=(a); i>=(b); i--)
#define SZ(a) int((a).size())
#define ms(a, b) memset(a, b, sizeof(a))
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define eb emplace_back
typedef pair<int, int> pii;
typedef vector<int> vi;

const db eps = 1e-9;

int T, N, Q;
db E[105], S[105], d[105][105], d2[105][105];

db dist(db s, db e) {return e / s;}
db adj(db x) {return (x < eps) ? 0 : x;}

void floyd() {
    FOR(k, 1, N) FOR(i, 1, N) FOR(j, 1, N)
        if(d[i][k] != -1 && d[k][j] != -1)
            d[i][j] = (d[i][j] == -1) ? (d[i][k] + d[k][j]) : min(d[i][j], d[i][k] + d[k][j]);
}

int main() {
    ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cin >> T;
    FOR(Ti, 1, T) {
        cin >> N >> Q;
        FOR(i, 1, N) cin >> E[i] >> S[i];
        FOR(i, 1, N) FOR(j, 1, N) cin >> d[i][j];
        floyd();
        cout << "Case #" << Ti << ": ";
        while(Q--) {
            int u, v; cin >> u >> v;
            FOR(i, 1, N) FOR(j, 1, N) d2[i][j] = d[i][j] * ((E[i] >= d[i][j]) ? 1 : -1);
            FOR(k, 1, N) FOR(i, 1, N) FOR(j, 1, N)
                if(d2[i][k] != -1 && d2[k][j] != -1) {
                    db t = dist(S[k], d2[i][k]) + adj(d2[i][k] - E[k]) + dist(S[k], d2[k][j]) + adj(d2[k][j] - E[k]);
                    d2[i][j] = (d2[i][j] == -1) ? t : min(d2[i][j], t);
                }
            cout << fixed << setprecision(7) << d2[u][v] << " ";
        }
        cout << endl;
    }
    return 0;
}
