#include <bits/stdc++.h>
using namespace std;

typedef long double ld;
const ld INF = 1e20;

struct cmp {
    bool operator() (const pair<int, ld>& p1, const pair<int, ld>& p2) const {
        return p1.second > p2.second;
    }
};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n, q;
        cin >> n >> q;

        vector<int> e(n), s(n);
        vector<vector<ld>> d(n, vector<ld>(n, INF));

        for (int i = 0; i < n; i++) {
            cin >> e[i] >> s[i];
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> d[i][j];
                if (d[i][j] == -1) {
                    d[i][j] = INF;
                }
            }
        }

        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                }
            }
        }

        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int u, v;
            cin >> u >> v;
            u--, v--;

            priority_queue<pair<int, ld>, vector<pair<int, ld>>, cmp> pq;
            vector<ld> dist(n, INF);
            pq.push(make_pair(u, 0.0));
            dist[u] = 0.0;

            while (!pq.empty()) {
                int city = pq.top().first;
                ld time = pq.top().second;
                pq.pop();

                if (city == v) {
                    cout << " " << fixed << setprecision(9) << time;
                    break;
                }

                if (time > dist[city]) {
                    continue;
                }

                ld ride_time = d[city][v] / (ld) s[city];
                if (time + ride_time <= dist[v]) {
                    dist[v] = time + ride_time;
                }

                for (int neighbor = 0; neighbor < n; neighbor++) {
                    if (city == neighbor || d[city][neighbor] > e[city]) {
                        continue;
                    }

                    ld switch_time = d[city][neighbor] / (ld) s[city];
                    if (time + switch_time < dist[neighbor]) {
                        dist[neighbor] = time + switch_time;
                        pq.push(make_pair(neighbor, dist[neighbor]));
                    }
                }
            }
        }

        cout << endl;
    }

    return 0;
}
