#include <bits/stdc++.h>
using namespace std;

const int MAXN = 105;
const double INF = 1e18;

int n, q;
int e[MAXN], s[MAXN];
double d[MAXN][MAXN];
double dist[MAXN][MAXN];

void floyd_warshall() {
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (d[i][k] >= 0 && d[k][j] >= 0) {
                    double nd = d[i][k] + d[k][j];
                    if (d[i][j] < 0 || nd < d[i][j]) {
                        d[i][j] = nd;
                    }
                }
            }
        }
    }
}

void solve(int tc) {
    cin >> n >> q;
    for (int i = 1; i <= n; i++) {
        cin >> e[i] >> s[i];
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> dist[i][j];
            if (dist[i][j] < 0) {
                d[i][j] = -1;
            } else {
                d[i][j] = dist[i][j] / s[i];
            }
        }
    }
    floyd_warshall();
    cout << "Case #" << tc << ":";
    for (int i = 1; i <= q; i++) {
        int u, v;
        cin >> u >> v;
        double ans = d[u][v];
        for (int j = 1; j <= n; j++) {
            if (j != u && j != v && d[u][j] >= 0 && d[j][v] >= 0) {
                double t = d[u][j] + d[j][v];
                double r = min((double)e[j], t * s[j]);
                ans = min(ans, t + (d[u][j] - r) / s[u] + (d[j][v] - (t - r)) / s[j]);
            }
        }
        cout << " " << fixed << setprecision(7) << ans;
    }
    cout << "\n";
}

int main() {
    int t;
    cin >> t;
    for (int tc = 1; tc <= t; tc++) {
        solve(tc);
    }
    return 0;
}
