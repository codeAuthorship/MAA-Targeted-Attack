#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

const double INF = 1e18;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;
        vector<double> E(N), S(N);
        vector<vector<double>> D(N, vector<double>(N));
        for (int i = 0; i < N; i++) {
            cin >> E[i] >> S[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cin >> D[i][j];
            }
        }
        cout << "Case #" << t << ": ";
        for (int q = 0; q < Q; q++) {
            int U, V;
            cin >> U >> V;
            U--, V--;
            vector<double> dist(N, INF);
            priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
            dist[U] = 0;
            pq.push({0, U});
            while (!pq.empty()) {
                int u = pq.top().second;
                double d = pq.top().first;
                pq.pop();
                if (d > dist[u]) continue;
                for (int v = 0; v < N; v++) {
                    if (D[u][v] == -1) continue;
                    double t = D[u][v] / S[u];
                    double e = min(D[u][v], E[u]);
                    if (dist[u] + t < dist[v] && e >= D[u][v]) {
                        dist[v] = dist[u] + t;
                        pq.push({dist[v], v});
                    }
                }
            }
            cout << fixed << setprecision(8) << dist[V] << " ";
        }
        cout << endl;
    }
    return 0;
}
