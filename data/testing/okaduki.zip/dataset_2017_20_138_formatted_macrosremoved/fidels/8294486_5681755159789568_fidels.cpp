#include <bits/stdc++.h>
using namespace std;

const double INF = 1e18;

int main() {
    int t; cin >> t;
    for (int ca = 1; ca <= t; ++ca) {
        int n, q; cin >> n >> q;
        vector<double> e(n), s(n);
        vector<vector<double>> d(n, vector<double>(n));
        for (int i = 0; i < n; ++i) {
            cin >> e[i] >> s[i];
            for (int j = 0; j < n; ++j) {
                cin >> d[i][j];
                if (d[i][j] == -1) d[i][j] = INF;
            }
        }
        for (int k = 0; k < n; ++k) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                }
            }
        }
        cout << "Case #" << ca << ":";
        for (int i = 0; i < q; ++i) {
            int u, v; cin >> u >> v; --u, --v;
            vector<vector<double>> dist(n, vector<double>(n, INF));
            for (int i = 0; i < n; ++i) {
                if (e[i] >= d[u][i]) {
                    dist[i][i] = d[u][i] / s[i];
                }
            }
            for (int k = 0; k < n; ++k) {
                for (int i = 0; i < n; ++i) {
                    for (int j = 0; j < n; ++j) {
                        if (dist[i][k] < INF && e[j] >= d[k][j] && d[i][j] <= e[k] - d[u][k]) {
                            dist[i][j] = min(dist[i][j], dist[i][k] + d[k][j] / s[j]);
                        }
                    }
                }
            }
            double ans = INF;
            for (int i = 0; i < n; ++i) {
                if (e[i] >= d[v][i]) {
                    ans = min(ans, dist[u][i] + d[i][v] / s[i]);
                }
            }
            cout << " " << fixed << setprecision(9) << ans;
        }
        cout << endl;
    }
    return 0;
}
