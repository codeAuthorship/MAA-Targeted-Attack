#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int n, q;
vector<vector<int>> adj, dist;
vector<int> e, s;

void dijkstra(int src) {
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, src});
    dist[src][src] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        for (int v = 0; v < n; v++) {
            if (adj[u][v] != -1 && dist[src][u] + adj[u][v] < dist[src][v]) {
                dist[src][v] = dist[src][u] + adj[u][v];
                pq.push({dist[src][v], v});
            }
        }
    }
}

int main() {
    int t;
    cin >> t;

    for (int caseno = 1; caseno <= t; caseno++) {
        cin >> n >> q;

        e.assign(n, 0);
        s.assign(n, 0);
        adj.assign(n, vector<int>(n, -1));
        dist.assign(n, vector<int>(n, INF));

        for (int i = 0; i < n; i++) {
            cin >> e[i] >> s[i];
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> adj[i][j];
            }
        }

        for (int i = 0; i < n; i++) {
            dijkstra(i);
        }

        cout << "Case #" << caseno << ":";

        while (q--) {
            int u, v;
            cin >> u >> v;
            u--; v--;

            double ans = (double)dist[u][v] / s[u]; 
            double remaining_distance = e[u] - dist[u][v];

            if (remaining_distance < 0) {
                continue;
            }

            if (remaining_distance >= dist[u][v]) {
                cout << " " << fixed << setprecision(7) << ans;
                continue;
            }

            double time_with_switch = (double)remaining_distance / s[u] + (double)dist[u][v] / s[v];
            double time_without_switch = (double)dist[u][v] / s[u];

            if (time_with_switch < time_without_switch && remaining_distance >= 0) {
                ans += (double)remaining_distance / s[u] + (double)dist[u][v] / s[v];
            } else {
                ans += (double)dist[u][v] / s[u];
            }

            cout << " " << fixed << setprecision(7) << ans;
        }

        cout << endl;
    }

    return 0;
}
