#include <bits/stdc++.h>
using namespace std;

typedef pair<double, int> pdi;
const double INF = 1e18;

vector<vector<int>> d;
vector<vector<double>> t;
vector<pair<double, double>> horses;
vector<vector<pdi>> adj;

void dijkstra(int s, vector<double>& dist) {
    dist.assign(adj.size(), INF);
    dist[s] = 0;
    priority_queue<pdi, vector<pdi>, greater<pdi>> pq;
    pq.emplace(0, s);
    while (!pq.empty()) {
        int u = pq.top().second;
        double d_u = pq.top().first;
        pq.pop();
        if (d_u > dist[u]) continue;
        for (auto& [v, w] : adj[u]) {
            double t_u_v = (d[u][v] == -1 ? INF : d[u][v] / horses[u].second);
            double new_dist = dist[u] + t_u_v + w / horses[u].second;
            if (new_dist < dist[v]) {
                dist[v] = new_dist;
                pq.emplace(new_dist, v);
            }
        }
    }
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, q;
        cin >> n >> q;
        horses.resize(n);
        for (int i = 0; i < n; ++i) {
            cin >> horses[i].first >> horses[i].second;
        }
        d.assign(n, vector<int>(n));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cin >> d[i][j];
            }
        }
        adj.assign(2 * n, vector<pdi>());
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (i == j) continue;
                double t_i_j = (d[i][j] == -1 ? INF : d[i][j] / horses[i].second);
                adj[i].emplace_back(j + n, t_i_j);
                adj[j + n].emplace_back(i, t_i_j);
            }
        }
        for (int i = 0; i < n; ++i) {
            double t_i_2n = horses[i].first / horses[i].second;
            adj[i].emplace_back(i + n, t_i_2n);
        }
        vector<double> dist;
        cout << "Case #" << case_num << ":";
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            --u, --v;
            dijkstra(u, dist);
            cout << " " << fixed << setprecision(9) << dist[v + n];
        }
        cout << endl;
    }
    return 0;
}
