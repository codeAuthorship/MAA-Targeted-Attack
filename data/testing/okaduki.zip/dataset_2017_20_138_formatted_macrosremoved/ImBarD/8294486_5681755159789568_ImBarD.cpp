#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-9;
const double INF = 1e9;

struct City {
    double max_distance;
    double speed;
};

struct Edge {
    int dest;
    double dist;
};

struct State {
    int city;
    double time;
    bool operator<(const State& other) const {
        return time > other.time;
    }
};

double dijkstra(int start, int end, const vector<City>& cities, const vector<vector<Edge>>& graph) {
    int n = cities.size();
    vector<double> dist(n, INF);
    priority_queue<State> pq;
    pq.push({start, 0});
    dist[start] = 0;
    while (!pq.empty()) {
        State state = pq.top();
        pq.pop();
        int city = state.city;
        double time = state.time;
        if (city == end) {
            return time;
        }
        if (dist[city] + EPSILON < time) {
            continue;
        }
        for (const Edge& edge : graph[city]) {
            int dest = edge.dest;
            double dist = edge.dist;
            double speed = cities[city].speed;
            double max_distance = cities[city].max_distance;
            double travel_time;
            if (dist > max_distance) {
                continue;
            }
            if (dist + EPSILON >= max_distance) {
                travel_time = max_distance / speed;
            } else {
                double remaining_distance = max_distance - dist;
                double remaining_time = remaining_distance / speed;
                double new_speed = min(speed, cities[dest].speed);
                travel_time = dist / speed + remaining_distance / new_speed + remaining_time;
            }
            if (dist[dest] + EPSILON > time + travel_time) {
                dist[dest] = time + travel_time;
                pq.push({dest, dist[dest]});
            }
        }
    }
    return -1;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, q;
        cin >> n >> q;
        vector<City> cities(n);
        for (int j = 0; j < n; j++) {
            cin >> cities[j].max_distance >> cities[j].speed;
        }
        vector<vector<Edge>> graph(n, vector<Edge>(n));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                int dist;
                cin >> dist;
                if (dist != -1) {
                    graph[j][k] = {k, dist};
                }
            }
        }
        cout << "Case #" << i << ":";
        for (int j = 0; j < q; j++) {
            int start, end;
            cin >> start >> end;
            double time = dijkstra(start - 1, end - 1, cities, graph);
            cout << " " << fixed << setprecision(7) << time;
        }
        cout << endl;
    }
    return 0;
}
