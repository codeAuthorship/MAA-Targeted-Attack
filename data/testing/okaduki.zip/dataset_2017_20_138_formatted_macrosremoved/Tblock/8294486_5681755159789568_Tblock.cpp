#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <cmath>
#include <limits>

using namespace std;

const double INF = numeric_limits<double>::max();

struct City {
    double max_distance;
    double speed;
};

struct Edge {
    int to;
    double distance;
};

struct State {
    int city;
    double time;

    bool operator>(const State& other) const {
        return time > other.time;
    }
};

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, q;
        cin >> n >> q;

        vector<City> cities(n);
        vector<vector<Edge>> adj(n);

        for (int j = 0; j < n; j++) {
            double max_distance, speed;
            cin >> max_distance >> speed;

            cities[j] = {max_distance, speed};
        }

        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                double distance;
                cin >> distance;

                if (distance != -1) {
                    adj[j].push_back({k, distance});
                }
            }
        }

        cout << "Case #" << i << ":";

        for (int j = 0; j < q; j++) {
            int u, v;
            cin >> u >> v;
            u--, v--;

            priority_queue<State, vector<State>, greater<State>> pq;
            vector<vector<double>> best_time(n, vector<double>(n, INF));

            for (const auto& edge : adj[u]) {
                if (edge.distance > cities[u].max_distance) {
                    continue;
                }
                double time = edge.distance / cities[u].speed;
                best_time[edge.to][u] = time;
                pq.push({edge.to, time});
            }

            while (!pq.empty()) {
                State current = pq.top();
                pq.pop();

                if (current.time > best_time[current.city][v]) {
                    continue;
                }

                for (const auto& edge : adj[current.city]) {
                    if (edge.distance > cities[edge.to].max_distance) {
                        continue;
                    }
                    double time = current.time + edge.distance / cities[edge.to].speed;
                    if (time < best_time[edge.to][v]) {
                        best_time[edge.to][v] = time;
                        pq.push({edge.to, time});
                    }
                }
            }

            double result = best_time[v][u];
            cout << " " << fixed << setprecision(9) << result;
        }

        cout << endl;
    }

    return 0;
}
