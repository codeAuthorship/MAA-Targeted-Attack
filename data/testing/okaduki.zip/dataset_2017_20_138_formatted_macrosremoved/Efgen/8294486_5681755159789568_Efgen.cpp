#include <bits/stdc++.h>
using namespace std;
const double eps = 1e-9;
const int MOD = 1000000007;
typedef double td_d;

const double EPS = 1e-9;
const int INF = 1000000000;

ifstream T("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/okaduki/sammyMaX/A-small-practice.in");
ofstream c("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/okaduki/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

const int SZ = 105;

int n, v;
long long cost[SZ];
long long hspeed[SZ], hrange[SZ];

inline void poigrqsxeo(int &N, double dprange[105], td_d &mindp,
                       double dp[105]) {
  int j = 0;
  while (j < N) {
    if (dprange[j] >= cost[N - 1])
      dp[j] += 1.0 * cost[N - 1] / hspeed[j], dprange[j] -= cost[N - 1];
    else
      dp[j] = 1e15, dprange[j] = 0;
    mindp = min(mindp, dp[j]);
    j++;
  }
}

void d() {
  T >> n >> v;
  for (int N = 0; N < n; N++)
    T >> hrange[N] >> hspeed[N];
  int N;
  for (N = 0; N < n; N++)
    for (int j = 0; j < n; j++) {
      int tmp;
      T >> tmp;
      if (j == N + 1)
        cost[N] = tmp;
    }
  for (int N = 0; N < v; N++) {
    int a, b;
    T >> a >> b;
  }
  double dp[SZ] = {}, dprange[SZ] = {};
  dprange[0] = hrange[0];
  for (int N = 1; N < n; N++) {
    td_d mindp = 1e15;
    poigrqsxeo(N, dprange, mindp, dp);
    dp[N] = mindp, dprange[N] = hrange[N];
  }
  c << dp[n - 1] << '\n';
  cout << dp[n - 1] << '\n';
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  c << fixed << setprecision(12);
  int get;
  T >> get;
  for (int N = 0; N < get; N++)
    c << "Case #" << N + 1 << ": ", d();
  return 0;
}
