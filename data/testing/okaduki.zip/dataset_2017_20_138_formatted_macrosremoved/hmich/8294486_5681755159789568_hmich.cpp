#include <bits/stdc++.h>
#define ll long long
#define ld long double
#define pii pair<int,int>
#define pld pair<ld, int>
#define mp make_pair
#define MAXN 100005
using namespace std;

const ld EPS = 1e-9;
const ld INF = 1e18;

ld e[MAXN], s[MAXN];
ld d[MAXN][MAXN];

ld dijkstra(int n, int u, int v) {
    priority_queue<pld, vector<pld>, greater<pld>> q;
    vector<ld> dist(n+1, INF);
    vector<bool> vis(n+1, false);
    dist[u] = 0;
    q.push(mp(0, u));
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = true;
        for (int v = 1; v <= n; v++) {
            if (d[u][v] == -1) continue;
            ld w = d[u][v] / s[u];
            if (e[u] < w) continue;
            ld t = w;
            if (dist[u] > EPS) t += dist[u];
            if (dist[v] > t + EPS) {
                dist[v] = t;
                q.push(mp(dist[v], v));
            }
        }
    }
    return dist[v];
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n, q;
        cin >> n >> q;
        for (int i = 1; i <= n; i++) {
            cin >> e[i] >> s[i];
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                cin >> d[i][j];
            }
        }
        cout << "Case #" << t << ": ";
        for (int i = 0; i < q; i++) {
            int u, v;
            cin >> u >> v;
            ld ans = dijkstra(n, u, v);
            cout << fixed << setprecision(7) << ans << " ";
        }
        cout << endl;
    }
    return 0;
}
