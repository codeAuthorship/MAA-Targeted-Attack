#include <bits/stdc++.h>
using namespace std;

const double INF = 1e18;

double dijkstra(const vector<vector<int>>& graph, const vector<int>& E, const vector<int>& S, int start, int end) {
    int n = graph.size();
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    vector<double> dist(n, INF);
    pq.emplace(0, start);
    dist[start] = 0;
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (u == end) {
            return d;
        }
        for (int v = 0; v < n; ++v) {
            if (graph[u][v] != -1) {
                double t = 1.0 * graph[u][v] / S[u];
                if (dist[u] + t < dist[v] && 1.0 * graph[u][v] <= E[u]) { 
                    dist[v] = dist[u] + t;
                    pq.emplace(dist[v], v);
                }
            }
        }
    }
    return -1;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        int n, q;
        cin >> n >> q;
        vector<int> E(n), S(n);
        for (int j = 0; j < n; ++j) {
            cin >> E[j] >> S[j];
        }
        vector<vector<int>> graph(n, vector<int>(n));
        for (int j = 0; j < n; ++j) {
            for (int k = 0; k < n; ++k) {
                cin >> graph[j][k];
            }
        }
        cout << "Case #" << i << ": ";
        for (int j = 0; j < q; ++j) {
            int u, v;
            cin >> u >> v;
            double ans = dijkstra(graph, E, S, u - 1, v - 1);
            cout << fixed << setprecision(9) << ans << " ";
        }
        cout << endl;
    }
    return 0;
}
