#include <bits/stdc++.h>
using namespace std;

typedef long double ld;
const ld INF = 1e30;

struct Horse {
    int max_dist, speed;
    ld time_to_next_city;
};

vector<Horse> horses;
vector<vector<int>> dist;
vector<vector<ld>> memo;

ld solve(int u, int v) {
    if (u == v) return 0;
    if (memo[u][v] >= 0) return memo[u][v];

    ld ans = INF;
    for (int w = 0; w < horses.size(); w++) {
        ld time = (ld)dist[u][v] / horses[w].speed;
        if (time > horses[w].time_to_next_city) continue;
        if (time > (ld)horses[w].max_dist / horses[w].speed) continue;
        ld time_change = (w == u ? 0 : 1) + (w == v ? 0 : 1);
        ans = min(ans, time + time_change + solve(w, v));
    }

    return memo[u][v] = ans;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;

        horses.resize(N);
        for (int i = 0; i < N; i++) {
            cin >> horses[i].max_dist >> horses[i].speed;
            horses[i].time_to_next_city = (ld)horses[i].max_dist / horses[i].speed;
        }

        dist.resize(N, vector<int>(N));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cin >> dist[i][j];
            }
        }

        memo.assign(N, vector<ld>(N, -1));
        for (int i = 0; i < Q; i++) {
            int u, v;
            cin >> u >> v;
            u--, v--;
            cout << fixed << setprecision(9) << "Case #" << t << ": " << solve(u, v) << endl;
        }
    }

    return 0;
}
