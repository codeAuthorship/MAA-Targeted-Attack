#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;

typedef set<int> si;

typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<string> vs;

typedef long long LL;            
typedef unsigned long long ull;  
typedef unsigned uint;

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char colors[] = {'R', 'O', 'Y', 'G', 'B', 'V'};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

double besttime[1010];
LL c[110], d[110], dist[110][110], a[110], b[110], dd[110];
long double best[110][110];
inline void bhgtewtuai(int &i, int &j) {
  best[i][j] = besttime[j] + ((dd[i] - dd[j]) * 1.0) / d[j];
}

int main() {
  ios::sync_with_stdio(true);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_16_Usenix_RF_1.0_True_MCTS_Classic_True/okaduki/lazyBit/A-small-practice.in",
          "r", stdin);
  ;
 

  long long n, ans, l, y, t, s = 0, p, q;
  int i, j;
  cin >> t;
  int ct = 1;
  for (; t--;) {
    cin >> n;
    ;
    cin >> q;
    ;
    for (i = 0; i < n; i++) {
      cin >> c[i];
      ;
      cin >> d[i];
      ;
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) {
        cin >> dist[i][j];
        ;
      }
    }
    for (i = 0; i < q; i++) {
      cin >> a[i];
      ;
      cin >> b[i];
      ;
    }
    dd[0] = 0;
    for (i = 1; i < n; i++) {
      dd[i] = dd[i - 1] + dist[i - 1][i];
    }
    besttime[0] = 0.0;
    long double r;
    for (i = 1; i < n; i++) {
      r = 1e18;
      for (j = 0; j < i; j++) {
        if (dd[i] - dd[j] <= c[j])
          bhgtewtuai(i, j);
        else {
          best[i][j] = 1e18;
        }
        r = min(r, best[i][j]);
      }
      besttime[i] = r;
    }
 
    printf("Case #%d: %0.6lf\n", ct++, besttime[n - 1]);
  }
  return (0);
}
