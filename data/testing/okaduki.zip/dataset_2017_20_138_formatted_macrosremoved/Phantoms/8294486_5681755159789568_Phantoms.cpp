#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

#define MAXN 110
#define INF 1e18

typedef long long ll;
typedef pair<double, int> pdi;

int T, N, Q, E[MAXN], S[MAXN];
ll D[MAXN][MAXN];
double dist[MAXN];

void dijkstra(int start) {
    priority_queue<pdi, vector<pdi>, greater<pdi>> pq;
    for (int i = 1; i <= N; i++) {
        dist[i] = INF;
    }
    dist[start] = 0.0;
    pq.push({0.0, start});
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[u]) continue;
        for (int v = 1; v <= N; v++) {
            if (D[u][v] != -1) {
                double t = (double) D[u][v] / S[u];
                double x = dist[u] + t;
                if (x < dist[v]) {
                    if (E[v] >= D[u][v]) {
                        dist[v] = x;
                        pq.push({dist[v], v});
                    } else {
                        double y = x + ((double) D[u][v] - E[v]) / (2.0 * E[v] - D[u][v]) * t;
                        if (y < dist[v]) {
                            dist[v] = y;
                            pq.push({dist[v], v});
                        }
                    }
                }
            }
        }
    }
}

int main() {
    scanf("%d", &T);
    for (int t = 1; t <= T; t++) {
        scanf("%d %d", &N, &Q);
        for (int i = 1; i <= N; i++) {
            scanf("%d %d", &E[i], &S[i]);
        }
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= N; j++) {
                scanf("%lld", &D[i][j]);
            }
        }
        printf("Case #%d: ", t);
        for (int i = 0; i < Q; i++) {
            int u, v;
            scanf("%d %d", &u, &v);
            dijkstra(u);
            printf("%.8f", dist[v]);
            if (i == Q-1) {
                printf("\n");
            } else {
                printf(" ");
            }
        }
    }
    return 0;
}
