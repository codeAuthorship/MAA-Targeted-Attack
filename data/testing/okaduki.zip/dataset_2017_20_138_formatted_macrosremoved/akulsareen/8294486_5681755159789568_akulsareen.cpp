#include <bits/stdc++.h>
using namespace std;
typedef long double ld;
const int MAXN = 105;

ld e[MAXN], s[MAXN], d[MAXN][MAXN];

int main() {
   int T;
   cin >> T;
   for (int t = 1; t <= T; t++) {
       int n, q;
       cin >> n >> q;
       for (int i = 1; i <= n; i++) {
           cin >> e[i] >> s[i];
       }
       for (int i = 1; i <= n; i++) {
           for (int j = 1; j <= n; j++) {
               cin >> d[i][j];
           }
       }
       cout << "Case #" << t << ":";
       while (q--) {
           int u, v;
           cin >> u >> v;
           ld ans = d[u][v] / s[u];
           for (int i = 1; i <= n; i++) {
               for (int j = 1; j <= n; j++) {
                   if (d[i][j] != -1 && i != j) {
                       ld t1 = d[u][i] / s[u];
                       ld t2 = 0;
                       if (d[u][i] <= e[u]) {
                           t2 = d[i][j] / s[i];
                       }
                       if (t1 + t2 <= ans && d[j][v] != -1) {
                           ans = t1 + t2 + d[j][v] / s[j];
                       }
                   }
               }
           }
           cout << " " << fixed << setprecision(10) << ans;
       }
       cout << endl;
   }
   return 0;
}
