#include <iostream>
#include <string>
using namespace std;

bool is_tidy(string n) {
    for (int i = 0; i < n.length() - 1; i++) {
        if (n[i] > n[i+1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string n) {
    for (int i = n.length() - 1; i > 0; i--) {
        if (n[i] < n[i-1]) {
            n[i-1]--;
            for (int j = i; j < n.length(); j++) {
                n[j] = '9';
            }
        }
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = make_tidy(n);
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
