#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int t) {
  string s = to_string(t);
  vi k;
  for (int i = (0); i < (s.size()); i++) {
    char m = s[i];
    k.push_back(m - '0');
  }
  vi ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i])
      return false;
  return true;
}

int main() {
  int ret_val = 0;

  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/4yn/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int m;
    cin >> m;
    for (int t = m; t >= 0; t--) {
      if (check(t)) {
        fout << "Case #" << i + 1 << ": " << t << endl;
        break;
      }
    }
  }
  return ret_val;
}
