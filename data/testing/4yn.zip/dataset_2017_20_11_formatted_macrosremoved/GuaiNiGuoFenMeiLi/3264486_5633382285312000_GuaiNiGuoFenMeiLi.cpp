#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>
#include <utility>
#include <vector>
using namespace std;
typedef pair<int, int> pii;
typedef double dbl;

int main() {
  int ret_val = 0;
  int tt;
  cin >> tt;
  for (int t = 1; t <= tt; ++t) {
    long long m;
    vector<int> v;
    cin >> m;

    while (m > 0) {
      v.push_back(m % 10);
      m = m / 10;
    }
    int ind = v.size() - 1;
    while (ind > 0 && (v[ind] <= v[ind - 1]))
      ind--;
    if (ind != 0) {
      v[ind]--;
      while (ind + 1 < v.size() && v[ind + 1] == v[ind] + 1) {
        v[ind]++;
        v[++ind]--;
      }
      while (ind > 0)
        v[--ind] = 9;
    }

    for (int i = v.size() - 1; i >= 0; --i)
      m = m * 10 + v[i];

    cout << "Case #" << t << ": " << m << endl;
  }
  return ret_val;
}
