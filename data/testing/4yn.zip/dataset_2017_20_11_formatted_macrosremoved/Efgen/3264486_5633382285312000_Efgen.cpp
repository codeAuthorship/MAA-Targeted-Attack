#include <bits/stdc++.h>
#include <utility>
using namespace std;

typedef double dbl;

ifstream hkds_Var("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/4yn/sammyMaX/A-small-practice.in");
ofstream tc("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/4yn/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

string solves(string m, char prev) {
  if (m.size() == 0) {
    return "";
  }
  char minc = '9';
  for (char n : m)
    minc = min(minc, n);
  if (m[0] > minc) {
    if (m.size() > 1 && m[1] > m[0]) {
      return m[0] + solves(m.substr(1), m[0]);
    } else {
      string res = "";
      if (m[0] > minc) {
        if (m[0] > '1')
          res += (char)(m[0] - 1);
      }

      for (int i = 1; i < m.size(); i++)
        res += '9';
      return res;
    }
  }
  return minc + solves(m.substr(1), minc);
}

void do_voicxf_fct() {
  string m;
  hkds_Var >> m;
  tc << solves(m, '0') << '\n';
}

inline void qixxpqkohe(int &i) {
  tc << "Case #" << i + 1 << ": ", do_voicxf_fct();
  i++;
}

inline void ixeboyhtry(int &t) {
  int i = 0;
  while (i < t)
    qixxpqkohe(i);
}

int main() {
  int t;
  hkds_Var >> t;
  ixeboyhtry(t);
}
