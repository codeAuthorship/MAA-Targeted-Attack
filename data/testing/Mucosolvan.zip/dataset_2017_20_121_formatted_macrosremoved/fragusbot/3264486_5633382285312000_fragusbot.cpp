#include <iostream>
#include <string>

using namespace std;

long long largestTidyNumber(long long N) {
    string s = to_string(N);

    int index = s.length();
    for (int i = s.length() - 1; i >= 1; i--) {
        if (s[i] < s[i-1]) {
            index = i;
            s[i-1]--; 
        }
    }

    for (int i = index; i < s.length(); i++) {
        s[i] = '9';
    }

    return stoll(s);
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;

        long long result = largestTidyNumber(N);

        cout << "Case #" << i << ": " << result << endl;
    }

    return 0;
}
