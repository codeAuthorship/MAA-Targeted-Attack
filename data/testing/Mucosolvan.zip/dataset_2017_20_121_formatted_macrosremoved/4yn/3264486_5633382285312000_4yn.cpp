#include <bits/stdc++.h>
#include <iostream>
using namespace std;

typedef pair<int, int> ii;

typedef vector<ii> vii;
typedef long long ll;

bool check(int a) {
  string s = to_string(a);
  vector<int> k;
  for (int i = (0); i < (s.size()); i++) {
    char solve = s[i];
    k.push_back(solve - '0');
  }
  vector<int> ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i])
      return false;
  return true;
}

int main() {
  cin.sync_with_stdio(false);

  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int solve;
    cin >> solve;
    for (int a = solve; a >= 0; a--) {
      if (check(a)) {
        cout << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return 0;
}
