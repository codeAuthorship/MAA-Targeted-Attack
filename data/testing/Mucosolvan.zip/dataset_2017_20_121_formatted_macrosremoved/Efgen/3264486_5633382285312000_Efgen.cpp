#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef long double LD;

ifstream v("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/Mucosolvan/sammyMaX/A-small-practice.in");

string solves(string get, char prev) {
  if (get.size() == 0)
    return "";
  char minc = '9';
  for (char c : get)
    minc = min(minc, c);
  if (get[0] > minc) {
    if (get.size() > 1 && get[1] > get[0])
      return get[0] + solves(get.substr(1), get[0]);
    else {
      string x = "";
      if (get[0] > minc)
        if (get[0] > '1')
          x += (char)(get[0] - 1);
      for (int i = 1; i < get.size(); i++)
        x += '9';
      return x;
    }
  }
  return minc + solves(get.substr(1), minc);
}

void solve() {
  string get;
  v >> get;
  cout << solves(get, '0') << '\n';
}

int main() {
  ios::sync_with_stdio(false);

  int t;
  v >> t;
  for (int i = 0; i < t; i++)
    cout << "Case #" << i + 1 << ": ", solve();
  return 0;
}
