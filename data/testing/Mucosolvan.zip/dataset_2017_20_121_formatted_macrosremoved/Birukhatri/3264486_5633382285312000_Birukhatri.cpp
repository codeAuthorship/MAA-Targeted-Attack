#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef long double ld;
typedef long double LD;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;

typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long ll;           // NOTES:int64
typedef unsigned long long ull; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

char ans[50];

bool containszero(int l) {
  int i = 0;
  while (ans[i] == '0') {
    i++;
  }
  while (i < l) {
    if (ans[i] == '0')
      return 1;
    i++;
  }
  return false;
}
int main() {
  ios::sync_with_stdio(1);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, k, l, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> ans;
    bool p = 0;
    l = strlen(ans);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (ans[i] < ans[i - 1]) {
          for (j = i; j < l; j++)
            ans[j] = '9';
          ans[i - 1] = (char)(ans[i - 1] - 1);
        }
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (ans[i] == '0') {
          for (j = i; j < l; j++)
            ans[j] = '9';
          ans[i - 1] = (char)(ans[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (ans[i] < ans[i - 1]) {
            for (j = i; j < l; j++)
              ans[j] = '9';

            ans[i - 1] = (char)(ans[i - 1] - 1);
          }
        }
      }
    }
    cout << "Case #" << c++ << ": ";
    i = 0;
    while (ans[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      cout << ans[i++];
    }
    cout << "\n";
  }
  return (0);
}
