#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long num) {
    string str = to_string(num);
    for (int i = 0; i < str.length() - 1; i++) {
        if (str[i] > str[i+1]) {
            return false;
        }
    }
    return true;
}

long long lastTidy(long long n) {
    if (isTidy(n)) {
        return n;
    }
    string str = to_string(n);
    int i;
    for (i = str.length() - 1; i > 0; i--) {
        if (str[i] < str[i-1]) {
            break;
        }
    }
    long long result = stoll(str.substr(0, i)) - 1;
    for (int j = i; j < str.length(); j++) {
        result = result * 10 + 9;
    }
    return lastTidy(result);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long result = lastTidy(N);
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
