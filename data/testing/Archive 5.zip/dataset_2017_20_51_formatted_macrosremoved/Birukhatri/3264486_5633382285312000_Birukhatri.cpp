#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           // NOTES:int64
typedef unsigned long long ULL; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void debugarr(int *arr, int n) {
  cout << "[";
  int i;
  for (i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

char N[50];

bool containszero(int r) {
  int i = 0;
  while (N[i] == '0') {
    i++;
  }
  while (i < r) {
    if (N[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void kqngvekphd(int &r, int &j, int &i) {
  if (N[i] < N[i - 1]) {
    for (j = i; j < r; j++)
      N[j] = '9';
    N[i - 1] = (char)(N[i - 1] - 1);
  }
}

inline void rkatagpaio(int &r, int &j, int &i) {
  for (i = r - 1; i > 0; i--)
    kqngvekphd(r, j, i);
}

int main() {
  ios::sync_with_stdio(true);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, k, r, tc, t, s = 0, d;
  scanf("%d", &t);
  ;
  int c = 1;
  while (t--) {
    scanf("%s ", N);
    bool p = false;
    r = strlen(N);
    if (!containszero(r))
      rkatagpaio(r, j, i);
    while (containszero(r)) {
      for (i = 0; i < r; i++) {
        if (N[i] == '0') {
          for (j = i; j < r; j++)
            N[j] = '9';
          N[i - 1] = (char)(N[i - 1] - 1);
          break;
        }
      }
      if (!containszero(r)) {
        for (i = r - 1; i > 0; i--) {
          if (N[i] < N[i - 1]) {
            for (j = i; j < r; j++) {
              N[j] = '9';
            }
            N[i - 1] = (char)(N[i - 1] - 1);
          }
        }
      }
    }
    cout << "Case #" << c++ << ": ";
    i = 0;
    while (N[i] == '0') {
      i++;
      continue;
    }
    while (i < r) {
      cout << N[i++];
    }
    cout << "\n";
  }
  return (0);
}
