#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

inline void ojjcvbsrsc(std::string &s, int &i, vi &k) {
  char t = s[i];
  k.push_back(t - '0');
}

bool check(int a) {
  string s = to_string(a);
  vi k;
  for (int i = (0); i < (s.size()); i++)
    ojjcvbsrsc(s, i, k);
  vi ne = k;
  sort(ne.begin(), ne.end());
  {
    int i = (0);
    while (i < (k.size())) {
      if (k[i] != ne[i])
        return false;
      i++;
    }
  }
  return true;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/gultai4ukr/bennikartefla/A-small-practice.in");

  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/gultai4ukr/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int n;
  fin >> n;
  for (int i = (0); i < (n); i++) {
    int t;
    fin >> t;
    for (int a = t; a >= 0; a--) {
      if (check(a)) {
        fout << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return 0;
}
