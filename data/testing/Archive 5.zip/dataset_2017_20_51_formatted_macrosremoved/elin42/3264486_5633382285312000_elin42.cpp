#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

bool is_tidy(ll n) {
    ll prev_digit = n % 10;
    n /= 10;
    while (n > 0) {
        ll curr_digit = n % 10;
        if (curr_digit > prev_digit) {
            return false;
        }
        prev_digit = curr_digit;
        n /= 10;
    }
    return true;
}

ll solve(ll n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        ll n;
        cin >> n;
        ll ans = solve(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
