#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
#include <utility>
#include <vector>
using namespace std;
typedef pair<int, int> ii;
typedef long long ll;
typedef vector<int> vi;

ifstream fin("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/ccsnoopy/sammyMaX/A-small-practice.in");

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      string res = "";
      if (s[0] > minc && s[0] > '1')
        res += (char)(s[0] - 1);
      for (int i = 1; i < s.size(); i++)
        res += '9';
      return res;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void open() {
  string s;
  fin >> s;
  printf("%s\n", solves(s, '0').c_str());
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/ccsnoopy/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);
  int ct;
  fin >> ct;
  for (int i = 0; i < ct; i++)
    printf("Case #%d: ", i + 1), open();
  return 0;
}
