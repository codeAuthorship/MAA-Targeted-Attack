#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long num) {
    string str = to_string(num);
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i - 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string str = to_string(n);
    int len = str.length();
    int idx = len - 1;
    while (idx > 0 && str[idx] < str[idx - 1]) {
        idx--;
    }
    long long ans = stoll(str.substr(0, idx)) * pow(10, len - idx) - 1;
    while (!is_tidy(ans)) {
        ans--;
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long n;
        cin >> n;
        long long ans = last_tidy(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
