#include <bits/stdc++.h>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long ll;            
typedef unsigned long long ULL;  
typedef unsigned uint;

 
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void open(int *arr, int n) {
  printf("[");
  for (int i = 0; i < n; i++)
    printf("%d ", arr[i]);
  printf("]\n");
}

char str[50];

bool containszero(int tc) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  while (i < tc) {
    if (str[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void eznrsxcnfd(int &tc, int &j, int &i) {
  for (j = i; j < tc; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

inline void jzrjwuyvjy(int &tc, int &j, int &i) {
  for (j = i; j < tc; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/ccsnoopy/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/ccsnoopy/lazyBit/A-small-practice.in",
          "r", stdin);

 
  int n, i, j, k, tc, m, ct, s = 0, d;
  scanf("%d", &ct);
  ;
  int c = 1;
  while (ct--) {
    scanf("%s ", str);
    bool p = 0;
    tc = strlen(str);
    if (!containszero(tc)) {
      for (i = tc - 1; i > 0; i--) {
        if (str[i] < str[i - 1])
          jzrjwuyvjy(tc, j, i);
      }
    }
    while (containszero(tc)) {
      for (i = 0; i < tc; i++) {
        if (str[i] == '0') {
          for (j = i; j < tc; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(tc)) {
        for (i = tc - 1; i > 0; i--) {
          if (str[i] < str[i - 1])
            eznrsxcnfd(tc, j, i);
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < tc) {
      printf("%c", str[i++]);
    }
    printf("\n");
  }
  return (0);
}
