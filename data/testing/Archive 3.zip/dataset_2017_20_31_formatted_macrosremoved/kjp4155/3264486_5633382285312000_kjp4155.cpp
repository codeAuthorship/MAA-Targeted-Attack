#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string str = to_string(n);
    int idx = -1;
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i-1]) {
            idx = i-1;
            break;
        }
    }
    if (idx == -1) {
        return n;
    }
    while (idx > 0 && str[idx] == str[idx-1]) {
        idx--;
    }
    str[idx]--;
    for (int i = idx+1; i < str.length(); i++) {
        str[i] = '9';
    }
    return stoll(str);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long ans = solve(n);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
