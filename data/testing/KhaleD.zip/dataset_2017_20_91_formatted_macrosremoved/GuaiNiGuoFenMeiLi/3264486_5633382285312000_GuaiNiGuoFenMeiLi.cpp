#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.size(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_tidy(long long n) {
    while (!is_tidy(n)) {
        int pos = -1;
        string s = to_string(n);
        for (int i = 1; i < s.size(); i++) {
            if (s[i] < s[i-1]) {
                pos = i-1;
                break;
            }
        }
        if (pos == -1) {
            break;
        }
        s[pos] -= 1;
        for (int i = pos+1; i < s.size(); i++) {
            s[i] = '9';
        }
        n = stoll(s);
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long answer = find_tidy(N);
        cout << "Case #" << t << ": " << answer << endl;
    }
    return 0;
}
