#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
typedef set<int> si;

typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef unsigned long long ull;
typedef vector<int> VI;
typedef long double LD;

string solves(string get, char prev) {
  if (get.size() == 0)
    return "";
  char minc = '9';
  for (char c : get)
    minc = min(minc, c);
  if (get[0] > minc) {
    if (get.size() > 1 && get[1] > get[0])
      return get[0] + solves(get.substr(1), get[0]);
    else {
      string res = "";
      if (get[0] > minc && get[0] > '1')
        res += (char)(get[0] - 1);
      for (int i = 1; i < get.size(); i++)
        res += '9';
      return res;
    }
  }
  return minc + solves(get.substr(1), minc);
}

void solve() {
  string get;
  cin >> get;
  printf("%s\n", solves(get, '0').c_str());
}

int main() {
  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/KhaleD/sammyMaX/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d ", &t);
  for (int i = 0; i < t; i++)
    printf("Case #%d: ", i + 1), solve();
}
