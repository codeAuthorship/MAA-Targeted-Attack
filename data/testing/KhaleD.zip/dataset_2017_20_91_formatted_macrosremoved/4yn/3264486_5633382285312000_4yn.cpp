#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int a) {
  string s = to_string(a);
  vi k;
  for (int i = (0); i < (s.size()); i++) {
    char b = s[i];
    k.push_back(b - '0');
  }
  vi ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i])
      return false;
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/KhaleD/bennikartefla/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;

  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/KhaleD/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int n;
  scanf("%d ", &n);
  for (int i = (0); i < (n); i++) {
    int b;
    scanf("%d ", &b);
    for (int a = b; a >= 0; a--) {
      if (check(a)) {
        fout << "Case #" << i + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return ret_val;
}
