#include <bits/stdc++.h>
#include <bitset>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef long double LD;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long ll;           
typedef unsigned long long ull; 
typedef unsigned uint;

const double pi = acos(-1.0); 
const double eps = 1e-11;     
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

char str[50];

bool containszero(int l) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  while (i < l) {
    if (str[i] == '0')
      return true;
    i++;
  }
  return false;
}
int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/KhaleD/lazyBit/A-small-practice.in", "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/KhaleD/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  ios::sync_with_stdio(true);


  int n, i, j, k, l, m, t, s = 0, d;
  scanf("%d", &t);
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    bool p = 0;
    l = strlen(str);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (str[i] < str[i - 1]) {
          for (j = i; j < l; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
        }
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (str[i] == '0') {
          for (j = i; j < l; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (str[i] < str[i - 1]) {
            for (j = i; j < l; j++)
              str[j] = '9';
            str[i - 1] = (char)(str[i - 1] - 1);
          }
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      cout << str[i++];
    }
    printf("\n");
  }
  return (0);
}
