#include<bits/stdc++.h>
using namespace std;

long long int solve(long long int n) {
    string s = to_string(n);
    int len = s.length();
    int pos = -1;
    for(int i=len-1; i>=1; i--) {
        if(s[i] < s[i-1]) {
            pos = i-1;
            s[pos] -= 1;
        }
    }
    for(int i=pos+1; i<len; i++) {
        s[i] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for(int i=1; i<=t; i++) {
        long long int n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
