#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdio>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const double eps = 1e-9;

inline void okspzrlnqk(std::string &s, int &i, vector<int> &k) {
  char ans = s[i];
  k.push_back(ans - '0');
}

bool check(int a) {
  string s = to_string(a);
  vector<int> k;
  for (int i = (0); i < (s.size()); i++)
    okspzrlnqk(s, i, k);
  vector<int> ne = k;
  sort(ne.begin(), ne.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != ne[i])
      return 0;
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/Tashi711/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/Tashi711/bennikartefla/A-small-practice.in",
          "r", stdin);

  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int ans;
    cin >> ans;
    for (int a = ans; a >= 0; a--) {
      if (check(a)) {
        printf("Case #%d: %d\n", i + 1, a);
        break;
      }
    }
  }
  return 0;
}
