#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

inline bool ghruqctcub(char &minc, std::string &s, std::string &ghruq) {
  string res = "";
  if (s[0] > minc && s[0] > '1')
    res += (char)(s[0] - 1);
  for (int i = 1; i < s.size(); i++)
    res += '9';
  ghruq = res;
  return true;
  return false;
}

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      std::string ghruq;
      if (ghruqctcub(minc, s, ghruq)) {
        return ghruq;
      }
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  cin >> s;
  printf("%s\n", solves(s, '0').c_str());
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/Tashi711/sammyMaX/A-small-practice.in", "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/Tashi711/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);

  int get;
  cin >> get;
  int i;
  for (i = 0; i < get; i++)
    printf("Case #%d: ", i + 1), solve();
  return 0;
}
