#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
const double EPS = 1e-9;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ULL; 
typedef unsigned uint;



struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void solve(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

char N[50];

bool containszero(int x) {
  int i = 0;
  while (N[i] == '0') {
    i++;
  }
  while (i < x) {
    if (N[i] == '0') {
      return 1;
    }
    i++;
  }
  return false;
}
int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/Tashi711/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  int n, i, j, q, x, a, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> N;
    bool p = 0;
    x = strlen(N);
    if (!containszero(x)) {
      for (i = x - 1; i > 0; i--) {
        if (N[i] < N[i - 1]) {
          for (j = i; j < x; j++)
            N[j] = '9';
          N[i - 1] = (char)(N[i - 1] - 1);
        }
      }
    }
    while (containszero(x)) {
      {
        i = 0;
        while (i < x) {
          if (N[i] == '0') {
            for (j = i; j < x; j++)
              N[j] = '9';
            N[i - 1] = (char)(N[i - 1] - 1);
            break;
          }
          i++;
        }
      }
      if (!containszero(x)) {
        for (i = x - 1; i > 0; i--) {
          if (N[i] < N[i - 1]) {
            for (j = i; j < x; j++)
              N[j] = '9';
            N[i - 1] = (char)(N[i - 1] - 1);
          }
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (N[i] == '0') {
      i++;
      continue;
    }
    while (i < x) {
      cout << N[i++];
    }
    printf("\n");
  }
  return (0);
}
