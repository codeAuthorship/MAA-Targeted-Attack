#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

typedef unsigned long long ull;
typedef vector<vector<int>> vvi;
typedef long double ld;
typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> PII;
typedef vector<int> VI;
typedef set<int> si;

inline bool eqmcvoistj(char &minc, std::string &get, std::string &eqmcv) {
  string v = "";
  if (get[0] > minc && get[0] > '1') {
    v += (char)(get[0] - 1);
  }
  for (int i = 1; i < get.size(); i++)
    v += '9';
  eqmcv = v;
  return true;
  return false;
}

string solves(string get, char prev) {
  if (get.size() == 0)
    return "";
  char minc = '9';
  for (char c : get)
    minc = min(minc, c);
  if (get[0] > minc) {
    if (get.size() > 1 && get[1] > get[0]) {
      return get[0] + solves(get.substr(1), get[0]);
    } else {
      std::string eqmcv;
      if (eqmcvoistj(minc, get, eqmcv)) {
        return eqmcv;
      }
    }
  }
  return minc + solves(get.substr(1), minc);
}

void solve() {
  string get;
  cin >> get;
  cout << solves(get, '0') << '\n';
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/satyaki3794/sammyMaX/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/satyaki3794/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++)
    cout << "Case #" << i + 1 << ": ", solve();
  return 0;
}
