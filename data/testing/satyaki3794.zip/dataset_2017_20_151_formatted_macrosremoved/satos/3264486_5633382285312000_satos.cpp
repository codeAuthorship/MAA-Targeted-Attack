#include <iostream>
#include <string>

using namespace std;

long long get_largest_tidy_number(long long N) {
    string s = to_string(N);
    int n = s.length();
    int i = n - 1;

    while (i > 0 && s[i - 1] <= s[i]) {
        i--;
    }

    if (i == 0) {
        return N;
    }

    while (i > 0 && s[i - 1] > s[i]) {
        s[i - 1]--;
        i--;
    }
    for (int j = i + 1; j < n; j++) {
        s[j] = '9';
    }

    return stoll(s);
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long result = get_largest_tidy_number(N);
        cout << "Case #" << i << ": " << result << endl;
    }

    return 0;
}
