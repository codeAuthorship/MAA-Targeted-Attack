#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef long double LD;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long ll;           // NOTES:int64
typedef unsigned long long ull; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &get(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void solve(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

char str[50];

bool containszero(int l) {
  int i = 0;
  for (; str[i] == '0';) {
    i++;
  }
  while (i < l) {
    if (str[i] == '0') {
      return 1;
    }
    i++;
  }
  return false;
}
int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/satyaki3794/lazyBit/A-small-practice.in",
          "r", stdin);

  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/satyaki3794/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, k, l, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    bool p = 0;
    l = strlen(str);
    if (!containszero(l)) {
      for (i = l - 1; i > 0; i--) {
        if (str[i] < str[i - 1]) {
          for (j = i; j < l; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
        }
      }
    }
    while (containszero(l)) {
      for (i = 0; i < l; i++) {
        if (str[i] == '0') {
          for (j = i; j < l; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(l)) {
        for (i = l - 1; i > 0; i--) {
          if (str[i] < str[i - 1]) {
            for (j = i; j < l; j++)
              str[j] = '9';
            str[i - 1] = (char)(str[i - 1] - 1);
          }
        }
      }
    }
    cout << "Case #" << c++ << ": ";
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < l) {
      cout << str[i++];
    }
    cout << "\n";
  }
  return (0);
}
