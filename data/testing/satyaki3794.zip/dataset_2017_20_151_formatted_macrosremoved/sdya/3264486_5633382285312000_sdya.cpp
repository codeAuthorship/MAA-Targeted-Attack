#include <iostream>
#include <string>

using namespace std;

string find_last_tidy_number(const string& n) {
    int i = n.size() - 1;
    while (i > 0 && n[i-1] > n[i]) {
        i--;
    }
    if (i == 0) {
        return n;
    }
    n[i-1]--;
    for (int j = i; j < n.size(); j++) {
        n[j] = '9';
    }

    return find_last_tidy_number(n);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << find_last_tidy_number(n) << endl;
    }
    return 0;
}
