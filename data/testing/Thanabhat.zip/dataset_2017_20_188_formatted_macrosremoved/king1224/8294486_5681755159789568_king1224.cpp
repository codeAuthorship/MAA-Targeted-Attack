#include <bits/stdc++.h>
using namespace std;

const double INF = 1e9;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n, q;
        cin >> n >> q;

        vector<int> e(n), s(n);
        vector<vector<int>> d(n, vector<int>(n));
        for (int i = 0; i < n; i++) {
            cin >> e[i] >> s[i];
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> d[i][j];
            }
        }

        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (d[i][k] != -1 && d[k][j] != -1) {
                        if (d[i][j] == -1 || d[i][j] > d[i][k] + d[k][j]) {
                            d[i][j] = d[i][k] + d[k][j];
                        }
                    }
                }
            }
        }

        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int u, v;
            cin >> u >> v;
            u--; v--;

            vector<double> dist(n, INF);
            priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
            dist[u] = 0;
            pq.push({0, u});
            while (!pq.empty()) {
                auto [t, i] = pq.top();
                pq.pop();
                if (i == v) {
                    cout << " " << fixed << setprecision(9) << t;
                    break;
                }
                for (int j = 0; j < n; j++) {
                    if (i != j && d[i][j] != -1 && e[j] >= d[i][j]) {
                        double time = d[i][j] / double(s[i]);
                        if (dist[i] + time < dist[j]) {
                            dist[j] = dist[i] + time;
                            pq.push({dist[j], j});
                        }
                    }
                }
            }
        }
        cout << endl;
    }

    return 0;
}
