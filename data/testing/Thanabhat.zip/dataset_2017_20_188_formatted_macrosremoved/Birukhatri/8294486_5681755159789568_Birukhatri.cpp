#include <bitset>
#include <cctype>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef long double ld;
typedef long double LD;
typedef set<int> si;
typedef long long td_ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ull; 

const double pi = acos(-1.0); 
const double eps = 1e-11;     
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char colors[] = {'R', 'O', 'Y', 'G', 'B', 'V'};
const char dz[] = "SENW";
struct debugger {

} dbg;

void debugarr(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

double besttime[1010];
LL c[110], d[110], dist[110][110], a[110], b[110], dd[110];
long double best[110][110];
inline void yfjccluyek(int &i, int &j) {
  best[i][j] = besttime[j] + ((dd[i] - dd[j]) * 1.0) / d[j];
}

inline void gquwyvwlaf(int &i) { dd[i] = dd[i - 1] + dist[i - 1][i]; }

inline void qtgjugfpjc(td_ll &n, int &j, int &i) {
  i = 0;
  while (i < n) {
    for (j = 0; j < n; j++) {
      cin >> dist[i][j];
      ;
    }
    i++;
  }
}

int main() {

  ;


  td_ll n, k, N, m, t, s = 0, p, q;
  int i, j;
  cin >> t;
  int ct = 1;
  while (t--) {
    cin >> n;
    ;
    cin >> q;
    ;
    for (i = 0; i < n; i++) {
      cin >> c[i];
      ;
      cin >> d[i];
      ;
    }
    qtgjugfpjc(n, j, i);
    for (i = 0; i < q; i++) {
      cin >> a[i];
      ;
      cin >> b[i];
      ;
    }
    dd[0] = 0;
    for (i = 1; i < n; i++)
      gquwyvwlaf(i);
    besttime[0] = 0.0;
    LD r;
    for (i = 1; i < n; i++) {
      r = 1e18;
      for (j = 0; j < i; j++) {
        if (dd[i] - dd[j] <= c[j])
          yfjccluyek(i, j);
        else
          best[i][j] = 1e18;

        r = min(r, best[i][j]);
      }
      besttime[i] = r;
    }

    printf("Case #%d: %0.6lf\n", ct++, besttime[n - 1]);
  }
  return (0);
}
