#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <iomanip>
#include <limits>

using namespace std;

const double INF = numeric_limits<double>::max();

struct Horse {
    double distance;
    double speed;
};

struct Edge {
    int from;
    int to;
    double time;
};

struct State {
    int city;
    double time;
    bool operator>(const State& other) const {
        return time > other.time;
    }
};

vector<vector<Edge>> buildGraph(const vector<Horse>& horses, const vector<vector<int>>& distances) {
    int n = horses.size();
    vector<vector<Edge>> graph(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (distances[i][j] != -1) {
                double time = (double)distances[i][j] / horses[i].speed;
                graph[i].push_back({i, j, time});
            }
        }
    }
    return graph;
}

vector<double> dijkstra(const vector<vector<Edge>>& graph, int start) {
    int n = graph.size();
    vector<double> dist(n, INF);
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push({start, 0});
    while (!pq.empty()) {
        State curr = pq.top();
        pq.pop();
        if (dist[curr.city] != INF) {
            continue;
        }
        dist[curr.city] = curr.time;
        for (const Edge& edge : graph[curr.city]) {
            int nextCity = edge.to;
            double nextTime = curr.time + edge.time;
            if (dist[nextCity] == INF) {
                pq.push({nextCity, nextTime});
            }
        }
    }
    return dist;
}

vector<double> solveTest() {
    int n, q;
    cin >> n >> q;
    vector<Horse> horses(n);
    for (Horse& horse : horses) {
        cin >> horse.distance >> horse.speed;
    }
    vector<vector<int>> distances(n, vector<int>(n));
    for (auto& row : distances) {
        for (int& cell : row) {
            cin >> cell;
        }
    }
    vector<vector<Edge>> graph = buildGraph(horses, distances);
    vector<double> result;
    for (int i = 0; i < q; i++) {
        int start, end;
        cin >> start >> end;
        start--;
        end--;
        vector<double> dist = dijkstra(graph, start);
        result.push_back(dist[end]);
    }
    return result;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        vector<double> result = solveTest();
        cout << "Case #" << i << ":";
        for (double res : result) {
            cout << " " << fixed << setprecision(9) << res;
        }
        cout << endl;
    }
    return 0;
}
