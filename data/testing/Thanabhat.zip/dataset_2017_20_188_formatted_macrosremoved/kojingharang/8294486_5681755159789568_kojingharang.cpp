#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

const double eps = 1e-9;

struct Horse {
    double endurance, speed;
};

struct Edge {
    int from, to;
    double distance;
};

struct State {
    int city;
    double time;
    Horse horse;

    bool operator < (const State& other) const {
        return time > other.time;
    }
};

vector<vector<int>> adj;
vector<vector<double>> dist;
vector<Horse> horses;
vector<int> prev_city;
vector<double> prev_time;

void dijkstra(int start, int end) {
    int n = adj.size();
    dist.assign(n, vector<double>(n, 1e18));
    prev_city.assign(n, -1);
    prev_time.assign(n, 1e18);
    dist[start][0] = 0;
    priority_queue<State> pq;
    pq.push({start, 0, horses[start]});
    while (!pq.empty()) {
        State s = pq.top(); pq.pop();
        int city = s.city;
        double time = s.time;
        Horse horse = s.horse;
        if (city == end) {
            return;
        }
        if (time - eps > prev_time[city]) {
            continue;
        }
        if (horse.endurance - eps < dist[start][city]) {
            continue;
        }
        for (int next : adj[city]) {
            double d = dist[city][next];
            if (d < 0) continue;
            double t = d / horse.speed;
            Horse next_horse = horse;
            next_horse.endurance -= d;
            if (next_horse.endurance < 0) {
                continue;
            }
            if (prev_time[next] - eps > time + t) {
                prev_time[next] = time + t;
                prev_city[next] = city;
                pq.push({next, prev_time[next], next_horse});
                dist[start][next] = dist[start][city] + d;
            }
        }
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n, q;
        cin >> n >> q;
        horses.resize(n);
        for (int i = 0; i < n; i++) {
            cin >> horses[i].endurance >> horses[i].speed;
        }
        adj.assign(n, vector<int>(n));
        dist.assign(n, vector<double>(n));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> dist[i][j];
                if (dist[i][j] >= 0) {
                    adj[i].push_back(j);
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int start, end;
            cin >> start >> end;
            start--; end--;
            dijkstra(start, end);
            double time = prev_time[end];
            cout << " " << fixed << setprecision(9) << time;
        }
        cout << endl;
    }
    return 0;
}
