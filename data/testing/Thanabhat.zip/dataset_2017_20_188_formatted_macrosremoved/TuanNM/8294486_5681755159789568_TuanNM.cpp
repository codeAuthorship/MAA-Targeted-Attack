#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

bool can_travel(int u, int v, const vector<vector<int>>& distances) {
    return distances[u][v] != -1;
}

double travel_time(int u, int v, const vector<int>& endurance, const vector<int>& speed, const vector<vector<int>>& distances) {
    double distance = distances[u][v];
    double max_distance = endurance[u];
    double speed_limit = speed[u];
    if (distance > max_distance) {
        distance -= max_distance;
        max_distance = endurance[v];
        speed_limit = speed[v];
    }
    return distance / speed_limit + (distance > 0 ? ceil(distance / max_distance) : 0) * 24.0;
}

vector<double> shortest_path(int source, const vector<int>& endurance, const vector<int>& speed, const vector<vector<int>>& distances) {
    int n = endurance.size();
    vector<double> dist(n, INFINITY);
    dist[source] = 0;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    pq.emplace(0, source);
    while (!pq.empty()) {
        double d = pq.top().first;
        int u = pq.top().second;
        pq.pop();
        if (d > dist[u]) continue;
        for (int v = 0; v < n; ++v) {
            if (can_travel(u, v, distances)) {
                double w = travel_time(u, v, endurance, speed, distances);
                if (dist[u] + w < dist[v]) {
                    dist[v] = dist[u] + w;
                    pq.emplace(dist[v], v);
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, q;
    cin >> n >> q;
    vector<int> endurance(n);
    vector<int> speed(n);
    for (int i = 0; i < n; ++i) {
        cin >> endurance[i] >> speed[i];
    }
    vector<vector<int>> distances(n, vector<int>(n));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> distances[i][j];
        }
    }
    for (int k = 1; k <= q; ++k) {
        int u, v;
        cin >> u >> v;
        vector<double> dist = shortest_path(u - 1, endurance, speed, distances);
        cout << setprecision(10) << fixed << " " << dist[v - 1];
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        cout << "Case #" << i << ":";
        solve();
    }
    return 0;
}
