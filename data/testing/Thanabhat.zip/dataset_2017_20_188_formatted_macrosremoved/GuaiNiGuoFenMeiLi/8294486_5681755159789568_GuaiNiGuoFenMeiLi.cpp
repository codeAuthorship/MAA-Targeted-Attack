#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100;
const int INF = 1e9;

int N, Q;
int E[MAXN+5], S[MAXN+5];
int D[MAXN+5][MAXN+5];

double dist[MAXN+5][MAXN+5];

void dijkstra(int s) {
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    for (int i = 1; i <= N; i++) {
        dist[s][i] = INF;
    }
    dist[s][s] = 0;
    pq.push({0, s});
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[s][u]) continue;
        for (int v = 1; v <= N; v++) {
            if (D[u][v] != -1) {
                double time = (double)D[u][v] / S[u];
                if (dist[s][v] > dist[s][u] + time && dist[s][u] + time <= E[u]) {
                    dist[s][v] = dist[s][u] + time;
                    pq.push({dist[s][v], v});
                }
            }
        }
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> Q;
        for (int i = 1; i <= N; i++) {
            cin >> E[i] >> S[i];
        }
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= N; j++) {
                cin >> D[i][j];
                if (D[i][j] == -1) {
                    dist[i][j] = INF;
                } else {
                    dist[i][j] = (double)D[i][j] / S[i];
                }
            }
        }
        for (int k = 1; k <= N; k++) {
            for (int i = 1; i <= N; i++) {
                for (int j = 1; j <= N; j++) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 1; i <= Q; i++) {
            int u, v;
            cin >> u >> v;
            cout << " " << fixed << setprecision(9) << dist[u][v];
        }
        cout << endl;
    }
    return 0;
}
