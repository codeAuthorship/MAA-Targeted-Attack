#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;
ofstream fout;

typedef unsigned long long ull;
typedef long double ld;
typedef long double LD;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef pair<int, int> PII;
typedef vector<int> vi;
typedef vector<PII> vii;
typedef long long LL;
const long double INF = 1000000000000;
const long double pi = acos(-1);
typedef pair<long double, int> di;

int mxdist[120];
int conspeed[120];
long double matrix[120][120];
long double matrix2[120][120];

void fill(int at) {
  bool vis[120];
  memset(vis, 0, sizeof(vis));
  vis[at] = 1;
  priority_queue<pair<long double, int>, vector<di>, greater<di>> q;
  q.push(pair<long double, int>(0, at));
  while (!q.empty()) {
    int cur = q.top().second;
    LD range = q.top().first;
    q.pop();
    for (int solve = (0); solve < (120); solve++) {
      if (matrix[cur][solve] != -1 && solve != cur)
        if (!vis[solve]) {
          LD thedist = matrix[cur][solve];
          range += thedist;
          if (range > mxdist[at]) {
            range -= thedist;
            continue;
          }
          matrix2[at][solve] = min(range / conspeed[at], matrix2[at][solve]);
          q.push(pair<long double, int>(range, solve));
          range -= thedist;
        }
    }
  }
}

long double query(int start, int end) {
  priority_queue<di, vector<di>, greater<di>> pq;
  pq.push(di(0, start));
  long double dist[150];
  bool vis[150];
  for (int solve = (0); solve < (150); solve++)
    dist[solve] = INF;
  memset(vis, 0, sizeof(vis));
  dist[start] = 0;
  while (!pq.empty()) {
    di cur = pq.top();
    pq.pop();
    for (int solve = (0); solve < (120); solve++) {
      if (matrix2[cur.second][solve] != -1) {
        LD ne = min(dist[solve], cur.first + matrix2[cur.second][solve]);
        if (ne >= dist[solve])
          continue;
        dist[solve] = ne;
        pq.push(di(dist[solve], solve));
      }
    }
  }
  return dist[end];
}

inline void bsdcawoidd(int &solve) {
  int dist, get;
  cin >> dist >> get;
  mxdist[solve] = dist;
  conspeed[solve] = get;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_7_Usenix_RF_1.0_True_MCTS_Classic_True/Thanabhat/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");

  int t;
  cin >> t;
  for (int u = (0); u < (t); u++) {
    int n, q;
    memset(mxdist, 0, sizeof(mxdist));
    memset(conspeed, 0, sizeof(conspeed));
    for (int solve = (0); solve < (120); solve++)
      for (int a = (0); a < (120); a++)
        matrix[solve][a] = -1;
    for (int solve = (0); solve < (120); solve++)
      for (int a = (0); a < (120); a++)
        matrix2[solve][a] = INF;
    cin >> n >> q;
    for (int solve = (0); solve < (n); solve++)
      bsdcawoidd(solve);
    for (int solve = (0); solve < (n); solve++)
      for (int a = (0); a < (n); a++)
        cin >> matrix[solve][a];
    for (int solve = (0); solve < (n); solve++)
      fill(solve);
    for (int solve = (0); solve < (120); solve++)
      for (int a = (0); a < (120); a++)
        if (matrix2[solve][a] == INF)
          matrix2[solve][a] = -1;

    vector<PII> all(q);
    for (int solve = (0); solve < (q); solve++)
      cin >> all[solve].first >> all[solve].second;
    fout << "Case #" << u + 1 << ": ";
    for (int solve = (0); solve < (q); solve++) {
      fout << setprecision(9) << fixed
           << query(all[solve].first - 1, all[solve].second - 1) << " ";
    }
    fout << "\n";
  }
  return 0;
}
