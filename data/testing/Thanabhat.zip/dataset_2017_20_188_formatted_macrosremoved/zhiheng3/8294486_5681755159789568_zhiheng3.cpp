#include <bits/stdc++.h>
using namespace std;

const double INF = 1e18;
const double EPS = 1e-9;

int T, n, q;
double e[110], s[110], d[110][110], dist[110][110], f[110][110];

void solve(int t) {
    cin >> n >> q;
    for (int i = 1; i <= n; ++i) {
        cin >> e[i] >> s[i];
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            cin >> d[i][j];
            if (d[i][j] == -1) {
                dist[i][j] = INF;
            } else {
                dist[i][j] = d[i][j];
            }
        }
    }
    for (int k = 1; k <= n; ++k) {
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
            }
        }
    }
    cout << "Case #" << t << ":";
    while (q--) {
        int u, v;
        cin >> u >> v;
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                if (dist[u][i] + dist[i][j] + dist[j][v] <= e[i] && dist[i][j] != INF) {
                    f[i][j] = dist[i][j] / s[i] + dist[u][i] / s[i] + dist[j][v] / s[j];
                } else {
                    f[i][j] = INF;
                }
            }
        }
        for (int k = 1; k <= n; ++k) {
            for (int i = 1; i <= n; ++i) {
                for (int j = 1; j <= n; ++j) {
                    f[i][j] = min(f[i][j], f[i][k] + f[k][j]);
                }
            }
        }
        double ans = INF;
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                ans = min(ans, f[i][j]);
            }
        }
        cout << " " << fixed << setprecision(9) << ans;
    }
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        solve(t);
    }
    return 0;
}
