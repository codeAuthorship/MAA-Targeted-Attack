#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <cmath>
using namespace std;

const int MAXN = 100;
const double EPS = 1e-9;
const double INF = 1e18;

int n, q;
double e[MAXN+5], s[MAXN+5], d[MAXN+5][MAXN+5];

double dijkstra(int u, int v) {
    priority_queue<pair<double,int>, vector<pair<double,int>>, greater<pair<double,int>>> pq;
    vector<double> dist(n+1, INF);
    pq.push(make_pair(0.0, u));
    dist[u] = 0.0;
    while (!pq.empty()) {
        auto p = pq.top(); pq.pop();
        int x = p.second;
        double t = p.first;
        if (x == v) return t;
        if (t - dist[x] > EPS) continue;
        for (int y = 1; y <= n; ++y) {
            if (d[x][y] < 0) continue;
            double speed = min(s[x], s[y]);
            double time = d[x][y] / speed;
            double new_dist = dist[x] + time;
            double new_energy = e[x] - d[x][y];
            if (new_energy < 0) continue;
            if (new_dist < dist[y] - EPS) {
                dist[y] = new_dist;
                pq.push(make_pair(new_dist, y));
            }
        }
    }
    return INF;
}

int main() {
    int t; cin >> t;
    for (int tc = 1; tc <= t; ++tc) {
        cin >> n >> q;
        for (int i = 1; i <= n; ++i) {
            cin >> e[i] >> s[i];
        }
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                cin >> d[i][j];
            }
        }
        cout << "Case #" << tc << ":";
        for (int i = 0; i < q; ++i) {
            int u, v; cin >> u >> v;
            double time = dijkstra(u, v);
            cout << " " << fixed << setprecision(9) << time;
        }
        cout << endl;
    }
    return 0;
}
