#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>
#include <cmath>
using namespace std;

const double INF = 1e18;

struct Horse {
    int max_distance;
    int speed;
};

struct Edge {
    int to;
    double weight;
};

double shortest_path(const vector<vector<Edge>>& graph, const vector<Horse>& horses,
                     int start, int end) {
    int n = graph.size();
    vector<double> dist(n, INF);
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<>> pq;
    dist[start] = 0;
    pq.emplace(0, start);
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (d > dist[u]) continue;
        for (const auto& e : graph[u]) {
            int v = e.to;
            double w = e.weight;
            double t = w / horses[u].speed;
            if (horses[u].max_distance < w) continue;
            if (dist[u] + t < dist[v]) {
                dist[v] = dist[u] + t;
                pq.emplace(dist[v], v);
            }
        }
    }
    return dist[end];
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n, q;
        cin >> n >> q;
        vector<Horse> horses(n);
        for (int i = 0; i < n; i++) {
            cin >> horses[i].max_distance >> horses[i].speed;
        }
        vector<vector<Edge>> graph(n, vector<Edge>(n));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int d;
                cin >> d;
                if (d != -1) {
                    graph[i][j] = {j, static_cast<double>(d)};
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int u, v;
            cin >> u >> v;
            u--, v--;
            double min_time = shortest_path(graph, horses, u, v);
            cout << " " << fixed << setprecision(9) << min_time;
        }
        cout << "\n";
    }
    return 0;
}
