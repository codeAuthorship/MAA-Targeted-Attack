#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

const double INF = 1e18;

struct Horse {
    int speed;
    long long max_distance;
};

struct Edge {
    int dest;
    long long distance;
    double time;
};

double dijkstra(int start, int end, vector<vector<Edge>> &adj, vector<Horse> &horses) {
    int n = adj.size();
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    vector<double> dist(n, INF);
    dist[start] = 0;
    pq.push(make_pair(0, start));
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[u])
            continue;
        for (auto &e : adj[u]) {
            int v = e.dest;
            double w = e.time;
            if (horses[u].max_distance < e.distance)
                continue; 
            double new_dist = dist[u] + w;
            if (new_dist < dist[v]) {
                dist[v] = new_dist;
                pq.push(make_pair(new_dist, v));
            }
        }
    }
    return dist[end];
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;
        vector<Horse> horses(N);
        for (int i = 0; i < N; i++)
            cin >> horses[i].max_distance >> horses[i].speed;
        vector<vector<Edge>> adj(N, vector<Edge>(N));
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++) {
                int d;
                cin >> d;
                if (d != -1) {
                    double time = (double)d / horses[i].speed;
                    adj[i][j] = {j, d, time};
                }
            }
        cout << "Case #" << t << ": ";
        while (Q--) {
            int start, end;
            cin >> start >> end;
            start--; end--;
            double time = dijkstra(start, end, adj, horses);
            cout << fixed << setprecision(8) << time << " ";
        }
        cout << endl;
    }
    return 0;
}
