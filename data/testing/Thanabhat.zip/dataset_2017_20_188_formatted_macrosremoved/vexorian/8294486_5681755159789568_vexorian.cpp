#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>

using namespace std;

const double EPS = 1e-9;
const int MAXN = 100;
const int INF = 1e9;

struct Horse {
    int endurance, speed;
};

struct Edge {
    int to;
    double weight;
};

vector<Horse> horses;
vector<vector<int>> distances;
vector<vector<Edge>> graph;

int n, q;

double dijkstra(int start, int end) {
    vector<double> dist(n, INF);
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    dist[start] = 0.0;
    pq.push({0.0, start});
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (u == end) {
            return d;
        }
        for (const Edge& e : graph[u]) {
            int v = e.to;
            double w = e.weight;
            double newDist = d + w;
            double newTime = newDist / horses[u].speed;
            if (horses[u].endurance < newDist) {
                continue;
            }
            if (newTime < dist[v] - EPS) {
                dist[v] = newTime;
                pq.push({dist[v], v});
            }
        }
    }
    return -1.0;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n >> q;
        horses.resize(n);
        distances.resize(n, vector<int>(n));
        graph.resize(n);
        for (int j = 0; j < n; j++) {
            cin >> horses[j].endurance >> horses[j].speed;
        }
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                cin >> distances[j][k];
                if (distances[j][k] != -1) {
                    graph[j].push_back({k, (double) distances[j][k]});
                }
            }
        }
        cout << "Case #" << i << ":";
        for (int j = 0; j < q; j++) {
            int start, end;
            cin >> start >> end;
            start--, end--;
            double time = dijkstra(start, end);
            cout << " " << fixed << setprecision(9) << time;
        }
        cout << endl;
        horses.clear();
        distances.clear();
        graph.clear();
    }
    return 0;
}
