#include <bits/stdc++.h>
#define ld long double
using namespace std;

const ld INF = 1e18;

vector<vector<ld>> dist, time_;
vector<pair<ld, ld>> horses;
int n;

void floyd_warshall() {
    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (dist[i][k] < INF && dist[k][j] < INF) {
                    ld new_dist = dist[i][k] + dist[k][j];
                    ld new_time = new_dist / min(horses[i].second, horses[k].second);
                    if (new_dist <= horses[k].first) {
                        if (new_time < time_[i][j]) {
                            time_[i][j] = new_time;
                        }
                    }
                }
            }
        }
    }
}

int main() {
    int t;
    cin >> t;

    for (int test = 1; test <= t; test++) {
        int q;
        cin >> n >> q;

        dist.resize(n, vector<ld>(n));
        time_.resize(n, vector<ld>(n, INF));
        horses.resize(n);

        for (int i = 0; i < n; i++) {
            ld e, s;
            cin >> e >> s;
            horses[i] = {e, s};
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> dist[i][j];
                if (dist[i][j] == -1) {
                    dist[i][j] = INF;
                }
            }
        }

        floyd_warshall();

        cout << "Case #" << test << ": ";
        while (q--) {
            int u, v;
            cin >> u >> v;
            u--, v--;

            cout << fixed << setprecision(10) << time_[u][v] << " ";
        }
        cout << endl;

        dist.clear();
        time_.clear();
        horses.clear();
    }

    return 0;
}
