#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>

using namespace std;

const double INF = 1e18;

struct Horse {
    double endurance;
    double speed;
};

struct Edge {
    int to;
    double dist;
};

typedef vector<vector<Edge>> Graph;

vector<double> dijkstra(int s, const Graph& graph, const vector<Horse>& horses) {
    int n = graph.size();
    vector<double> dist(n, INF);
    dist[s] = 0;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    pq.push(make_pair(0, s));
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[u]) continue;
        for (const Edge& e : graph[u]) {
            int v = e.to;
            double w = e.dist;
            for (int i = 0; i < n; i++) {
                double t = w / horses[i].speed;
                if (horses[i].endurance >= t) {
                    double new_dist = dist[u] + t;
                    if (new_dist < dist[v]) {
                        dist[v] = new_dist;
                        pq.push(make_pair(new_dist, v));
                    }
                }
            }
        }
    }
    return dist;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;
        vector<Horse> horses(N);
        for (int i = 0; i < N; i++) {
            cin >> horses[i].endurance >> horses[i].speed;
        }
        Graph graph(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int D;
                cin >> D;
                if (D != -1) {
                    graph[i].push_back({j, D});
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < Q; i++) {
            int u, v;
            cin >> u >> v;
            u--, v--;
            vector<double> dist_u = dijkstra(u, graph, horses);
            cout << " " << setprecision(9) << fixed << dist_u[v];
        }
        cout << endl;
    }
    return 0;
}
