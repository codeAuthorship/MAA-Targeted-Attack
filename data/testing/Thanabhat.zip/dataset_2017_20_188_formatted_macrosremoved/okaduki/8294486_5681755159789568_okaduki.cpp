#include <bits/stdc++.h>
using namespace std;

const double INF = 1e9;

int main() {
    int t;
    cin >> t;

    for (int test_case = 1; test_case <= t; ++test_case) {
        int n, q;
        cin >> n >> q;

        vector<double> e(n), s(n);
        vector<vector<double>> d(n, vector<double>(n));

        for (int i = 0; i < n; ++i) {
            cin >> e[i] >> s[i];
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cin >> d[i][j];
            }
        }

        for (int k = 0; k < n; ++k) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (d[i][k] >= 0 && d[k][j] >= 0) {
                        d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                    }
                }
            }
        }

        cout << "Case #" << test_case << ":";
        while (q--) {
            int u, v;
            cin >> u >> v;
            --u, --v;

            double ans = d[u][v] / s[u];
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (i != u && d[i][j] >= 0 && d[i][u] + d[u][v] + d[v][j] <= e[i]) {
                        ans = min(ans, (d[i][u] + d[u][v] + d[v][j]) / s[i]);
                    }
                }
            }
            cout << " " << fixed << setprecision(9) << ans;
        }
        cout << endl;
    }
    return 0;
}
