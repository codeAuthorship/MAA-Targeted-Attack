#include<bits/stdc++.h>
using namespace std;
const int MAXN=110;
const double EPS=1e-8;
int T,N,Q;
double E[MAXN],S[MAXN],D[MAXN][MAXN];
struct Edge{
    int v; double w;
    Edge(){}
    Edge(int v,double w):v(v),w(w){}
};
vector<Edge> G[MAXN];
double dijkstra(int u,int v){
    double d[MAXN];
    priority_queue<pair<double,int>,vector<pair<double,int> >,greater<pair<double,int> > > Q;
    for(int i=1;i<=N;i++) d[i]=1e18;
    d[u]=0; Q.push(make_pair(0,u));
    while(!Q.empty()){
        int u=Q.top().second; Q.pop();
        for(auto &e:G[u]){
            int v=e.v; double w=e.w;
            if(d[v]-d[u]-w>EPS) d[v]=d[u]+w,Q.push(make_pair(d[v],v));
        }
    }
    return d[v];
}
int main(){
    scanf("%d",&T);
    for(int t=1;t<=T;t++){
        scanf("%d%d",&N,&Q);
        for(int i=1;i<=N;i++) scanf("%lf%lf",&E[i],&S[i]);
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++)
                scanf("%lf",&D[i][j]);
        for(int i=1;i<=N;i++){
            G[i].clear();
            for(int j=1;j<=N;j++){
                if(i==j || D[i][j]<0) continue;
                double dist=D[i][j],time=dist/S[i];
                G[i].push_back(Edge(j,time));
            }
        }
        printf("Case #%d:",t);
        while(Q--){
            int u,v; scanf("%d%d",&u,&v);
            printf(" %.7lf",dijkstra(u,v));
        }
        printf("\n");
    }
    return 0;
}
