#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll, int> pli;

const ll INF = 1e18;

vector<vector<pair<int, ll>>> adj;
vector<vector<ll>> dist;          
vector<ll> max_dist, speed;

void dijkstra(int src) {
    dist[src][src] = 0;
    priority_queue<pli, vector<pli>, greater<pli>> pq;
    pq.push({0, src});
    while (!pq.empty()) {
        int u = pq.top().second;
        ll d = pq.top().first;
        pq.pop();
        if (d > dist[src][u]) continue;
        for (auto [v, w] : adj[u]) {
            if (max_dist[u] < w) continue;
            ll time = w * speed[u];
            if (d + time < dist[src][v]) {
                dist[src][v] = d + time;
                pq.push({dist[src][v], v});
            }
        }
    }
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, q;
        cin >> n >> q;
        adj.assign(n, vector<pair<int, ll>>());
        max_dist.resize(n);
        speed.resize(n);
        dist.assign(n, vector<ll>(n, INF));
        for (int i = 0; i < n; i++) {
            cin >> max_dist[i] >> speed[i];
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                ll d;
                cin >> d;
                if (d != -1) {
                    adj[i].push_back({j, d});
                }
            }
        }
        for (int i = 0; i < n; i++) {
            dijkstra(i);
        }
        cout << "Case #" << case_num << ": ";
        for (int i = 0; i < q; i++) {
            int u, v;
            cin >> u >> v;
            cout << dist[u - 1][v - 1] << " ";
        }
        cout << endl;
    }
    return 0;
}
