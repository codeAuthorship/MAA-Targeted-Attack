#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define ll long long
#define ld long double
#define pii pair<int, int>
#define vi vector<int>
#define vl vector<ll>
#define all(x) (x).begin(), (x).end()
#define fi first
#define se second
#define MOD 1000000007
#define INF 1e18
#define endl '\n'

int t, n, q, e[105], s[105];
ld d[105][105], dist[105][105];

void floydWarshall() {
    for(int k = 1; k <= n; k++) {
        for(int i = 1; i <= n; i++) {
            for(int j = 1; j <= n; j++) {
                if(d[i][k] == -1 || d[k][j] == -1) continue;
                if(d[i][j] == -1) d[i][j] = d[i][k] + d[k][j];
                else d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
            }
        }
    }
}

ld getTime(int u, int v) {
    if(d[u][v] == -1) return INF;
    ld time = d[u][v]/s[u];
    if(time <= e[u]) return time;
    ld remDist = e[u]*s[u];
    time = e[u]/s[u];
    for(int i = 1; i <= n; i++) {
        if(d[u][i] == -1 || i == u || i == v) continue;
        ld horseDist = min(remDist, d[u][i]);
        ld horseTime = horseDist/s[u];
        if(horseTime > e[u]) return INF;
        remDist -= horseDist;
        time += horseTime;
    }
    remDist = d[u][v] - (e[u]*s[u] - remDist);
    ld horseTime = remDist/s[v];
    if(horseTime > e[v]) return INF;
    time += horseTime;
    return time;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    cin >> t;
    for(int i = 1; i <= t; i++) {
        cin >> n >> q;
        for(int j = 1; j <= n; j++) {
            cin >> e[j] >> s[j];
        }
        for(int j = 1; j <= n; j++) {
            for(int k = 1; k <= n; k++) {
                cin >> d[j][k];
                if(d[j][k] == -1) dist[j][k] = INF;
                else dist[j][k] = d[j][k]/s[j];
            }
        }
        floydWarshall();
        cout << "Case #" << i << ":";
        for(int j = 1; j <= q; j++) {
            int u, v;
            cin >> u >> v;
            ld time = getTime(u, v);
            cout << " " << fixed << setprecision(10) << time;
        }
        cout << endl;
    }

    return 0;
}
