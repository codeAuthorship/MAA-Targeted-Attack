#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <tuple>
#include <cmath>

using namespace std;

const double INF = 1e18;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;
        vector<int> E(N), S(N);
        vector<vector<int>> D(N, vector<int>(N));
        for (int i = 0; i < N; i++) {
            cin >> E[i] >> S[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cin >> D[i][j];
            }
        }
        vector<vector<double>> dist(N, vector<double>(N, INF));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (i == j) {
                    dist[i][j] = 0.0;
                } else if (D[i][j] >= 0) {
                    double time = (double) D[i][j] / S[i];
                    dist[i][j] = time;
                }
            }
        }
        for (int k = 0; k < N; k++) {
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int q = 0; q < Q; q++) {
            int U, V;
            cin >> U >> V;
            U--; V--;
            double ans = (double) dist[U][V];
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (i == j) continue;
                    double time1 = (double) D[U][i] / S[U];
                    double time2 = (double) D[i][j] / S[i];
                    double time3 = (double) D[j][V] / S[j];
                    if (time1 + time2 + time3 <= E[U]) {
                        ans = min(ans, time1 + time2 + time3);
                    }
                }
            }
            cout << " " << fixed << setprecision(10) << ans;
        }
        cout << endl;
    }
    return 0;
}
