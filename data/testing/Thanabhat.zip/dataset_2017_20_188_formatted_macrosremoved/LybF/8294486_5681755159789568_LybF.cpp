#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int main() {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        int n, q; cin >> n >> q;
        vector<int> e(n), s(n);
        vector<vector<int>> d(n, vector<int>(n));
        for (int i = 0; i < n; i++) {
            cin >> e[i] >> s[i];
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> d[i][j];
                if (d[i][j] == -1) {
                    d[i][j] = INF;
                }
            }
        }
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int u, v; cin >> u >> v; u--; v--;
            double ans = (double)d[u][v] / s[u];
            for (int j = 0; j < n; j++) {
                if (j != u && j != v && d[u][j] != INF && d[j][v] != INF) {
                    double time_to_j = (double)d[u][j] / s[u];
                    double time_from_j = (double)d[j][v] / s[j];
                    ans = min(ans, time_to_j + time_from_j);
                }
            }
            cout << " " << fixed << setprecision(9) << ans;
        }
        cout << endl;
    }
    return 0;
}
