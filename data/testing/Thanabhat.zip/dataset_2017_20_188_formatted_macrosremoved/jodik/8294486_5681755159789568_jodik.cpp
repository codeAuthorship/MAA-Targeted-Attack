#include <bits/stdc++.h>
using namespace std;

const double INF = 1e18;
const double eps = 1e-9;

int N, Q;
double E[105], S[105], D[105][105];

vector<int> adj[105];
double dist[105][105];
bool vis[105][105];

void dijkstra(int start, int k) {
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    pq.push({0, start});
    dist[start][k] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (vis[u][k]) continue;
        vis[u][k] = true;

        for (int v : adj[u]) {
            double cost = D[u][v] / S[u];
            if (dist[v][k] > dist[u][k] + cost && E[v] >= D[u][v]) {
                dist[v][k] = dist[u][k] + cost;
                pq.push({dist[v][k], v});
            }
        }
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> N >> Q;

        for (int i = 1; i <= N; i++) {
            cin >> E[i] >> S[i];
            adj[i].clear();
            for (int j = 1; j <= N; j++) {
                cin >> D[i][j];
                if (D[i][j] != -1) adj[i].push_back(j);
                dist[i][j] = INF;
                vis[i][j] = false;
            }
        }

        for (int k = 1; k <= Q; k++) {
            int u, v;
            cin >> u >> v;

            for (int i = 1; i <= N; i++) dist[i][k] = INF;
            dijkstra(u, k);

            double ans = dist[v][k];
            printf("%.9f ", ans);
        }

        printf("\n");
    }

    return 0;
}
