#include <bits/stdc++.h>
using namespace std;
#define double long double 
const double INF = 1e18;


vector<double> dijkstra(int start, int n, vector<vector<double>>& adj) {
    vector<double> dist(n, INF);
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<>> pq;
    pq.emplace(0.0, start);
    dist[start] = 0.0;
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (dist[u] < d) continue;
        for (int v = 0; v < n; v++) {
            if (adj[u][v] < 0) continue;
            double nd = d + adj[u][v] / adj[u][n+1];
            if (nd < dist[v]) {
                dist[v] = nd;
                pq.emplace(nd, v);
            }
        }
    }
    return dist;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, q;
        cin >> n >> q;
        vector<double> e(n), s(n);
        for (int j = 0; j < n; j++) cin >> e[j] >> s[j];
        vector<vector<double>> adj(n, vector<double>(n+2, -1.0));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                cin >> adj[j][k];
                if (adj[j][k] >= 0) adj[j][k] *= -1.0;
            }
            adj[j][j] = 0.0;
            adj[j][n] = e[j];
            adj[j][n+1] = s[j];
        }
        for (int j = 0; j < q; j++) {
            int u, v;
            cin >> u >> v;
            u--, v--;
            vector<double> dist = dijkstra(u, n, adj);
            cout << fixed << setprecision(10) << " " << dist[v] << flush;
        }
        cout << endl;
    }
    return 0;
}
