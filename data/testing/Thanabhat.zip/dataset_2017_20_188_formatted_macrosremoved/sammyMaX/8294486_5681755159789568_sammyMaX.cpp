#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

const double INF = 1e9;

struct Horse {
    int e; 
    int s;
};

struct Edge {
    int to;
    double dist;
};

typedef vector<vector<Edge>> Graph;

vector<double> dijkstra(const Graph& graph, int start) {
    int n = graph.size();
    vector<double> dist(n, INF);
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    dist[start] = 0.0;
    pq.push({0.0, start});

    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[u]) continue;

        for (const Edge& e : graph[u]) {
            int v = e.to;
            double w = e.dist;
            double new_dist = dist[u] + w;
            if (new_dist < dist[v]) {
                dist[v] = new_dist;
                pq.push({new_dist, v});
            }
        }
    }

    return dist;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, q;
        cin >> n >> q;

        vector<Horse> horses(n);
        for (int j = 0; j < n; j++) {
            cin >> horses[j].e >> horses[j].s;
        }

        vector<vector<double>> dist(n, vector<double>(n, INF));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                cin >> dist[j][k];
            }
        }

        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                if (dist[j][k] >= 0) {
                    double time = (double)dist[j][k] / horses[j].s;
                    if (time <= horses[j].e) {
                        dist[j][k] = time;
                    }
                }
            }
        }

        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                for (int l = 0; l < n; l++) {
                    if (dist[k][j] + dist[j][l] < dist[k][l]) {
                        dist[k][l] = dist[k][j] + dist[j][l];
                    }
                }
            }
        }

        cout << "Case #" << i << ":";
        for (int j = 0; j < q; j++) {
            int u, v;
            cin >> u >> v;
            u--; v--;

            double ans = dist[u][v];
            cout << " " << fixed << setprecision(9) << ans;
        }
        cout << endl;
    }

    return 0;
}
