#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

const double eps = 1e-9;

struct Horse {
    double endurance, speed;
};

struct Edge {
    int to;
    double dist;
};

typedef vector<vector<Edge>> Graph;

vector<double> dijkstra(const Graph& g, int s) {
    int n = g.size();
    vector<double> dist(n, -1.0);
    dist[s] = 0.0;
    priority_queue<pair<double, int>> q;
    q.push({0.0, s});
    while (!q.empty()) {
        int u = q.top().second;
        double d = -q.top().first;
        q.pop();
        if (dist[u] - eps > d) continue;
        for (const auto& e : g[u]) {
            int v = e.to;
            double w = e.dist;
            double t = w / horses[u].speed;
            if (horses[u].endurance - eps < w) t += (w - horses[u].endurance) / horses[u].speed + eps;
            if (dist[v] < 0.0 || dist[v] - eps > dist[u] + t) {
                dist[v] = dist[u] + t;
                q.push({-dist[v], v});
            }
        }
    }
    return dist;
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, q;
        cin >> n >> q;
        vector<Horse> horses(n);
        for (int i = 0; i < n; ++i) {
            cin >> horses[i].endurance >> horses[i].speed;
        }
        Graph g(n, vector<Edge>(n));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int d;
                cin >> d;
                if (d >= 0) {
                    g[i][j] = {j, (double)d};
                }
            }
        }
        vector<vector<double>> dist(n, vector<double>(n));
        for (int i = 0; i < n; ++i) {
            dist[i] = dijkstra(g, i);
        }
        cout << "Case #" << case_num << ":";
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            --u, --v;
            double ans = dist[u][v];
            for (int k = 0; k < n; ++k) {
                if (k != u && k != v && dist[u][k] >= 0.0 && dist[k][v] >= 0.0) {
                    ans = min(ans, dist[u][k] + dist[k][v]);
                }
            }
            cout << " " << fixed << setprecision(10) << ans;
        }
        cout << endl;
    }
    return 0;
}
