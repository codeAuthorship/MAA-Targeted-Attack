#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const int INF = 1000000000;

ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/WCG/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s) {
    minc = min(minc, c);
  }
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      string v = "";
      if (s[0] > minc)
        if (s[0] > '1')
          v += (char)(s[0] - 1);
      for (int i = 1; i < s.size(); i++)
        v += '9';
      return v;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  cin >> s;
  fout << solves(s, '0') << '\n';
}

int main() {

  int get;
  cin >> get;
  int i;
  {
    i = 0;
    while (i < get) {
      fout << "Case #" << i + 1 << ": ", solve();
      i++;
    }
  }

  return 0;
}
