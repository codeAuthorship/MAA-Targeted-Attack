#include <bitset>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;
const int INF = 1000000000;
ofstream fout;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL; // NOTES:int64
                      // NOTES:uint64

// NOTES:pi
// NOTES:eps

struct debugger {};

char x[50];

bool containszero(int q) {
  int i = 0;
  while (x[i] == '0') {
    i++;
  }
  while (i < q) {
    if (x[i] == '0')
      return 1;
    i++;
  }
  return false;
}
inline void qrbniemsee(int &j) { x[j] = '9'; }

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/WCG/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out");

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, k, q, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> x;
    bool p = 0;
    q = strlen(x);
    if (!containszero(q)) {
      for (i = q - 1; i > 0; i--) {
        if (x[i] < x[i - 1]) {
          for (j = i; j < q; j++)
            qrbniemsee(j);
          x[i - 1] = (char)(x[i - 1] - 1);
        }
      }
    }
    while (containszero(q)) {
      for (i = 0; i < q; i++) {
        if (x[i] == '0') {
          for (j = i; j < q; j++)
            x[j] = '9';
          x[i - 1] = (char)(x[i - 1] - 1);
          break;
        }
      }
      if (!containszero(q)) {
        for (i = q - 1; i > 0; i--) {
          if (x[i] < x[i - 1]) {
            for (j = i; j < q; j++)
              x[j] = '9';
            x[i - 1] = (char)(x[i - 1] - 1);
          }
        }
      }
    }
    fout << "Case #" << c++ << ": ";
    i = 0;
    while (x[i] == '0') {
      i++;
      continue;
    }
    while (i < q) {
      fout << x[i++];
    }
    fout << "\n";
  }
  return (0);
}
