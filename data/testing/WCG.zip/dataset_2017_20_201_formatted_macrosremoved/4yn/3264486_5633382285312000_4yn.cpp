#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
using namespace std;
ofstream d;

const int INF = ~(1 << 31);
const double pi = acos(-1);

bool check(int a) {
  string s = to_string(a);
  vector<int> k;
  {
    int i = (0);
    while (i < (s.size())) {
      char x = s[i];
      k.push_back(x - '0');
      i++;
    }
  }
  vector<int> get = k;
  sort(get.begin(), get.end());
  for (int i = (0); i < (k.size()); i++)
    if (k[i] != get[i])
      return false;
  return true;
}

int main() {
  d.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/WCG/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");

  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    int x;
    cin >> x;
    {
      int a;
      for (a = x; a >= 0;) {
        if (check(a)) {
          d << "Case #" << i + 1 << ": " << a << endl;
          break;
        }
        a--;
      }
    }
  }
  return 0;
}
