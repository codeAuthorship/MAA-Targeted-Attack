#include <bitset>
#include <cctype>
#include <complex>
#include <deque>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 
using namespace std;

typedef set<int> si;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long ll;            
typedef unsigned long long ULL;  
typedef unsigned uint;

 

struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

char str[50];

inline void nevmxtycmn(int &i) { i++; }

bool containszero(int a) {
  int i = 0;
  while (str[i] == '0')
    nevmxtycmn(i);
  while (i < a) {
    if (str[i] == '0')
      return 1;
    i++;
  }
  return 0;
}
inline void rpkzhyezno(int &a, int &j, int &i) {
  for (j = i; j < a; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

inline void tgsorfrnzx(int &a, int &j, int &i) {
  for (j = i; j < a; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

inline void douutclqnq(int &a, int &j, int &i) {
  if (str[i] < str[i - 1])
    rpkzhyezno(a, j, i);
  i--;
}

int main() {
  ios::sync_with_stdio(1);

 
  int n, i, j, k, a, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    bool p = 0;
    a = strlen(str);
    if (!containszero(a)) {
      for (i = a - 1; i > 0; i--) {
        if (str[i] < str[i - 1])
          tgsorfrnzx(a, j, i);
      }
    }
    while (containszero(a)) {
      for (i = 0; i < a; i++) {
        if (str[i] == '0') {
          for (j = i; j < a; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(a)) {
        {
          i = a - 1;
          while (i > 0)
            douutclqnq(a, j, i);
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < a) {
      cout << str[i++];
    }
    printf("\n");
  }
  return (0);
}
