#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long findLastTidyNumber(long long n) {
    if (isTidy(n)) {
        return n;
    }
    long long lastTidy = n;
    while (!isTidy(lastTidy)) {
        string s = to_string(lastTidy);
        int i = 0;
        while (i < s.length() - 1 && s[i] <= s[i+1]) {
            i++;
        }
        s[i]--;
        for (int j = i+1; j < s.length(); j++) {
            s[j] = '9';
        }
        lastTidy = stoll(s);
    }
    return lastTidy;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long lastTidy = findLastTidyNumber(n);
        cout << "Case #" << i << ": " << lastTidy << endl;
    }
    return 0;
}
