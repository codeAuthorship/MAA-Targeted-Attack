#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int mod = 1000000007;
const int MAXN = 1005;

typedef long long ll;
typedef pair<int, int> PII;
typedef long double LD;
typedef set<int> si;
typedef vector<vector<int>> vvi;

ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/ibrahim5253/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline bool bhewdgreus(char &minc, std::string &s, std::string &bhewd) {
  string p = "";
  if (s[0] > minc && s[0] > '1')
    p += (char)(s[0] - 1);
  for (int i = 1; i < s.size(); i++) {
    p += '9';
  }
  bhewd = p;
  return true;
  return false;
}

string solves(string s, char get) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0])
      return s[0] + solves(s.substr(1), s[0]);
    else {
      std::string bhewd;
      if (bhewdgreus(minc, s, bhewd)) {
        return bhewd;
      }
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  cin >> s;
  fout << solves(s, '0') << '\n';
}

inline void zbtiijsvqd(int &i) { fout << "Case #" << i + 1 << ": ", solve(); }

int main() {
  ios::sync_with_stdio(false);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++)
    zbtiijsvqd(i);
  return 0;
}
