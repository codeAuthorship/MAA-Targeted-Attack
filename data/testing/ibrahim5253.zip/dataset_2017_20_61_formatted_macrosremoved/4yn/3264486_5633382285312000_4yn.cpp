#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;

typedef unsigned long long ull;
typedef vector<int> VI;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef pair<int, int> PII;

typedef vector<PII> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void jksutrhvml(std::string &s, int &j, vector<int> &solve) {
  char t = s[j];
  solve.push_back(t - '0');
}

bool check(int a) {
  string s = to_string(a);
  vector<int> solve;
  {
    int j = (0);
    while (j < (s.size())) {
      jksutrhvml(s, j, solve);
      j++;
    }
  }
  vector<int> ne = solve;
  sort(ne.begin(), ne.end());
  for (int j = (0); j < (solve.size()); j++) {
    if (solve[j] != ne[j])
      return 0;
  }
  return true;
}

int main() {
  cin.sync_with_stdio(false);

  int n;
  cin >> n;
  for (int j = (0); j < (n); j++) {
    int t;
    cin >> t;
    for (int a = t; a >= 0; a--) {
      if (check(a)) {
        cout << "Case #" << j + 1 << ": " << a << endl;
        break;
      }
    }
  }
  return 0;
}
