#include <iostream>
#include <string>

using namespace std;

string find_tidy_number(string n) {
    int last_non_decreasing = -1;
    for (int i = 1; i < n.length(); i++) {
        if (n[i] < n[i-1]) {
            last_non_decreasing = i-1;
            break;
        }
    }

    if (last_non_decreasing == -1) {
        return n;
    }

    n[last_non_decreasing]--;

    for (int i = last_non_decreasing+1; i < n.length(); i++) {
        n[i] = '9';
    }

    int first_non_zero = 0;
    while (n[first_non_zero] == '0') {
        first_non_zero++;
    }
    return n.substr(first_non_zero);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        string tidy = find_tidy_number(n);
        cout << "Case #" << i << ": " << tidy << endl;
    }
    return 0;
}
