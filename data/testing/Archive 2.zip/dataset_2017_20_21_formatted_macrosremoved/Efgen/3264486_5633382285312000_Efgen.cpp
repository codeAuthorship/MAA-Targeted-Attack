#include <bits/stdc++.h>
#include <iostream>
#include <set>
#include <utility>
#include <vector>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<int, int> PII;
typedef vector<int> vi;
typedef long double LD;
typedef set<int> si;

ifstream fin("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/bennikartefla/sammyMaX/A-small-practice.in");
ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/bennikartefla/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline bool uplvcluyqe(char &minc, std::string &s, std::string &uplvc) {
  string res = "";
  if (s[0] > minc)
    if (s[0] > '1')
      res += (char)(s[0] - 1);
  for (int i = 1; i < s.size(); i++)
    res += '9';
  uplvc = res;
  return true;
  return false;
}

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    minc = min(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      std::string uplvc;
      if (uplvcluyqe(minc, s, uplvc)) {
        return uplvc;
      }
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  fin >> s;
  fout << solves(s, '0') << '\n';
}

int main() {
  ios::sync_with_stdio(false);

  int t;
  fin >> t;
  for (int i = 0; i < t; i++)
    fout << "Case #" << i + 1 << ": ", solve();
  return 0;
}
