#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 0; i < len - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    long long last_tidy = n;
    while (!is_tidy(last_tidy)) {
        string s = to_string(last_tidy);
        int len = s.length();
        for (int i = len - 1; i > 0; i--) {
            if (s[i] < s[i-1]) {
                int j = i-1;
                while (j > 0 && s[j-1] == s[j]) {
                    j--;
                }
                s[j]--;
                for (int k = j+1; k < len; k++) {
                    s[k] = '9';
                }
            }
        }
        last_tidy = stoll(s);
    }
    return last_tidy;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        long long last_tidy = last_tidy_number(n);
        cout << "Case #" << t << ": " << last_tidy << endl;
    }
    return 0;
}
