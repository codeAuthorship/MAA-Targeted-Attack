#include <bits/stdc++.h>
#define ld long double
using namespace std;

const ld eps = 1e-9, inf = 1e18;

int n, q, T;
ld e[105], s[105], d[105][105];

ld dist(ld t, ld x, ld y) {
    return t + sqrt(x * x + y * y) / s[n];
}

void floyd_warshall() {
    for(int k = 1; k <= n; ++k) {
        for(int i = 1; i <= n; ++i) {
            for(int j = 1; j <= n; ++j) {
                if(d[i][k] == -1 || d[k][j] == -1) continue;
                if(d[i][j] == -1 || d[i][j] > d[i][k] + d[k][j]) {
                    d[i][j] = d[i][k] + d[k][j];
                }
            }
        }
    }
}

ld dijkstra(int st, int en) {
    priority_queue<pair<ld, int>> pq;
    vector<ld> dist(n+1, inf);
    dist[st] = 0.0;
    pq.push({0.0, st});
    while(!pq.empty()) {
        int u = pq.top().second;
        ld time = -pq.top().first;
        pq.pop();
        if(u == en) return time;
        if(dist[u] < time) continue;
        for(int v = 1; v <= n; ++v) {
            if(d[u][v] == -1) continue;
            ld new_time = dist(time, d[u][v], e[u]);
            if(new_time + eps < dist[v]) {
                dist[v] = new_time;
                pq.push({-new_time, v});
            }
        }
    }
    return -1.0;
}

int main() {
    ios::sync_with_stdio(false); cin.tie(nullptr);
    cin >> T;
    for(int t = 1; t <= T; ++t) {
        cin >> n >> q;
        for(int i = 1; i <= n; ++i) cin >> e[i] >> s[i];
        for(int i = 1; i <= n; ++i) {
            for(int j = 1; j <= n; ++j) {
                cin >> d[i][j];
            }
        }
        floyd_warshall();
        cout << "Case #" << t << ":";
        for(int i = 1; i <= q; ++i) {
            int u, v; cin >> u >> v;
            cout << " " << fixed << setprecision(9) << dijkstra(u, v);
        }
        cout << endl;
    }
    return 0;
}
