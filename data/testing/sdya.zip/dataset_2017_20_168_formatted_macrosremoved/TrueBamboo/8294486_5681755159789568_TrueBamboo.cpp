#include <iostream>
#include <iomanip>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

const double INF = 1e18;

struct Horse {
    int endurance;
    double speed;
};

struct Edge {
    int u, v;
    double w;
};

struct State {
    int u;
    double time;
    bool operator<(const State& other) const {
        return time > other.time;
    }
};

double dijkstra(const vector<vector<Edge>>& graph, const vector<Horse>& horses, int source, int target) {
    int n = graph.size();
    vector<double> dist(n, INF);
    priority_queue<State> pq;
    dist[source] = 0;
    pq.push({source, 0});
    while (!pq.empty()) {
        State curr = pq.top();
        pq.pop();
        if (curr.u == target) {
            return curr.time;
        }
        if (curr.time > dist[curr.u]) {
            continue;
        }
        for (const Edge& e : graph[curr.u]) {
            int v = e.v;
            double w = e.w;
            double t;
            if (horses[curr.u].endurance >= w) {
                t = w / horses[curr.u].speed;
            } else {
                t = (horses[curr.u].endurance / horses[curr.u].speed) + ((w - horses[curr.u].endurance) / horses[v].speed);
            }
            if (curr.time + t < dist[v]) {
                dist[v] = curr.time + t;
                pq.push({v, dist[v]});
            }
        }
    }
    return -1;  
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, q;
        cin >> n >> q;
        vector<Horse> horses(n);
        for (int i = 0; i < n; ++i) {
            cin >> horses[i].endurance >> horses[i].speed;
        }
        vector<vector<Edge>> graph(n, vector<Edge>(n, {-1, -1, INF}));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int d;
                cin >> d;
                if (d != -1) {
                    graph[i][j] = {i, j, d};
                }
            }
        }
        for (int k = 0; k < n; ++k) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    graph[i][j].w = min(graph[i][j].w, graph[i][k].w + graph[k][j].w);
                }
            }
        }
        cout << "Case #" << case_num << ":";
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            --u, --v;
            double time = dijkstra(graph, horses, u, v);
            cout << " " << fixed << setprecision(9) << time;
        }
        cout << "\n";
    }
    return 0;
}
