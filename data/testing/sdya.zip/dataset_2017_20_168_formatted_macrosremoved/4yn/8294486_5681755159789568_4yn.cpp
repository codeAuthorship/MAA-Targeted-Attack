#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef long double td_ld;
typedef pair<int, int> ii;

typedef vector<ii> vii;
typedef long long ll;
const long double INF = 1000000000000;
const long double pi = acos(-1);
typedef pair<long double, int> di;

int mxdist[120];
int conspeed[120];
long double matrix[120][120];
long double matrix2[120][120];

void fill(int at) {
  bool vis[120];
  memset(vis, 0, sizeof(vis));
  vis[at] = 1;
  priority_queue<pair<long double, int>, vector<di>, greater<di>> q;
  q.push(pair<long double, int>(0, at));
  while (!q.empty()) {
    int cur = q.top().second;
    td_ld range = q.top().first;
    q.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix[cur][i] != -1 && i != cur)
        if (!vis[i]) {
          td_ld thedist = matrix[cur][i];
          range += thedist;
          if (range > mxdist[at]) {
            range -= thedist;
            continue;
          }
          matrix2[at][i] = min(range / conspeed[at], matrix2[at][i]);
          q.push(pair<long double, int>(range, i));
          range -= thedist;
        }
    }
  }
}

long double query(int start, int end) {
  priority_queue<di, vector<di>, greater<di>> pq;
  pq.push(di(0, start));
  vector<long double> dist(150);
  bool vis[150];
  for (int i = (0); i < (150); i++)
    dist[i] = INF;
  memset(vis, 0, sizeof(vis));
  dist[start] = 0;
  for (; !pq.empty();) {
    di cur = pq.top();
    pq.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix2[cur.second][i] != -1) {
        td_ld ne = min(dist[i], cur.first + matrix2[cur.second][i]);
        if (ne >= dist[i])
          continue;
        dist[i] = ne;
        pq.push(di(dist[i], i));
      }
    }
  }
  return dist[end];
}

inline void irsvfybwmh(std::ofstream &fout, vector<ii> &solve, int &i) {
  fout << setprecision(9) << fixed
       << query(solve[i].first - 1, solve[i].second - 1) << " ";
}

inline void zbawugabxr(int &i) {
  int dist, speed;
  cin >> dist >> speed;
  mxdist[i] = dist;
  conspeed[i] = speed;
}

inline void pqemfzaivi(int &u, std::ofstream &fout) {
  int n, q;
  memset(mxdist, 0, sizeof(mxdist));
  memset(conspeed, 0, sizeof(conspeed));
  for (int i = (0); i < (120); i++)
    for (int a = (0); a < (120); a++)
      matrix[i][a] = -1;
  for (int i = (0); i < (120); i++)
    for (int a = (0); a < (120); a++)
      matrix2[i][a] = INF;
  cin >> n >> q;
  for (int i = (0); i < (n); i++)
    zbawugabxr(i);
  for (int i = (0); i < (n); i++)
    for (int a = (0); a < (n); a++)
      cin >> matrix[i][a];
  for (int i = (0); i < (n); i++)
    fill(i);
  for (int i = (0); i < (120); i++)
    for (int a = (0); a < (120); a++)
      if (matrix2[i][a] == INF)
        matrix2[i][a] = -1;
  vector<ii> solve(q);
  for (int i = (0); i < (q); i++)
    cin >> solve[i].first >> solve[i].second;
  fout << "Case #" << u + 1 << ": ";
  for (int i = (0); i < (q); i++)
    irsvfybwmh(fout, solve, i);
  fout << endl;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  for (int u = (0); u < (t); u++)
    pqemfzaivi(u, fout);
  return 0;
}
