#include <bits/stdc++.h>
using namespace std;

const double eps = 1e-9;

struct Edge {
    int to;
    double cost;
};
typedef vector<vector<Edge>> Graph;

double dijkstra(const Graph& g, int s, int t, const vector<int>& E, const vector<int>& S) {
    int n = g.size();
    vector<double> d(n, numeric_limits<double>::infinity());
    d[s] = 0;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    pq.push(make_pair(0, s));
    while (!pq.empty()) {
        double dist = pq.top().first;
        int u = pq.top().second;
        pq.pop();
        if (u == t) return dist;
        if (dist > d[u]) continue;
        for (const auto& e : g[u]) {
            int v = e.to;
            double cost = e.cost / S[u];
            if (E[u] < cost + eps) continue;
            double newDist = dist + cost;
            if (newDist < d[v]) {
                d[v] = newDist;
                pq.push(make_pair(newDist, v));
            }
        }
        if (E[u] >= dist + eps) {
            double newDist = dist + (g[u][u].cost / S[u]);
            if (newDist < d[u]) {
                d[u] = newDist;
                pq.push(make_pair(newDist, u));
            }
        }
    }
    return numeric_limits<double>::infinity();
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, Q;
        cin >> N >> Q;
        vector<int> E(N), S(N);
        for (int i = 0; i < N; ++i) cin >> E[i] >> S[i];
        Graph g(N, vector<Edge>(N));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                int d;
                cin >> d;
                if (d != -1) {
                    g[i][j] = {j, d};
                }
            }
        }
        for (int i = 0; i < Q; ++i) {
            int u, v;
            cin >> u >> v;
            --u; --v;
            double dist = dijkstra(g, u, v, E, S);
            cout << "Case #" << t << ": " << fixed << setprecision(8) << dist << endl;
        }
    }
    return 0;
}
