#include <bits/stdc++.h>
using namespace std;

const double eps = 1e-9;

struct Horse {
    long long e;  
    long long s;
};

struct Edge {
    int to;
    long long dist;
};

vector<vector<Edge>> adj;
vector<Horse> horses;
int n;

void add_edge(int from, int to, long long dist) {
    adj[from].push_back({to, dist});
    adj[to].push_back({from, dist});
}

void dijkstra(int start, vector<double>& dist) {
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<>> pq;
    pq.push({0.0, start});
    dist[start] = 0.0;
    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (d > dist[u]) continue;
        for (auto [v, w] : adj[u]) {
            double new_dist = d + (double)w / horses[u].s;
            if (new_dist < dist[v] - eps) {
                dist[v] = new_dist;
                pq.push({new_dist, v});
            }
        }
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int Q;
        cin >> n >> Q;
        horses.resize(n);
        for (int i = 0; i < n; ++i) {
            cin >> horses[i].e >> horses[i].s;
        }
        adj.assign(n, {});
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                long long dist;
                cin >> dist;
                if (dist != -1) add_edge(i, j, dist);
            }
        }
        cout << "Case #" << t << ":";
        while (Q--) {
            int u, v;
            cin >> u >> v;
            --u, --v;
            vector<double> dist(n, 1e18);
            dijkstra(u, dist);
            cout << " " << fixed << setprecision(10) << dist[v];
        }
        cout << endl;
    }
    return 0;
}
