#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;

const ll INF = 1e18;

int N, Q;
vector<ll> E, S;
vector<vector<ll>> D;

double travel_time(ll d, ll s) {
    return (double)d / (double)s;
}

double dijkstra(int u, int v) {
    priority_queue<pli, vector<pli>, greater<pli>> pq;
    vector<ll> dist(N, INF);
    pq.push(make_pair(0, u));
    dist[u] = 0;
    while (!pq.empty()) {
        int x = pq.top().second;
        ll d = pq.top().first;
        pq.pop();
        if (d > dist[x]) continue;
        if (x == v) return (double)d / (double)S[x];
        for (int y = 0; y < N; y++) {
            if (y == x || D[x][y] == -1) continue;
            ll w = D[x][y];
            if (w > E[x]) continue;
            double t = travel_time(w, S[x]);
            if (dist[x] + w < dist[y]) {
                dist[y] = dist[x] + w;
                pq.push(make_pair(dist[y], y));
            }
            if (E[y] >= dist[y] + w && dist[x] + w + travel_time(dist[y] + w - E[y], S[y]) < dist[y]) {
                dist[y] = dist[x] + w + (dist[y] + w - E[y]) / (double)S[y];
                pq.push(make_pair(dist[y], y));
            }
        }
    }
    return -1;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> Q;
        E.resize(N);
        S.resize(N);
        D.resize(N, vector<ll>(N));
        for (int i = 0; i < N; i++) cin >> E[i] >> S[i];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cin >> D[i][j];
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < Q; i++) {
            int u, v;
            cin >> u >> v;
            u--; v--;
            cout << " " << fixed << setprecision(10) << dijkstra(u, v);
        }
        cout << endl;
    }
    return 0;
}
