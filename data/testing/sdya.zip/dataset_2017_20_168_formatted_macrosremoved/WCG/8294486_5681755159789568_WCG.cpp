#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>
#include <cmath>

using namespace std;

const double INF = 1e18;

struct Horse {
    int e, s;
};

struct Edge {
    int u, v;
    double w;
};

struct State {
    int u;
    double t;
};

bool operator>(const State& a, const State& b) {
    return a.t > b.t;
}

double dijkstra(const vector<vector<Edge>>& adj, const vector<Horse>& horses, int s, int t) {
    int n = adj.size();
    vector<double> dist(n, INF);
    priority_queue<State, vector<State>, greater<State>> pq;
    dist[s] = 0;
    pq.push({s, 0});
    while (!pq.empty()) {
        State cur = pq.top();
        pq.pop();
        if (cur.u == t) {
            return cur.t;
        }
        if (cur.t > dist[cur.u]) {
            continue;
        }
        for (const Edge& e : adj[cur.u]) {
            double t = e.w / horses[cur.u].s;
            if (cur.t + t <= horses[e.v].e && cur.t + t < dist[e.v]) {
                dist[e.v] = cur.t + t;
                pq.push({e.v, dist[e.v]});
            }
        }
    }
    return -1;
}

void solve(int case_num) {
    int n, q;
    cin >> n >> q;
    vector<Horse> horses(n);
    for (Horse& h : horses) {
        cin >> h.e >> h.s;
    }
    vector<vector<int>> dist(n, vector<int>(n));
    for (vector<int>& row : dist) {
        for (int& d : row) {
            cin >> d;
        }
    }
    vector<vector<Edge>> adj(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (dist[i][j] != -1) {
                double t = (double) dist[i][j] / horses[i].s;
                adj[i].push_back({i, j, t});
            }
        }
    }
    cout << "Case #" << case_num << ":";
    for (int i = 0; i < q; i++) {
        int s, t;
        cin >> s >> t;
        double ans = dijkstra(adj, horses, s - 1, t - 1);
        cout << " " << fixed << setprecision(9) << ans;
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve(i);
    }
    return 0;
}
