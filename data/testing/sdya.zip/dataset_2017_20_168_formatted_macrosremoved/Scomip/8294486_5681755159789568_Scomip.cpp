#include <bits/stdc++.h>
#define ll long long
using namespace std;

const double eps = 1e-7;
const int MAXN = 105;

int N, Q;
ll E[MAXN], S[MAXN], D[MAXN][MAXN];
double dis[MAXN][MAXN], dp[MAXN][MAXN];

void floyd() {
    for (int k = 1; k <= N; ++k) {
        for (int i = 1; i <= N; ++i) {
            for (int j = 1; j <= N; ++j) {
                if (D[i][k] == -1 || D[k][j] == -1) continue;
                if (D[i][j] == -1 || D[i][k] + D[k][j] < D[i][j]) {
                    D[i][j] = D[i][k] + D[k][j];
                }
            }
        }
    }
}

double calc(int u, int v, double t) {
    if (u == v) return 0;
    if (t > E[u] + eps) return 1e18;
    if (dp[u][v] > -eps) return dp[u][v];
    dp[u][v] = 1e18;
    for (int i = 1; i <= N; ++i) {
        if (i == u || D[u][i] == -1) continue;
        double time = D[u][i] / (double)S[u];
        double rem = t + time - E[u];
        if (rem > eps) time += rem;
        dp[u][v] = min(dp[u][v], time + calc(i, v, time));
    }
    return dp[u][v];
}

void solve(int tc) {
    memset(D, -1, sizeof(D));
    memset(dp, -1, sizeof(dp));
    cin >> N >> Q;
    for (int i = 1; i <= N; ++i) {
        cin >> E[i] >> S[i];
    }
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= N; ++j) {
            cin >> D[i][j];
            if (D[i][j] != -1) {
                dis[i][j] = (double)D[i][j] / S[i];
            } else {
                dis[i][j] = 1e18;
            }
        }
    }
    floyd();
    cout << "Case #" << tc << ": ";
    for (int i = 1; i <= Q; ++i) {
        int u, v;
        cin >> u >> v;
        double ans = dis[u][v];
        for (int j = 1; j <= N; ++j) {
            if (E[j] >= dis[u][j] + dis[j][v] && D[u][j] != -1 && D[j][v] != -1) {
                ans = min(ans, calc(j, v, dis[u][j]));
            }
        }
        cout << fixed << setprecision(7) << ans << " ";
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int tc = 1; tc <= T; ++tc) {
        solve(tc);
    }
    return 0;
}
