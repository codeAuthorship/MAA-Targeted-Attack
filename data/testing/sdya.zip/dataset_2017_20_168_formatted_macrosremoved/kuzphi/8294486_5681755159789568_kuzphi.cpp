#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int T, N, Q;
vector<pair<int, int>> cities;
vector<vector<int>> dist;

double travel_time(int u, int v, int horse) {
    double d = dist[u][v];
    double s = cities[horse].second;
    double e = cities[horse].first;
    if (d > e) return INF;
    return d / s;
}

double solve(int u, int v) {
    vector<vector<double>> dp(N, vector<double>(N, INF));
    for (int horse = 0; horse < N; horse++) {
        dp[u][v] = min(dp[u][v], travel_time(u, v, horse));
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (i == j || dist[i][j] == -1) continue;
            for (int horse1 = 0; horse1 < N; horse1++) {
                if (dp[u][i] == INF || travel_time(i, j, horse1) == INF) continue;
                for (int horse2 = 0; horse2 < N; horse2++) {
                    if (dp[j][v] == INF || travel_time(j, v, horse2) == INF) continue;
                    double time = dp[u][i] + travel_time(i, j, horse1) + dp[j][v] + travel_time(j, v, horse2);
                    dp[u][v] = min(dp[u][v], time);
                }
            }
        }
    }
    return dp[u][v];
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> Q;
        cities.clear();
        for (int i = 0; i < N; i++) {
            int e, s;
            cin >> e >> s;
            cities.push_back({e, s});
        }
        dist.clear();
        for (int i = 0; i < N; i++) {
            vector<int> row;
            for (int j = 0; j < N; j++) {
                int d;
                cin >> d;
                row.push_back(d);
            }
            dist.push_back(row);
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < Q; i++) {
            int u, v;
            cin >> u >> v;
            u--; v--;
            double ans = solve(u, v);
            cout << " " << ans;
        }
        cout << "\n";
    }
    return 0;
}
