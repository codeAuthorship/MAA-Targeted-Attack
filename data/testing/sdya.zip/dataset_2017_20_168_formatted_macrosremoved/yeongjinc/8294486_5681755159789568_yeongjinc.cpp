#include <bits/stdc++.h>
#define INF 1e18 
using namespace std;
typedef long long ll;

struct Horse {
    ll endurance;
    ll speed;
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, Q;
        cin >> N >> Q;

        Horse horses[N];
        for (int i = 0; i < N; i++) {
            cin >> horses[i].endurance >> horses[i].speed;
        }

        ll distances[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cin >> distances[i][j];
            }
        }

        cout << "Case #" << t << ":";
        for (int q = 0; q < Q; q++) {
            int start, end;
            cin >> start >> end;
            start--, end--;

            ll dist[N];
            bool visited[N];
            for (int i = 0; i < N; i++) {
                dist[i] = INF;
                visited[i] = false;
            }
            dist[start] = 0;

            for (int i = 0; i < N - 1; i++) {
                ll minDist = INF;
                int u;
                for (int j = 0; j < N; j++) {
                    if (!visited[j] && dist[j] < minDist) {
                        minDist = dist[j];
                        u = j;
                    }
                }

                visited[u] = true;

                for (int v = 0; v < N; v++) {
                    if (distances[u][v] != -1) {
                        ll time = (ll)distances[u][v] * horses[u].endurance / horses[u].speed;
                        if (horses[u].endurance >= distances[u][v]) {
                            if (!visited[v] && dist[u] + time < dist[v]) {
                                dist[v] = dist[u] + time;
                            }
                        } else {
                            for (int w = 0; w < N; w++) {
                                if (w != u && distances[w][v] != -1 && horses[w].endurance >= distances[w][v]) {
                                    ll time1 = (ll)distances[u][w] * horses[u].endurance / horses[u].speed;
                                    ll time2 = (ll)distances[w][v] * horses[w].endurance / horses[w].speed;
                                    if (!visited[v] && dist[u] + time1 + time2 < dist[v]) {
                                        dist[v] = dist[u] + time1 + time2;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            cout << " " << fixed << setprecision(9) << (double)dist[end] / 3600;
        }

        cout << endl;
    }

    return 0;
  }
