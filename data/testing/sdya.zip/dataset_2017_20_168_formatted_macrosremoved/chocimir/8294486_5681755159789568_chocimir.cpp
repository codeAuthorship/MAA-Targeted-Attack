#include <bits/stdc++.h>
using namespace std;

const double eps = 1e-9;

struct Horse {
    double endurance, speed;
};

struct Edge {
    int to;
    double dist;
};

int n, q;
vector<Horse> horses;
vector<vector<Edge>> adj;

double dijkstra(int src, int dst) {
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<>> pq;
    vector<double> dist(n, numeric_limits<double>::infinity());
    dist[src] = 0;
    pq.emplace(0, src);
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (u == dst) {
            return d;
        }
        if (d > dist[u] + eps) {
            continue;
        }
        for (const auto& [v, w] : adj[u]) {
            double new_dist = d + w / horses[u].speed;
            if (new_dist < dist[v]) {
                dist[v] = new_dist;
                pq.emplace(new_dist, v);
            }
        }
    }
    return -1;  
}

void solve() {
    cin >> n >> q;
    horses.resize(n);
    for (auto& h : horses) {
        cin >> h.endurance >> h.speed;
    }
    adj.assign(n, {});
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int d;
            cin >> d;
            if (d != -1 && i != j) {
                double t = d / horses[i].speed;
                adj[i].push_back({j, t});
            }
        }
    }
    for (int i = 1; i <= q; ++i) {
        int u, v;
        cin >> u >> v;
        --u, --v;
        cout << "Case #" << i << ": " << fixed << setprecision(9) << dijkstra(u, v) << '\n';
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        solve();
    }
    return 0;
}
