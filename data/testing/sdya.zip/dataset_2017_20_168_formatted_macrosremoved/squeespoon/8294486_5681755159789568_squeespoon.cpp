#include <bits/stdc++.h>
using namespace std;
using ld = long double;
const ld EPS = 1e-9;

struct Edge {
  int to;
  ld time;
  Edge(int to, ld time) : to(to), time(time) {}
};

bool operator<(const Edge& a, const Edge& b) {
  return a.time > b.time;
}

int n;
vector<pair<ld, ld>> horses;
vector<vector<int>> dist;
vector<vector<int>> adj;

void dijkstra(int start, vector<ld>& d) {
  priority_queue<Edge> pq;
  d[start] = 0;
  pq.emplace(start, 0);
  while (!pq.empty()) {
    auto [u, time] = pq.top(); pq.pop();
    if (time > d[u] + EPS) continue;
    for (auto v : adj[u]) {
      ld new_time = time + (ld)dist[u][v] / horses[u].second;
      if (new_time < d[v] - EPS) {
        d[v] = new_time;
        pq.emplace(v, new_time);
      }
    }
  }
}

void solve() {
  int q;
  cin >> n >> q;
  horses.resize(n);
  for (int i = 0; i < n; ++i) {
    cin >> horses[i].first >> horses[i].second;
  }
  dist.resize(n, vector<int>(n));
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      cin >> dist[i][j];
    }
  }
  vector<vector<ld>> d(n, vector<ld>(n, 1e18));
  adj.resize(n);
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      if (dist[i][j] != -1 && horses[i].first >= dist[i][j]) {
        adj[i].push_back(j);
      }
    }
  }
  for (int i = 0; i < n; ++i) {
    dijkstra(i, d[i]);
  }
  cout << "Case #" << ++cases << ":";
  while (q--) {
    int u, v;
    cin >> u >> v;
    --u, --v;
    cout << " " << fixed << setprecision(10) << d[u][v];
  }
  cout << "\n";
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int t;
  cin >> t;
  int cases = 0;
  while (t--) {
    solve();
  }

  return 0;
}
