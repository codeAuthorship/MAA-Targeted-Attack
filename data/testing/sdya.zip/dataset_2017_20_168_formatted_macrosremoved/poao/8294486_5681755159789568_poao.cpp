#include <bits/stdc++.h>
using namespace std;

const double inf = 1e18;

struct Horse {
  int e;
  int s;
};

struct Edge {
  int u;
  int v;
  int d;
};

struct Query {
  int u;
  int v;
};

vector<int> dijkstra(int s, int n, const vector<vector<Edge>>& adj) {
  vector<int> dist(n, -1);
  priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
  pq.push({0, s});
  while (!pq.empty()) {
    int d = pq.top().first;
    int u = pq.top().second;
    pq.pop();
    if (dist[u] != -1) continue;
    dist[u] = d;
    for (const auto& e : adj[u]) {
      if (dist[e.v] == -1) {
        pq.push({d + e.d, e.v});
      }
    }
  }
  return dist;
}

double calc_time(const Horse& h, int d) {
  return (double) d / h.s + (double) d / h.e;
}

void solve() {
  int n, q;
  cin >> n >> q;

  vector<Horse> horses(n);
  for (int i = 0; i < n; i++) {
    cin >> horses[i].e >> horses[i].s;
  }

  vector<vector<Edge>> adj(n);
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      int d;
      cin >> d;
      if (d != -1) {
        adj[i].push_back({i, j, d});
      }
    }
  }

  vector<Query> queries(q);
  for (int i = 0; i < q; i++) {
    cin >> queries[i].u >> queries[i].v;
    queries[i].u--; queries[i].v--;
  }

  vector<vector<double>> dp(n, vector<double>(n, inf));
  for (int i = 0; i < n; i++) {
    vector<int> dist = dijkstra(i, n, adj);
    for (int j = 0; j < n; j++) {
      if (dist[j] != -1) {
        dp[i][j] = calc_time(horses[i], dist[j]);
      }
    }
  }

  for (int k = 0; k < n; k++) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
      }
    }
  }

  cout << fixed << setprecision(9);
  for (int i = 0; i < q; i++) {
    cout << " " << dp[queries[i].u][queries[i].v];
  }
  cout << "\n";
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int t;
  cin >> t;
  for (int i = 1; i <= t; i++) {
    cout << "Case #" << i << ":";
    solve();
  }

  return 0;
}
