#include <iostream>
#include <queue>
#include <vector>
#include <iomanip>
#include <cmath>
using namespace std;

const double INF = 1e18;

struct Horse {
    int distance, speed;
};

struct Edge {
    int from, to;
    double weight;
};

void dijkstra(int s, vector<vector<Edge>>& adj, vector<double>& dist) {
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> pq;
    dist[s] = 0;
    pq.push({0, s});
    while (!pq.empty()) {
        int u = pq.top().second;
        double d = pq.top().first;
        pq.pop();
        if (d > dist[u]) continue;
        for (const auto& e : adj[u]) {
            int v = e.to;
            double w = e.weight;
            if (dist[v] > dist[u] + w) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int n, q;
        cin >> n >> q;
        vector<Horse> horses(n);
        vector<vector<Edge>> adj(n);
        for (int i = 0; i < n; ++i) {
            cin >> horses[i].distance >> horses[i].speed;
        }
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int d;
                cin >> d;
                if (d != -1) {
                    double w = static_cast<double>(d) / horses[i].speed;
                    adj[i].push_back({i, j, w});
                }
            }
        }
        for (int k = 0; k < n; ++k) {
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (adj[i][k].weight != INF && adj[k][j].weight != INF) {
                        adj[i][j].weight = min(adj[i][j].weight, adj[i][k].weight + adj[k][j].weight);
                    }
                }
            }
        }
        cout << "Case #" << t << ": ";
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            --u, --v;
            double ans = INF;
            for (int j = 0; j < n; ++j) {
                double t1 = adj[u][j].weight;
                double t2 = adj[j][v].weight;
                double d1 = horses[j].distance - adj[u][j].weight * horses[j].speed;
                double d2 = horses[j].distance - adj[j][v].weight * horses[j].speed;
                if (d1 >= 0 && d2 >= 0) {
                    double t = t1 + t2 + d2 / horses[j].speed;
                    ans = min(ans, t);
                }
            }
            cout << fixed << setprecision(9) << ans << " ";
        }
        cout << endl;
    }
    return 0;
}
