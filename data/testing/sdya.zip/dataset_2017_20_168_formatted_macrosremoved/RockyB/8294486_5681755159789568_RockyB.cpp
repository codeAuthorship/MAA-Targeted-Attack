#include <bits/stdc++.h>
using namespace std;
#define ll long long

const int INF = 1e9;

struct horse {
    int e, s; 
};

horse horses[105];
int d[105][105];

void solve(int t) {
    int n, q;
    cin >> n >> q;
    for (int i = 1; i <= n; i++) {
        cin >> horses[i].e >> horses[i].s;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> d[i][j];
        }
    }
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (d[i][k] != -1 && d[k][j] != -1) {
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                }
            }
        }
    }
    cout << "Case #" << t << ":";
    for (int i = 0; i < q; i++) {
        int u, v;
        cin >> u >> v;
        double ans = (double) d[u][v] / horses[u].s;
        priority_queue<pair<double, int>> pq;
        pq.push({-horses[u].e, u});
        unordered_set<int> visited;
        while (!pq.empty()) {
            auto [time, curr] = pq.top();
            pq.pop();
            if (visited.count(curr)) continue;
            visited.insert(curr);
            time = -time;
            if (curr == v) {
                ans = min(ans, time / (double) horses[v].s);
                break;
            }
            for (int j = 1; j <= n; j++) {
                if (d[curr][j] != -1 && curr != j) {
                    double dist = d[curr][j];
                    double new_time = dist / (double) horses[curr].s;
                    if (new_time + time < ans) {
                        pq.push({-(time + new_time), j});
                    }
                }
            }
        }
        cout << " " << fixed << setprecision(8) << ans;
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        solve(t);
    }
    return 0;
}
