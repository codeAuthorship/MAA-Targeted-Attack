#include <bits/stdc++.h>
using namespace std;

const int MAXN = 105;
const double INF = 1e15;
int n, Q, u[MAXN], v[MAXN];
double e[MAXN], s[MAXN], d[MAXN][MAXN], dist[MAXN][MAXN];
double dp[MAXN][MAXN], speed[MAXN][MAXN];

void floyd() {
    for (int k = 1; k <= n; ++k)
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                if (d[i][k] != -1 && d[k][j] != -1 && (d[i][j] == -1 || d[i][j] > d[i][k] + d[k][j]))
                    d[i][j] = d[i][k] + d[k][j];
}

double getTime(int u, int v, double len) {
    if (len <= e[u])
        return len / s[u];
    double t1 = e[u] / s[u], t2 = (len - e[u]) / speed[u][v], t3 = (e[v] - len) / s[v];
    return t1 + t2 + t3;
}

void solve(int tc) {
    cin >> n >> Q;
    for (int i = 1; i <= n; ++i)
        cin >> e[i] >> s[i];
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) {
            cin >> d[i][j];
            if (d[i][j] != -1)
                dist[i][j] = d[i][j] * 1.0 / s[i];
            else
                dist[i][j] = INF;
        }
    floyd();
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) {
            if (i == j)
                speed[i][j] = s[i];
            else if (d[i][j] == -1)
                speed[i][j] = INF;
            else
                speed[i][j] = d[i][j] * 1.0 / (dist[i][j] + getTime(i, j, dist[i][j]));
        }
    cout << "Case #" << tc << ":";
    while (Q--) {
        int u, v;
        cin >> u >> v;
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                dp[i][j] = INF;
        dp[u][0] = 0;
        for (int k = 1; k <= n; ++k)
            for (int i = 1; i <= n; ++i)
                for (int j = 1; j <= n; ++j)
                    dp[j][k] = min(dp[j][k], dp[i][k - 1] + getTime(i, j, d[i][j]));
        cout << " " << fixed << setprecision(9) << dp[v][n - 1];
    }
    cout << "\n";
}

int main() {
    int t;
    cin >> t;
    for (int tc = 1; tc <= t; ++tc)
        solve(tc);
    return 0;
}
