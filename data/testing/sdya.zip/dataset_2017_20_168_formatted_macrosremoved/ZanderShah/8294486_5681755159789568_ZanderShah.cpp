#include <bits/stdc++.h>
#define ld long double
using namespace std;

const int MAXN = 105;
const ld INF = 1e20L;

int N, Q;
ld E[MAXN], S[MAXN], D[MAXN][MAXN], dist[MAXN][MAXN];
ld dp[MAXN][MAXN];

ld time(ld d, ld e, ld s) {
    ld t = d / s;
    if (t < e) {
        return t;
    } else {
        return e + (d - e * s) / (2 * s);
    }
}

void floyd_warshall() {
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            if (i == j) {
                dist[i][j] = 0;
            } else if (D[i][j] != -1) {
                dist[i][j] = time(D[i][j], E[i], S[i]);
            } else {
                dist[i][j] = INF;
            }
        }
    }

    for (int k = 1; k <= N; k++) {
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= N; j++) {
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
            }
        }
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> N >> Q;

        for (int i = 1; i <= N; i++) {
            cin >> E[i] >> S[i];
        }

        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= N; j++) {
                cin >> D[i][j];
            }
        }

        floyd_warshall();

        cout << "Case #" << t << ":";
        for (int i = 1; i <= Q; i++) {
            int U, V;
            cin >> U >> V;

            for (int j = 1; j <= N; j++) {
                for (int k = 1; k <= N; k++) {
                    if (D[j][k] != -1 && dist[U][j] != INF && dist[k][V] != INF) {
                        ld time_j_to_k = time(D[j][k], E[j], S[j]);
                        dp[j][k] = dist[U][j] + time_j_to_k + dist[k][V];
                    } else {
                        dp[j][k] = INF;
                    }
                }
            }

            for (int k = 1; k <= N; k++) {
                for (int j = 1; j <= N; j++) {
                    for (int l = 1; l <= N; l++) {
                        dp[j][l] = min(dp[j][l], dp[j][k] + dp[k][l]);
                    }
                }
            }

            cout << " " << fixed << setprecision(10) << dp[U][V];
        }

        cout << endl;
    }

    return 0;
}
