#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const double eps = 1e-9;

struct Horse {
    ll e, s;
};

struct Edge {
    int v; ll w;
};

bool operator<(const Edge& e1, const Edge& e2) {
    return e1.w > e2.w;
}

double dijkstra(const vector<vector<Edge>>& adj, const vector<Horse>& horses, int s, int t) {
    int n = adj.size();
    vector<double> dist(n, 1e18);
    dist[s] = 0.0;
    priority_queue<Edge> pq;
    pq.push({s, 0});
    while (!pq.empty()) {
        int u = pq.top().v; ll d = pq.top().w; pq.pop();
        if (d > dist[u] + eps) continue;
        if (u == t) break;
        for (const auto& e : adj[u]) {
            int v = e.v; ll w = e.w;
            double t = (double) w / horses[u].s;
            if (horses[u].e >= w) {
                if (dist[v] > dist[u] + t) {
                    dist[v] = dist[u] + t;
                    pq.push({v, dist[v]});
                }
            } else {
                double r = (double) horses[u].e / horses[u].s;
                if (dist[v] > dist[u] + r + (double) (w - horses[u].e) / horses[v].s) {
                    dist[v] = dist[u] + r + (double) (w - horses[u].e) / horses[v].s;
                    pq.push({v, dist[v]});
                }
            }
        }
    }
    return dist[t];
}

int main() {
    int T; cin >> T;
    for (int t = 1; t <= T; t++) {
        int n, q; cin >> n >> q;
        vector<Horse> horses(n);
        for (int i = 0; i < n; i++) {
            cin >> horses[i].e >> horses[i].s;
        }
        vector<vector<Edge>> adj(n + n);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                ll d; cin >> d;
                if (d != -1) {
                    adj[i].push_back({n + j, d});
                    adj[n + j].push_back({i, d});
                }
            }
        }
        cout << "Case #" << t << ":";
        for (int i = 0; i < q; i++) {
            int u, v; cin >> u >> v; u--; v--;
            double ans = dijkstra(adj, horses, u, v + n);
            printf(" %.8lf", ans);
        }
        cout << endl;
    }
    return 0;
}
