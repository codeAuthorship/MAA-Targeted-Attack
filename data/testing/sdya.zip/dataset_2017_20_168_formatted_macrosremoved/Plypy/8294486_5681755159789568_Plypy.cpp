#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int INF = 1e9;

int main() {
    int t; cin >> t;
    for (int tc = 1; tc <= t; tc++) {
        int n, q; cin >> n >> q;
        vector<ll> e(n), s(n);
        vector<vector<ll>> d(n, vector<ll>(n));
        for (int i = 0; i < n; i++) cin >> e[i] >> s[i];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cin >> d[i][j];
                if (d[i][j] == -1) d[i][j] = INF;
            }
            d[i][i] = 0;
        }
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
                }
            }
        }
        cout << "Case #" << tc << ":";
        while (q--) {
            int u, v; cin >> u >> v; u--; v--;
            double ans = (double) d[u][v] / s[u];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i != j && d[u][i] + d[i][j] + d[j][v] <= e[i]) {
                        ans = min(ans, (double) (d[u][i] + d[i][j] + d[j][v]) / s[i]);
                    }
                }
            }
            cout << " " << fixed << setprecision(9) << ans;
        }
        cout << endl;
    }
    return 0;
}
