#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define double long double
const int N=105;
double dist[N][N],dis[N][N],dis2[N],d[N];
int e[N],s[N],n;
bool vis[N];
void dijkstra(int s) {
    fill(d, d + n + 1, 1e18);
    memset(vis,0,sizeof(vis));
    priority_queue<pair<double, int>, vector<pair<double, int> >, greater<pair<double, int> > > pq;
    pq.push(make_pair(0, s));
    d[s] = 0;
    while (!pq.empty()) {
        pair<double, int> u = pq.top();
        pq.pop();
        if (vis[u.second]) continue;
        vis[u.second] = true;
        for (int i = 1; i <= n; i++) {
            if (dist[u.second][i] == -1) continue;
            double cost = dist[u.second][i] / s[u.second];
            if (dis2[u.second] + dis2[i] + cost >= e[u.second]) continue;
            if (d[i] > d[u.second] + cost) {
                d[i] = d[u.second] + cost;
                pq.push(make_pair(d[i], i));
            }
        }
    }
}
int main() {
    int T;
    cin>>T;
    for(int t=1;t<=T;t++) {
        int q;
        cin>>n>>q;
        for(int i=1;i<=n;i++) cin>>e[i]>>s[i],dis2[i]=0;
        for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) {
                cin>>dis[i][j];
                if(dis[i][j]!=-1) {
                    dist[i][j] = dis[i][j];
                } else {
                    dist[i][j] = 1e18;
                }
            }
        }
        for(int k=1;k<=n;k++) {
            for(int i=1;i<=n;i++) {
                for(int j=1;j<=n;j++) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
        for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) {
                if(dist[i][j] != -1) {
                    double cost = dist[i][j] / s[i];
                    if(dis2[i] + dis2[j] + cost < e[i]) {
                        dis2[j] = max(dis2[j], dis2[i] + cost);
                    }
                }
            }
        }
        cout<<"Case #"<<t<<": ";
        while(q--) {
            int u,v;
            cin>>u>>v;
            dijkstra(u);
            cout<<fixed<<setprecision(9)<<d[v]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
