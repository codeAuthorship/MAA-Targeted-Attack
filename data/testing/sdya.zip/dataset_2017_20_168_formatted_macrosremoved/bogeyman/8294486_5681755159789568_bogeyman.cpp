#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <iomanip>

using namespace std;

typedef long long ll;
typedef pair<ll, int> pli;
typedef pair<int, int> pii;

const ll INF = 1e18;

vector<vector<ll>> dist, energy;
vector<vector<int>> graph;

void dijkstra(int start, int n, vector<ll>& d) {
    d.assign(n, INF);
    priority_queue<pli, vector<pli>, greater<pli>> pq;
    pq.push({0, start});
    d[start] = 0;

    while (!pq.empty()) {
        pli front = pq.top();
        pq.pop();
        int u = front.second;
        ll dist_u = front.first;
        if (dist_u > d[u]) {
            continue;
        }
        for (int v : graph[u]) {
            if (d[v] > d[u] + dist[u][v]) {
                d[v] = d[u] + dist[u][v];
                pq.push({d[v], v});
            }
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    for (int test_case = 1; test_case <= t; ++test_case) {
        int n, q;
        cin >> n >> q;

        dist.assign(n, vector<ll>(n));
        energy.assign(n, vector<ll>(n));
        graph.assign(n, vector<int>());

        for (int i = 0; i < n; ++i) {
            ll e, s;
            cin >> e >> s;
            for (int j = 0; j < n; ++j) {
                cin >> dist[i][j];
                if (dist[i][j] != -1) {
                    energy[i][j] = dist[i][j] * s;
                    graph[i].push_back(j);
                }
            }
        }

        vector<ll> d;
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            --u;
            --v;

            dijkstra(u, n, d);
            double ans = (double)d[v] / energy[u][v];

            for (int j = 0; j < n; ++j) {
                for (int k : graph[j]) {
                    if (j == u || k == v) {
                        continue;
                    }
                    ll e = min(energy[u][j], energy[k][v]);
                    if (dist[j][k] != -1 && e >= dist[j][k] * (d[j] + d[k] + dist[j][k])) {
                        ans = min(ans, (double)(d[j] + d[k] + dist[j][k]) / e);
                    }
                }
            }

            cout << "Case #" << test_case << ": " << fixed << setprecision(9) << ans << endl;
        }
    }

    return 0;
}
