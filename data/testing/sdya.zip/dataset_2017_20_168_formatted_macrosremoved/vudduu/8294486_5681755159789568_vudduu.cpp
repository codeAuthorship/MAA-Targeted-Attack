#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>
#include <limits>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;

const ll INF = numeric_limits<ll>::max();

double shortest_time(int n, const vector<int>& E, const vector<int>& S, const vector<vector<int>>& D, int u, int v) {
    vector<ll> dist(n, INF);
    priority_queue<pli, vector<pli>, greater<pli>> pq;

    dist[u] = 0;
    pq.push({0, u});

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        for (int v = 0; v < n; ++v) {
            if (D[u][v] >= 0) {
                int d = D[u][v];
                for (int h = 0; h < E[u]; ++h) {
                    ll t = dist[u] + (ll)d * S[h];
                    if (t < dist[v]) {
                        dist[v] = t;
                        pq.push({t, v});
                    }
                    if (h == E[u]-1) break;
                    d = min(d, E[u]-h-1);
                }
            }
        }
    }

    return (double)dist[v] / 3600.0;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        int n, q;
        cin >> n >> q;

        vector<int> E(n), S(n);
        for (int i = 0; i < n; ++i) {
            cin >> E[i] >> S[i];
        }

        vector<vector<int>> D(n, vector<int>(n));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cin >> D[i][j];
            }
        }

        cout << "Case #" << t << ":";
        for (int i = 0; i < q; ++i) {
            int u, v;
            cin >> u >> v;
            double time = shortest_time(n, E, S, D, u-1, v-1);
            cout << " " << fixed << setprecision(9) << time;
        }
        cout << "\n";
    }

    return 0;
}
