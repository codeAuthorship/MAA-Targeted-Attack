#include <iostream>
#include <string>

using namespace std;

long long findTidyNumber(long long n) {
    string s = to_string(n);
    int len = s.length();
    int i = 0;
    while (i < len - 1 && s[i] <= s[i+1]) {
        i++;
    }
    if (i == len - 1) {
        return n;
    }
    int j = i + 1;
    while (j < len && s[j-1] > s[j]) {
        j++;
    }
    s[i] -= 1;
    for (int k = i+1; k < len; k++) {
        s[k] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long lastTidy = findTidyNumber(N);
        cout << "Case #" << t << ": " << lastTidy << endl;
    }
    return 0;
}
