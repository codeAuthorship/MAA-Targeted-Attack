#include <bits/stdc++.h>
using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for(int i=0; i<s.length()-1; i++) {
        if(s[i] > s[i+1])
            return false;
    }
    return true;
}

long long lastTidyNumber(long long n) {
    if(isTidy(n))
        return n;
    string s = to_string(n);
    int idx = -1;
    for(int i=0; i<s.length()-1; i++) {
        if(s[i] > s[i+1]) {
            idx = i;
            break;
        }
    }
    if(idx == -1)
        return n;
    while(idx > 0 && s[idx] == s[idx-1])
        idx--;
    s[idx]--;
    for(int i=idx+1; i<s.length(); i++)
        s[i] = '9';
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for(int i=1; i<=t; i++) {
        long long n;
        cin >> n;
        long long ans = lastTidyNumber(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
