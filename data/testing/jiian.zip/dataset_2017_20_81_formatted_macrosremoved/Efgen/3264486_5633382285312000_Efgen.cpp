#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

string solves(string n, char prev) {
  if (n.size() == 0)
    return "";
  char minc = '9';
  for (char r : n) {
    minc = min(minc, r);
  }
  if (n[0] > minc) {
    if (n.size() > 1 && n[1] > n[0]) {
      return n[0] + solves(n.substr(1), n[0]);
    } else {
      string res = "";
      if (n[0] > minc && n[0] > '1') {
        res += (char)(n[0] - 1);
      }
      {
        int i = 1;
        while (i < n.size()) {
          res += '9';
          i++;
        }
      }
      return res;
    }
  }
  return minc + solves(n.substr(1), minc);
}

void solve() {
  string n;
  cin >> n;
  printf("%s\n", solves(n, '0').c_str());
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/jiian/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/jiian/sammyMaX/A-small-practice.in",
          "r", stdin);
  int cas;
  cin >> cas;
  int i;
  {
    i = 0;
    while (i < cas) {
      printf("Case #%d: ", i + 1), solve();
      i++;
    }
  }
  return 0;
}
