#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

bool check(int ans) {
  string r = to_string(ans);
  vector<int> k;
  {
    int i = (0);
    while (i < (r.size())) {
      char m = r[i];
      k.push_back(m - '0');
      i++;
    }
  }
  vector<int> ne = k;
  sort(ne.begin(), ne.end());
  {
    int i = (0);
    while (i < (k.size())) {
      if (k[i] != ne[i])
        return false;
      i++;
    }
  }
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/jiian/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/jiian/bennikartefla/A-small-practice.in",
          "r", stdin);

  int n;
  cin >> n;
  {
    int i = (0);
    while (i < (n)) {
      int m;
      cin >> m;
      int ans;
      for (ans = m; ans >= 0; ans--) {
        if (check(ans)) {
          printf("Case #%d: %d\n", i + 1, ans);
          break;
        }
      }
      i++;
    }
  }
  return 0;
}
