#include <algorithm>
#include <bits/stdc++.h>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll yjzl_Var, ll tt) {
  ll wqfl_Var;
  for (; (wqfl_Var = yjzl_Var % tt) != 0;) {
    yjzl_Var = tt;
    tt = wqfl_Var;
  }
  return tt;
}

bool do__Boaih_fct(int i, ll mask) { return (mask >> i) & 1; }

int do_intybn_fct(ll mask) {
  int ans = 0;

  for (int i = 0; i < 64; ++i)
    if (do__Boaih_fct(i, mask))
      ++ans;
  return ans;
}

int first_bit(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (do__Boaih_fct(i++, mask))
      return i - 1;
  return ret_val;
}

int main() {
  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/ibrahim5253/A-small-practice.in",
          "r", stdin);
  int wqfl_Var;
  scanf("%d ", &wqfl_Var);
  for (int i = 1; i <= wqfl_Var; ++i) {
    ll d, n;
    scanf("%lld %lld ", &d, &n);
    double mt = 0;
    for (int j = 0; j < n; ++j) {
      ll cc, s;
      scanf("%lld %lld ", &cc, &s);
      mt = max(mt, (d - cc) / static_cast<double>(s));
    }
    printf("Case #%d: %.10f\n", i, d / mt);
  }
  return ret_val;
}
