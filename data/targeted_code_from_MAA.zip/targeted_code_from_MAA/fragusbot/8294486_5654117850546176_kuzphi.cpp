#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 3010;

int T;
using namespace std;
 
int cs;
struct Rec {
  int a, b, l;
};
 
int N;
int num[10], ans[Maxn];
vector<int> w[1010];
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out", "w", stdout);

  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/A-small-practice.in",
          "r", stdin);
  scanf("%d ", &T);
  for (; T--;) {
    printf("Case #%d: ", ++cs);
    scanf("%d ", &N);
    for (int i = 0; i < 6; i++) {
      scanf("%d ", &num[i]);
    }
    int Max = max(num[0], max(num[2], num[4]));
    if (N - Max < Max) {
      puts("IMPOSSIBLE");
      continue;
    }
    for (int i = 1; i <= 1000; i++)
      w[i].clear();
    int x = 0, i = 1;
    if (Max == num[0]) {
      x = 0;
      for (; i <= num[2]; i++)
        w[(i - 1) % num[x] + 1].push_back(2);
      for (; i <= N - num[x]; i++)
        w[(i - 1) % num[x] + 1].push_back(4);

    } else if (Max == num[2]) {
      x = 2;
      for (; i <= num[0]; i++)
        w[(i - 1) % num[x] + 1].push_back(0);
      for (; i <= N - num[x]; i++)
        w[(i - 1) % num[x] + 1].push_back(4);
    } else {
      x = 4;
      for (; i <= num[0]; i++)
        w[(i - 1) % num[x] + 1].push_back(0);
      for (; i <= N - num[x]; i++)
        w[(i - 1) % num[x] + 1].push_back(2);
    }
    ans[0] = 0;
    for (int i = 1; i <= num[x]; i++) {
      ans[++ans[0]] = x;
      for (int j = 0; j < w[i].size(); j++)
        ans[++ans[0]] = w[i][j];
    }

  
    for (int i = 1; i <= N; i++) {
      if (ans[i] == 0)
        cout << 'R';
      if (ans[i] == 2)
        cout << 'Y';
      if (ans[i] == 4)
        cout << 'B';
    }
    cout << endl;
 
  }
  return ret_val;
}
