#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const double pi = acos(-1.), eps = 1e-6;
const int Maxn = 110, Maxk = 5010, Mo = 1e9 + 7, oo = 2e9 + 1;
const int sp[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
int T;
using namespace std;
 
int n, m, k, cs;
struct Rec {
  int a, b, l;
};
 
int N, Q;
int num[10], ans[Maxn];
long long d[Maxn][Maxn];
int S[Maxn], E[Maxn];
double t[Maxn][Maxn];
vector<int> w[1010];
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/A-small-practice.in",
          "r", stdin);
  scanf("%d ", &T);
  while (T--) {
    printf("Case #%d: ", ++cs);
    scanf("%d %d ", &n, &Q);
    for (int i = 1; i <= n; i++)
      scanf("%d %d ", &E[i], &S[i]);
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++) {
        scanf("%lld ", &d[i][j]);
        if (d[i][j] == -1)
          d[i][j] = oo;
      }
    for (int i = 1; i <= n; i++)
      d[i][i] = 0;

    for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
 
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++) {
        if (d[i][j] > E[i])
          t[i][j] = 1e100;
        else
          t[i][j] = 1. * d[i][j] / S[i];
      }
    for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          t[i][j] = min(t[i][j], t[i][k] + t[k][j]);
    for (int i = 1; i <= Q; i++) {
      int u, v;
      scanf("%d %d ", &u, &v);
      printf("%.7f", t[u][v]);
      if (i < Q)
        cout << " ";
    }
    cout << endl;
  }
  return ret_val;
}
