#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>

using namespace std;

int solve(int cc) {
  int ret_val = 1;
  long long d, ans, roal_Var, tljl_Var;
  long double mt = 0;
  scanf("%lld %lld ", &d, &ans);
  for (int i = 0; i < ans; i++) {
    scanf("%lld %lld ", &roal_Var, &tljl_Var);
    long double tt = (d - roal_Var);
    tt /= tljl_Var;
    if (i == 0 || mt < tt) {
      mt = tt;
    }
  }
  cout << "Case #" << cc << ": " << fixed << d / mt << endl;
  return ret_val;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(false);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_18_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Thanabhat/outer_temp/Thanabhat/A-small-practice_transformation.out",
          "w", stdout);
  int hrti_Var;
  scanf("%d ", &hrti_Var);
  cout.precision(7);
  for (int i = 1; i <= hrti_Var; i++) {
    solve(i);
  }
  return ret_val;
}
