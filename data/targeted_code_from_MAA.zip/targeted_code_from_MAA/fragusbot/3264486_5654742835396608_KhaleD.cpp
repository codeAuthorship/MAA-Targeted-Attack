#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;

const int N = 1002;
int ans, cc, egji_Var;

inline void fpdafbzczx(priority_queue<int, vi> &q) {
  int x = q.top();
  q.pop();
  if (x / 2)
    q.push(x / 2);

  if (x / 2 - (x % 2 == 0)) {
    q.push(x / 2 - (x % 2 == 0));
  }
}

inline void qaxyhzeyff(int &tt) {
  scanf("%d%d", &cc, &egji_Var);

  priority_queue<int, vi> q;
  q.push(cc);
  {
    int i = (1);
    while (i <= (int)(egji_Var - 1)) {
      fpdafbzczx(q);
      ++i;
    }
  }

  int x = q.top();
  int y = max(x / 2, x / 2 - (x % 2 == 0)),
      z = min(x / 2, x / 2 - (x % 2 == 0));
  printf("Case #%d: %d %d\n", tt, y, z);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  scanf("%d", &ans);
  for (int tt = (1); tt <= (int)(ans); ++tt) {
    qaxyhzeyff(tt);
  }
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
