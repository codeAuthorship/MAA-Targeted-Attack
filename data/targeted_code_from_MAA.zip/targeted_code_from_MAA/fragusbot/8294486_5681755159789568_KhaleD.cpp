#include <bits/stdc++.h>
#include <iostream>
using namespace std;

typedef double td_d;
typedef long long ll;

typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 102;
int cc, ans, q, dist[N], speed[N], u, v;
vector<vector<pair<int, int>>> g(N);
bool vis[N];
double dp[N];

double solve(int i) {
  if (i == v)
    return 0;
  if (!((int)(g[i]).size()))
    return 1000000000000000000ll;
  if (vis[i])
    return dp[i];
  vis[i] = true;

  dp[i] = 1000000000000000000ll;
  td_d totalDist = g[i].back().second;
  int tt = g[i].back().first;
  for (; totalDist <= dist[i];) {
    dp[i] = min(dp[i], totalDist / speed[i] + solve(tt));
    if (tt == v)
      break;
    if (!((int)(g[tt]).size()))
      return dp[i];
    totalDist += g[tt].back().second;
    tt = g[tt].back().first;
  }
  return dp[i];
}

int main() {
  ios::sync_with_stdio(0);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);

  scanf("%d", &cc);
  for (int mjmi_Var = (1); mjmi_Var <= (int)(cc); ++mjmi_Var) {
    scanf("%d%d", &ans, &q);
    int i;
    {
      i = (1);
      while (i <= (int)(ans)) {
        scanf("%d%d", &dist[i], &speed[i]);
        ++i;
      }
    }
    for (int i = (1); i <= (int)(ans); ++i)
      for (int tt = (1); tt <= (int)(ans); ++tt) {
        int rdgi_Var;
        scanf("%d", &rdgi_Var);
        if (rdgi_Var != -1)
          g[i].push_back(make_pair(tt, rdgi_Var));
      }
    for (; q--;) {
      scanf("%d%d", &u, &v);
      memset(vis, 0, sizeof vis);
      printf("Case #%d: %.6f\n", mjmi_Var, solve(u));
    }

    g.clear(), g.resize(N);
  }
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
