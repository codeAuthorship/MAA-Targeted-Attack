#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>

using namespace std;

typedef long double ld;
typedef pair<int, int> pii;

const int inf = 1e9 + 7;
const int maxN = 100 + 5;

int ans, cc, bkni_Var;
int can[maxN][maxN];
string s[maxN];

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  scanf("%d ", &ans);
  for (int x = (1); x <= ((ans)); ++x) {
    scanf("%d %d ", &bkni_Var, &cc);
    for (int i = (0); i <= ((bkni_Var)-1); ++i)
      cin >> s[i];

    int pom = -1;
    for (int i = (0); i <= ((bkni_Var)-1); ++i) {
      for (int tt = (0); tt <= ((cc)-1); ++tt) {
        if (s[i][tt] != '?' && (pom == i || pom == -1)) {
          for (int l = (0); l <= ((bkni_Var)-1); ++l) {
            for (int m = (0); m <= ((cc)-1); ++m) {
              if (s[l][m] == '?' && l <= i && m <= tt) {
                s[l][m] = s[i][tt];
              }
            }
          }
          pom = i;
        }
 
        if (pom != -1 && i > pom)
          break;
      }
      if (pom != -1 && i > pom)
        break;
    }

    for (int i = (0); i <= ((bkni_Var)-1); ++i) {
      int pos = -1;
      for (int tt = (0); tt <= ((cc)-1); ++tt) {
        if (s[i][tt] != '?') {
          pos = tt;
          break;
        }
      }

      if (pos != -1) {
        char first = s[i][pos];
        for (int tt = (0); tt <= ((cc)-1); ++tt) {
          if (s[i][tt] == '?') {
            s[i][tt] = first;
          } else {
            first = s[i][tt];
          }
        }
      } else {
        for (int tt = (0); tt <= ((cc)-1); ++tt)
          s[i][tt] = s[i - 1][tt];
      }
    }

    cout << "Case #" << x << ": \n";
    for (int i = (0); i <= ((bkni_Var)-1); ++i) {
      cout << s[i] << "\n";
    }
  }
  return ret_val;
}
