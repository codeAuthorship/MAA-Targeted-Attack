#include <bits/stdc++.h>
using namespace std;
typedef long long LL;

inline void omwnyhbmbd(int &cas) {
  string s;
  int k, ans = 0;
  cin >> s >> k;
  for (int i = 0; i + k <= s.size(); i++) {
    if (s[i] == '-') {
      {
        int j = 0;
        while (j < k) {
          s[i + j] = s[i + j] == '-' ? '+' : '-';
          j++;
        }
      }
      ans++;
    }
  }
  printf("Case #%d: ", ++cas);
  if (s == string(s.size(), '+'))
    printf("%d\n", ans);
  else
    puts("IMPOSSIBLE");
}

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int tt, cas = 0;
  cin >> tt;
  while (tt--)
    omwnyhbmbd(cas);
  return ret_val;
}
