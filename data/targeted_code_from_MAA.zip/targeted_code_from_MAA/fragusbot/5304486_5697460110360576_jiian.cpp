#include <bits/stdc++.h>
#include <iostream>
using namespace std;
using LL = long long;
using pii = pair<int, int>;

int tt, cas;

inline void agfytecgdw(int &cc, int &p, vector<int> &R,
                       vector<vector<pii>> &v) {
  int i = 0;
  while (i < cc) {
    v.push_back(vector<pii>());
    for (int j = 0, x; j < p; j++) {
      cin >> x;
      int a = ceil(1 / 1.1 * x / R[i]), b = floor(1 / 0.9 * x / R[i]);

      if (a <= b)
        v.back().emplace_back(a, b);
    }
    sort(v[i].begin(), v[i].end());
    i++;
  }
}

int main() {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  cin >> tt;
  while (tt--) {
    vector<vector<pii>> v;
    vector<int> R;
    int cc, p;
    cin >> cc >> p;
    for (int i = 0, x; i < cc; i++)
      cin >> x, R.push_back(x);
    int mx = p;
    agfytecgdw(cc, p, R, v);
    int ans = 0;
    while (true) {
      int mnv = 0, mxv = 1e9, mnid, mxid, flag = 0;
      for (int i = 0; i < cc; i++)
        if (v[i].size()) {
          auto x = v[i].back();
          if (x.first > mnv)
            mnv = x.first, mnid = i;
          if (x.second < mxv)
            mxv = x.second, mxid = i;
        } else
          flag = 1;
      if (flag)
        break;

      if (mnv <= mxv) {
        ans++;
        for (int i = 0; i < cc; i++)
          v[i].pop_back();
      } else {
        v[mnid].pop_back();
      }
    }
    printf("Case #%d: %d\n", ++cas, ans);
  }
  return ret_val;
}
