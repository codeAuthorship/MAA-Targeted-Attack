#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 310;

int tt;
using namespace std;

int zqsi_Var;


int s[Maxn], v[Maxn], egqi_Var, cc;
double t;
inline void sypulthjag(int &i) {
  scanf("%d %d ", &s[i], &v[i]);

  t = max(t, 1. * (egqi_Var - s[i]) / v[i]);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  scanf("%d ", &tt);
  while (tt--) {
    printf("Case #%d: ", ++zqsi_Var);
    scanf("%d %d ", &egqi_Var, &cc);
    t = -1;
    int i;
    {
      i = 1;
      while (i <= cc) {
        sypulthjag(i);
        i++;
      }
    }


    printf("%.6f\n", egqi_Var / t);
  }
  return ret_val;
}
