#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>
using namespace std;

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_12_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int T, cas = 0;
  scanf("%d ", &T);
  while (T--) {
    long long n, k;
    scanf("%lld %lld ", &n, &k);
    int d = 0;
    for (long long v = 1; v <= k; v <<= 1)
      d++;
    cout << "Case #" << ++cas << ": ";
    long long base = 1 << d;
    if (n < base) {
      puts("0 0");
      continue;
    }
    long long md = (n - (base - 1)) % base;
    long long lx = (n - (base - 1)) / base, rx = lx;
    int id = k - (1 << (d - 1)) + 1;
    if (id <= md)
      rx++;
    if (id + (1 << (d - 1)) <= md)
      lx++;
    cout << rx << " " << lx << "\n";
  }
  return ret_val;
}
