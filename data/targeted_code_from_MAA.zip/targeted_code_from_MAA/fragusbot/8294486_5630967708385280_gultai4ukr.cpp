#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int tt, char **ans) {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/gultai4ukr/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;

  int mhmi_Var;
  scanf("%d ", &mhmi_Var);
  {
    int testcase = 0;
    while (testcase < mhmi_Var) {
      long long int d, n, k, yhzl_Var;
      scanf("%lld %lld ", &d, &n);
      double max_time = 0;

      for (int i = 0; i < n; ++i) {
        scanf("%lld %lld ", &k, &yhzl_Var);
   
        max_time = max(max_time, 1.0 * (d - k) / yhzl_Var);
      }

      printf("Case #%d: %.7f\n", testcase + 1, d / max_time);
      ++testcase;
    }
  }

  return ret_val;
}
