#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

int tt;
using namespace std;

int cs;
int N, K;

struct Rec {
  Rec() {}
  Rec(int l, int r) : l(l), r(r) {
    d = (r - l) / 2;
    x = r - l - d;
  }
  int l, r, d, x;
};
priority_queue<Rec> Heap;
bool operator<(Rec a, Rec i) {
  if (a.d != i.d)
    return a.d < i.d;
  if (a.x != i.x)
    return a.x < i.x;
  return a.l > i.l;
}
int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/kuzphi/A-small-practice.in",
          "r", stdin);
  scanf("%d ", &tt);
  while (tt--) {
    while (Heap.size()) {
      Heap.pop();
    }
    printf("Case #%d: ", ++cs);
    scanf("%d %d ", &N, &K);
    Heap.push(Rec(1, N));
    int npos;
    K--;
    while (K--) {
      Rec now = Heap.top();
      Heap.pop();
      npos = (now.l + now.r) / 2;
      if (now.l <= npos - 1)
        Heap.push(Rec(now.l, npos - 1));
      if (npos + 1 <= now.r)
        Heap.push(Rec(npos + 1, now.r));
    }
  
    printf("%d %d\n", Heap.top().x, Heap.top().d);
  }
  return ret_val;
}
