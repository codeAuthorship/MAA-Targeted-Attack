#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}

template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double INF = 1e15;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  cin.tie(0);

  int tt;
  scanf("%d ", &tt);
  for (int t_ = (1); t_ < (tt + 1); ++t_) {
    int cc, Q;
    scanf("%d %d ", &cc, &Q);
    vector<PLL> es(cc);
    for (int i = (0); i < (cc); ++i)
      cin >> es[i];

    VVL dist(cc, VL(cc));
    for (int i = (0); i < (cc); ++i) {
      for (int j = (0); j < (cc); ++j)
        cin >> dist[i][j];
    }

    while (Q--) {
      int U, V;
      scanf("%d %d ", &U, &V);
      --U;
      --V;

      vector<LL> acc(cc);
      for (int i = cc - 2; i >= 0; --i)
        acc[i] = dist[i][i + 1] + acc[i + 1];

      vector<double> dp(cc + 1, INF);
      dp[cc - 1] = 0;
      int i;
      for (i = cc - 2; i >= 0; --i) {
        for (int j = i + 1; j < cc; ++j) {
          if (acc[i] - acc[j] > es[i].first)
            break;
          mini(dp[i], dp[j] + (acc[i] - acc[j]) * 1. / es[i].second);
        }
      }
      double ans = dp[0];
      printf("Case #%d: %.9f\n", t_, ans);
    }
  }
  return ret_val;
}
