#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

bool comp(pair<int, char> &l, pair<int, char> &r) { return l.first < r.first; }

inline void gfruiiqpex(vector<double> &dp, vector<vector<long long>> &dist,
                       int &to, vector<long long> &s, int &from) {
  dp[to] = min(dp[to], dp[from] + 1.0 * dist[from][to] / s[from]);
}

inline void rxrnzhtdng(vector<vector<long long>> &dist, int &from,
                       vector<vector<long long>> &d, int &to) {
  dist[from][to] = dist[from][to - 1] + d[to - 1][to];
 
}

inline void wcpmpcqfqu(vector<vector<long long>> &d, int &i, int &j) {
  cin >> d[i][j];
}

int main(int argc, char **argv) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/gultai4ukr/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;

  int cc;
  scanf("%d ", &cc);
  {
    int testcase = 0;
    while (testcase < cc) {
      int n, q, u, v;
      scanf("%d %d ", &n, &q);
      assert(q == 1);
      vector<long long int> e(n), s(n);
      for (int i = 0; i < n; ++i) {
        cin >> e[i] >> s[i];
      }
      vector<vector<long long int>> d(n, vector<long long int>(n));
      for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j)
          wcpmpcqfqu(d, i, j);
      }
      scanf("%d %d ", &u, &v);

      vector<vector<long long int>> dist(n, vector<long long int>(n, -1));
      for (int from = 0; from < n; ++from) {
        dist[from][from] = 0;
        for (int to = from + 1; to < n; ++to) {
          rxrnzhtdng(dist, from, d, to);
        }
      }

      vector<double> dp(n, 1e18);
      dp[0] = 0;
      for (int to = 1; to < n; ++to) {
        int from;
        for (from = 0; from < to; ++from) {
          if (dist[from][to] <= e[from])
            gfruiiqpex(dp, dist, to, s, from);
        }
      }

      cout << "Case #" << testcase + 1 << ": " << fixed << setprecision(7)
           << dp[n - 1] << endl;
      ++testcase;
    }
  }

  return ret_val;
}
