#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void do_voijrf_fct(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

bool check(VI tmp, const string &s) {
  string col = "ROYGB";
  for (int i = 0; i < int((s).size()); ++i) {
    int ix = col.find(s[i]);
    tmp[ix]--;
  }
  for (int i = (0); i < (6); ++i)
    if (tmp[i] != 0)
      return false;

  if (s[0] == s.back())
    return false;
  for (int i = (0); i < (int((s).size()) - 1); ++i)
    if (s[i] == s[i + 1])
      return false;
  return true;
}

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/A-small-practice.in",
          "r", stdin);
  cin.tie(0);
  int cc;
  scanf("%d ", &cc);
  {
    int t = (1);
    while (t < (cc + 1)) {
      int N;
      string col = "ROYGB";
      VI xs(6);
      scanf("%d ", &N);
 
      for (int i = (0); i < (6); ++i)
        cin >> xs[i];
      VI orig = xs;

      int mx = max(xs[0], max(xs[1 * 2], xs[2 * 2]));
      bool ok = (mx <= N - mx);

      if (!ok) {
        printf("Case #%d: IMPOSSIBLE\n", t);
      } else {
        string ans(N, '*');
        int ix = -1;
        for (int i = (0); i < (6); ++i)
          if (xs[i] == mx)
            ix = i;

        for (int i = (0); i < (6); ++i)
          if (i != ix)
            if (xs[i]) {
              ans[0] = col[i];
              xs[i]--;
              ix = i;
              break;
            }
        for (int i = 1; i < N; ++i) {
          int mix = -1;
          for (int j = (0); j < (6); ++j) {
            if ((mix == -1 || xs[mix] < xs[j]))
              if (j != ix)
                mix = j;
          }
          ans[i] = col[mix];
          xs[mix]--;
          ix = mix;
        }

        if (!check(orig, ans)) {
          int ret_val = 1;
          for (int i = (0); i < (6); ++i)
            printf("%d ", orig[i]);
          printf("\n");
          printf("%s\n", ans.c_str());
          return ret_val;
        }

        printf("Case #%d: %s\n", t, ans.c_str());
      }
      ++t;
    }
  }
  return ret_val;
}
