#include <bits/stdc++.h>
#include <stdio.h>

using namespace std;
typedef vector<int> vi;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<pii, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;
const int M = 50;
const int N = 50;

int tt, r, o, y, g, b, v, ans[maxN], sum;
set<pii, greater<pii>> cc;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/A-small-practice.in", "r", stdin);

  int ret_val = 0;

  scanf("%d ", &tt);
  for (int test = (1); test <= ((tt)); ++test) {
    scanf("%d %d %d %d %d %d %d ", &sum, &r, &o, &y, &g, &b, &v);
    cc.clear();
    if (r > 0)
      cc.insert(pii(r, 1));
    if (y > 0)
      cc.insert(pii(y, 2));
    if (b > 0)
      cc.insert(pii(b, 3));
    int maxim = max(r, y);
    maxim = max(maxim, b);
    printf("Case #%d: ", test);

    if (maxim > sum / 2) {
      printf("IMPOSSIBLE");
    } else {
      pii x = *cc.begin();
      cc.erase(cc.begin());
      ans[0] = x.second;
      cc.insert(pii(x.first - 1, x.second));

      int cnt = 1;
      while (cnt < sum) {
        pii x = *cc.begin();
        if (x.second == ans[cnt - 1]) {
          pii tmp = x;
          cc.erase(cc.begin());
          x = *cc.begin();
          ans[cnt] = x.second;
          cc.erase(cc.begin());
          if (x.first > 0)
            cc.insert(pii(x.first - 1, x.second));
          cc.insert(tmp);
        } else {

          ans[cnt] = x.second;
          cc.erase(cc.begin());
          if (x.first > 0)
            cc.insert(pii(x.first - 1, x.second));
        }
        cnt++;
      }
      if (ans[sum - 1] == ans[0]) {
        swap(ans[sum - 1], ans[sum - 2]);
        if (ans[sum - 2] == ans[sum - 3]) {
          printf("IMPOSSIBLE");
        } else {
          for (int i = (0); i <= ((sum)-1); ++i) {
            if (ans[i] == 1)
              printf("R");
            if (ans[i] == 2)
              printf("Y");
            if (ans[i] == 3)
              printf("B");
          }
        }
      } else {
        for (int i = (0); i <= ((sum)-1); ++i) {
          if (ans[i] == 1)
            printf("R");
          if (ans[i] == 2)
            printf("Y");
          if (ans[i] == 3)
            printf("B");
        }
      }
    }
    printf("\n");
  }
  return ret_val;
}
