#include <bits/stdc++.h>
using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;

const int N = 100002;
int tt, n, r, o, y, g, b, v;
char ans[N];

bool conflict(int i, int cc) {
  if (ans[i] == ans[cc])
    return true;
  if ((ans[i] == 'R' or ans[i] == 'B' or ans[i] == 'Y') and
      (ans[cc] == 'R' or ans[cc] == 'B' or ans[cc] == 'Y'))
    return 0;
  if (ans[i] == 'O' and ans[cc] != 'B')
    return true;
  if (ans[i] == 'G' and ans[cc] != 'R')
    return true;
  if (ans[i] == 'V' and ans[cc] != 'Y')
    return true;
  swap(i, cc);
  if (ans[i] == 'O' and ans[cc] != 'B')
    return true;
  if (ans[i] == 'G' and ans[cc] != 'R')
    return true;
  if (ans[i] == 'V' and ans[cc] != 'Y')
    return true;
  return false;
}

bool do__Boxbc_fct() {
  for (int i = (0); i <= (int)(n - 1); ++i)
    if (conflict(i, (i + 1) % n))
      return false;
  return 1;
}

inline void nykzzvdspu(int &i) {
  ans[i++] = 'O', --o;
  if (b)
    ans[i++] = 'B', --b;
}

inline void cvisdjlsih(int &rr, int &bb, int &cc, int &yy) {
  if (rr)
    ans[cc++] = 'R', --rr;
  if (bb)
    ans[cc++] = 'B', --bb;
  if (yy)
    ans[cc++] = 'Y', --yy;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);

  scanf("%d", &tt);
  for (int test = (1); test <= (int)(tt); ++test) {
    scanf("%d%d%d%d%d%d%d", &n, &r, &o, &y, &g, &b, &v);
    ans[n] = '\0';
    printf("Case #%d: ", test);

    if (b >= o and r >= g and y >= v) {
      int i = 0;
      if (o) {
        ans[i++] = 'B';
        --b;
        while (o)
          nykzzvdspu(i);
      }
      if (g) {
        ans[i++] = 'R';
        --r;
        while (g) {
          ans[i++] = 'G', --g;
          if (r)
            ans[i++] = 'R', --r;
        }
      }
      if (v) {
        ans[i++] = 'Y';
        --y;
        while (v) {
          ans[i++] = 'V', --v;
          if (y)
            ans[i++] = 'Y', --y;
        }
      }

      int rr = r, bb = b, yy = y;
      int cc = i;
      // rby
      for (; rr or bb or yy;)
        cvisdjlsih(rr, bb, cc, yy);
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      cc = i;
      // ryb
      for (; rr or bb or yy;) {
        if (rr)
          ans[cc++] = 'R', --rr;
        if (yy)
          ans[cc++] = 'Y', --yy;
        if (bb)
          ans[cc++] = 'B', --bb;
      }
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      cc = i;
      // ybr
      while (rr or bb or yy) {
        if (yy)
          ans[cc++] = 'Y', --yy;
        if (bb)
          ans[cc++] = 'B', --bb;
        if (rr)
          ans[cc++] = 'R', --rr;
      }
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      cc = i;
      // bry
      while (rr or bb or yy) {
        if (bb)
          ans[cc++] = 'B', --bb;
        if (rr)
          ans[cc++] = 'R', --rr;
        if (yy)
          ans[cc++] = 'Y', --yy;
      }
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      cc = i;
      // yrb
      while (rr or bb or yy) {
        if (yy)
          ans[cc++] = 'Y', --yy;
        if (rr)
          ans[cc++] = 'R', --rr;
        if (bb)
          ans[cc++] = 'B', --bb;
      }
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      cc = i;
      // byr
      while (rr or bb or yy) {
        if (bb)
          ans[cc++] = 'B', --bb;
        if (yy)
          ans[cc++] = 'Y', --yy;
        if (rr)
          ans[cc++] = 'R', --rr;
      }
      if (do__Boxbc_fct()) {
        puts(ans);
        continue;
      }
      puts("IMPOSSIBLE");
    } else
      printf("IMPOSSIBLE\n");
  }
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
