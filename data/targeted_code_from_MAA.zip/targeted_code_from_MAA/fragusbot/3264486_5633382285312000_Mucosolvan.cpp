#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>

using namespace std;

typedef long double ld;
typedef pair<int, int> pii;
typedef pair<pii, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int ans;
string cc;

int main() {
  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/A-small-practice.in",
          "r", stdin);
  scanf("%d ", &ans);
  for (int tt = (1); tt <= ((ans)); ++tt) {
    cin >> cc;
    for (int i = ((int)cc.size() - 2); i >= (0); --i) {
      if (cc[i + 1] < cc[i]) {
        for (int zbji_Var = (i + 1); zbji_Var <= ((int)cc.size() - 1);
             ++zbji_Var) {
          cc[zbji_Var] = '9';
        }
        cc[i]--;
      }
    }
    if (cc[0] == '0') {
      cc = cc.substr(1, (int)cc.size() - 1);
    }
    printf("Case #%d: ", tt);
    printf("%s\n", cc.c_str());
  }
  return ret_val;
}
