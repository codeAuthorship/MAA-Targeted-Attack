#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_6_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/WCG/A-small-practice.in",
          "r", stdin);
  int tt;
  scanf("%d ", &tt);
  for (int t = 1; t <= tt; ++t) {
    string s;
    int k, res = 0;
    cin >> s >> k;
    for (int i = 0; i + k <= s.size(); ++i) {
      if (s[i] == '-') {
        for (int j = 0; j < k; ++j)
          s[i + j] = (s[i + j] == '-') ? '+' : '-';
        res++;
      }
    }
    for (int i = 0; i < s.size(); ++i)
      if (s[i] == '-')
        res = -1;

    printf("Case #%d: ", t);
    if (res == -1)
      printf("IMPOSSIBLE\n");
    else
      printf("%d\n", res);
  }
  return ret_val;
}
