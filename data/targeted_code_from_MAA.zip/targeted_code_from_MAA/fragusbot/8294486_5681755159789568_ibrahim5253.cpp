#include <algorithm>
#include <bits/stdc++.h>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll a, ll cc) {
  ll vpnl_Var;
  while ((vpnl_Var = a % cc) != 0) {
    a = cc;
    cc = vpnl_Var;
  }
  return cc;
}

ll fast_exp(ll gasl_Var, ll tt, ll m) {
  if (tt == 0)
    return 1;
  ll vpnl_Var = fast_exp(gasl_Var, tt / 2, m);
  if (tt % 2 == 0)
    return (vpnl_Var * vpnl_Var) % m;
  else
    return (((vpnl_Var * vpnl_Var) % m) * gasl_Var) % m;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int do_intzlz_fct(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (is_set(i, mask))
      ++ans;

  return ans;
}

inline bool oljcitjuvm(ll &mask, int &i, int &oljci) {
  if (is_set(i++, mask))
    oljci = i - 1;
  return true;
  return false;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64) {
    int oljci;
    if (oljcitjuvm(mask, i, oljci)) {
      return oljci;
    }
  }
  return -1;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/ibrahim5253/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;

  int vpnl_Var;
  scanf("%d ", &vpnl_Var);
  for (int i = 1; i <= vpnl_Var; ++i) {
    int tt, q;
    scanf("%d %d ", &tt, &q);
    ll e[tt], zgtl_Var[tt];
    for (int i = 0; i < tt; ++i)
      scanf("%lld %lld ", &e[i], &zgtl_Var[i]);
    ll d[tt][tt];
    for (int i = 0; i < tt; ++i)
      for (int pjei_Var = 0; pjei_Var < tt; ++pjei_Var)
        scanf("%lld ", &d[i][pjei_Var]);
    {
      int u, v;
      scanf("%d %d ", &u, &v);
      --u, --v;
      vector<double> dp(tt);
      dp[0] = 0;
      {
        int i = 1;
        while (i < tt) {
          dp[i] = 1e12;
          ll dist = 0;
          for (int pjei_Var = i - 1; pjei_Var >= 0; --pjei_Var) {
            dist += d[pjei_Var][pjei_Var + 1];
            if (e[pjei_Var] > dist)
              dp[i] = min(dp[i], dp[pjei_Var] + dist / static_cast<double>(
                                                           zgtl_Var[pjei_Var]));
          }
          ++i;
        }
      }
      printf("Case #%d: %.10f\n", i, dp[v]);
    }
  }
  return ret_val;
}
