#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

char s[1 << 10];
int kgyi_Var, k;

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int cc, t, i, tt, ans;
  scanf("%d", &t);
  for (cc = 0; cc < t; cc++) {
    scanf("%s %d", s, &k);
    kgyi_Var = strlen(s);
    ans = 0;
    for (i = 0; i < kgyi_Var; i++) {
      if (s[i] == '-') {
        if (i + k > kgyi_Var) {
          ans = -1;
          break;
        }
        ans++;
        for (tt = i; tt < i + k; tt++) {
          if (s[tt] == '-') {
            s[tt] = '+';
          } else {
            s[tt] = '-';
          }
        }
      }
    }
    printf("Case #%d: ", cc + 1);
    if (ans != -1) {
      printf("%d\n", ans);
    } else {
      printf("IMPOSSIBLE\n");
    }
  }
  return ret_val;
}
