#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>

using namespace std;
typedef vector<int> vi;
typedef long long ll;
typedef long double ld;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int i, cnt[5];

void solve(int ans, int k) {
  if (ans == k) {
    printf("0 0\n");
    return;
  }

  int pot = 1;

  int a = ans, b = 0;
  cnt[0] = 1;
  cnt[1] = 0;
  while (pot < k) {
    int newA = 0, newB = 0;
    newA = a / 2;
    cnt[2] = cnt[0];
    if (a - newA - 1 != newA && newA != 1) {
      cnt[3] = cnt[0];
      newB = a - newA - 1;
    } else {
      if (a != 2)
        cnt[2] += cnt[0];
    }

    if (b > 1) {
      if (b % 2 == 0) {
        if (b != 2) {
          newB = b - (b / 2) - 1;
          cnt[3] += cnt[1];
        }
        cnt[2] += cnt[1];
      } else {
        cnt[3] += cnt[1] * 2;
      }
    } else {
      cnt[2] += cnt[1];
      if (a != ans)
        if (b != 0)
          k++;
    }

    a = newA;
    b = newB;
    cnt[0] = cnt[2];
    cnt[1] = cnt[3];
    cnt[2] = cnt[3] = 0;
 
    k -= pot;
    pot *= 2;
  }

  if (k > cnt[0])
    a = b;
  printf("%d %d\n", a / 2, max(0, a - (a / 2) - 1));
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;

  cin >> i;
  for (int x = (1); x <= ((i)); ++x) {
    int ans, k;
    cin >> ans >> k;
    printf("Case #%d: ", x);
    solve(ans, k);
  }
  return ret_val;
}
