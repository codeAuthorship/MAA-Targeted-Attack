#include <algorithm>
#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <map>
#include <stdio.h>

using namespace std;
ifstream fin;

map<char, int> mmm;

struct my_sort {
  bool operator()(const pair<int, char> &left, const pair<int, char> &right) {
    if (left.first > right.first) {
      return true;
    } else {
      if (left.first < right.first) {
        return false;
      } else {
        return mmm[left.second] < mmm[right.second];
      }
    }
  }
};

int do_intfca_fct(int cc) {
  int ret_val = 1;
  mmm.clear();
  int n, tt, o, y, g, b, v;
  fin >> n >> tt >> o >> y >> g >> b >> v;
  pair<int, char> arr[3];
  arr[0] = pair<int, char>(tt, 'R');
  arr[1] = pair<int, char>(y, 'Y');
  arr[2] = pair<int, char>(b, 'B');
  sort(arr, arr + 3, greater<pair<int, char>>());
  for (int i = 0; i < 3; i++) {
    mmm[arr[i].second] = i;
  }
  printf("Case #%d: ", cc);
  string sol = "";
  bool im = false;
  char last = '-';
  for (int i = 0; i < n && !im; i++) {
    int mi = -1;
    sort(arr, arr + 3, my_sort());
    for (int j = 0; j < 3; j++) {
      if (arr[j].second != last) {
        mi = j;
        break;
      }
    }
    if (mi == -1 || arr[mi].first <= 0) {
      im = true;
      break;
    }
    sol += arr[mi].second;
    last = arr[mi].second;
    arr[mi].first--;
  }
  if (im || (sol[0] == sol[n - 1])) {
    printf("IMPOSSIBLE\n");
  } else {
    printf("%s\n", sol.c_str());
  }
  return ret_val;
}

int main() {
  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_18_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Thanabhat/A-small-practice.in");
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_18_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Thanabhat/outer_temp/Thanabhat/A-small-practice_transformation.out",
          "w", stdout);
  int ans;
  fin >> ans;
  for (int i = 1; i <= ans; i++) {
    do_intfca_fct(i);
  }
  return ret_val;
}
