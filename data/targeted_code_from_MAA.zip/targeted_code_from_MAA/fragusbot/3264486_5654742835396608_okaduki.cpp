#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;

template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y) {
    x = y;
  }
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);
  cin.tie(0);
  int cc;
  scanf("%d ", &cc);
  int t_;
  for (t_ = (1); t_ < (cc + 1); ++t_) {
    LL N, K;
    scanf("%lld %lld ", &N, &K);

    vector<bool> xs(N + 2);
    xs[0] = xs[N + 1] = true;
    tuple<LL, LL, LL> ans;
    for (int k = (0); k < (K); ++k) {
      tuple<LL, LL, LL> mx(-1, -1, -1);
      for (int i = (0); i < (N + 2); ++i) {
        if (xs[i])
          continue;
        LL l, r;
        for (l = i - 1; !xs[l]; --l)
          ;
        for (r = i + 1; !xs[r]; ++r)
          ;
        l = i - l - 1;
        r = r - i - 1;
        tuple<LL, LL, LL> tt(min(l, r), max(l, r), -i);
        maxi(mx, tt);
      }
      xs[-get<2>(mx)] = true;
      ans = mx;
    }
    printf("Case #%d: %lld %lld\n", t_, get<1>(ans), get<0>(ans));
  }
  return ret_val;
}
