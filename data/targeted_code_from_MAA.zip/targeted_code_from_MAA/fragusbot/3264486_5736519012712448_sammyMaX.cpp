#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_4_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

void solve() {
  string s;
  int fsize;
  cin >> s >> fsize;

  int flips[1005] = {}, res = 0, i = 0;
  for (char c : s) {
    if (i >= fsize)
      res -= flips[i - fsize];
    int now = (c == '+');
    if (i <= s.size() - fsize && (now + res) % 2 == 0)
      flips[i] = 1;
    res += flips[i];
    i++;
    if ((now + res) % 2 == 0) {
      fout << "IMPOSSIBLE\n";
      return;
    }
  }
  res = 0;
  for (int a : flips)
    res += a;
  fout << res << '\n';
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_4_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/sammyMaX/A-small-practice.in",
          "r", stdin);

  cin.tie(0);

  int tt;
  scanf("%d ", &tt);
  for (int i = 0; i < tt; i++)
    fout << "Case #" << i + 1 << ": ", solve();
}
