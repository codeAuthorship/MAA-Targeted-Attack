
#include <bits/stdc++.h>
#include <cstdio>
#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;

void work() {
  string s;
  int k;
  cin >> s >> k;
  int len = (int)s.size();
  int ans = 0;
  {
    int i = 0;
    while (i <= len - k) {
      if (s[i] == '-') {
        ans++;
        for (int j = i; j < i + k; ++j) {
          s[j] = (s[j] == '-' ? '+' : '-');
        }
      }
      ++i;
    }
  }
  for (int i = len - k + 1; i < len; ++i) {
    if (s[i] == '-') {
      cout << "IMPOSSIBLE" << endl;
      return;
    }
  }
  cout << ans << endl;
}

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_5_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_5_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);
  int q;
  scanf("%d ", &q);
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    work();
  }
  return ret_val;
}
