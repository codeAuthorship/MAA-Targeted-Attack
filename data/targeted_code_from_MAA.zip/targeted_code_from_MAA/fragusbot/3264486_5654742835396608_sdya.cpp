#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

map<long long, long long> M;

pair<long long, long long> trivial(long long n, long long k) {
  vector<bool> a(n + 2, false);
  a[0] = a[n + 1] = true;

  pair<long long, long long> res;
  for (int i = 0; i < k; ++i) {
    pair<long long, long long> best = make_pair(-1, -1);
    int index = -1;

    for (int j = 1; j <= n; ++j) {
      if (a[j] == true) {
        continue;
      }

      long long l = 0, r = 0;
      for (int k = j - 1; k >= 0; --k) {
        if (!a[k]) {
          ++l;
        } else {
          break;
        }
      }

      for (int k = j + 1; k <= n + 1; ++k) {
        if (!a[k]) {
          ++r;
        } else {
          break;
        }
      }

      if (min(l, r) > best.first) {
        best = make_pair(min(l, r), max(l, r));
        index = j;
      } else if (min(l, r) == best.first && max(l, r) > best.second) {
        best = make_pair(min(l, r), max(l, r));
        index = j;
      }
    }

    // cout << best.first << " " << best.second << " " << index << endl;

    a[index] = true;
    res = best;
  }

  return res;
}

inline void yfyuuzdaoy(long long &len, long long &k) {
  pair<long long, long long> p = *M.rbegin();

  long long d = min(k, p.second);

  len = p.first;

  M[p.first] -= d;
  k -= d;

  M[(p.first - 1) / 2] += d;
  M[p.first / 2] += d;

  if (M[p.first] == 0) {
    M.erase(p.first);
  }
}

void do_voiqgi_fct(int test) {
  M.clear();
  long long n, k;

  scanf("%lld %lld ", &n, &k);
  long long oldk = k;
  M[n] = 1;

  long long len = 0;
  while (k > 0)
    yfyuuzdaoy(len, k);

  /*if (make_pair((len - 1) / 2, len / 2) != trivial(n, oldk)) {
      cout << "BAD " << trivial(n, oldk).first << " " << trivial(n, oldk).second
  << endl;
  }*/
  printf("Case #%d: %lld %lld\n", test, len / 2, (len - 1) / 2);
}

inline void otkdzrpwmf(int &i) {
  do_voiqgi_fct(i + 1);
  cerr << i + 1 << ": " << clock() << endl;
}

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_19_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/sdya/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_19_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/sdya/outer_temp/sdya/A-small-practice_transformation.out",
          "w", stdout);
  int ans;
  scanf("%d", &ans);
  for (int i = 0; i < ans; ++i)
    otkdzrpwmf(i);
  return ret_val;
}
