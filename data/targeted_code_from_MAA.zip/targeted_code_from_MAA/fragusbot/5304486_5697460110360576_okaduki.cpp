#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &do_stdjzt_fct(istream &tt, pair<S, T> &p) {
  return tt >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T prfT_Var) {
  if (x < prfT_Var)
    x = prfT_Var;
}
template <class T> void do_voinyl_fct(T &x, T prfT_Var) {
  if (x > prfT_Var)
    x = prfT_Var;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  cin.tie(0);

  int cc;
  scanf("%d ", &cc);
  for (int t_ = (1); t_ < (cc + 1); ++t_) {
    int gati_Var, P;
    scanf("%d %d ", &gati_Var, &P);
    VL rs(gati_Var);
    for (int i = (0); i < (gati_Var); ++i)
      cin >> rs[i];
    VVL qs(gati_Var, VL(P));
    for (int i = (0); i < (gati_Var); ++i) {
      for (int mupi_Var = (0); mupi_Var < (P); ++mupi_Var)
        cin >> qs[i][mupi_Var];
      sort(begin(((qs[i]))), end(((qs[i]))));
    }

    LL ans = 0;
    if (gati_Var == 1) {
      int i;
      for (i = (0); i < (P); ++i) {
        int lb_k = ceil(qs[0][i] * 1. / (rs[0] * 1.1));
        int ub_k = floor(qs[0][i] * 1. / (rs[0] * 0.9));
        if (lb_k <= ub_k)
          ++ans;
      }
    } else {
      int i2 = 0;
      for (int i1 = (0); i1 < (P); ++i1) {
        int lb_k = ceil(qs[0][i1] * 1. / (rs[0] * 1.1));
        int ub_k = floor(qs[0][i1] * 1. / (rs[0] * 0.9));

        for (; i2 < P;) {
          int lb2_k = (int)ceil(qs[1][i2] * 1. / (rs[1] * 1.1));
          int ub2_k = (int)floor(qs[1][i2] * 1. / (rs[1] * 0.9));
          if (lb_k <= ub2_k && lb2_k <= ub_k) {
            ++ans;
            ++i2;
            break;
          } else if (ub_k < lb2_k)
            break;

          ++i2;
        }
      }
    }

    printf("Case #%d: %lld\n", t_, ans);
  }
  return ret_val;
}
