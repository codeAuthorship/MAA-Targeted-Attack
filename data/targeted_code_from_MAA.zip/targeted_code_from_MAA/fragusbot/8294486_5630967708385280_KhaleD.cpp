#include <bits/stdc++.h>
#include <iostream>
using namespace std;

typedef double td_d;
typedef long long ll;

typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 100002;
int ans, d, tt, pos[N], speed[N];

inline void nkecpptdmr(int &cc) {
  scanf("%d%d", &d, &tt);
  for (int i = (1); i <= (int)(tt); ++i)
    scanf("%d%d", &pos[i], &speed[i]);

  td_d maxT = 0;

  for (int i = (1); i <= (int)(tt); ++i)
    maxT = max(maxT, 1.0 * (d - pos[i]) / speed[i]);

  printf("Case #%d: %.6f\n", cc, d / maxT);
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);

  scanf("%d", &ans);
  for (int cc = (1); cc <= (int)(ans); ++cc)
    nkecpptdmr(cc);
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
