#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/WCG/A-small-practice.in",
          "r", stdin);
  int tt;
  scanf("%d ", &tt);
  for (int t = 1; t <= tt; ++t) {
    int d, n;
    scanf("%d %d ", &d, &n);

    long long bk, bs, k, s;
    scanf("%lld %lld ", &k, &s);
    k = d - k;
    bk = k;
    bs = s;
    for (int i = 1; i < n; ++i) {
      scanf("%lld %lld ", &k, &s);
      k = d - k;
      if (s * bk < bs * k) {
        bs = s;
        bk = k;
      }
    }
    bs *= d;
    long long q = bs / bk, cc = bs % bk;

    cout << "Case #" << t << ": " << q << ".";
    for (int i = 0; i < 6; ++i) {
      cc = cc * 10;
      cout << cc / k;
      cc = cc % k;
    }
    cout << endl;
  }
  return ret_val;
}
