#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &do_stdnix_fct(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);
  cin.tie(0);
  int tt;
  scanf("%d ", &tt);
  for (int lidi_Var = (1); lidi_Var < (tt + 1); ++lidi_Var) {
    LL D, cc;
    scanf("%lld %lld ", &D, &cc);
    double mn = 0;
    vector<PLL> xs(cc);
    {
      int i = (0);
      while (i < (cc)) {
        cin >> xs[i];
        ++i;
      }
    }
    {
      int i = (0);
      while (i < (cc)) {
        mn = max(mn, (D - xs[i].first) * 1. / xs[i].second);
        ++i;
      }
    }
    double ans = D / mn;
    printf("Case #%d: %.9f\n", lidi_Var, ans);
  }
  return ret_val;
}
