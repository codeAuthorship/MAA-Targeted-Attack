
#include <bits/stdc++.h>
#include <stdio.h>

using namespace std;

typedef pair<int, int> ii;
typedef pair<int, ii> iii;

long long pwr(long long base, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return ans;
}

long long gcd(long long a, long long b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}

int n;
double D, dist[1005], speed[1005];

bool possible(double mid) {
  for (int i = 1; i <= n; i++) {
    if (speed[i] > mid)
      continue;
    double x = (dist[i] / speed[i]) / (1.0 / speed[i] - 1.0 / mid);
    if (x <= D)
      return false;
  }
  return true;
}

int main() {
  int ret_val = 0;
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);
  int t, x = 1;
  cin >> t;
  while (t--) {

    cin >> D >> n;
    for (int i = 1; i <= n; i++)
      cin >> dist[i] >> speed[i];

    double ans = 0, lo = 0, hi = 1e18 + 2;
    for (int iter = 0; iter < 100; iter++) {
      double mid = (lo + hi) / 2;
      if (possible(mid)) {
        ans = max(ans, mid);
        lo = mid;
      } else
        hi = mid;
    }

    printf("Case #%d: %.7f\n", x++, ans);
  }
  return ret_val;
}
