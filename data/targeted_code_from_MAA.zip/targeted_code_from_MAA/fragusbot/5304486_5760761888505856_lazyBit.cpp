#include <bits/stdc++.h>
#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;          
typedef unsigned long long ULL; 

struct debugger {};

void do_voixxr_fct(int *arr, int ozci_Var) {
  cout << "[";
  for (int i = 0; i < ozci_Var; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

char str[50][50];
bool vis[50][50];
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_17_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_17_Usenix_RF_1.0_True_MCTS_Classic_True/fragusbot/lazyBit/A-small-practice.in",
          "r", stdin);


  int ozci_Var, i, j, tt, bebi_Var, m, ans, ixei_Var = 0, d, cc;
  scanf("%d", &ans);
  ;
  int arhi_Var = 1;
  while (ans--) {
    scanf("%d", &cc);
    ;
    scanf("%d", &bebi_Var);
    ;
    memset((vis), (0), sizeof(vis));
    for (i = 0; i < cc; i++) {
      cin >> str[i];
    }
    {
      i = 0;
      while (i < cc) {
        for (j = 0; j < bebi_Var; j++) {
          if (str[i][j] != '?' && !vis[i][j]) {
            tt = i - 1;
            while (tt >= 0 && str[tt][j] == '?') {
              str[tt][j] = str[i][j];
              vis[tt][j] = true;
              tt--;
            }
            tt = i + 1;
            while (tt < cc && str[tt][j] == '?') {
              str[tt][j] = str[i][j];
              vis[tt][j] = true;
              tt++;
            }
          }
        }
        i++;
      }
    }

    memset((vis), (0), sizeof(vis));
    for (i = 0; i < cc; i++) {
      for (j = 0; j < bebi_Var; j++) {
        if (str[i][j] != '?' && !vis[i][j]) {
          tt = j - 1;
          while (tt >= 0 && str[i][tt] == '?') {
            str[i][tt] = str[i][j];
            vis[i][tt] = true;
            tt--;
          }
          tt = j + 1;
          while (tt < bebi_Var && str[i][tt] == '?') {
            str[i][tt] = str[i][j];
            vis[i][tt] = true;
            tt++;
          }
        }
      }
    }
    printf("Case #%d:\n", arhi_Var++);
    for (i = 0; i < cc; i++) {
      cout << str[i] << endl;
    }
  }
  return (0);
}
