#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <vector>
using namespace std;
const double eps = 1e-9;
const double EPS = 1e-9;

inline void T(int &tc) {
  int s = 1;
  for (; s <= tc;) {
    long long n, i, j, z;
    map<long long, long long> m;
    queue<long long> q;
    cin >> n >> i;

    q.push(n);
    m[n] = 1;

    for (; i > 0;) {
      long long c = q.front();
      q.pop();
      j = c / 2;
      z = (c - 1) / 2;
      i -= m[c];
      if (m.find(j) == m.end())
        q.push(j);
      m[j] += m[c];
      if (m.find(z) == m.end())
        q.push(z);
      m[z] += m[c];
    }

    printf("Case #%d: %lld %lld\n", s, j, z);
    ++s;
  }
}

int main() {
  int tc;

  cin >> tc;

  T(tc);

  return 0;
}
