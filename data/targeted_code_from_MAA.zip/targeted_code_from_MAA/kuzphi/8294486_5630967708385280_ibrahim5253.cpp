#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
const int MOD = 1000000007;
const int INF = 1000000000;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void vpzypzihte(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll do_llmdi_fct(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    vpzypzihte(a, b, t);
  return b;
}

ll fast_exp(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool is_set(int i, ll v) { return (v >> i) & 1; }

int get(ll v) {
  int ans = 0;
  int i;
  for (i = 0; i < 64; ++i)
    if (is_set(i, v))
      ++ans;
  return ans;
}

int solve(ll v) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, v))
      return i - 1;
  return -1;
}

inline void vhsmairriv(double &mt, ll &d) {
  ll k, s;
  cin >> k >> s;
  mt = max(mt, (d - k) / static_cast<double>(s));
}

inline void fftxbjtozx(int &i) {
  ll d, n;
  cin >> d >> n;
  double mt = 0;
  int j;
  for (j = 0; j < n; ++j)
    vhsmairriv(mt, d);
  printf("Case #%d: %.10f\n", i, d / mt);
}

int main() {

  int t;
  cin >> t;
  int i;
  for (i = 1; i <= t; ++i)
    fftxbjtozx(i);
  return 0;
}
