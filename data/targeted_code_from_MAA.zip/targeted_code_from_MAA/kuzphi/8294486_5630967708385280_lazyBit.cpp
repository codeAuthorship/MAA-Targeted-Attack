#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
ifstream fin;

const int MOD = 1000000007;
const long double PI = 3.1415926535897932384626433832795;

typedef set<int> si;
typedef double td_d;
typedef long double ld;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<string> vs;

typedef long long LL;            
typedef unsigned long long ull;  

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
} N;

inline void ynjemspedf(int &n, int *a) {
  int i = 0;
  while (i < n) {
    cout << a[i] << " ";
    i++;
  }
}

void debugarr(int *a, int n) {
  cout << "[";
  ynjemspedf(n, a);
  cout << "]" << endl;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_16_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/lazyBit/A-small-practice.in");

  ;
 

  int n, i, j, k, b, m, t, s = 0, d, p;
  fin >> t;
  ;
  int c = 1;
  while (t--) {
    fin >> d;
    ;
    fin >> n;
    ;
    td_d ans = 0.0;
    td_d r;
 
    for (i = 0; i < n; i++) {
      fin >> k;
      ;
      fin >> s;
      ;
      td_d r = ((d - k) * 1.0) / s;
 
      ans = max(ans, r);
    }
    printf("Case #%d: %0.6lf\n", c++, d / ans);
  }
  return (0);
}
