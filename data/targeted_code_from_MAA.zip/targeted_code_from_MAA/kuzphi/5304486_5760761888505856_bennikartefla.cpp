#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

typedef pair<int, int> ii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_7_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/bennikartefla/A-small-practice.in");

  int t;
  fin >> t;
  for (int u = (0); u < (t); u++) {
    int n, m;
    fin >> n >> m;
    char N[500][500];
    bool vis[500][500];
    memset(vis, 0, sizeof(vis));
    for (int i = (0); i < (n); i++)
      for (int a = (0); a < (m); a++)
        fin >> N[i][a];
    for (int i = (0); i < (n); i++)
      for (int a = (0); a < (m); a++) {
        if (N[i][a] != '?')
          if (!vis[i][a]) {
            vis[i][a] = true;
            int startx = a;
            int endx = a;
            char am = N[i][a];
            for (int a2 = (a + 1); a2 < (m); a2++) {
              if (N[i][a2] == '?') {
                N[i][a2] = am;
                vis[i][a2] = true;
                endx++;
              } else
                break;
            }
            for (int a2 = a - 1; a2 >= 0; a2--) {
              if (N[i][a2] == '?') {
                N[i][a2] = am;
                vis[i][a2] = true;
                startx--;
              } else {
                break;
              }
            }

            for (int i2 = (i + 1); i2 < (n); i2++) {
              bool can = 1;
              for (int a2 = (startx); a2 < (endx + 1); a2++)
                if (N[i2][a2] != '?')
                  can = false;
              if (can) {
                for (int a2 = (startx); a2 < (endx + 1); a2++) {
                  N[i2][a2] = am;
                  vis[i2][a2] = true;
                }
              } else
                break;
            }
            for (int i2 = i - 1; i2 >= 0; i2--) {
              bool can = true;
              for (int a2 = (startx); a2 < (endx + 1); a2++)
                if (N[i2][a2] != '?')
                  can = false;
              if (can) {
                for (int a2 = (startx); a2 < (endx + 1); a2++) {
                  N[i2][a2] = am;
                  vis[i2][a2] = true;
                }
              } else
                break;
            }
          }
      }
    printf("Case #%d:\n", u + 1);
    for (int i = (0); i < (n); i++) {
      for (int a = (0); a < (m); a++)
        printf("%c", N[i][a]);
      printf("\n");
    }
  }
  return 0;
}
