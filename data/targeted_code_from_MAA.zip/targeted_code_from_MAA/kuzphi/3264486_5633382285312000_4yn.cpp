#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

const int MOD = 1000000007;
const long double PI = 3.1415926535897932384626433832795;

int tc;

inline void gndtsjlqwu(int &get, long long dp[18][2][10], int &i, int &j) {
  dp[i + 1][0][get] += dp[i][1][j];
}

long long ctdy(string input) {
  long long dp[18][2][10];
  memset(dp, 0, sizeof(dp));
  {
    int i = '0';
    for (; i <= input[0];) {
      if (i != input[0]) {
        dp[0][0][i - '0'] = 1;
      } else {
        dp[0][1][i - '0'] = 1;
      }
      i++;
    }
  };
  for (int i = 0; i < input.size() - 1; i++) {
    for (int j = 0; j <= 9; j++) {
      for (int get = j; get <= 9; get++)
        dp[i + 1][0][get] += dp[i][0][j];
    }
    for (int j = 0; j <= 9; j++) {
      if (dp[i][1][j] == 0)
        continue;
      for (int get = j; get <= input[i + 1] - '0'; get++) {
        if (get != input[i + 1] - '0')
          gndtsjlqwu(get, dp, i, j);
        else {
          dp[i + 1][1][get] += dp[i][1][j];
        }
      }
    }
  }
  long long sum = 0;
  for (int i = 0; i <= 9; i++) {
    sum += dp[input.size() - 1][0][i];
    sum += dp[input.size() - 1][1][i];
  }
  return sum;
}

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    char c[30];
    long long num;
    string s;
    cin >> c;
    sscanf(c, "%lld", &num);
    s = c;
    long long goal = ctdy(s);

    long long ub = num, lb = 0, m;
    while (ub - lb > 1) {
      m = (ub + lb) / 2;
      num = m;
      sprintf(c, "%lld", num);
      s = c;
      if (ctdy(s) != goal) {
        lb = m;
      } else {
        ub = m;
      }
    }

    printf("Case #%d: %lld\n", t, ub);
  }
  return 0;
}
