#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

const double eps = 1e-9;
const int MAXN = 1005;
const long double PI = 3.1415926535897932384626433832795;
const int mod = 1000000007;
const int INF = 1000000000;

struct AugPath {
  int A, B;               
  vector<vector<int>> G;  
  vector<bool> visited;   
  vector<int> P;         

  AugPath(int _A, int _B) : A(_A), B(_B), G(_A), P(_B, -1) {}

  void AddEdge(int a, int b) { 
    G[a].push_back(b);
  }
  bool Aug(int x) {
    if (visited[x])
      return 0;
    visited[x] = 1;
 
    for (auto it : G[x]) {
      if (P[it] == -1) {
        P[it] = x;
        return 1;
      }
    }
    for (auto it : G[x]) {
      if (Aug(P[it])) {
        P[it] = x;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int s = 0;
    for (int i = 0; i < A; ++i) {
      visited.resize(A, 0);
      s += Aug(i);
      visited.clear();
    }
    return s;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> s;
    for (int i = 0; i < B; ++i) {
      if (P[i] != -1)
        s.emplace_back(P[i], i);
    }
    return s;
  }
};

int tc;

int d[7][7] = {
    
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0},  
    {0, 0, 0, 0, 0, 1, 0},                        
    {0, 1, 0, 0, 0, 1, 1},                         
    {0, 1, 0, 0, 0, 0, 0},                         
    {0, 1, 1, 1, 0, 0, 0},                         
    {0, 0, 0, 1, 0, 0, 0},                    
};

char color_dict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int next_node[1009], visited[1009];
int c[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string dfs(int node, string cur_string) {
  if (visited[node] == 1) {
    return cur_string;
  }
  visited[node] = 1;
  cur_string = cur_string + color_dict[color[node]];
  return dfs(next_node[node], cur_string);
}

string merge(string a, string b) {
  int found = false;
  int x = 0, y = 0;
  for (int i = 0; i < a.size(); i++) {
    for (int j = 0; j < b.size(); j++) {
      if (a[i] == b[j]) {
        x = i;
        y = j;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
 
  string c = "";
  for (int i = 0; i < b.size(); i++) {
    c += b[(y + i) % b.size()];
  }
  string rt = "";
  for (int i = 0; i < x; i++) {
    rt += a[i];
  }
  rt += c;
  for (int i = x; i < a.size(); i++) {
    rt += a[i];
  }
  return rt;
}
int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_1_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/4yn/A-small-practice.in");

  fin >> tc;
  for (int t = 1; t <= tc; t++) {
    int n;
    fin >> n;
    int counter = 0;
    c[0] = 0;
    for (int i = 1; i < 7; i++) {
      fin >> c[i];
      c[i] += c[i - 1];
      for (int j = c[i - 1]; j < c[i]; j++) {
        color[j] = i;
      }
    }
    AugPath mcbm(n, n);
    memset(adj, 0, sizeof(adj));
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        adj[i][j] = d[color[i]][color[j]];
        if (adj[i][j] == 1) {
          mcbm.AddEdge(i, j);
        }
      }
    }
    auto matches = mcbm.MCBM();
 
    if (matches != n) {
      cout << "Case #" << t << ": IMPOSSIBLE\n";
      continue;
    }

    auto match = mcbm.GetMatchings();

    memset(next_node, -1, sizeof(next_node));
    memset(visited, -1, sizeof(visited));

    for (auto i : match) {
      next_node[i.first] = i.second;
 
    }
    stables.clear();
    for (int i = 0; i < n; i++) {
      if (next_node[i] != -1)
        if (visited[i] == -1) {
          stables.push_back(dfs(i, ""));
        }
    }

    {
      int i = 0;
      while (i < stables.size()) {
        for (int j = 1; j < stables.size(); j++) {
          string test = merge(stables[0], stables[j]);
          if (test != "") {
            stables[0] = test;
            stables[j] = "";
          }
        }
        i++;
      }
    }
    cout << "Case #" << t << ": " << stables[0] << "\n";
  }
  return 0;
}
