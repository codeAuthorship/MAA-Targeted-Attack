#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;
ofstream fout;

const int mod = 1000000007;
const double EPS = 1e-9;

int T;
int n, p;
long long r[1009];

long long eleven(long long c) { return c * 11 / 10; }

long long ninety(long long c) {
  long long y = c * 9 / 10;
  if (c % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  long long c = r[ingredient] * servings;
  return (ninety(c) <= number) && (number <= eleven(c));
}

inline void
get(priority_queue<long long, vector<long long>, greater<long long>> q[1009],
    int &i, long long &tmp) {
  cin >> tmp;
  q[i].push(tmp);
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_1_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  cin >> T;
  for (int t = 1; t <= T; t++) {
    long long tmp;
    priority_queue<long long, vector<long long>, greater<long long>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
      cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++)
        get(q, i, tmp);
    }
    long long ans = 0;
    long long cansendserving = 1;
    long long curservingsize = 1;
    long long b = 1;
    while (1) {
 
      bool okay = 1;
      cansendserving = 1;
      for (int i = 0; i < n; i++) {
        if (q[i].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(i, q[i].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
 
        ans++;
        for (int i = 0; i < n; i++) {
          q[i].pop();
        }
      } else {
 
        b = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          b = min(b, q[i].top() / eleven(r[i]));
        }
        if (b <= curservingsize) {
          b = curservingsize + 1;
        }
        curservingsize = b;
 
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize)) {
            q[i].pop();
          }
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    fout << "Case #" << t << ": " << ans << endl;
  }
  return 0;
}
