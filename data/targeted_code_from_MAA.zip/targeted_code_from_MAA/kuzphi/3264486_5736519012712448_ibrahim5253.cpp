#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
const int MOD = 1000000007;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll solve(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0) {
    a = b;
    b = t;
  }
  return b;
}

bool is_set(int i, ll x) { return (x >> i) & 1; }

int get(ll x) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (is_set(i, x))
      ++ans;
  return ans;
}

int first_bit(ll x) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, x))
      return i - 1;
  return -1;
}

inline void tlbcoyapdl(int &f, int &j, int &p, std::string &s) {
  ++f;
  {
    int v = j;
    for (; v < j + p;) {
      s[v] = (s[v] == '+' ? '-' : '+');
      ++v;
    }
  }
}

inline void zcfiwldkxa(int &f, int &j, int &p, std::string &s) {
  if (s[j] == '-')
    tlbcoyapdl(f, j, p, s);
}

int main() {

  int t;
  scanf("%d ", &t);
  for (int i = 1; i <= t; ++i) {
    string s;
    int p;
    cin >> s >> p;
    int f = 0, n = s.length();
    int j;
    for (j = 0; j < n - p + 1; ++j)
      zcfiwldkxa(f, j, p, s);
    for (int j = 0; j < n; ++j)
      if (s[j] == '-') {
        f = -1;
        break;
      }
    printf("Case #%d: ", i);
    if (f == -1)
      printf("IMPOSSIBLE\n");
    else
      printf("%d\n", f);
  }
  return 0;
}
