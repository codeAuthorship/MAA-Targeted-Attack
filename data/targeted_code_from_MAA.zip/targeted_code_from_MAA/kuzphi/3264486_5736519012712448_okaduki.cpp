#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const int mod = 1000000007;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &n, pair<S, T> &p) {
  return n >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}

template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

int main() {
  cin.tie(0);
  ios_base::sync_with_stdio(false);

  int T;
  cin >> T;
  {
    int t = (1);
    while (t < (T + 1)) {
      string S;
      cin >> S;
      int K;
      cin >> K;
      int N = int((S).size());
      VI s(N);
      {
        int i = (0);
        while (i < (N)) {
          s[i] = S[i] == '+';
          ++i;
        }
      }

      int ans = 0;
      for (int i = 0; i + K <= N; ++i) {
        if (!s[i]) {
          ++ans;
          for (int k = (0); k < (K); ++k) {
            s[i + k] = !s[i + k];
          }
        }
      }
      if (accumulate(begin((s)), end((s)), 0) != N)
        printf("Case #%d: IMPOSSIBLE\n", t);
      else {
        printf("Case #%d: %d\n", t, ans);
      }
      ++t;
    }
  }

  return 0;
}
