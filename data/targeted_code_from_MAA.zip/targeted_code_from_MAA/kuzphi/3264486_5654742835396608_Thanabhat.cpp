#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const double EPS = 1e-9;
const int INF = 1000000000;
const int MOD = 1000000007;

int solve(int T) {
  long long n, k, get = 0, onell = 1LL;
  cin >> n >> k;
  while (k > 0) {
    n -= (onell << get);
    if (k > (onell << get)) {
      k -= (onell << get);
      get++;
    } else {
      break;
    }
 
  }
  long long solmax = 0, solmin = 0;
  if (n > 0) {
    long long d = (onell << (get + 1));
    long long ttt = n / d;
    long long tttt = n % d;
    if (tttt >= k) {
      solmax = ttt + 1;
    } else
      solmax = ttt;

    tttt -= (d / 2);
    if (tttt >= k) {
      solmin = ttt + 1;
    } else {
      solmin = ttt;
    }
  }
  printf("Case #%d: %lld %lld\n", T, solmax, solmin);
  return 1;
}

int main() {
  int get;
  cin >> get;

  for (int i = 0; i < get; i++) {
    solve(i + 1);
  }
  return 0;
}
