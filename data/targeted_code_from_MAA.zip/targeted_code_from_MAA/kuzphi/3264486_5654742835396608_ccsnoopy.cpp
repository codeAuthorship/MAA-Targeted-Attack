#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
using namespace std;
const int mod = 1000000007;
const int MOD = 1000000007;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void open() {}

inline void stbvwtfyuh(int &b) {
  int n, k;
  cin >> n;
  cin >> k;
  priority_queue<int> pq;
  pq.push(n);

  printf("Case #%d: ", b);

  while (k--) {
    int top = pq.top();
    pq.pop();
    int mid = top - 1;
    int ans, r;
    ans = mid / 2;
    r = (mid + 1) / 2;
    if (k == 0) {
      printf("%d %d\n", r, ans);
    }
    if (ans) {
      pq.push(ans);
    }

    if (r) {
      pq.push(r);
    }
  }

  cerr << "Test " << b << " done \n";
  b++;
}

inline void mksbmfiulo(int &tc) {
  int b = 1;
  while (b <= tc)
    stbvwtfyuh(b);
}

int main(void) {
  open();
  int tc;
  cin >> tc;
  mksbmfiulo(tc);
  return 0;
}
