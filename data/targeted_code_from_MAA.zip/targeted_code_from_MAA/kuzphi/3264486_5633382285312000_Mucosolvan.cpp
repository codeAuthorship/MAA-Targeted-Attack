#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;
const int MOD = 1000000007;
typedef unsigned long long ull;
typedef set<int> si;
typedef vector<int> vi;
typedef long long LL;
typedef long double LD;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int T;
string s;

inline void cgouvyucid(int &i) {
  for (int a = (i + 1); a <= ((int)s.size() - 1); ++a)
    s[a] = '9';
  s[i]--;
}

int main() {

  cin >> T;
  for (int x = (1); x <= ((T)); ++x) {
    cin >> s;
    for (int i = ((int)s.size() - 2); i >= (0); --i) {
      if (s[i + 1] < s[i])
        cgouvyucid(i);
    }
    if (s[0] == '0')
      s = s.substr(1, (int)s.size() - 1);
    printf("Case #%d: ", x);
    printf("%s\n", s.c_str());
  }
  return 0;
}
