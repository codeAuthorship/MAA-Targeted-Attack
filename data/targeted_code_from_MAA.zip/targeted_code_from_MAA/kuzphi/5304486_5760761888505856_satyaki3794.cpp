// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MAXN = 1005;

long long pwr(long long base, long long p, long long T = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % T;
    base = (base * base) % T;
    p /= 2;
  }
  return ans;
}

long long gcd(long long a, long long b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}

int r, c;
char n[26][26];

int main() {

  cin.tie(0);

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    cin >> r >> c;
    for (int i = 1; i <= r; i++)
      cin >> (n[i] + 1);

    for (int i = 1; i <= r; i++)
      for (int j = 1; j <= c; j++)
        if (n[i][j] != '?') {

          int miny = j, maxy = j;

          int y = j - 1;
          while (y >= 1 && n[i][y] == '?') {
            n[i][y--] = n[i][j];
            miny = y + 1;
          }

          y = j + 1;
          while (y <= c && n[i][y] == '?') {
            n[i][y++] = n[i][j];
            maxy = y - 1;
          }
        }

    queue<pair<int, int>> qq;
    for (int i = 1; i <= r; i++)
      if (n[i][1] != '?') {

        int x = i - 1;
        for (; x >= 1 && n[x][1] == '?';) {
          for (int j2 = 1; j2 <= c; j2++)
            n[x][j2] = n[x + 1][j2];
          x--;
        }

        x = i + 1;
        while (x <= r && n[x][1] == '?') {
          for (int j2 = 1; j2 <= c; j2++)
            n[x][j2] = n[x - 1][j2];
          x++;
        }
      }

    printf("Case #%d:\n", x++);
    for (int i = 1; i <= r; i++)
      printf("%s\n", (n[i] + 1));
  }

  return 0;
}
