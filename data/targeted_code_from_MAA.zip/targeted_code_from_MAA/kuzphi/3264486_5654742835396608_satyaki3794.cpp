// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;

const int MOD = 1000000007;

typedef vector<int> vi;
typedef set<int> si;
typedef long long LL;

typedef pair<LL, LL> ii;

LL pwr(LL c, LL p, LL mod = (1000000007LL)) {
  LL ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * c) % mod;
    c = (c * c) % mod;
    p /= 2;
  }
  return ans;
}

struct compare {
  bool operator()(const ii &a, const ii &b) const {
    if ((a.first - 1) / 2 != (b.first - 1) / 2)
      return a.first > b.first;
    return (a.first - 1 - (a.first - 1) / 2) >
           (b.first - 1 - (b.first - 1) / 2);
  }
};

set<ii> arr;

int main() {

  cin.tie(0);

  // for(int i=1;i<=10;i++)
  //     arr.insert(ii(i, 0));
  // for(auto it : arr)
  //     cout<<it.ff<<" ";cout<<endl;

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    LL n, N;
    cin >> n >> N;
    // k--;

    arr.clear();
    arr.insert(ii(-n, 1));
    set<ii>::iterator it;
    LL ans_l, ans_r;

    // int ctr = 0;
    while (N > 0) {

      // ctr++;
      // if(ctr == 10)   break;

      assert(!arr.empty());
      it = arr.begin();
      ii temp = (*it);
      temp.first *= -1;
      arr.erase(it);
      if (temp.second == 0)
        continue;

      // cout<<endl;
      // cout<<"now at "<<temp.ff<<" "<<temp.ss<<endl;

      LL z = min(N, temp.second);
      if (temp.second > z) {
        arr.insert(ii(-temp.first, temp.second - z));
        temp.second = z;
      }
      N -= z;

      LL l = (temp.first - 1) / 2, r = temp.first - 1 - l;
      ans_l = max(l, r);
      ans_r = min(l, r);

      // cout<<"got "<<l<<" "<<r<<" and k = "<<k<<endl;

      if (l > 0) {
        it = arr.lower_bound(ii(-l, -1));
        if (it != arr.end() && (*it).first == -l) {
          LL cnt = (*it).second + temp.second;
          arr.erase(it);
          arr.insert(ii(-l, cnt));
          // cout<<"pushed "<<l<<" "<<cnt<<" at left"<<endl;
        } else {
          LL cnt = temp.second;
          arr.insert(ii(-l, cnt));
          // cout<<"pushed "<<l<<" "<<cnt<<" at left"<<endl;
        }
      }

      if (r > 0) {
        it = arr.lower_bound(ii(-r, -1));
        if (it != arr.end() && (*it).first == -r) {
          LL cnt = (*it).second + temp.second;
          arr.erase(it);
          arr.insert(ii(-r, cnt));
          // cout<<"pushed "<<r<<" "<<cnt<<" at right"<<endl;
        } else {
          LL cnt = temp.second;
          arr.insert(ii(-r, cnt));
          // cout<<"pushed "<<r<<" "<<cnt<<" at right"<<endl;
        }
      }
    }

    cout << "Case #" << x++ << ": " << ans_l << " " << ans_r << endl;
  }

  return 0;
}
