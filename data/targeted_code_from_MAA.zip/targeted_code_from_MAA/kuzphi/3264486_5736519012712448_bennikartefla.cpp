#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void bjmqreujpr(int &howmany) { howmany += 1000000; }

int doit(string s, int len) {
  int howmany = 0;
  while (true) {
    if (s.size() == len) {
      int f1 = 0;
      int f2 = 0;
      for (int i = (0); i < (len); i++) {
        if (s[i] == '+')
          f1++;
        else
          f2++;
      }
      if (f1 == len) {

      } else if (f2 == len) {
        howmany++;
      } else
        bjmqreujpr(howmany);

      break;
    } else {
      if (s[0] == '+')
        s.erase(s.begin());
      else {
        int i;
        {
          i = (0);
          while (i < (len)) {
            if (s[i] == '+')
              s[i] = '-';
            else
              s[i] = '+';
            i++;
          }
        }
        howmany++;
      }
    }
  }
  return howmany;
}

int main() {

  int n;
  cin >> n;
  {
    int i = (0);
    while (i < (n)) {
      string s;
      cin >> s;
      int x;
      cin >> x;
      int bst = INF;
      bst = min(doit(s, x), bst);
      reverse(s.begin(), s.end());
      bst = min(doit(s, x), bst);
      printf("Case #%d: ", i + 1);
      if (bst > 10000)
        printf("IMPOSSIBLE\n");
      else
        printf("%d\n", bst);
      i++;
    }
  }
  return 0;
}
