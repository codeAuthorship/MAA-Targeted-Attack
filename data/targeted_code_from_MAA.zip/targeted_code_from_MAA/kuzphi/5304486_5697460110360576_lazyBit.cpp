#include <bitset>
#include <cctype>
#include <climits>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ULL;  
typedef unsigned uint;

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &get(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

int req[110], lb[110], ub[110];
int q[110][110];
inline void mfmlptstvm(_Bool vis[52][52], vector<pair<int, int>> &v, int &o) {
  vis[v[o].first][v[o].second] = false;
}

inline void wiwbgavzfi(_Bool vis[52][52], vector<pair<int, int>> &v) {
  for (int o = 0; o < v.size(); o++)
    mfmlptstvm(vis, v, o);
}

inline void unglbypjns(int &p, int &i, int &j) {
  for (j = 0; j < p; j++) {
    cin >> q[i][j];
    ;
  }
}

int main() {

  ;

  ;

  int n, i, j, b, l, x, t, s = 0, d, r, ans, p;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    memset((req), (0), sizeof(req));
    memset((lb), (0), sizeof(lb));
    memset((ub), (0), sizeof(ub));
    memset((q), (0), sizeof(q));
    cin >> n;
    ;
    cin >> p;
    ;
    for (i = 0; i < n; i++) {
      cin >> req[i];
      ;
    }
    for (i = 0; i < n; i++)
      unglbypjns(p, i, j);
    for (i = 0; i < n; i++)
      sort(q[i], q[i] + p);

    for (i = 0; i < n; i++) {
      double nt = (9 * req[i]) / 10.0;
      lb[i] = (int)nt;
      if (lb[i] < nt)
        lb[i]++;
      ub[i] = (11 * req[i]) / 10;
    }
    int ns;
    ans = 0;
    bool vis[52][52];
    memset((vis), (0), sizeof(vis));
 
    for (i = 0; i < n; i++) {
      for (j = 0; j < p; j++) {
        if (q[i][j] < lb[i])
          continue;
        ns = q[i][j] / lb[i];
        int mx = q[i][j] / ub[i];
        if (mx * ub[i] < q[i][j]) {
          mx++;
        }
        swap(mx, ns);
        while (ns <= mx) {
          int f = 1;
 
          vector<pair<int, int>> v;
          v.clear();
          for (int x = i + 1; x < n; x++) {
            f = 0;
            for (int o = 0; o < p; o++) {
    
              if (!vis[x][o] && ns * lb[x] <= q[x][o] &&
                  ns * ub[x] >= q[x][o]) {
                vis[x][o] = true;
                v.push_back(make_pair(x, o));
                f = 1;
                break;
              }
            }
 
            if (f == 0)
              break;
          }
          if (f == 0)
            wiwbgavzfi(vis, v);
          else {
            ans++;

            break;
          }
          ns++;
        }
      }
      break;
    }
    printf("Case #%d: %d\n", c++, ans);
  }
  return (0);
}
