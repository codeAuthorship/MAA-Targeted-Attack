#include <bitset>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
const int MOD = 1000000007;

typedef pair<int, int> ii;

typedef vector<string> vs;

typedef long long LL;            
typedef unsigned long long ULL;  

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

inline void krtypdvxmi(int *arr, int &i) { cout << arr[i] << " "; }

void get(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    krtypdvxmi(arr, i);
  cout << "]" << endl;
}

char str[50][50];
bool vis[50][50];
inline void fetqiiotfv(int &ans, int &j, int &i, int &tc) {
  if (str[i][j] != '?' && !vis[i][j]) {
    tc = j - 1;
    while (tc >= 0 && str[i][tc] == '?') {
      str[i][tc] = str[i][j];
      vis[i][tc] = true;
      tc--;
    }
    tc = j + 1;
    while (tc < ans && str[i][tc] == '?') {
      str[i][tc] = str[i][j];
      vis[i][tc] = 1;
      tc++;
    }
  }
}

inline void oixzfrhred(int &i, int &j, int &tc) {
  str[tc][j] = str[i][j];
  vis[tc][j] = true;
  tc--;
}

int main() {
 
  int n, i, j, tc, ans, m, t, s = 0, d, r;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> r;
    ;
    cin >> ans;
    ;
    memset((vis), (0), sizeof(vis));
    for (i = 0; i < r; i++) {
      cin >> str[i];
    }
    for (i = 0; i < r; i++) {
      for (j = 0; j < ans; j++) {
        if (str[i][j] != '?' && !vis[i][j]) {
          tc = i - 1;
          while (tc >= 0 && str[tc][j] == '?')
            oixzfrhred(i, j, tc);
          tc = i + 1;
          while (tc < r && str[tc][j] == '?') {
            str[tc][j] = str[i][j];
            vis[tc][j] = true;
            tc++;
          }
        }
      }
    }

    memset((vis), (0), sizeof(vis));
    for (i = 0; i < r; i++) {
      for (j = 0; j < ans; j++)
        fetqiiotfv(ans, j, i, tc);
    }
    printf("Case #%d:\n", c++);
    for (i = 0; i < r; i++)
      cout << str[i] << endl;
  }
  return (0);
}
