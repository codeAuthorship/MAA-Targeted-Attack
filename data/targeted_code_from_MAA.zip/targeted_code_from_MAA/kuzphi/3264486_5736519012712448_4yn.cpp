#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const double eps = 1e-9;
const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;
const int INF = 1000000000;

int tc;

inline void zgbyxsqidn(int &fl, int &get, int &k, std::string &s) {
 
  fl++;
  for (int j = get; j < get + k; j++) {
    if (s[j] == '-')
      s[j] = '+';
    else
      s[j] = '-';
  }
}

int main() {
  scanf("%d ", &tc);
  for (int t = 1; t <= tc; t++) {
    string s;
    int k, fl = 0;
    cin >> s >> k;
    int get;
    {
      get = 0;
      for (; get < s.size() - k + 1;) {
        if (s[get] == '-')
          zgbyxsqidn(fl, get, k, s);
        get++;
      }
    }
    int f = 1;
    for (int get = s.size() - k + 1; get < s.size(); get++) {
      if (s[get] == '-')
        f = 0;
    }
    if (f == 1)
      printf("Case #%d: %d\n", t, fl);
    else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
  return 0;
}
