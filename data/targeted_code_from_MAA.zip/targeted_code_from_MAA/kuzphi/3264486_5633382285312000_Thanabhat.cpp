#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;
const double eps = 1e-9;

int T(int get) {
  string n;
  cin >> n;
  int p = 0;
  while (p < n.length() - 1) {
    if (n[p] > n[p + 1]) {
      break;
    }
    p++;
  }
  if (p == n.length() - 1) {
    printf("Case #%d: %s\n", get, n.c_str());
    return 1;
  }
  for (; p > 0 && n[p - 1] == n[p];) {
    p--;
  }
  n[p] = n[p] - 1;
  for (int i = p + 1; i < n.length(); i++)
    n[i] = '9';

  if (n[0] == '0') {
    n.erase(n.begin());
  }
  printf("Case #%d: %s\n", get, n.c_str());
  return 1;
}

int main() {
  int r;
  scanf("%d ", &r);
  {
    int i = 0;
    while (i < r) {
      T(i + 1);
      i++;
    }
  }

  return 0;
}
