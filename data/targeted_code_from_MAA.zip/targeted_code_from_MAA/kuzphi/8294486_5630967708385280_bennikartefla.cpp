#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
typedef double td_d;

const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;
const int MAXN = 1005;
const int MOD = 1000000007;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void snrzpanige(double &n, double &t2) {
  td_d a, b;
  cin >> a >> b;
  td_d t = (n - a) / b;
  t2 = max(t, t2);
}

inline void zcwacqhzac(std::ofstream &fout, int &u) {
  td_d n, m;
  cin >> n >> m;
  td_d t2 = 0;
  for (int i = (0); i < (m); i++)
    snrzpanige(n, t2);
  fout << "Case #" << u + 1 << ": " << setprecision(10) << fixed << n / t2
       << endl;
}

int main() {

  ofstream fout("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_7_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  for (int u = (0); u < (t); u++)
    zcwacqhzac(fout, u);
  return 0;
}
