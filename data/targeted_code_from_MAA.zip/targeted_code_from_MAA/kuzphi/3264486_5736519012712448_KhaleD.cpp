#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const double eps = 1e-9;
const int MOD = 1000000007;
typedef long long LL;

typedef pair<LL, LL> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 200002;
int t, n, k;
char a[N];

bool solve() {
  for (int i = (0); i <= (int)(n - 1); ++i)
    if (a[i] == '-')
      return false;
  return true;
}

inline void qwajglpsvv(int &testCase) {
  cin >> a;
  n = strlen(a);
  cin >> k;

  int ans = 0;
  for (int i = (0); i <= (int)(n - k); ++i)
    if (a[i] == '-') {
      ++ans;
      for (int j = (i); j <= (int)(i + k - 1); ++j)
        a[j] = a[j] == '-' ? '+' : '-';
    }

  if (solve())
    cout << "Case #" << testCase << ": " << ans << "\n";
  else
    cout << "Case #" << testCase << ": IMPOSSIBLE\n";
}

int main() {

  cin >> t;
  for (int testCase = (1); testCase <= (int)(t); ++testCase)
    qwajglpsvv(testCase);
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
