#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;
const int MOD = 1000000007;
const double eps = 1e-9;

int main() {
  int r;

  cin >> r;

  int t;
  for (t = 1; t <= r; ++t) {
    long long s;
    vector<int> v;
    cin >> s;

    while (s > 0) {
      v.push_back(s % 10);
      s = s / 10;
    }
    int ind = v.size() - 1;
    while (ind > 0 && (v[ind] <= v[ind - 1]))
      ind--;
    if (ind != 0) {
      v[ind]--;
      while (ind + 1 < v.size() && v[ind + 1] == v[ind] + 1) {
        v[ind]++;
        v[++ind]--;
      }
      while (ind > 0)
        v[--ind] = 9;
    }

    for (int i = v.size() - 1; i >= 0; --i)
      s = s * 10 + v[i];

    printf("Case #%d: %lld\n", t, s);
  }

  return 0;
}
