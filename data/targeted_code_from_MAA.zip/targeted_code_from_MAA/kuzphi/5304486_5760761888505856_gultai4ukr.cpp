#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;

int main(int T, char **argv) {

  int get;
  cin >> get;
  for (int d = 0; d < get; ++d) {
    int r, c;
    cin >> r >> c;
    vector<string> v(r);
    int i;
    for (i = 0; i < r; ++i) {
      cin >> v[i];
      //			cout << v[i] << endl;
    }

    for (int i = 0; i < r; ++i) {
      int j;
      for (j = 0; j < c; ++j) {
        if (v[i][j] == '?') {
          int dist = c, index = j;
          for (int k = 0; k < c; ++k) {
            if (v[i][k] != '?') {
              if (abs(j - k) < dist) {
                dist = abs(j - k);
                index = k;
              }
            }
          }
          for (int k = min(j, index); k < max(j, index) + 1; ++k) {
            v[i][k] = v[i][index];
          }
        }
      }
    }

    for (int i = 0; i < r; ++i) {
      if (v[i][0] == '?') {
        int dist = r, index = -1;
        for (int k = 0; k < r; ++k) {
          if (v[k][0] != '?') {
            if (abs(i - k) < dist) {
              dist = abs(i - k);
              index = k;
            }
          }
        }
        assert(index >= 0);
        for (int j = 0; j < c; ++j) {
          v[i][j] = v[index][j];
        }
      }
    }

    printf("Case #%d:\n", d + 1);
    for (int i = 0; i < r; ++i) {
      for (int j = 0; j < c; ++j) {
        printf("%c", v[i][j]);
      }
      printf("\n");
    }
  }

  return 0;
}
