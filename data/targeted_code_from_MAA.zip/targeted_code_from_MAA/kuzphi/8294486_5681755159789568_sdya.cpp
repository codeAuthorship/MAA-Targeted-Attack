#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const double eps = 1e-9;
const int mod = 1000000007;
ifstream fin;

const int MAXN = 1005;

void get() {}

const int maxN = 110;
const long long inf = 1000000000000000000LL;

int n, q;
long long d[maxN][maxN];
long long e[maxN], s[maxN];

long long a[maxN], b[maxN];

double c[maxN];

double solve(int u, int v) {
  --u;
  --v;

  for (int i = 0; i < n; ++i) {
    c[i] = 1e50;
  }
  c[u] = 0.0;

  for (int steps = 0; steps < 200; ++steps) {
    {
      int i = 0;
      while (i < n) {
        for (int j = 0; j < n; ++j) {
          if (e[i] < d[i][j]) {
            continue;
          } else if (i == j || d[i][j] == inf) {
            continue;
          }
          c[j] = min(c[j], c[i] + (double)(d[i][j]) / (double)(s[i]));
        }
        ++i;
      }
    }
  }
  return c[v];
}

inline void kkzsozoszf(int &i, int &j) { d[i][j] = inf; }

void solve(int test) {
  fin >> n >> q;
  {
    int i = 0;
    while (i < n) {
      fin >> e[i] >> s[i];
      ++i;
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      fin >> d[i][j];
      if (d[i][j] == -1)
        kkzsozoszf(i, j);
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      for (int r = 0; r < n; ++r) {
        d[j][r] = min(d[j][r], d[j][i] + d[i][r]);
      }
    }
  }

  vector<double> res;
  for (int i = 0; i < q; ++i) {
    int u, v;
    fin >> u >> v;
    res.push_back(solve(u, v));
  }

  printf("Case #%d:", test);
  for (int i = 0; i < q; ++i) {
    printf(" %.10lf", res[i]);
  }
  printf("\n");
}

int main(int y, char *argv[]) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_19_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sdya/A-small-practice.in");

  int left_bound, right_bound;

 

  int t;
  fin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else {
      get();
    }
    cerr << i << ": " << clock() << endl;
  }

  return 0;
}
