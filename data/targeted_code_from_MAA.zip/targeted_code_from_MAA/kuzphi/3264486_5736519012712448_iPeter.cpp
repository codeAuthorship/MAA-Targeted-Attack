#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const double EPS = 1e-9;
const int MAXN = 1005;
const int INF = 1000000000;
ofstream fout;

char s[2000];
inline void irrqjxpush(int &n) { n = -1; }

inline void flqnrwzwpa(int &k, int &n) {
  int j = 0;
  for (; j < k;) {
    if (s[j] == '-')
      irrqjxpush(n);
    ++j;
  }
}

inline void qwxaxptoro(int &n, int &k, int &i) {
  ++n;
  for (int j = 0; j < k; ++j) {
    s[i - j] = (s[i - j] == '-' ? '+' : '-');
  }
}

int main(void) {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_12_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/iPeter/outer_temp/iPeter/A-small-practice_transformation.out");

  int t;
  cin >> t;
  {
    int T = 1;
    while (T <= t) {
      int n = 0, k;
      cin >> s >> k;
      {
        int i = strlen(s) - 1;
        while (i + 1 >= k) {
          if (s[i] == '-')
            qwxaxptoro(n, k, i);
          // printf("%c %s\n", s[i], s);
          --i;
        }
      }
      flqnrwzwpa(k, n);

      if (n < 0) {
        fout << "Case #" << T << ": IMPOSSIBLE\n";
        T++;
        continue;
      }
      fout << "Case #" << T << ": " << n << "\n";
      T++;
    }
  }
  return 0;
}
