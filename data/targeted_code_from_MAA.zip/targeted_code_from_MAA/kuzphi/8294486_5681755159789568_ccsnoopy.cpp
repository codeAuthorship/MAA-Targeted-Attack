#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;
const double eps = 1e-9;
const int mod = 1000000007;

typedef set<int> si;
typedef long long LL;
typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<int> VI;

void open() {}
int n, q, fr, to;
int energy[120];
int spd[120];
int dist[120][120];
map<pair<PII, int>, double> memo;

double dp(int idx, int pony, int left) {
  pair<PII, int> z = make_pair(PII(idx, pony), left);
  if (idx == to)
    return 0;
  if (memo.find(z) != memo.end() && memo[z] < 1e12)
    return memo[z];

  double ans = 1e12;

  if (dist[idx][idx + 1] <= left) {
    ans = min(dp(idx + 1, pony, left - dist[idx][idx + 1]) +
                  1.0 * dist[idx][idx + 1] / spd[pony],
              ans);
  }

  if (dist[idx][idx + 1] <= energy[idx]) {
    ans = min(ans, dp(idx + 1, idx, energy[idx] - dist[idx][idx + 1]) +
                       1.0 * dist[idx][idx + 1] / spd[idx]);
  }
  return memo[z] = ans;
}

inline void arzjzpmvbr(int &ct) {
  cin >> n;
  cin >> q;

  for (int i = 0; i < n; i++) {
    cin >> energy[i];
    cin >> spd[i];
  }

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++)
      cin >> dist[i][j];
  }

  cin >> fr;
  cin >> to;
  fr--;
  to--;
  memo.clear();

  printf("Case #%d: %.10lf\n", ct, dp(0, 0, energy[0]));

  cerr << "Test " << ct << " done \n";
}

int main(void) {
  open();
  int tc;
  cin >> tc;

  for (int ct = 1; ct <= tc; ct++)
    arzjzpmvbr(ct);
  return 0;
}
