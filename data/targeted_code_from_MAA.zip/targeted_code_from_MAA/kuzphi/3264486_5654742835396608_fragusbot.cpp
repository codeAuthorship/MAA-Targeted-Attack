#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int INF = 1000000000;

struct E {
  int l, r;
  E(int nl, int nr) : l(nl), r(nr) {}
  bool operator<(const E &o) const {
    int v = r - l;
    int ov = o.r - o.l;
    if (v / 2 != ov / 2) {
      return v / 2 > ov / 2;
    }

    if ((v + 1) / 2 != (ov + 1) / 2) {
      return (v + 1) / 2 > (ov + 1) / 2;
    }

    return l < o.l;
  }
};

inline void solve(int &d) {
  printf("Case #%d: ", d);
  int n, k;
  cin >> n >> k;
  set<E> ss = {{0, n + 1}};
  while (k-- > 1) {
    int l = ss.begin()->l;
    int r = ss.begin()->r;
    ss.erase(ss.begin());
    int s = (l + r) / 2;
    if (s - l - 1 >= 1)
      ss.emplace(l, s);

    if (r - s - 1 >= 1) {
      ss.emplace(s, r);
    }
  }
  int ans = ss.begin()->r - ss.begin()->l;
  printf("%d %d\n", (ans + 1) / 2 - 1, ans / 2 - 1);
}

int main() {
  int tt;
  cin >> tt;
  for (int d = 1; d <= tt; ++d)
    solve(d);
  return 0;
}
