
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <numeric>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

void work() {
  string s;
  cin >> s;
  int pos;
  for (int c = 1; c <= 18; ++c) {
    pos = -1;
    for (int i = 0; i < (int)s.size() - 1; ++i) {
      if (s[i] > s[i + 1]) {
        s[i]--;
        pos = i + 1;
        break;
      }
    }
    if (pos != -1) {
      for (int i = pos; i < (int)s.size(); ++i) {
        s[i] = '9';
      }
    }
  }
  for (int i = 0; i < (int)s.size(); ++i) {
    if (s[i] != '0') {
      pos = i;
      break;
    }
  }
  for (int i = pos; i < (int)s.size(); ++i) {
    cout << s[i];
  }
  cout << endl;
}

int main() {

  int q;
  scanf("%d ", &q);
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    work();
  }
  return 0;
}
