#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int mod = 1000000007;
const int MAXN = 1005;
const long double PI = 3.1415926535897932384626433832795;

ifstream fin("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/A-small-practice.in");

inline bool vwcqsvdbrd() {
  printf("IMPOSSIBLE\n");
  return true;
  return false;
}

void solve() {
  int n, r, o, y, g, b, v;
  fin >> n >> r >> o >> y >> g >> b >> v;
  int tc[2000] = {};
  int cs[] = {r, y, b};
  int i;
  for (i = 0; i < n; i++) {
    int mxi = 0, mxamt = -1;
    for (int j = 0; j < 3; j++) {
      if (i > 0 && tc[i - 1] == j)
        continue;
      if (cs[j] > mxamt || (cs[j] == mxamt && j == tc[0]))
        mxi = j, mxamt = cs[j];
    }
    if (mxamt <= 0 || (i == n - 1 && mxi == tc[0])) {
      if (vwcqsvdbrd()) {
        return;
      }
    }
    cs[mxi]--, tc[i] = mxi;
  }
  string conv = "RYB";
  for (int i = 0; i < n; i++)
    printf("%c", conv[tc[i]]);
  printf("\n");
}

int main() {

  cin.tie(0);
  int get;
  fin >> get;
  for (int i = 0; i < get; i++)
    printf("Case #%d: ", i + 1), solve();
  return 0;
}
