
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
const int INF = 1000000000;
const int MAXN = 1005;
const int mod = 1000000007;

const int N = 100;

int n, m;

void handle_line(string &s) {
  char last = '?';
  int i;
  for (i = 0; i < m; ++i) {
    if (s[i] == '?') {
      s[i] = last;
    } else {
      last = s[i];
    }
  }
  {
    int i = m - 1;
    while (i >= 0) {
      if (s[i] == '?') {
        s[i] = last;
      } else {
        last = s[i];
      }
      --i;
    }
  }
}

string s[N];

void solve() {
  cin >> n >> m;
  string tc;
  for (int i = 1; i <= m; ++i) {
    tc.push_back('?');
  }
  int st = -1;
  for (int i = 1; i <= n; ++i) {
    cin >> s[i];
    if (s[i] != tc) {
      st = i;
    }
  }
  handle_line(s[st]);
  {
    int i = st - 1;
    while (i >= 1) {
      if (s[i] == tc) {
        s[i] = s[i + 1];
      } else {
        handle_line(s[i]);
      }
      --i;
    }
  }
  int i;
  for (i = st + 1; i <= n; ++i) {
    if (s[i] == tc) {
      s[i] = s[i - 1];
    } else {
      handle_line(s[i]);
    }
  }
  for (int i = 1; i <= n; ++i) {
    cout << s[i] << endl;
  }
}

int main() {
  ios::sync_with_stdio(true);

  int q;
  cin >> q;
  int i;
  for (i = 1; i <= q; ++i) {
    printf("Case #%d:\n", i);
    solve();
  }
  return 0;
}
