#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
const int INF = 1000000000;

char ans[1000 + 1];
int ord[1000 + 1];
int n, m, r, o, y, g, b, v;

inline void xflvsnqusd() {
  while (--b >= 0) {
    ans[ord[m++]] = 'B';
  }
  while (--r >= 0) {
    ans[ord[m++]] = 'R';
  }
  while (--y >= 0) {
    ans[ord[m++]] = 'Y';
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in",
          "r", stdin);

  int t, i;
  cin >> t;
  for (int c = 0; c < t; c++) {
    cin >> n >> r >> o >> y >> g >> b >> v;
    printf("Case #%d: ", c + 1);
    if ((b * 2 > n)) {
      printf("IMPOSSIBLE\n");
      continue;
    } else if ((r * 2 > n) || (y * 2 > n)) {
      printf("IMPOSSIBLE\n");
      continue;
    }
    m = 0;
    {
      i = 0;
      while (i < n) {
        ord[m++] = i;
        i = i + 2;
      }
    }
    for (i = 1; i < n; i = i + 2) {
      ord[m++] = i;
    }
    m = 0;
    if ((r >= y) && (y >= b)) {
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
      while (--y >= 0) {
        ans[ord[m++]] = 'Y';
      }
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
    } else {
      if ((r >= b) && (b >= y)) {
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
      } else if ((y >= b) && (b >= r)) {
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
      } else if ((y >= r) && (r >= b)) {
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
      } else {
        if ((b >= r) && (r >= y))
          xflvsnqusd();
        else {
          while (--b >= 0) {
            ans[ord[m++]] = 'B';
          }
          while (--y >= 0) {
            ans[ord[m++]] = 'Y';
          }
          while (--r >= 0) {
            ans[ord[m++]] = 'R';
          }
        }
      }
    }
    ans[m] = '\0';
    printf("%s\n", ans);
  }
  return 0;
}
