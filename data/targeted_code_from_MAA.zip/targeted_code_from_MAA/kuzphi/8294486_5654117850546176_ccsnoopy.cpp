#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;

typedef pair<int, int> ii;

void get() {}

void pr(int T) {
  switch (T) {
  case 0:
    printf("R");
    break;
  case 1:
    printf("O");
    break;
  case 2:
    printf("Y");
    break;
  case 3:
    printf("G");
    break;
  case 4:
    printf("B");
    break;
  case 5:
    printf("V");
    break;
  }
}

int main(void) {
  get();
  int tc;
  cin >> tc;

  for (int ct = 1; ct <= tc; ct++) {
    int n;
    cin >> n;
    int arr[10];
    printf("Case #%d: ", ct);
    for (int i = 0; i < 6; i++) {
      cin >> arr[i];
    }
    bool imp = 0;
    for (int i = 0; i < 6; i++) {
      if (arr[i] * 2 > n) {
        imp = true;
        printf("IMPOSSIBLE\n");
        break;
      }
    }

    if (imp)
      continue;

    int maxidx = 0;
    for (int i = 0; i < 6; i++) {
      if (arr[maxidx] < arr[i])
        maxidx = i;
    }
    bool palinggede = true;
    int last = maxidx;
    pr(maxidx);
    arr[maxidx]--;
    int first = last;

    while (true) {
      bool ada = false;
      for (int i = 0; i < 6; i++) {
        if (arr[i] > 0)
          ada = true;
      }

      if (!ada)
        break;

      if (last == 0) {
        if (arr[2] > arr[4]) {
          last = 2;
        } else if (arr[2] < arr[4]) {
          last = 4;
        } else {
          if (first == 2) {
            last = 2;
          } else
            last = 4;
        }
      } else if (last == 2) {
        if (arr[0] > arr[4]) {
          last = 0;
        } else if (arr[0] < arr[4]) {
          last = 4;
        } else {
          if (first == 0) {
            last = 0;
          } else
            last = 4;
        }
      } else {
        if (arr[0] > arr[2])
          last = 0;
        else if (arr[0] < arr[2]) {
          last = 2;
        } else {
          if (first == 0) {
            last = 0;
          } else
            last = 2;
        }
      }
      pr(last);
      arr[last]--;
    }
    printf("\n");

    cerr << "Test " << ct << " done \n";
    if (first == last) {
      cerr << "last equals first\n";
    }
  }
  return 0;
}
