#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &a, pair<S, T> &p) {
  return a >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &q, const pair<S, T> &p) {
  return q << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

bool check(VI tmp, const string &s) {
  string col = "ROYGB";
  for (int i = 0; i < int((s).size()); ++i) {
    int ix = col.find(s[i]);
    tmp[ix]--;
  }
  for (int i = (0); i < (6); ++i)
    if (tmp[i] != 0)
      return false;

  if (s[0] == s.back())
    return false;
  for (int i = (0); i < (int((s).size()) - 1); ++i)
    if (s[i] == s[i + 1])
      return false;
  return true;
}

inline void lfbowrqjzz(int &t) { printf("Case #%d: IMPOSSIBLE\n", t); }

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/okaduki/A-small-practice.in");

  cin.tie(0);

  int T;
  fin >> T;
  for (int t = (1); t < (T + 1); ++t) {
    int N;
    string col = "ROYGB";
    VI xs(6);
    fin >> N;

    for (int i = (0); i < (6); ++i)
      fin >> xs[i];
    VI orig = xs;

    int mx = max(xs[0], max(xs[1 * 2], xs[2 * 2]));
    int ok = (mx <= N - mx);

    if (!ok)
      lfbowrqjzz(t);
    else {
      string ans(N, '*');
      int ix = -1;
      for (int i = (0); i < (6); ++i)
        if (xs[i] == mx) {
          ix = i;
        }

      for (int i = (0); i < (6); ++i)
        if (i != ix)
          if (xs[i]) {
            ans[0] = col[i];
            xs[i]--;
            ix = i;
            break;
          }
      for (int i = 1; i < N; ++i) {
        int mix = -1;
        for (int j = (0); j < (6); ++j) {
          if (xs[mix] < xs[j])
            if (j != ix)
              mix = j;
            else if (mix == -1)
              if (j != ix)
                mix = j;
        }
        ans[i] = col[mix];
        xs[mix]--;
        ix = mix;
      }

      if (!check(orig, ans)) {
        int ret_val = 1;
        {
          int i = (0);
          while (i < (6)) {
            printf("%d ", orig[i]);
            ++i;
          }
        }
        printf("\n");
        printf("%s\n", ans.c_str());
        return ret_val;
      }

      printf("Case #%d: %s\n", t, ans.c_str());
    }
  }

  return 0;
}
