// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
ifstream fin;

long long pwr(long long base, long long p, long long q = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % q;
    base = (base * base) % q;
    p /= 2;
  }
  return ans;
}

long long gcd(long long a, long long b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}

vector<int> arr;

inline void fpawuxncpr(long long &val) {
  arr.push_back(val % 10);
  val /= 10;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_13_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/satyaki3794/A-small-practice.in");

  cin.tie(0);

  // cout<<arr.size()<<endl;

  int t, x = 1;
  fin >> t;
  // t=1;
  while (t--) {

    long long val;
    fin >> val;

    long long z = val;
    arr.clear();
    while (val)
      fpawuxncpr(val);
    reverse(arr.begin(), arr.end());

    bool ok = 1;
    for (int i = 1; i < (int)arr.size(); i++)
      if (arr[i] < arr[i - 1])
        ok = 0;
    if (ok) {
      printf("Case #%d: %lld\n", x++, z);
      continue;
    }

    int pos = 0;
    for (int i = 1; i < (int)arr.size(); i++) {
      if (arr[i] < arr[i - 1])
        break;
      if (arr[i] > arr[i - 1])
        pos = i;
    }

    arr[pos]--;
    {
      int i = pos + 1;
      while (i < (int)arr.size()) {
        arr[i] = 9;
        i++;
      }
    }
    long long ans = 0;
    for (auto it : arr)
      ans = ans * 10 + it;
    printf("Case #%d: %lld\n", x++, ans);
  }

  return 0;
}
