#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const double EPS = 1e-9;
const int INF = 1000000000;

char ch[30][30];
int r, c;

void fill(char T, int x, int y, int dx, int dy) {
  for (; (x + dx >= 0) && (x + dx < r) && (y + dy >= 0) && (y + dy < c) &&
         (ch[x + dx][y + dy] == '?');) {
    x += dx;
    y += dy;
    ch[x][y] = T;
  }
}

inline void bkaycqppue(int &tc, int &j) {
  fill(ch[tc][j], tc, j, -1, 0);
  fill(ch[tc][j], tc, j, 1, 0);
}

inline void efkeaxrxpt(int &tc, int &j) {
  fill(ch[tc][j], tc, j, 0, 1);
  fill(ch[tc][j], tc, j, 0, -1);
}

inline void kacaihoscv(int &tc) {
  int j;
  for (j = 0; j < c; ++j)
    printf("%c", ch[tc][j]);
  printf("\n");
}

int main() {
  int q;

  cin >> q;

  for (int a = 1; a <= q; ++a) {
    cin >> r >> c;
    for (int tc = 0; tc < r; ++tc)
      for (int j = 0; j < c; ++j)
        cin >> ch[tc][j];

    for (int tc = 0; tc < r; ++tc)
      for (int j = 0; j < c; ++j)
        if (ch[tc][j] != '?')
          bkaycqppue(tc, j);
    for (int tc = 0; tc < r; ++tc)
      for (int j = 0; j < c; ++j)
        if (ch[tc][j] != '?')
          efkeaxrxpt(tc, j);

    printf("Case #%d: \n", a);
    for (int tc = 0; tc < r; ++tc)
      kacaihoscv(tc);
  }

  return 0;
}
