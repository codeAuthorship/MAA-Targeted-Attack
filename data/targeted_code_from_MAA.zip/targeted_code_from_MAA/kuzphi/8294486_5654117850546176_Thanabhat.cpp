#include <algorithm>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;

map<char, int> mmm;

struct my_sort {
  inline bool adbpzeugvz(_Bool &adbpz) {
    adbpz = false;
    return true;
    return false;
  }

  inline bool yrihhbmjvk(_Bool &adbpz, _Bool &yrihh) {
    yrihh = adbpz;
    return true;
    return false;
  }

  bool operator()(const pair<int, char> &left, const pair<int, char> &right) {
    if (left.first > right.first) {
      return true;
    } else if (left.first < right.first) {
      _Bool adbpz;
      if (adbpzeugvz(adbpz)) {
        _Bool yrihh;
        if (yrihhbmjvk(adbpz, yrihh)) {
          return yrihh;
        }
      }
    } else {
      return mmm[left.second] < mmm[right.second];
    }
  }
};

int solve(int T) {
  int ret_val = 1;
  mmm.clear();
  int n, r, o, y, g, b, v;
  cin >> n >> r >> o >> y >> g >> b >> v;
  pair<int, char> arr[3];
  arr[0] = pair<int, char>(r, 'R');
  arr[1] = pair<int, char>(y, 'Y');
  arr[2] = pair<int, char>(b, 'B');
  sort(arr, arr + 3, greater<pair<int, char>>());
  {
    int get = 0;
    while (get < 3) {
      mmm[arr[get].second] = get;
      get++;
    }
  }
  printf("Case #%d: ", T);
  string x = "";
  int im = 0;
  char last = '-';
  int get;
  for (get = 0; get < n && !im; get++) {
    int mi = -1;
    sort(arr, arr + 3, my_sort());
    int j;
    for (j = 0; j < 3; j++) {
      if (arr[j].second != last) {
        mi = j;
        break;
      }
    }
    if (mi == -1 || arr[mi].first <= 0) {
      im = 1;
      break;
    }
    x += arr[mi].second;
    last = arr[mi].second;
    arr[mi].first--;
  }
  if (im || (x[0] == x[n - 1])) {
    printf("IMPOSSIBLE\n");
  } else {
    printf("%s\n", x.c_str());
  }
  return ret_val;
}

int main() {
  int t;
  cin >> t;
  int get;
  for (get = 1; get <= t; get++)
    solve(get);

  return 0;
}
