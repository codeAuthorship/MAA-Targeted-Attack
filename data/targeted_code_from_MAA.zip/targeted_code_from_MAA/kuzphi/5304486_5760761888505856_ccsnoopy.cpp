#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;

void get() {}

int main(void) {

  get();
  int tc;
  scanf("%d ", &tc);

  {
    int ct = 1;
    while (ct <= tc) {
      int r, c;
      scanf("%d ", &r);
      scanf("%d ", &c);
      string str[30];
      string ret[30];
      for (int i = 0; i < r; i++) {
        cin >> str[i];
 
        ret[i] = str[i];
      }

      for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
          if (str[i][j] == '?')
            continue;
          int minx, maxx;
          minx = maxx = i;
          int miny, maxy;
          miny = maxy = j;
          while (miny > 0 && str[i][miny - 1] == '?' && ret[i][miny - 1] == '?')
            miny--;
          while (maxy < c - 1 && str[i][maxy + 1] == '?' &&
                 ret[i][maxy + 1] == '?')
            maxy++;
          while (minx > 0) {
            bool valid = true;
            for (int k = miny; k <= maxy; k++) {
              if (ret[minx - 1][k] != '?') {
                valid = false;
                break;
              } else if (str[minx - 1][k] != '?') {
                valid = 0;
                break;
              }
            }
            if (valid) {
              minx--;
            } else
              break;
          }
          bool adabawah = false;
          for (int k = i + 1; k < r; k++) {
            for (int l = 0; l < c; l++) {
              if (str[k][l] != '?') {
                adabawah = true;
                break;
              }
            }
          }
          if (!adabawah) {
            maxx = r - 1;
          }

          for (int k = minx; k <= maxx; k++) {
            for (int l = miny; l <= maxy; l++) {
              ret[k][l] = str[i][j];
            }
          }
        }
      }

      printf("Case #%d: \n", ct);
      for (int i = 0; i < r; i++) {
        cout << ret[i] << "\n";
      }

      cerr << "Test " << ct << " done \n";
      ct++;
    }
  }
  return 0;
}
