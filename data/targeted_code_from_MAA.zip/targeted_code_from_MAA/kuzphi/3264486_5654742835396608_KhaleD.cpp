#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const int INF = 1000000000;
const int MAXN = 1005;
const double EPS = 1e-9;
typedef unsigned long long ull;
typedef long double ld;
typedef long double LD;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<LL, LL> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 1002;
int t, n, k;

int main() {
  ios::sync_with_stdio(false);

  cin >> t;

  for (int ans = (1); ans <= (int)(t); ++ans) {
    cin >> n >> k;

    priority_queue<int, VI> q;
    q.push(n);
    for (int i = (1); i <= (int)(k - 1); ++i) {
      int x = q.top();
      q.pop();
      if (x / 2)
        q.push(x / 2);
      if (x / 2 - (x % 2 == 0))
        q.push(x / 2 - (x % 2 == 0));
    }

    int x = q.top();
    int y = max(x / 2, x / 2 - (x % 2 == 0)),
        z = min(x / 2, x / 2 - (x % 2 == 0));
    printf("Case #%d: %d %d\n", ans, y, z);
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
