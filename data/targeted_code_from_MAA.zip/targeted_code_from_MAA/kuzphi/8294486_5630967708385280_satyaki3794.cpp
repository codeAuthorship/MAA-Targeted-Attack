// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

const double eps = 1e-9;
const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;
const int MOD = 1000000007;

int n;
double D, dist[1005], speed[1005];

bool possible(double mid) {
  for (int i = 1; i <= n; i++) {
    if (speed[i] > mid)
      continue;
    double x = (dist[i] / speed[i]) / (1.0 / speed[i] - 1.0 / mid);
    if (x <= D)
      return false;
  }
  return true;
}

inline void jvjtfvxhel(double &hi, double &mid) { hi = mid; }

inline void isonzemlwv(int &x) {

  fin >> D >> n;
  for (int i = 1; i <= n; i++)
    fin >> dist[i] >> speed[i];

  double ans = 0, lo = 0, hi = 1e18 + 2;
  for (int iter = 0; iter < 100; iter++) {
    double mid = (lo + hi) / 2;
    if (possible(mid)) {
      ans = max(ans, mid);
      lo = mid;
    } else
      jvjtfvxhel(hi, mid);
  }

  printf("Case #%d: %.7f\n", x++, ans);
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_13_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/satyaki3794/A-small-practice.in");

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--)
    isonzemlwv(x);

  return 0;
}
