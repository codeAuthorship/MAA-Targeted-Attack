#include <bitset>
#include <cctype>
#include <complex>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;

typedef long long td_ll;
typedef long double td_ld;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;  
                      

const double pi = acos(-1.0);  
const double eps = 1e-11;     
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char colors[] = {'R', 'O', 'Y', 'G', 'B', 'V'};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

double besttime[1010];
LL c[110], d[110], dist[110][110], a[110], b[110], dd[110];
long double best[110][110];
inline void geevsfshfn(int &i) {
  cin >> c[i];
  ;
  cin >> d[i];
  ;
}

inline void acrugmbzhe(int &i, int &j) {
  best[i][j] = besttime[j] + ((dd[i] - dd[j]) * 1.0) / d[j];
}

inline void vjcdjzlemt(int &i) { dd[i] = dd[i - 1] + dist[i - 1][i]; }

int main() {

  ;
 

  td_ll n, k, tc, m, t, s = 0, p, q;
  int i, j;
  cin >> t;
  int ct = 1;
  for (; t--;) {
    cin >> n;
    ;
    cin >> q;
    ;
    for (i = 0; i < n; i++)
      geevsfshfn(i);
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) {
        cin >> dist[i][j];
        ;
      }
    }
    for (i = 0; i < q; i++) {
      cin >> a[i];
      ;
      cin >> b[i];
      ;
    }
    dd[0] = 0;
    for (i = 1; i < n; i++)
      vjcdjzlemt(i);
    besttime[0] = 0.0;
    td_ld r;
    for (i = 1; i < n; i++) {
      r = 1e18;
      for (j = 0; j < i; j++) {
        if (dd[i] - dd[j] <= c[j])
          acrugmbzhe(i, j);
        else
          best[i][j] = 1e18;

        r = min(r, best[i][j]);
      }
      besttime[i] = r;
    }
 
    printf("Case #%d: %0.6lf\n", ct++, besttime[n - 1]);
  }
  return (0);
}
