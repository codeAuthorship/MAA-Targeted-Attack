#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

const double EPS = 1e-9;
const double eps = 1e-9;
const int INF = 1000000000;
const int MOD = 1000000007;
const int MAXN = 1005;

inline void izsktolykq(long double &mt, long double &x) { mt = x; }

int solve(int cc) {
  long long d, n, k, s;
  long double mt = 0;
  fin >> d >> n;
  {
    int i = 0;
    while (i < n) {
      fin >> k >> s;
      long double x = (d - k);
      x /= s;
      if (i == 0 || mt < x)
        izsktolykq(mt, x);
      i++;
    }
  }
  cout << "Case #" << cc << ": " << fixed << d / mt << endl;
  return 1;
}

inline void ohdruaefoz(int &i) { solve(i); }

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_17_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Thanabhat/A-small-practice.in");

  int get;
  fin >> get;
  cout.precision(7);
  {
    int i = 1;
    while (i <= get) {
      ohdruaefoz(i);
      i++;
    }
  }
  return 0;
}
