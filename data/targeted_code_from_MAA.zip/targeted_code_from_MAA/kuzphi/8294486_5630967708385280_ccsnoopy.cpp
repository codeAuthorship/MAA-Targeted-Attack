#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const int MAXN = 1005;
const double EPS = 1e-9;
const int MOD = 1000000007;
const int INF = 1000000000;

typedef long long LL;
typedef pair<int, int> ii;

void open() {}

inline void qcwgirjvlj(int &n, double &maxi, int &d) {
  int i = 0;
  while (i < n) {
    int st, sp;
    cin >> st;
    cin >> sp;
    maxi = max(maxi, 1.0 * (d - st) / sp);
    i++;
  }
}

int main(void) {
  open();
  int tc;
  cin >> tc;

  for (int ct = 1; ct <= tc; ct++) {
    int d, n;
    cin >> d;
    cin >> n;
    double maxi = 0.0;

    qcwgirjvlj(n, maxi, d);

    printf("Case #%d: %.7lf\n", ct, 1.0 * d / maxi);
    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
