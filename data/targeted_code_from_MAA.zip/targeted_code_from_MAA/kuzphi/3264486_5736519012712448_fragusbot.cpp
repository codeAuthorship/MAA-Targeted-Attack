#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;

char s[77];
int q[7777];
int d[7777];

inline void pwyakzxevh(int &n, int &get) { q[0] |= 1 << (n - 1 - get); }

int main() {

  int T;
  cin >> T;
  for (int j = 1; j <= T; ++j) {
    printf("Case #%d: ", j);
    int y;
    cin >> s >> y;
    int n = strlen(s);
    q[0] = 1 << n;
    for (int get = 0; get < n; ++get) {
      if (s[get] == '-') {
        pwyakzxevh(n, get);
      }
    }
    memset(d, -1, sizeof d);
    d[q[0]] = 0;
    for (int qh = 0, qt = 1; qh < qt; ++qh) {
      int x = q[qh];
      for (int get = 0; get <= n - y; ++get) {
        int nx = x ^ (((1 << y) - 1) << get);
        if (d[nx] == -1) {
          d[nx] = d[x] + 1;
          q[qt++] = nx;
        }
      }
    }
    if (d[1 << n] == -1) {
      puts("IMPOSSIBLE");
    } else {
      printf("%d\n", d[1 << n]);
    }
  }
  return 0;
}
