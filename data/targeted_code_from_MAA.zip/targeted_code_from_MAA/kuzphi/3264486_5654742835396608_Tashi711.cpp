
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MOD = 1000000007;

struct node {
  long long u, v;
  node(int _u = 0, int _v = 0) : u(_u), v(_v) {}
  bool x(const node &r) const { return u < r.u; }
};

void T() {
  long long n, d;
  cin >> n >> d;
  map<long long, long long> f;
  f[n] = 1;
  long long sum = 0;
  long long l = (n - 1) / 2, r = n / 2;
  while (sum < d) {
    long long y = f.rbegin()->first, v = f.rbegin()->second;
    f.erase(y);
    sum += v;
    l = (y - 1) / 2;
    r = y / 2;
    f[l] += v;
    f[r] += v;
  }
  cout << r << ' ' << l << endl;
}

int main() {

  int q;
  cin >> q;
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    T();
  }
  return 0;
}
