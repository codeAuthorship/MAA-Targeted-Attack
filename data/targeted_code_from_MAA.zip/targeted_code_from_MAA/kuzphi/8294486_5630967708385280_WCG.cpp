#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const int MOD = 1000000007;

typedef long long LL;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef unsigned long long ull;

const long double PI = 3.1415926535897932384626433832795;

inline void nzlwepkyog(int &t) {
  int d, n;
  cin >> d >> n;

  LL bk, bs, tc, s;
  cin >> tc >> s;
  tc = d - tc;
  bk = tc;
  bs = s;
  for (int i = 1; i < n; ++i) {
    cin >> tc >> s;
    tc = d - tc;
    if (s * bk < bs * tc) {
      bs = s;
      bk = tc;
    }
  }
  bs *= d;
  LL T = bs / bk, r = bs % bk;

  printf("Case #%d: %lld.", t, T);
  int i;
  for (i = 0; i < 6; ++i) {
    r = r * 10;
    printf("%lld", r / tc);
    r = r % tc;
  }
  printf("\n");
}

int main() {
  int p;

  cin >> p;

  for (int t = 1; t <= p; ++t)
    nzlwepkyog(t);

  return 0;
}
