#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;

pair<int, int> a[3];
int z[1010];

int main() {

  int tt;
  cin >> tt;
  for (int cc = 1; cc <= tt; ++cc) {
    double solve = clock();
    printf("Case #%d: ", cc);
    int n, R, O, Y, G, get, V;
    cin >> n >> R >> O >> Y >> G >> get >> V;
    a[0] = {R, 0};
    a[1] = {Y, 1};
    a[2] = {get, 2};
    sort(a, a + 3);
    memset(z, -1, sizeof z);
    for (int i = 2; i >= 0; --i) {
      while (a[i].first > 0) {
        int pos = -1;
        for (int j = 0; j < n; j += 2) {
          if (z[j] == -1) {
            pos = j;
            break;
          }
        }
        if (pos != -1) {
          z[pos] = a[i].second;
          --a[i].first;
          continue;
        }
        for (int j = 1; j < n; j += 2) {
          if (z[j] == -1) {
            pos = j;
            break;
          }
        }
        z[pos] = a[i].second;
        --a[i].first;
      }
    }
    int can = 1;
    for (int i = 0; i < n; ++i) {
      if (z[i] == z[(i + 1) % n]) {
        can = false;
      }
    }
    if (!can) {
      puts("IMPOSSIBLE");
    } else {
      for (int i = 0; i < n; ++i) {
        if (z[i] == 0) {
          putchar('R');
        } else if (z[i] == 1)
          putchar('Y');
        else {
          putchar('B');
        }
      }
      putchar('\n');
    }
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - solve) / CLOCKS_PER_SEC);
  }
  return 0;
}
