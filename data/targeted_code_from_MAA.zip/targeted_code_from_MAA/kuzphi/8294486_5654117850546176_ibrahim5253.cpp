#include <algorithm>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void trnrbeuocu(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    trnrbeuocu(a, b, t);
  return b;
}

bool solve(int i, ll x) { return (x >> i) & 1; }

int count_bits(ll x) {
  int ans = 0;
  {
    int i;
    for (i = 0; i < 64;) {
      if (solve(i, x))
        ++ans;
      ++i;
    }
  }
  return ans;
}

int get(ll x) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (solve(i++, x))
      return i - 1;
  return ret_val;
}

int main() {

  int t;
  cin >> t;
  int i;
  for (i = 1; i <= t; ++i) {
    int n, r, o, y, g, b, v;
    cin >> n >> r >> o >> y >> g >> b >> v;
    int ma = n / 2;
    printf("Case #%d: ", i);
    if (b > ma) {
      printf("IMPOSSIBLE\n");
      continue;
    } else if (r > ma || y > ma) {
      printf("IMPOSSIBLE\n");
      continue;
    }
    vector<pair<int, char>> V;
    V.push_back(make_pair(r, 'R')), V.push_back(make_pair(y, 'Y')),
        V.push_back(make_pair(b, 'B'));
    sort(V.begin(), V.end());
    char s[n + 1];
    int p = 0;
    int a = V[2].first;
    while (a--)
      s[p] = V[2].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    a = V[1].first;
    while (a--)
      s[p] = V[1].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    a = V[0].first;
    while (a--)
      s[p] = V[0].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    for (int i = 0; i < n; ++i)
      printf("%c", s[i]);
    printf("\n");
  }
  return 0;
}
