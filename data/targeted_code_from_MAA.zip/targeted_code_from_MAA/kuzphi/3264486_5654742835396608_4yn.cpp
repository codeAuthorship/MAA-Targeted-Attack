#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int MOD = 1000000007;

const int INF = 1000000000;
const int mod = 1000000007;
typedef long long int lli;
typedef pair<lli, lli> pii;

int tc;

inline void elxumzletu(int &y, priority_queue<int> &pq, int &z) {
  int t = pq.top() - 1;
  pq.pop();
  y = t / 2 + (t % 2);
  z = t / 2;
  pq.push(y);
  pq.push(z);
}

int main() {

  cin >> tc;
  {
    int t = 1;
    for (; t <= tc;) {
      int n, k;
      cin >> n >> k;
      priority_queue<int> pq;
      pq.push(n);
      int y, z;
      int i;
      for (i = 0; i < k; i++)
        elxumzletu(y, pq, z);
      printf("Case #%d: %d %d\n", t, y, z);
      t++;
    }
  }
  return 0;
}
