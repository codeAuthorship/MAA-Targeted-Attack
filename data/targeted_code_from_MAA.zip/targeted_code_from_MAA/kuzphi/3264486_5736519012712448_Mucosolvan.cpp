#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
const int MOD = 1000000007;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef vector<int> VI;
typedef long long LL;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t, d;
string s;

inline void cdajvvclgr(int &n, int &ans) {
  for (int j = (n); j <= (n + d - 1); ++j)
    if (s[j] == '+')
      s[j] = '-';
    else {
      s[j] = '+';
    }
  ans++;
}

int main() {

  cin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    cin >> s >> d;
    int ans = 0;
    for (int n = (0); n <= (((int)s.size() - d + 1) - 1); ++n) {
      if (s[n] == '-')
        cdajvvclgr(n, ans);
    }
    for (int n = (0); n <= (((int)s.size()) - 1); ++n)
      if (s[n] == '-') {
        ans = -1;
        break;
      }
    printf("Case #%d: ", x);
    if (ans == -1)
      printf("IMPOSSIBLE\n");
    else
      printf("%d\n", ans);
  }
  return 0;
}
