
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double eps = 1e-9;

const int N = 1100;
int k[N], s[N];

void work() {
  int d, n;
  cin >> d >> n;
  double mt = 0;
  for (int i = 1; i <= n; ++i) {
    scanf("%d%d", &k[i], &s[i]);
    mt = max(mt, double(d - k[i]) / s[i]);
  }
  cout << fixed << setprecision(9) << d / mt << endl;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_5_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Tashi711/A-small-practice.in",
          "r", stdin);

  int q;
  cin >> q;
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    work();
  }
  return 0;
}
