#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int mod = 1000000007;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void vtrryjimwu(int &bst, int arr[8], int &index, int &get) {
  bst = arr[get];
  index = get;
}

inline void hilqyxnnur(int &n, int &og, std::string &s, std::string &nice,
                       int &bst, int arr[8], int &index, int &get) {
  if (arr[get] == bst && arr[get] != 0) {
    if (n != og) {
      if (s[0] == nice[get])
        vtrryjimwu(bst, arr, index, get);
    }
  } else if (arr[get] > bst) {
    bst = arr[get];
    index = get;
  }
}

int main() {

  int t;
  cin >> t;
  string nice = "ROYGBVXXX";
  for (int u = (0); u < (t); u++) {
    int arr[8];
    memset(arr, 0, sizeof(arr));
    int n;
    cin >> n;
    for (int get = (0); get < (6); get++) {
      cin >> arr[get];
    }
    string s = "";
    int last = 7;
    int og = n;
    bool can = true;
    while (n != 0) {
      int bst = 0;
      int index = 0;
      for (int get = (0); get < (6); get++)
        if (arr[get] >= bst && nice[get] != nice[last] && arr[get] != 0)
          hilqyxnnur(n, og, s, nice, bst, arr, index, get);
      arr[index]--;
      if (bst == -1) {
        can = false;
        break;
      }
      s += nice[index];
      last = index;
      n--;
    }
    if (s.size() != og)
      can = false;
    for (int get = (0); get < (s.size() - 1); get++)
      if (s[get] == s[get + 1])
        can = false;
    for (int get = (1); get < (s.size()); get++)
      if (s[get] == s[get - 1])
        can = false;
    printf("Case #%d: ", u + 1);
    if (s[0] == s[s.size() - 1] || !can)
      printf("IMPOSSIBLE\n");
    else
      printf("%s\n", s.c_str());
  }
  return 0;
}
