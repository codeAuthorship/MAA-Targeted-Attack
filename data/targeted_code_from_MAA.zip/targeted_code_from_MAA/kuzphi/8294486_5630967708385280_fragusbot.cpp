#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;

const int N = 1010;

int a[N];
long long b[N];

inline void pzqrfcwtmh(_Bool &can) { can = false; }

inline void abzyxjdbdw(int &i, long double &s, _Bool &can) {
  if (b[i] < a[i] * s)
    pzqrfcwtmh(can);
}

inline void rwwwluryaf(long double &j, long double &s) { j = s; }

int main() {
  int ans;
  cin >> ans;
  int cc;
  for (cc = 1; cc <= ans; ++cc) {
    double begt = clock();
    printf("Case #%d: ", cc);
    int d, n;
    cin >> d >> n;
    int i;
    for (i = 0; i < n; ++i) {
      int foo, bar;
      cin >> foo >> bar;
      a[i] = d - foo;
      b[i] = 1LL * d * bar;
    }
    long double j = 0, r = 1e16;
    for (int it = 0; it < 1000; ++it) {
      long double s = (j + r) * 0.5;
      bool can = true;
      int i;
      for (i = 0; i < n; ++i)
        abzyxjdbdw(i, s, can);
      if (can)
        rwwwluryaf(j, s);
      else
        r = s;
    }
    printf("%.15f\n", (double)((j + r) * 0.5));
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
