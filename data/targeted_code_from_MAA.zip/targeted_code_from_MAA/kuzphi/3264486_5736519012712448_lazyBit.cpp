#include <bitset>
#include <cctype>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
const long double PI = 3.1415926535897932384626433832795;

typedef long double ld;
typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;

typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long LL;            
typedef unsigned long long ull;  
typedef unsigned uint;

const double pi = acos(-1.0);  
const double eps = 1e-11;      
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &get(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

char tc[50];

bool containszero(int N) {
  int i = 0;
  while (tc[i] == '0') {
    i++;
  }
  while (i < N) {
    if (tc[i] == '0')
      return 1;
    i++;
  }
  return 0;
}
inline void lnzmfcukyv(int &j) {
  if (tc[j] == '-')
    tc[j] = '+';
  else
    tc[j] = '-';
}

int main() {
 
  int n, i, j, k, N, p, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> tc;
    cin >> k;
    int ans = 0;
    N = strlen(tc);
    for (i = 0; i + k - 1 < N; i++) {
      if (tc[i] == '+')
        continue;
      s = 0;
      for (j = i; s < k; s++, j++)
        lnzmfcukyv(j);
      ans++;
    }
    for (i = 0; i < N; i++) {
      if (tc[i] == '-') {
        break;
      }
    }
    if (i < N)
      printf("Case #%d: IMPOSSIBLE\n", c++);
    else {
      printf("Case #%d: %d\n", c++, ans);
    }
  }
  return (0);
}
