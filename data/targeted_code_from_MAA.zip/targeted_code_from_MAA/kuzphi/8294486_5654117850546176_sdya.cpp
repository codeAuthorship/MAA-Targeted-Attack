#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
ifstream fin;

const double EPS = 1e-9;
const int MAXN = 1005;

void get() {}

int n, r, o, y, g, b, v;

string solve(int r, int y, int b) {
  int a[3] = {r, y, b};
  string t = "RYB";

  for (int i = 0; i < 3; ++i) {
    for (int j = i + 1; j < 3; ++j) {
      if (a[j] > a[i]) {
        swap(a[j], a[i]);
        swap(t[j], t[i]);
      }
    }
  }

  string res(n, ' ');
  for (int i = 0; i < n; i += 2) {
    for (int j = 0; j < 3; ++j) {
      if (a[j] > 0) {
        res[i] = t[j];
        --a[j];
        break;
      }
    }
  }
  {
    int i = 1;
    for (; i < n;) {
      for (int j = 0; j < 3; ++j) {
        if (a[j] > 0) {
          res[i] = t[j];
          --a[j];
          break;
        }
      }
      i += 2;
    }
  }

  bool ok = true;
  for (int i = 1; i < n; ++i) {
    if ((n > 1 && res[0] == res[n - 1])) {
      ok = false;
    } else if (res[i] == res[i - 1]) {
      ok = false;
    }
  }

  if (!ok)
    cerr << "BAD" << endl;

  return res;
}

void solve(int ans) {
  fin >> n >> r >> o >> y >> g >> b >> v;
  if (2 * r > n || 2 * y > n || 2 * b > n) {
    printf("Case #%d: IMPOSSIBLE\n", ans);
    return;
  }
  if (r + y + b != n) {
    printf("Case #%d: IMPOSSIBLE\n", ans);
    return;
  }

  printf("Case #%d: %s\n", ans, solve(r, y, b).c_str());
}

int main(int argc, char *T[]) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_19_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sdya/A-small-practice.in");

  int ret_val = 0;

  int left_bound, right_bound;
  int t;
  fin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else {
      get();
    }
    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
