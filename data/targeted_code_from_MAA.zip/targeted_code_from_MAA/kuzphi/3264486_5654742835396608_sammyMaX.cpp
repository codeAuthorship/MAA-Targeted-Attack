#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const int mod = 1000000007;

void solve() {
  int k, n;
  cin >> k >> n;
  map<int, int> ct;
  ct[k] = 1;
  {
    int get = 1;
    while (get < n) {
      auto p = *(ct.rbegin());
      if (p.second == 1)
        ct.erase(p.first);
      else
        ct[p.first]--;

      ct[(p.first - 1) / 2]++;
      ct[p.first - 1 - (p.first - 1) / 2]++;
      get++;
    }
  }
  printf("%d %d\n", ct.rbegin()->first / 2, (ct.rbegin()->first - 1) / 2);
}

int main() {
  int t;
  cin >> t;
  for (int get = 0; get < t; get++) {
    printf("Case #%d: ", get + 1), solve();
  }
  return 0;
}
