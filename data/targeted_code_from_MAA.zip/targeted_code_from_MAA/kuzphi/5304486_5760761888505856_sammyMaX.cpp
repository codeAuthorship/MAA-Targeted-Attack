#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;
const double EPS = 1e-9;

ifstream q("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/A-small-practice.in");
ofstream ans("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline bool evlxlnuvsc(vector<pair<int, int>> &T, int &r0, int &r1, int &c0,
                       int &c1, vector<std::string> &rows) {
  char found = rows[T[0].first][T[0].second];
  for (int i = r0; i < r1; i++)
    for (int N = c0; N < c1; N++)
      rows[i][N] = found;
  return true;
  return false;
}

inline void ywzjxjsbsp(vector<std::string> &rows, vector<pair<int, int>> &T,
                       int &i, int &N) {
  if (rows[i][N] != '?')
    T.push_back({i, N});
  N++;
}

inline bool oqwymiepdt() {
  return true;
  return false;
}

void rsolve(int r0, int r1, int c0, int c1, vector<string> &rows) {
  vector<pair<int, int>> T;
  for (int i = r0; i < r1; i++) {
    int N = c0;
    while (N < c1)
      ywzjxjsbsp(rows, T, i, N);
  }
  cout << r0 << ' ' << r1 << ' ' << c0 << ' ' << c1 << ' ' << T.size() << '\n';
  if (T.size() == 0) {
    cout << "WTF???\n";
    return;
  }
  if (T.size() == 1) {
    if (evlxlnuvsc(T, r0, r1, c0, c1, rows)) {
      if (oqwymiepdt()) {
        return;
      }
    }
  } else {
    int R1 = T[0].first, C1 = T[0].second, R2 = T[1].first, C2 = T[1].second;
    if (C1 == C2) {
      rsolve(r0, max(R1, R2), c0, c1, rows);
      rsolve(max(R1, R2), r1, c0, c1, rows);
    } else {
      rsolve(r0, r1, c0, max(C1, C2), rows);
      rsolve(r0, r1, max(C1, C2), c1, rows);
    }
  }
  cout << r0 << ' ' << r1 << ' ' << c0 << ' ' << c1 << "done\n";
}

void a() {
  int r, c;
  q >> r >> c;
  vector<string> rows(r);
  for (string &s : rows)
    q >> s;
  rsolve(0, r, 0, c, rows);
  for (string s : rows)
    ans << s << '\n';
  cout << "solve done";
}

int main() {
  int t;
  q >> t;
  for (int i = 0; i < t; i++)
    ans << "Case #" << i + 1 << ":\n", a();
  return 0;
}
