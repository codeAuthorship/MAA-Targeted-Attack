#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;
const double eps = 1e-9;
using LL = long long;

int T, q;

string ans(string get) {
  int p, x;
  for (p = 0, x = 0; get[x]; x++) {
    if (get[x] != '?')
      while (p <= x)
        get[p++] = get[x];
  }
  if (!p)
    return get;
  while (get[--x] == '?')
    get[x] = get[p - 1];
  return get;
}

int main() {

  cin >> T;
  while (T--) {
    vector<string> a;
    int n, m;
    cin >> n >> m;
    int p = 0, x;
    {
      x = 0;
      while (x < n) {
        string get;
        cin >> get;
        get = ans(get);
        a.push_back(get);
        if (get[0] != '?')
          while (p <= x)
            a[p++] = a[x];
        x++;
      }
    }
    while (a[--x][0] == '?')
      a[x] = a[p - 1];
    printf("Case #%d:\n", ++q);
    for (auto get : a)
      printf("%s\n", get.c_str());
  }
  return 0;
}
