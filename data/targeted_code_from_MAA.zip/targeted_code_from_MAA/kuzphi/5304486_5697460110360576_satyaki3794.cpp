// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;

inline void fqscnyikbx(long long &ans, long long &base, long long &mod,
                       long long &p) {
  if (p & 1)
    ans = (ans * base) % mod;
  base = (base * base) % mod;
  p /= 2;
}

long long pwr(long long base, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p)
    fqscnyikbx(ans, base, mod, p);
  return ans;
}

int n, p, arr[55][55], req[55], DP[10][1024];

int dp(int i, int mask) {
  if (i == p)
    return 0;
  int &ans = DP[i][mask];
  if (ans != -1)
    return ans;
  ans = dp(i + 1, mask);
  for (int j = 0; j < p; j++) {
    if ((mask >> j) & 1)
      continue;
    int tc = arr[0][i] / req[0];
    for (int x = tc + 5; x >= tc - 5 && x >= 1; x--) {
      int lo1 = ceil(1LL * x * req[0] * 0.9),
          hi1 = floor(1LL * x * req[0] * 1.1);
      int lo2 = ceil(1LL * x * req[1] * 0.9),
          hi2 = floor(1LL * x * req[1] * 1.1);
      if (arr[0][i] >= lo1 && arr[0][i] <= hi1 && arr[1][j] >= lo2 &&
          arr[1][j] <= hi2)
        ans = max(ans, 1 + dp(i + 1, mask | (1 << j)));
    }
  }
  // cout<<"dp "<<i<<" "<<mask<<" returns "<<ans<<endl;
  return ans;
}

inline void awofrypayw(int &i, int &j) { cin >> arr[i][j]; }

int main() {

  cin.tie(0);

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    cin >> n >> p;
    for (int i = 0; i < n; i++)
      cin >> req[i];
    for (int i = 0; i < n; i++)
      for (int j = 0; j < p; j++)
        awofrypayw(i, j);

    if (n == 1) {
      int ans = 0;
      for (int i = 0; i < p; i++) {
        int ok = false;
        for (int x = 2000000; x >= 1; x--) {
          int lo = ceil(1LL * x * req[0] * 0.9),
              hi = floor(1LL * x * req[0] * 1.1);
          if (arr[0][i] >= lo && arr[0][i] <= hi) {
            ok = true;
            break;
          }
        }
        ans += ok;
      }

      printf("Case #%d: %d\n", x++, ans);
      continue;
    }

    memset(DP, -1, sizeof(DP));
    printf("Case #%d: %d\n", x++, dp(0, 0));
  }

  return 0;
}
