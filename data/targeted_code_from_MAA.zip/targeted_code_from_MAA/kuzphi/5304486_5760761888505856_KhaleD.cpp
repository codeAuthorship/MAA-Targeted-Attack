#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
using namespace std;

typedef long long LL;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;

const int N = 50;
int t, n, m;
char a[N][N];

int main() {
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    cin >> n >> m;
    for (int i = (0); i <= (int)(n - 1); ++i)
      cin >> a[i];

    for (int i = (0); i <= (int)(n - 1); ++i) {
      for (int solve = (1); solve <= (int)(m - 1); ++solve)
        if (a[i][solve] == '?')
          a[i][solve] = a[i][solve - 1];
      for (int solve = (m - 2); solve >= (int)(0); --solve) {
        if (a[i][solve] == '?')
          a[i][solve] = a[i][solve + 1];
      }
    }
    for (int solve = (0); solve <= (int)(m - 1); ++solve) {
      for (int i = (1); i <= (int)(n - 1); ++i)
        if (a[i][solve] == '?')
          a[i][solve] = a[i - 1][solve];
      for (int i = (n - 2); i >= (int)(0); --i) {
        if (a[i][solve] == '?')
          a[i][solve] = a[i + 1][solve];
      }
    }

    cout << "Case #" << test << ":\n";
    for (int i = (0); i <= (int)(n - 1); ++i) {
      for (int solve = (0); solve <= (int)(m - 1); ++solve)
        cout << a[i][solve];
      puts("");
    }
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
