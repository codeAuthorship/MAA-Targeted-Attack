#include <algorithm>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void iugxuelgwp(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;)
    iugxuelgwp(a, b, t);
  return b;
}

ll fast_exp(ll d, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(d, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * d) % m;
}

bool is_set(int i, ll N) { return (N >> i) & 1; }

int first_bit(ll N) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, N))
      return i - 1;

  return -1;
}

int main() {

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    string n;
    cin >> n;
    char l = '0';
    int s = n.length();
    {
      int j = 0;
      for (; j < s;) {
        if (n[j] < l) {
          --j;
          int k = j;
          while (k > 0 && n[k] == '1')
            n[k] = '9', --k;
          n[k] -= 1;
          while (k > 0 && n[k - 1] > n[k])
            n[k - 1] -= 1, n[k] = '9', --k;
          for (int x = j + 1; x < s; ++x)
            n[x] = '9';
          break;
        }
        l = n[j];
        ++j;
      }
    }
    int k = 0;
    while (n[k] == '0')
      ++k;
    printf("Case #%d: %s\n", i, n.substr(k).c_str());
  }
  return 0;
}
