
#include <algorithm>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>

using namespace std;

const int N = 1100;

int n, cnt[6];
int ans[N];
char cc[6] = {'R', 'O', 'Y', 'G', 'B', 'V'};

void T() { ans[0] = -10000; }

bool nb(int j, int v) {
  int res = j - v;
  return (res == 1 || res == -1 || res == 5 || res == -5 || res == 0);
}

bool dfs(int p) {
  if (p == n + 1) {
    if (!nb(ans[1], ans[n])) {
      return true;
    } else {
      return false;
      for (int i = 1; i <= n; ++i) {
        printf("%c", cc[ans[i]]);
      }
      cout << endl;
    }
  }
  vector<int> pos;
  int maxc = -10000;
  for (int i = 0; i < 6; ++i) {
    if (cnt[i] > maxc && !nb(i, ans[p - 1])) {
      pos.clear();
      pos.push_back(i);
      maxc = cnt[i];
    } else {
      if (cnt[i] == maxc) {
        pos.push_back(i);
      }
    }
  }
  if (maxc == -10000) {
    return false;
  }
  for (int i = 0; i < (int)pos.size(); ++i) {
    int j = pos[i];
    if (!nb(j, ans[p - 1])) {
      cnt[j]--;
      ans[p] = j;
      int res = dfs(p + 1);
      if (res) {
        return true;
      }
      cnt[j]++;
    }
  }
  return false;
}

void work() {
  cin >> n;
  int maxc = 0;
  for (int i = 0; i < 6; ++i) {
    cin >> cnt[i];
    if (cnt[i] > maxc) {
      maxc = cnt[i];
    }
  }
  if (maxc > n / 2) {
    cout << "IMPOSSIBLE" << endl;
    return;
  }
  if (dfs(1)) {
    {
      int i = 1;
      while (i <= n) {
        printf("%c", cc[ans[i]]);
        ++i;
      }
    }
    cout << endl;
  } else {
    cout << "IMPOSSIBLE" << endl;
  }
}

int main() {

  T();
  int q;
  cin >> q;
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    work();
  }
  return 0;
}
