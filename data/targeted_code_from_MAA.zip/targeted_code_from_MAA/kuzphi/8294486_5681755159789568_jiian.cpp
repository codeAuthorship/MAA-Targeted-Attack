#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
using namespace std;
const int MAXN = 1005;
const double eps = 1e-9;
const double EPS = 1e-9;
const int INF = 1000000000;
using LL = long long;

double e[123], v[123], s[123], a[123][123], dp[123];

inline void mreainxelq(int &n, int &get) {
  for (int j = 1; j <= n; j++)
    cin >> a[get][j];
}

int main() {
  ios::sync_with_stdio(false);

  int T, r = 0;
  cin >> T;
  for (; T--;) {
    int n, q;
    cin >> n >> q;
    for (int get = 1; get <= n; get++)
      cin >> e[get] >> v[get];
    for (int get = 1; get <= n; get++)
      mreainxelq(n, get);
    for (int get = 2; get <= n; get++)
      s[get] = s[get - 1] + a[get - 1][get];
    dp[1] = 0;
    for (int get = 2; get <= n; get++)
      dp[get] = 1e17;
    for (int get = 0; get < n; get++)
      for (int j = get + 1; j <= n; j++)
        if (s[j] - s[get] <= e[get])
          dp[j] = min(dp[j], dp[get] + (s[j] - s[get]) / v[get]);
    int qu, qv;
    cin >> qu >> qv;
    printf("Case #%d: %.10f\n", ++r, dp[n]);
  }
  return 0;
}
