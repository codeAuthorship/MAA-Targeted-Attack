#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const int INF = 1000000000;
const int MAXN = 1005;

const double EPS = 1e-9;

inline void oqenbdjcrg(double &m, int &d, int &k, int &s) {
  cin >> k >> s;
  m = max(m, 1.0 * (d - k) / s);
}

inline void rprlzuikvu(double &m, int &d, int &k, int &s) {
  oqenbdjcrg(m, d, k, s);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in",
          "r", stdin);

  int t, i, d, n, k, s;
  double m;
  cin >> t;
  for (int c = 0; c < t; c++) {
    cin >> d >> n;
    m = 0.0;
    for (i = 0; i < n; i++)
      rprlzuikvu(m, d, k, s);
    printf("Case #%d: %.6f\n", c + 1, d / m);
  }
  return 0;
}
