#include <algorithm>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MOD = 1000000007;
const double EPS = 1e-9;
const int mod = 1000000007;
const int INF = 1000000000;

inline void apukmxxcxd(int &get, int q[55][55], int arr[get], int r[55],
                       int &sol) {
 
  int tmp_sol = 0;
  for (int i = 0; i < get; i++) {
    int ce1 = (int)(floor(10.0 / 9.0 * q[0][i] / r[0]) + 1e-5);
    int fl1 = (int)(ceil(10.0 / 11.0 * q[0][i] / r[0]) + 1e-5);
    int ce2 = (int)(floor(10.0 / 9.0 * q[1][arr[i]] / r[1]) + 1e-5);
    int fl2 = (int)(ceil(10.0 / 11.0 * q[1][arr[i]] / r[1]) + 1e-5);
 
    if (fl1 <= ce1)
      if (fl2 <= ce2) {
        if ((fl1 <= ce2 && ce1 >= fl2) || (fl2 <= ce1 && fl1 <= ce2)) {
          tmp_sol++;
        }
      }
  }
  sol = max(sol, tmp_sol);
}

int solve(int a) {
  int n, get, r[55], q[55][55];
  cin >> n >> get;
  for (int i = 0; i < n; i++) {
    cin >> r[i];
  }
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < get; j++) {
      cin >> q[i][j];
    }
  }

  int sol = 0;
  if (n == 1) {
    for (int i = 0; i < get; i++) {
      int ce = (int)(floor(10.0 / 9.0 * q[0][i] / r[0]) + 1e-5);
      int fl = (int)(ceil(10.0 / 11.0 * q[0][i] / r[0]) + 1e-5);
 
      if (fl <= ce) {
        sol++;
      }
    }
  } else if (n == 2) {
    int arr[get];
    for (int i = 0; i < get; i++) {
      arr[i] = i;
    }
    do {
      apukmxxcxd(get, q, arr, r, sol);
    } while (next_permutation(arr, arr + get));
  }
  printf("Case #%d: %d\n", a, sol);
  return 1;
}

int main() {

  int t;
  cin >> t;
  for (int i = 0; i < t; i++) {
    solve(i + 1);
  }
  return 0;
}
