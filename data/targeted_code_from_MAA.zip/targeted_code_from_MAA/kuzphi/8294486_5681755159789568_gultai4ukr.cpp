#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;
const int MOD = 1000000007;
const double eps = 1e-9;

inline void jwimrcgbol(vector<double> &dp, vector<vector<long long>> &dist,
                       int &to, vector<long long> &s, int &from) {
  dp[to] = min(dp[to], dp[from] + 1.0 * dist[from][to] / s[from]);
}

int main(int c, char **T) {

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    int n, q, u, v;
    cin >> n >> q;
    assert(q == 1);
    vector<long long int> e(n), s(n);
    for (int i = 0; i < n; ++i) {
      cin >> e[i] >> s[i];
    }
    vector<vector<long long int>> d(n, vector<long long int>(n));
    int i;
    for (i = 0; i < n; ++i) {
      for (int j = 0; j < n; ++j) {
        cin >> d[i][j];
      }
    }
    cin >> u >> v;

    vector<vector<long long int>> dist(n, vector<long long int>(n, -1));
    for (int from = 0; from < n; ++from) {
      dist[from][from] = 0;
      for (int to = from + 1; to < n; ++to) {
        dist[from][to] = dist[from][to - 1] + d[to - 1][to];
        //				cout << from << ' ' << to << ' ' <<
        // dist[from][to] << endl;
      }
    }

    vector<double> dp(n, 1e18);
    dp[0] = 0;
    for (int to = 1; to < n; ++to) {
      for (int from = 0; from < to; ++from) {
        if (dist[from][to] <= e[from]) {
          jwimrcgbol(dp, dist, to, s, from);
        }
      }
    }

    cout << "Case #" << testcase + 1 << ": " << fixed << setprecision(7)
         << dp[n - 1] << endl;
  }

  return 0;
}
