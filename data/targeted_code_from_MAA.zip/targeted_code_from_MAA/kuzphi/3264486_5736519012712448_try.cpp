#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <math.h>
#include <numeric>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
using namespace std;
const int INF = 1000000000;
const int mod = 1000000007;

char s[1 << 10];
int n, k;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in",
          "r", stdin);

  int c, t, i, ans;
  cin >> t;
  for (c = 0; c < t; c++) {
    cin >> s >> k;
    n = strlen(s);
    ans = 0;
    for (i = 0; i < n; i++) {
      if (s[i] == '-') {
        if (i + k > n) {
          ans = -1;
          break;
        }
        ans++;
        for (int j = i; j < i + k; j++) {
          if (s[j] == '-') {
            s[j] = '+';
          } else {
            s[j] = '-';
          }
        }
      }
    }
    printf("Case #%d: ", c + 1);
    if (ans != -1) {
      printf("%d\n", ans);
    } else {
      printf("IMPOSSIBLE\n");
    }
  }
  return 0;
}
