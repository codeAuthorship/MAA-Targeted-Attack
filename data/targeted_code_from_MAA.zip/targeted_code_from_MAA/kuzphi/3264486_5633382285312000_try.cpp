#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
using namespace std;

char s[64];
int n, l;

int main() {
  ios::sync_with_stdio(false);

  int c, T, i, f;
  scanf("%d", &T);
  for (c = 0; c < T; c++) {
    scanf("%s", s);
    l = strlen(s);
    for (i = l - 1; i >= 1; i--) {
      if (s[i] < s[i - 1]) {
        while ((i >= 1) && (s[i - 1] == '0')) {
          i--;
        }
        s[i - 1]--;
        memset(s + i, '9', (l - i) * sizeof(char));
      }
    }
    printf("Case #%d: %I64d\n", c + 1, atoll(s));
  }
  return 0;
}
