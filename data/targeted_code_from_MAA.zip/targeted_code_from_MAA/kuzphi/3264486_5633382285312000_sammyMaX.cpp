#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const double eps = 1e-9;
const int MAXN = 1005;
const long double PI = 3.1415926535897932384626433832795;

ifstream T("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/A-small-practice.in");
ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline void xcgoibpnwb(char &minc, char &c) { minc = min(minc, c); }

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s)
    xcgoibpnwb(minc, c);
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0])
      return s[0] + solves(s.substr(1), s[0]);
    else {
      string y = "";
      if (s[0] > minc)
        if (s[0] > '1')
          y += (char)(s[0] - 1);
      int i;
      for (i = 1; i < s.size(); i++)
        y += '9';
      return y;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void get() {
  string s;
  T >> s;
  fout << solves(s, '0') << '\n';
}

int main() {
  int t;
  T >> t;
  for (int i = 0; i < t; i++)
    fout << "Case #" << i + 1 << ": ", get();
  return 0;
}
