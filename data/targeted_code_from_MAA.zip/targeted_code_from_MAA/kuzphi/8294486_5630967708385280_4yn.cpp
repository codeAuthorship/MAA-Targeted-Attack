#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

const int mod = 1000000007;
const double EPS = 1e-9;
const long double PI = 3.1415926535897932384626433832795;

int tc;

long long d, n, solve, b;
vector<pair<long long, long long>> ks;

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_1_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/4yn/A-small-practice.in");

  fin >> tc;
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    fin >> d >> n;
    double lb, ub, ex;
    lb = 0;
    ub = 0;
    {
      int i = 0;
      while (i < n) {
        fin >> solve >> b;
        ks.push_back(pair<long long, long long>(solve, b));
        if (ub == 0) {
          if (solve != d) {
            ub = d * b / (d - solve + 0.0);
          }
        } else {
          if (solve != d) {
            ub = min(ub, d * b / (d - solve + 0.0));
          }
        }
        i++;
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = 1;
 
      for (int i = 0; i < n; i++) {
 
        if (ks[i].second >= ex)
          continue;
 
 
 
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    printf("Case #%d: %.7f\n", t, ub);
  }
  return 0;
}
