#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
const long double PI = 3.1415926535897932384626433832795;
const int MOD = 1000000007;
const int mod = 1000000007;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0) {
    a = b;
    b = t;
  }
  return b;
}

ll fast_exp(ll base, ll n, ll tc) {
  if (n == 0)
    return 1;
  ll t = fast_exp(base, n / 2, tc);
  if (n % 2 == 0)
    return (t * t) % tc;
  else
    return (((t * t) % tc) * base) % tc;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int get(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return ret_val;
}

int main() {

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    int n, q;
    cin >> n >> q;
    ll e[n], s[n];
    for (int i = 0; i < n; ++i)
      cin >> e[i] >> s[i];
    ll d[n][n];
    for (int i = 0; i < n; ++i)
      for (int j = 0; j < n; ++j)
        cin >> d[i][j];
    {
      int u, v;
      cin >> u >> v;
      --u, --v;
      vector<double> dp(n);
      dp[0] = 0;
      for (int i = 1; i < n; ++i) {
        dp[i] = 1e12;
        ll dist = 0;
        for (int j = i - 1; j >= 0; --j) {
          dist += d[j][j + 1];
          if (e[j] > dist)
            dp[i] = min(dp[i], dp[j] + dist / static_cast<double>(s[j]));
        }
      }
      printf("Case #%d: %.10f\n", i, dp[v]);
    }
  }
  return 0;
}
