#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const int INF = 1000000000;
const double eps = 1e-9;
const int mod = 1000000007;
const int MAXN = 1005;

int main() {

  int T, b = 0;
  cin >> T;
  for (; T--;) {
    long long n, k;
    cin >> n >> k;
    int d = 0;
    for (long long v = 1; v <= k; v <<= 1)
      d++;
    printf("Case #%d: ", ++b);
    long long get = 1 << d;
    if (n < get) {
      puts("0 0");
      continue;
    }
    long long md = (n - (get - 1)) % get;
    long long lx = (n - (get - 1)) / get, rx = lx;
    int id = k - (1 << (d - 1)) + 1;
    if (id <= md)
      rx++;

    if (id + (1 << (d - 1)) <= md)
      lx++;
    printf("%lld %lld\n", rx, lx);
  }
  return 0;
}
