#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

const long double PI = 3.1415926535897932384626433832795;
const int INF = 1000000000;
const int MAXN = 1005;
const int mod = 1000000007;
const double eps = 1e-9;
typedef long double LD;
typedef unsigned long long ull;
typedef long long LL;
typedef pair<int, int> PII;
typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 102;
int t, n, q, dist[N], speed[N], u, v;
vector<vector<PII>> g(N);
bool vis[N];
double dp[N];

double solve(int get) {
  if (get == v)
    return 0;
  if (!((int)(g[get]).size()))
    return 1000000000000000000ll;
  if (vis[get])
    return dp[get];
  vis[get] = true;

  dp[get] = 1000000000000000000ll;
  double totalDist = g[get].back().second;
  int j = g[get].back().first;
  while (totalDist <= dist[get]) {
    dp[get] = min(dp[get], totalDist / speed[get] + solve(j));
    if (j == v)
      break;
    if (!((int)(g[j]).size()))
      return dp[get];
    totalDist += g[j].back().second;
    j = g[j].back().first;
  }
  return dp[get];
}

inline void jbeagzqdxr(int &get, int &j) {
  int a;
  fin >> a;
  if (a != -1)
    g[get].push_back(make_pair(j, a));
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/KhaleD/A-small-practice.in");

  fin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    fin >> n >> q;
    for (int get = (1); get <= (int)(n); ++get)
      fin >> dist[get] >> speed[get];
    for (int get = (1); get <= (int)(n); ++get)
      for (int j = (1); j <= (int)(n); ++j)
        jbeagzqdxr(get, j);
    while (q--) {
      fin >> u >> v;
      memset(vis, 0, sizeof vis);
      printf("Case #%d: %.6f\n", test, solve(u));
    }

    g.clear(), g.resize(N);
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
