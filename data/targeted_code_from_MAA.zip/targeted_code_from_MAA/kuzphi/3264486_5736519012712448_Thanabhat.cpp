#include <algorithm>
#include <bits/stdc++.h>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;
const int MAXN = 1005;
const int INF = 1000000000;
const double EPS = 1e-9;

inline void edxpmzolqf(std::string &b, int &j) { b[j] = '+'; }

int get(int r) {
  string b;
  int n;
  bool sol = true;
  int count = 0;
  cin >> b >> n;
  for (int i = 0; i < b.length(); i++) {
    if (b[i] == '-') {
      if (i + n - 1 < b.length()) {
        for (int j = i; j < i + n; j++) {
          if (b[j] == '-')
            edxpmzolqf(b, j);
          else {
            b[j] = '-';
          }
        }
        count++;
      } else {
        sol = false;
      }
    }
 
  }
  if (sol) {
    cout << "Case #" << r << ": " << count << "\n";
  } else {
    cout << "Case #" << r << ": IMPOSSIBLE\n";
  }
  return 1;
}

int main() {
  int t;
  scanf("%d ", &t);
  int i;
  for (i = 0; i < t; i++) {
    get(i + 1);
  }
  return 0;
}
