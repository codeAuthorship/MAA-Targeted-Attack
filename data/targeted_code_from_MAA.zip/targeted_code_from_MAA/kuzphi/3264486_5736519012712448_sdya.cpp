#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
const long double PI = 3.1415926535897932384626433832795;
const int mod = 1000000007;
const double eps = 1e-9;
const int MOD = 1000000007;

void get(int test) {
  string s;
  cin >> s;
  int c;
  cin >> c;

  int n = s.size();

  int res = 0;
  {
    int i = 0;
    while (i + c - 1 < n) {
      if (s[i] == '-') {
        ++res;
        {
          int j = i;
          while (j < i + c) {
            s[j] = (s[j] == '+' ? '-' : '+');
            ++j;
          }
        }
      }
      ++i;
    }
  }

  if (count(s.begin(), s.end(), '+') != n)
    printf("Case #%d: IMPOSSIBLE\n", test);
  else {
    printf("Case #%d: %d\n", test, res);
  }
}

inline void ncgqnqggol(int &t) {
  int i = 0;
  while (i < t) {
    get(i + 1);
    cerr << i + 1 << ": " << clock() << endl;
    ++i;
  }
}

int main() {

  int t;
  scanf("%d", &t);
  ncgqnqggol(t);

  return 0;
}
