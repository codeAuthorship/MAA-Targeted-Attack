#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;

const double EPS = 1e-9;

int tc;

int main() {

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int T = 0; T < r; T++) {
      for (int j = 0; j < c; j++) {
        cin >> cake[T][j];
      }
    }
    for (int T = 0; T < r; T++) {
 
      for (int j = 1; j < c; j++) {
        if (cake[T][j - 1] != '?' && cake[T][j] == '?') {
          cake[T][j] = cake[T][j - 1];
        }
      }
 
      {
        int j = c - 2;
        while (j >= 0) {
          if (cake[T][j + 1] != '?' && cake[T][j] == '?') {
            cake[T][j] = cake[T][j + 1];
          }
          j--;
        }
      }
    }
    for (int T = 1; T < r; T++) {
 
      if (cake[T - 1][0] != '?' && cake[T][0] == '?') {
        for (int j = 0; j < c; j++) {
          cake[T][j] = cake[T - 1][j];
        }
      }
    }
    for (int T = r - 1; T >= 0; T--) {
 
      if (cake[T + 1][0] != '?')
        if (cake[T][0] == '?') {
          for (int j = 0; j < c; j++)
            cake[T][j] = cake[T + 1][j];
        }
    }
    printf("Case #%d:\n", t);
    for (int T = 0; T < r; T++) {
      for (int j = 0; j < c; j++) {
        printf("%c", cake[T][j]);
      }
      printf("\n");
    }
  }
  return 0;
}
