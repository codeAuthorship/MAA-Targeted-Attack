#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MOD = 1000000007;
ifstream fin;

const long double PI = 3.1415926535897932384626433832795;
const int mod = 1000000007;

pair<int, int> adj[50 + 1][50 + 1];
int cnt[50 + 1], cur[50 + 1];
int r[50 + 1], q[50 + 1];
int n, p;

int main() {

  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in");

  int t, i, j, flg, ans, maxl, maxi, get, mini;
  fin >> t;
  for (int c = 0; c < t; c++) {
    memset(cnt, 0, sizeof(cnt));
    fin >> n >> p;
    {
      i = 0;
      while (i < n) {
        fin >> r[i];
        i++;
      }
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < p; j++) {
        fin >> q[j];
      }
      sort(q, q + p);
      for (j = 0; j < p; j++) {
        if (((q[j] * 9 + 9) / 10 + r[i] - 1) / r[i] <=
            ((q[j] * 10) / 9) / r[i]) {
          adj[i][cnt[i]++] = make_pair(((q[j] * 9 + 9) / 10 + r[i] - 1) / r[i],
                                       ((q[j] * 10) / 9) / r[i]);
        }
      }
    }
    memset(cur, 0, sizeof(cur));
    flg = 1;
    ans = 0;
    for (; flg == 1;) {
      for (i = 0; i < n; i++) {
        if (cur[i] >= cnt[i]) {
          flg = 0;
          break;
        }
      }
      if (flg == 0) {
        break;
      }
      maxl = -1;
      maxi = -1;
      get = 1000000000;
      mini = -1;
      for (i = 0; i < n; i++) {
        if (maxl < adj[i][cur[i]].first) {
          maxl = adj[i][cur[i]].first;
          maxi = i;
        }
        if (get > adj[i][cur[i]].second) {
          get = adj[i][cur[i]].second;
          mini = i;
        }
      }
      if (maxl <= get) {
        ans++;
        for (i = 0; i < n; i++) {
          cur[i]++;
        }
      } else {
        cur[mini]++;
      }
    }
    printf("Case #%d: %d\n", c + 1, ans);
  }
  return 0;
}
