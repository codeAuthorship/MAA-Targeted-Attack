#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
const double EPS = 1e-9;
const int mod = 1000000007;

int n, tc;
char s[50][50];
int main(void) {
  int ret_val = 0;
  int t;
  cin >> t;
  for (int r = 1; r <= t; r++) {
    cin >> n >> tc;
    for (int ans = 0; ans < n; ++ans)
      cin >> s[ans];

    int get, solve = 0;
    for (int ans = 0; ans < n; ++ans) {
      get = 0;
      bool fill = false;
      for (int j = 0; j < tc; ++j) {
        if (s[ans][j] == '?')
          continue;
        fill = true;
        int st = get, ed = j + 1;
        for (; ed < tc && s[ans][ed] == '?'; ++ed)
          ;
        for (int x = st; x < ed; ++x) {
          int y = solve;
          for (; y <= ans;) {
            s[y][x] = s[ans][j];
            ++y;
          }
        }
        get = ed;
      }
      if (fill)
        solve = ans + 1;
    }

    for (int ans = 0; ans < n; ++ans)
      for (int j = 0; j < tc; ++j)
        if (s[ans][j] == '?')
          s[ans][j] = s[ans - 1][j];

    printf("Case #%d:\n", r);
    for (int ans = 0; ans < n; ++ans)
      printf("%s\n", s[ans]);
  }
  return ret_val;
}
