#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int mod = 1000000007;
ifstream fin;

const double eps = 1e-9;
const int INF = 1000000000;

char a[77][77];

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_18_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/fragusbot/A-small-practice.in");

  int T;
  fin >> T;
  for (int ans = 1; ans <= T; ++ans) {
    double begt = clock();
    printf("Case #%d:\n", ans);
    int n, m;
    fin >> n >> m;
    for (int i = 0; i < n; ++i) {
      fin >> a[i];
    }
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < m - 1; ++j) {
        if (a[i][j] != '?' && a[i][j + 1] == '?') {
          a[i][j + 1] = a[i][j];
        }
      }
      {
        int j = m - 1;
        while (j > 0) {
          if (a[i][j] != '?' && a[i][j - 1] == '?') {
            a[i][j - 1] = a[i][j];
          }
          --j;
        }
      }
    }
    for (int i = 0; i < n - 1; ++i) {
      for (int j = 0; j < m; ++j) {
        if (a[i][j] != '?')
          if (a[i + 1][j] == '?') {
            a[i + 1][j] = a[i][j];
          }
      }
    }
    for (int i = n - 1; i > 0; --i) {
      for (int j = 0; j < m; ++j) {
        if (a[i][j] != '?' && a[i - 1][j] == '?') {
          a[i - 1][j] = a[i][j];
        }
      }
    }
    for (int i = 0; i < n; ++i) {
      printf("%s\n", a[i]);
    }
    fprintf(stderr, "case %d solved in %.3f\n", ans,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
