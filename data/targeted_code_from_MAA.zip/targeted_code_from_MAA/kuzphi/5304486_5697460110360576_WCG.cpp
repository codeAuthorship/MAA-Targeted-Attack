#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const long double PI = 3.1415926535897932384626433832795;

long long q[55][55];
long long r[55];
int n, p;

struct package {
  long long large, small;
  int id;
};

bool myCompare(package p1, package get) {
  if (p1.large == get.large)
    return p1.small > get.small;
  return p1.large > get.large;
}

int main() {
  ios::sync_with_stdio(false);

  int d;

  cin >> d;

  for (int t = 1; t <= d; ++t) {
    int res = 0;
    vector<package> vp;
    vector<queue<long long>> qp(55);
    cin >> n >> p;
    for (int i = 0; i < n; ++i)
      cin >> r[i];
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < p; ++j) {
        cin >> q[i][j];
        package pp;
        pp.id = i;
        pp.large = floor(q[i][j] / (0.9 * r[i]));
        pp.small = ceil(q[i][j] / (1.1 * r[i]));
        if (pp.large >= pp.small)
          vp.push_back(pp);
      }
    }

    sort(vp.begin(), vp.end(), myCompare);
    for (int i = 0; i < vp.size(); ++i) {
      for (int j = 0; j < n; ++j) {
        while ((qp[j].size() > 0) && (vp[i].large < qp[j].front()))
          qp[j].pop();
      }

      qp[vp[i].id].push(vp[i].small);

      bool hasOne = true;
      for (int j = 0; j < n; ++j)
        if (qp[j].size() == 0)
          hasOne = false;
      if (hasOne) {
        res++;
        for (int j = 0; j < n; ++j)
          qp[j].pop();
      }
    }

    printf("Case #%d: %d\n", t, res);
  }

  return 0;
}
