#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &q, pair<S, T> &p) {
  return q >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}

template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;
const double INF = 1e15;

inline void mdbwgrreih(VVL &dist, vector<LL> &acc, int &i) {
  acc[i] = dist[i][i + 1] + acc[i + 1];
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/okaduki/A-small-practice.in");

  cin.tie(0);

  int T;
  fin >> T;
  int s;
  for (s = (1); s < (T + 1); ++s) {
    int N, Q;
    fin >> N >> Q;
    vector<PLL> es(N);
    for (int i = (0); i < (N); ++i)
      fin >> es[i];

    VVL dist(N, VL(N));
    for (int i = (0); i < (N); ++i)
      for (int j = (0); j < (N); ++j)
        fin >> dist[i][j];

    while (Q--) {
      int U, V;
      fin >> U >> V;
      --U;
      --V;

      vector<LL> acc(N);
      for (int i = N - 2; i >= 0; --i)
        mdbwgrreih(dist, acc, i);

      vector<double> dp(N + 1, INF);
      dp[N - 1] = 0;
      int i;
      for (i = N - 2; i >= 0; --i) {
        int j;
        for (j = i + 1; j < N; ++j) {
          if (acc[i] - acc[j] > es[i].first)
            break;
          mini(dp[i], dp[j] + (acc[i] - acc[j]) * 1. / es[i].second);
        }
      }
      double ans = dp[0];
      printf("Case #%d: %.9f\n", s, ans);
    }
  }

  return 0;
}
