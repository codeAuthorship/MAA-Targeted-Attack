// satyaki3794
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;

long long get(long long base, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return ans;
}

long long gcd(long long a, long long b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}

int n, red, orange, yellow, green, blue, violet;
vector<string> arr[5];

string yolo(int x) {
  string r = arr[x].back();
  arr[x].pop_back();
  return r;
}

string check(int x) {

  int y = -1, r = -1;
  int i;
  for (i = 1; i <= 3; i++) {
    if (i == x)
      continue;
    if (y == -1)
      y = i;
    else
      r = i;
  }

  int xsz = (int)arr[x].size(), ysz = (int)arr[y].size(),
      zsz = (int)arr[r].size();
  if (ysz + zsz < xsz)
    return "";
  if (ysz < zsz) {
    swap(y, r);
    swap(ysz, zsz);
  }

  // cout<<x<<" "<<y<<" "<<z<<endl;

  if (ysz >= xsz) {
    int rem = ysz - xsz;
    if (rem > zsz)
      return "";
    zsz -= rem;
    string ans = "";
    {
      int i = 0;
      while (i < xsz) {
        ans += yolo(x) + yolo(y);
        if (i == 0) {
          while (rem--) {
            ans += yolo(r) + yolo(y);
          }
        }
        if (i < zsz)
          ans += yolo(r);
        i++;
      }
    }
    return ans;
  } else {
    int rem = zsz - (xsz - ysz);
    if (rem > ysz)
      return "";
    string ans = "";
    {
      int i = 0;
      while (i < xsz) {
        ans += yolo(x);
        if (i < ysz) {
          ans += yolo(y);
          if (i < rem)
            ans += yolo(r);
        } else {
          ans += yolo(r);
        }
        i++;
      }
    }
    return ans;
  }
  return "";
}

int main() {

  cin.tie(0);

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    cin >> n >> red >> orange >> yellow >> green >> blue >> violet;

    orange = green = violet = 0;

    if (orange > 0 && blue < orange + 1) {
      printf("Case #%d: IMPOSSIBLE\n", x++);
      continue;
    }

    if (green > 0 && red < green + 1) {
      printf("Case #%d: IMPOSSIBLE\n", x++);
      continue;
    }

    if (violet > 0 && yellow < violet + 1) {
      printf("Case #%d: IMPOSSIBLE\n", x++);
      continue;
    }

    arr[1].clear();
    arr[2].clear();
    arr[3].clear();

    if (orange > 0) {
      blue -= orange + 1;
      string str = "B";
      while (orange--)
        str += "OB";
      arr[1].push_back(str);
    }

    if (green > 0) {
      red -= green + 1;
      string str = "R";
      while (green--)
        str += "GR";
      arr[2].push_back(str);
    }

    if (violet > 0) {
      yellow -= violet + 1;
      string str = "Y";
      while (violet--)
        str += "VY";
      arr[3].push_back(str);
    }

    while (blue--)
      arr[1].push_back("B");
    while (red--)
      arr[2].push_back("R");
    while (yellow--)
      arr[3].push_back("Y");

    string ans = "";
    ans = check(1);
    // cout<<ans<<endl;
    if ((int)ans.length() == n) {
      printf("Case #%d: %s\n", x++, ans.c_str());
      continue;
    }

    ans = check(2);
    if ((int)ans.length() == n) {
      printf("Case #%d: %s\n", x++, ans.c_str());
      continue;
    }

    ans = check(3);
    if ((int)ans.length() == n) {
      printf("Case #%d: %s\n", x++, ans.c_str());
      continue;
    }

    ans = "";
    if ((int)ans.length() != n) {
      printf("Case #%d: IMPOSSIBLE\n", x++);
      continue;
    }
  }

  return 0;
}
