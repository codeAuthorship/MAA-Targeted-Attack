#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

const double eps = 1e-9;
using LL = long long;
using pii = pair<int, int>;

int T, cas;

inline void jirowhapgu(vector<vector<pii>> &v, int &mnv, int &mnid, int &mxv,
                       int &mxid, int &i) {
  auto x = v[i].back();
  if (x.first > mnv)
    mnv = x.first, mnid = i;
  if (x.second < mxv)
    mxv = x.second, mxid = i;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_11_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/jiian/A-small-practice.in");

  fin >> T;
  for (; T--;) {
    vector<vector<pii>> v;
    vector<int> R;
    int n, p;
    fin >> n >> p;
    {
      int i = 0, x;
      for (; i < n;) {
        fin >> x, R.push_back(x);
        i++;
      }
    }
    int solve = p;
    for (int i = 0; i < n; i++) {
      v.push_back(vector<pii>());
      for (int j = 0, x; j < p; j++) {
        fin >> x;
        int a = ceil(1 / 1.1 * x / R[i]), b = floor(1 / 0.9 * x / R[i]);
        // while (1.0 * a * R[i] < 0.9 * x) a ++;
        // while (1.0 * b * R[i] > 1.1 * x) b --;
        // cout << a << " " << b << endl;
        if (a <= b)
          v.back().emplace_back(a, b);
      }
      sort(v[i].begin(), v[i].end());
    }
    int ans = 0;
    while (true) {
      int mnv = 0, mxv = 1e9, mnid, mxid, flag = 0;
      for (int i = 0; i < n; i++)
        if (v[i].size())
          jirowhapgu(v, mnv, mnid, mxv, mxid, i);
        else
          flag = 1;
      if (flag)
        break;
      // cout << mnv << " " << mxv << endl;
      if (mnv <= mxv) {
        ans++;
        for (int i = 0; i < n; i++)
          v[i].pop_back();
      } else
        v[mnid].pop_back();
    }
    printf("Case #%d: %d\n", ++cas, ans);
  }
  return 0;
}
