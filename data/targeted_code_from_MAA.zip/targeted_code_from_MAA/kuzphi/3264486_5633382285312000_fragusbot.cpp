#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;
const int MOD = 1000000007;

bool check(int n) {
  while (n > 0) {
    if (n % 10 < n / 10 % 10) {
      return 0;
    }
    n /= 10;
  }
  return 1;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_18_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/fragusbot/A-small-practice.in");

  int get;
  fin >> get;
  {
    int cc = 1;
    while (cc <= get) {
      printf("Case #%d: ", cc);
      int n;
      fin >> n;
      int ans = n;
      while (!check(ans)) {
        --ans;
      }
      printf("%d\n", ans);
      ++cc;
    }
  }
  return 0;
}
