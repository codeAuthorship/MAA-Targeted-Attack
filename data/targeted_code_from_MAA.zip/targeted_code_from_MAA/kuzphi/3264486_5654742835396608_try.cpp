#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;

priority_queue<int> Q, E;
int n, k;

inline void ljmtwzrlfy(int &x, int &y, int &z) {
  x = Q.top();
  Q.pop();
  y = x / 2;
  z = (x - 1) / 2;
  Q.push(y);
  Q.push(z);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in",
          "r", stdin);

  int t, x, y, z;
  cin >> t;
  for (int c = 0; c < t; c++) {
    cin >> n >> k;
    Q = E;
    Q.push(n);
    for (int i = 0; i < k; i++)
      ljmtwzrlfy(x, y, z);
    printf("Case #%d: %d %d\n", c + 1, y, z);
  }
  return 0;
}
