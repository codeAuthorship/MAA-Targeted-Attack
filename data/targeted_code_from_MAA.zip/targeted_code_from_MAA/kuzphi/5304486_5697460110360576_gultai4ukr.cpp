#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
typedef long double td_ld;

const int MOD = 1000000007;

inline void fafdtybknv(int &m1, int &m2) { swap(m1, m2); }

inline void qgdguwbzga(int &ans) { ans++; }

int main(int y, char **argv) {

  ofstream fout("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_14_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    int n, p;
    cin >> n >> p;
    vector<int> need(n);
    for (int i = 0; i < n; ++i) {
      cin >> need[i];
    }
    vector<vector<int>> q(n, vector<int>(p));
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < p; ++j) {
        cin >> q[i][j];
      }
    }

    assert(n < 3);
    int ans = 0;
    if (n == 1) {
      {
        int i = 0;
        while (i < p) {
          int k = q[0][i] / need[0];
          td_ld fr1 = 1.0L * q[0][i] / (k * need[0]);
          if (0.9L <= fr1)
            if (fr1 <= 1.1L) {
              ans++;
              ++i;
              continue;
            }
          td_ld fr2 = 1.0L * q[0][i] / ((k + 1) * need[0]);
          if (0.9L <= fr2 && fr2 <= 1.1L)
            qgdguwbzga(ans);
          ++i;
        }
      }
    } else {
      vector<int> perm(p);
      {
        int i = 0;
        while (i < p) {
          perm[i] = i;
          ++i;
        }
      }
      do {
        int cur = 0;
        for (int i = 0; i < p; ++i) {
          int m1 = q[0][i] / need[0];
          int m2 = q[1][i] / need[1];
          if (m2 < m1)
            fafdtybknv(m1, m2);
          for (int k = m1; k < m2 + 2; ++k) {
            td_ld fr01 = 1.0L * q[0][i] / (k * need[0]);
            td_ld fr11 = 1.0L * q[1][perm[i]] / (k * need[1]);
            td_ld fr02 = 1.0L * q[0][i] / ((k + 1) * need[0]);
            td_ld fr12 = 1.0L * q[1][perm[i]] / ((k + 1) * need[1]);
            if (0.9L <= fr01 && fr01 <= 1.1L && 0.9L <= fr11 && fr11 <= 1.1L) {
              cur++;
              break;
            } else if (0.9L <= fr02 && fr02 <= 1.1L && 0.9L <= fr12 &&
                       fr12 <= 1.1L) {
              cur++;
              break;
            }
          }
        }
        ans = max(ans, cur);
      } while (next_permutation(perm.begin(), perm.end()));
    }

    fout << "Case #" << testcase + 1 << ": " << ans << endl;
  }

  fout.close();
  return 0;
}
