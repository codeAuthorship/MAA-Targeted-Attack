#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
typedef long double ld;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;

const int N = 100002;
int t, n, r, o, y, g, b, v;
char ans[N];

bool conflict(int get, int j) {
  if (ans[get] == ans[j])
    return true;
  if ((ans[get] == 'R' or ans[get] == 'B' or ans[get] == 'Y') and
      (ans[j] == 'R' or ans[j] == 'B' or ans[j] == 'Y'))
    return false;
  if (ans[get] == 'O' and ans[j] != 'B')
    return true;
  if (ans[get] == 'G' and ans[j] != 'R')
    return true;
  if (ans[get] == 'V' and ans[j] != 'Y')
    return true;
  swap(get, j);
  if (ans[get] == 'O' and ans[j] != 'B')
    return true;
  if (ans[get] == 'G' and ans[j] != 'R')
    return true;
  if (ans[get] == 'V' and ans[j] != 'Y')
    return true;
  return false;
}

bool solve() {
  int get;
  for (get = (0); get <= (int)(n - 1); ++get)
    if (conflict(get, (get + 1) % n))
      return false;
  return true;
}

inline void qyhoiuveqv(int &get) {
  ans[get++] = 'O', --o;
  if (b)
    ans[get++] = 'B', --b;
}

int main() {
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    cin >> n >> r >> o >> y >> g >> b >> v;
    ans[n] = '\0';
    printf("Case #%d: ", test);

    if (b >= o and r >= g and y >= v) {
      int get = 0;
      if (o) {
        ans[get++] = 'B';
        --b;
        while (o)
          qyhoiuveqv(get);
      }
      if (g) {
        ans[get++] = 'R';
        --r;
        while (g) {
          ans[get++] = 'G', --g;
          if (r)
            ans[get++] = 'R', --r;
        }
      }
      if (v) {
        ans[get++] = 'Y';
        --y;
        while (v) {
          ans[get++] = 'V', --v;
          if (y)
            ans[get++] = 'Y', --y;
        }
      }

      int rr = r, bb = b, yy = y;
      int j = get;
      // rby
      while (rr or bb or yy) {
        if (rr)
          ans[j++] = 'R', --rr;
        if (bb)
          ans[j++] = 'B', --bb;
        if (yy)
          ans[j++] = 'Y', --yy;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = get;
      // ryb
      while (rr or bb or yy) {
        if (rr)
          ans[j++] = 'R', --rr;
        if (yy)
          ans[j++] = 'Y', --yy;
        if (bb)
          ans[j++] = 'B', --bb;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = get;
      // ybr
      while (rr or bb or yy) {
        if (yy)
          ans[j++] = 'Y', --yy;
        if (bb)
          ans[j++] = 'B', --bb;
        if (rr)
          ans[j++] = 'R', --rr;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = get;
      // bry
      while (rr or bb or yy) {
        if (bb)
          ans[j++] = 'B', --bb;
        if (rr)
          ans[j++] = 'R', --rr;
        if (yy)
          ans[j++] = 'Y', --yy;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = get;
      // yrb
      while (rr or bb or yy) {
        if (yy)
          ans[j++] = 'Y', --yy;
        if (rr)
          ans[j++] = 'R', --rr;
        if (bb)
          ans[j++] = 'B', --bb;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = get;
      // byr
      while (rr or bb or yy) {
        if (bb)
          ans[j++] = 'B', --bb;
        if (yy)
          ans[j++] = 'Y', --yy;
        if (rr)
          ans[j++] = 'R', --rr;
      }
      if (solve()) {
        puts(ans);
        continue;
      }
      puts("IMPOSSIBLE");
    } else
      printf("IMPOSSIBLE\n");
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
