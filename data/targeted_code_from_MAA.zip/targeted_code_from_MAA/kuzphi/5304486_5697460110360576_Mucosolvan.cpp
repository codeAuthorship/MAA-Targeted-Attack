#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;

typedef float td_f;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;
typedef long long LL;
typedef long double ld;

const int inf = 1e9 + 7;
const int maxN = 50;
const int M = 50;
const int N = 50;

int t, n, p;
int req[maxN], minim[maxN][maxN], arr[maxN][maxN], maxim[maxN][maxN];
bool graph[maxN][maxN];

bool przeciecie(int get, int j) {
  if (minim[1][get] == inf || minim[2][j] == inf)
    return false;
  if (minim[1][get] >= minim[2][j] && minim[1][get] <= maxim[2][j])
    return true;
  if (maxim[1][get] >= minim[2][j] && maxim[1][get] <= maxim[2][j])
    return true;
  return false;
}

// maximal bipartite matching code copied from
// http://www.geeksforgeeks.org/maximum-bipartite-matching/
bool bpm(bool bpGraph[M][N], int u, bool seen[], int matchR[]) {
  // Try every job one by one
  for (int v = 0; v < N; v++) {
    // If applicant u is interested in job v and v is
    // not visited
    if (bpGraph[u][v] && !seen[v]) {
      seen[v] = true; // Mark v as visited

      // If job 'v' is not assigned to an applicant OR
      // previously assigned applicant for job v (which is matchR[v])
      // has an alternate job available.
      // Since v is marked as visited in the above line, matchR[v]
      // in the following recursive call will not get job 'v' again
      if (matchR[v] < 0 || bpm(bpGraph, matchR[v], seen, matchR)) {
        matchR[v] = u;
        return true;
      }
    }
  }
  return false;
}

// Returns maximum number of matching from M to N
int maxBPM(bool bpGraph[M][N]) {
  // An array to keep track of the applicants assigned to
  // jobs. The value of matchR[i] is the applicant number
  // assigned to job i, the value -1 indicates nobody is
  // assigned.
  int matchR[N];

  // Initially all jobs are available
  memset(matchR, -1, sizeof(matchR));

  int result = 0; // Count of jobs assigned to applicants
  for (int u = 0; u < M; u++) {
    // Mark all jobs as not seen for next applicant.
    bool seen[N];
    memset(seen, 0, sizeof(seen));

    // Find if the applicant 'u' can get a job
    if (bpm(bpGraph, u, seen, matchR))
      result++;
  }
  return result;
}

inline void lzcfdrtzlz(int &x, int &j) { minim[x][j] = maxim[x][j] = inf; }

int main() {

  cin >> t;
  for (int test = (1); test <= ((t)); ++test) {
    cin >> n >> p;
    for (int get = (1); get <= ((n)); ++get) {
      cin >> req[get];
    }

    for (int x = (1); x <= ((n)); ++x)
      for (int j = (1); j <= ((p)); ++j)
        lzcfdrtzlz(x, j);
    for (int get = (1); get <= ((40)); ++get) {
      for (int j = (1); j <= ((40)); ++j) {
        graph[get][j] = 0;
        minim[get][j] = maxim[get][j] = inf;
      }
    }
    for (int get = (1); get <= ((n)); ++get)
      for (int j = (1); j <= ((p)); ++j)
        cin >> arr[get][j];

    for (int x = (1); x <= ((n)); ++x) {
      for (int j = (1); j <= ((p)); ++j) {
        td_f weight = req[x];
        int cnt = 1;
        while (weight <= 2 * arr[x][j]) {
          if (arr[x][j] >= 0.9 * weight && arr[x][j] <= 1.1 * weight) {
            minim[x][j] = min(minim[x][j], cnt);
            maxim[x][j] = cnt;
          }
          weight += req[x];
          cnt++;
        }
      }
    }

    cout << "Case #" << test << ": ";
    if (n == 1) {
      int ans = 0;
      for (int j = (1); j <= ((p)); ++j) {
        if (minim[1][j] != inf)
          ans++;
      }
      cout << ans << "\n";
    } else {
      for (int get = (1); get <= ((p)); ++get)
        for (int j = (1); j <= ((p)); ++j)
          if (przeciecie(get, j)) {
            graph[get][j] = 1;
            // cout<<i<<" "<<j * p + 1<<endl;
            // cout<<minim[1][i]<<" "<<maxim[1][i]<<" "<<minim[2][j]<<"
            // "<<maxim[2][j]<<endl;
          }
      /* RI(i, 30) {
              RI(j, 30) {
                      cout<<graph[i][j]<<" ";
              }
              cout<<endl;
      } */
      cout << maxBPM(graph) << "\n";
    }
  }
  return 0;
}
