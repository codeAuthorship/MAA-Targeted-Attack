#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int mod = 1000000007;
const int INF = 1000000000;

ifstream fin;

const long long inf = 1e16 + 7;
const long long maxN = 1e3 + 5;

int n, q, u, v, t;
int horse[maxN], dist[maxN][maxN], speed[maxN];
long long pref[maxN];
long double dp[maxN];

int main() {

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Mucosolvan/A-small-practice.in");

  fin >> t;
  for (long long x = (1); x <= ((t)); ++x) {
    fin >> n >> q;
    for (long long i = (1); i <= ((n)); ++i)
      fin >> horse[i] >> speed[i];
    for (long long i = (1); i <= ((n)); ++i) {
      for (long long j = (1); j <= ((n)); ++j) {
        fin >> dist[i][j];
      }
    }
    pref[1] = 0;
    long long i;
    for (i = (2); i <= (n); ++i) {
      pref[i] = pref[i - 1] + dist[i - 1][i];
    }
    cout << "Case #" << x << ": ";
    for (long long _ = (0); _ <= ((q)-1); ++_) {
      fin >> u >> v;
      for (long long i = (1); i <= ((n)); ++i)
        dp[i] = (long double)inf;
      dp[1] = 0;
      for (long long i = (1); i <= ((n)); ++i) {
        for (long long j = (i + 1); j <= (n); ++j) {
          // cout<<i<<" "<<j<<" "<<dist<<endl;
          if (pref[j] - pref[i] > horse[i])
            break;
          dp[j] =
              min(dp[j], dp[i] + (pref[j] - pref[i]) / (long double)speed[i]);
        }
      }
      cout << fixed << setprecision(9) << dp[n];
    }
    cout << endl;
  }
  return 0;
}
