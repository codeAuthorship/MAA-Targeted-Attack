#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;

typedef long long LL;
typedef pair<int, int> ii;

void solve() {}

int main(void) {
  solve();
  int tc;
  cin >> tc;
  char str[1010];
  int k;

  for (int ct = 1; ct <= tc; ct++) {
    cin >> str;
    cin >> k;
    int ret = 0;
    int len = strlen(str);

    {
      int j = 0;
      for (; j < len;) {
        if (str[j] == '-') {
          if (j + k > len) {
            ret = -1;
            break;
          }
          for (int n = 0; n < k; n++) {
            if (str[n + j] == '+')
              str[n + j] = '-';
            else
              str[n + j] = '+';
          }
          ret++;

        }
        j++;
      }
    }

    printf("Case #%d: ", ct);

    if (ret == -1) {
      printf("IMPOSSIBLE\n");
    } else {
      printf("%d\n", ret);
    }
    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
