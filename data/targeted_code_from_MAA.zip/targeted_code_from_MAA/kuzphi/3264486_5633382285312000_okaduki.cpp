#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int mod = 1000000007;
ifstream fin;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}

template <class T> void maxi(T &x, T y) {
  if (x < y) {
    x = y;
  }
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

bool istidy(LL x) {
  int prv = 10;
  while (x > 0) {
    if (prv < x % 10)
      return false;
    prv = x % 10;
    x /= 10;
  }
  return true;
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_9_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/okaduki/A-small-practice.in");

  cin.tie(0);

  int T;
  fin >> T;
  {
    int t = (1);
    while (t < (T + 1)) {
      LL N;
      fin >> N;
      LL ans = 0;
      for (ans = N; ans > 0; --ans) {
        if (istidy(ans))
          break;
      }

      printf("Case #%d: %lld\n", t, ans);
      ++t;
    }
  }

  return 0;
}
