#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const double EPS = 1e-9;
const int MOD = 1000000007;

int solve(int x) {
  int r, c;
  cin >> r >> c;
  string str[30];
  for (int i = 0; i < r; i++) {
    cin >> str[i];
  }
  set<char> s;
  for (int i = 0; i < r; i++) {
    for (int get = 0; get < c; get++) {
      if (str[i][get] != '?' && s.find(str[i][get]) == s.end()) {
 
        int jl = get, jr = get, it = i, ib = i;
        while (jl - 1 >= 0 && str[i][jl - 1] == '?') {
          jl--;
        }
        while (jr + 1 < c && str[i][jr + 1] == '?') {
          jr++;
        }
        while (true) {
          if (it - 1 >= 0) {
            int check = true;
            for (int a = jl; a <= jr; a++) {
              if (str[it - 1][a] != '?') {
                check = false;
              }
            }
            if (check) {
              it--;
            } else {
              break;
            }
          } else {
            break;
          }
        }
        while (true) {
          if (ib + 1 < r) {
            bool check = true;
            for (int a = jl; a <= jr; a++) {
              if (str[ib + 1][a] != '?') {
                check = false;
              }
            }
            if (check) {
              ib++;
            } else {
              break;
            }
          } else {
            break;
          }
        }
        {
          int a = it;
          while (a <= ib) {
            int l;
            for (l = jl; l <= jr; l++) {
              str[a][l] = str[i][get];
            }
            a++;
          }
        }
        s.insert(str[i][get]);
      }
    }
  }
  printf("Case #%d:\n", x);
  for (int i = 0; i < r; i++) {
    printf("%s\n", str[i].c_str());
  }
  return 1;
}

int main() {

  int t;
  cin >> t;
  int i;
  for (i = 0; i < t; i++) {
    solve(i + 1);
  }
  return 0;
}
