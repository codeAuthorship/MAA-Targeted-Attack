#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

const int mod = 1000000007;

struct Rectangle {
  char ch;
  int sx;
  int sy;
  int ex;
  int ey;
  Rectangle() {}
  Rectangle(char a, int b, int c, int d, int e) {
    ch = a;
    sx = b;
    sy = c;
    ex = d;
    ey = e;
  }
};

Rectangle r[26 + 1];
char s[25 + 1][25 + 1];
int n, tc, T;

bool operator<(const Rectangle &a, const Rectangle &b) {
  return a.sx < b.sx || (a.sx == b.sx && a.sy < b.sy);
}

bool intersect(const Rectangle &a, const Rectangle &b) {
  return !(a.ex < b.sx || a.sx > b.ex || a.ey < b.sy || a.sy > b.ey) &&
         !(a.sx > b.sx && a.ex < b.ex && a.sy > b.sy && a.ey < b.ey);
}

bool intersect(const Rectangle &a, int p) {
  int i;
  for (i = T; i < 26; i++) {
    if ((i != p) && (intersect(a, r[i]) == true)) {
      return true;
    }
  }
  return false;
}

inline void ppcnezabwt(int &i) {
  i = 0;
  while (i < n) {
    printf("%s\n", s[i]);
    i++;
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_3_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/try/A-small-practice.in");

  int c, t, i, j, x, y;
  fin >> t;
  for (c = 0; c < t; c++) {
    memset(r, -1, sizeof(r));
    fin >> n >> tc;
    for (i = 0; i < n; i++) {
      fin >> s[i];
      for (j = 0; j < tc; j++) {
        if (isupper(s[i][j])) {
          T = (int)(s[i][j] - 'A');
          if ((r[T].sx == -1) && (r[T].ex == -1) && (r[T].sy == -1) &&
              (r[T].ey == -1)) {
            r[T].ch = s[i][j];
            r[T].sx = i;
            r[T].sy = j;
            r[T].ex = i;
            r[T].ey = j;
          } else {
            r[T].sx = min(r[T].sx, i);
            r[T].sy = min(r[T].sy, j);
            r[T].ex = max(r[T].ex, i);
            r[T].ey = max(r[T].ey, j);
          }
        }
      }
    }
    sort(r, r + 26);
    for (T = 0; T < 26; T++) {
      if ((r[T].sx != -1) && (r[T].sy != -1) && (r[T].ex != -1) &&
          (r[T].ey != -1)) {
        break;
      }
    }
    for (i = T; i < 26; i++) {
      while (
          (r[i].sx - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx - 1, r[i].sy, r[i].ex, r[i].ey),
                     i) == false)) {
        r[i].sx--;
      }
      while (
          (r[i].sy - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy - 1, r[i].ex, r[i].ey),
                     i) == false))
        r[i].sy--;

      while ((r[i].ex + 1 < n) &&
             (intersect(Rectangle(r[i].ch, r[i].sx + 1, r[i].sy, r[i].ex + 1,
                                  r[i].ey),
                        i) == false)) {
        r[i].ex++;
      }
      while (
          (r[i].ey + 1 < tc) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy, r[i].ex, r[i].ey + 1),
                     i) == 0)) {
        r[i].ey++;
      }
    }
    for (i = T; i < 26; i++) {
      for (x = r[i].sx; x <= r[i].ex; x++) {
        for (y = r[i].sy; y <= r[i].ey; y++) {
          s[x][y] = r[i].ch;
        }
      }
    }
    printf("Case #%d:\n", c + 1);
    ppcnezabwt(i);
  }
  return 0;
}
