#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
const int INF = 1000000000;
const double EPS = 1e-9;
const double eps = 1e-9;
const int MAXN = 1005;

const long long inf = 1000000000000000000LL;

vector<long long> ans;

void rec(long long value, long long d) {
  if (value >= inf) {
    return;
  }
  ans.push_back(value);
  for (long long b = d; b <= 9; ++b) {
    if (value < inf / 10LL) {
      rec(value * 10LL + b, b);
    }
  }
}

void solve(int T) {
  long long n;
  cin >> n;

  int index = upper_bound(ans.begin(), ans.end(), n) - ans.begin() - 1;
  printf("Case #%d: %lld\n", T, ans[index]);
}

int main() {

  for (int b = 1; b <= 9; ++b) {
    rec(b, b);
  }

  sort(ans.begin(), ans.end());
  cerr << "Res size: " << ans.size() << endl;

  int t;
  scanf("%d", &t);

  for (int b = 0; b < t; ++b) {
    solve(b + 1);
    cerr << b + 1 << ": " << clock() << endl;
  }

  return 0;
}
