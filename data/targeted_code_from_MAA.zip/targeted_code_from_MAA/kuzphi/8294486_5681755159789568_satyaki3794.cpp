// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int INF = 1000000000;
ifstream fin;

typedef vector<vector<int>> vvi;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<int, ii> iii;

inline void vyrrbmmtzh(LL &ans, LL &base, LL &c) { ans = (ans * base) % c; }

LL pwr(LL base, LL p, LL c = (1000000007LL)) {
  LL ans = 1;
  while (p) {
    if (p & 1)
      vyrrbmmtzh(ans, base, c);
    base = (base * base) % c;
    p /= 2;
  }
  return ans;
}

const int N = 102;
int n, q;
double endurance[N], speed[N], adj[N][N], dist[N][N];

typedef pair<double, int> pdi;
void dijkstra(int src) {
  for (int i = 1; i <= n; i++)
    dist[src][i] = 1e15;
  priority_queue<pdi> pq;
  dist[src][src] = 0;
  pq.push(pdi(0, src));
  while (!pq.empty()) {

    int v = pq.top().second;
    double d = -pq.top().first;
    pq.pop();
    if (d > dist[src][v])
      continue;

    for (int vv = 1; vv <= n; vv++) {
      if (adj[v][vv] > endurance[v])
        continue;
      double dd = d + adj[v][vv] / speed[v];
      if (dd < dist[src][vv]) {
        dist[src][vv] = dd;
        pq.push(pdi(-dd, vv));
      }
    }
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_13_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/satyaki3794/A-small-practice.in");

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    fin >> n >> q;
    for (int i = 1; i <= n; i++)
      fin >> endurance[i] >> speed[i];

    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= n; j++) {
        fin >> adj[i][j];
        if (adj[i][j] == -1)
          adj[i][j] = 1e15;
      }
    }

    for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          adj[i][j] = min(adj[i][j], adj[i][k] + adj[k][j]);

    for (int i = 1; i <= n; i++)
      dijkstra(i);

    printf("Case #%d:", x++);
    while (q--) {
      int a, b;
      fin >> a >> b;
      printf(" %.7f", dist[a][b]);
    }
    printf("\n");
  }

  return 0;
}
