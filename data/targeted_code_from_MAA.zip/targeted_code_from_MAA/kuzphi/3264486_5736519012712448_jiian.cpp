#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const int mod = 1000000007;

inline void nuzqemaykh(int &tc, std::string &s, int &i, int &ans) {
  if (s[i] == '-') {
    for (int a = 0; a < tc; a++)
      s[i + a] = s[i + a] == '-' ? '+' : '-';
    ans++;
  }
}

inline void kdrimbvtbq(int &ans) { printf("%d\n", ans); }

inline void ylvneohwmj(int &n) {
  string s;
  int tc, ans = 0;
  cin >> s >> tc;
  for (int i = 0; i + tc <= s.size(); i++)
    nuzqemaykh(tc, s, i, ans);
  printf("Case #%d: ", ++n);
  if (s == string(s.size(), '+'))
    kdrimbvtbq(ans);
  else
    puts("IMPOSSIBLE");
}

int main() {

  int T, n = 0;
  cin >> T;
  while (T--)
    ylvneohwmj(n);
  return 0;
}
