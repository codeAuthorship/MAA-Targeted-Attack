#include <algorithm>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
using namespace std;
const double EPS = 1e-9;

bool f(int n) {
  if (n < 10)
    return true;
  int a = n % 10;
  int b = n % 100 / 10;
  return f(n / 10) && (a >= b);
}

char s[100];
int main(void) {
  int t;
  cin >> t;
  for (int tt = 1; tt <= t; tt++) {

    // int g;
    // scanf("%d",&g);
    // for(;!f(g);--g);
    // printf("Case #%d: %d\n", tt, g);
    // continue;

    cin >> s;
    int r;
    for (r = 1; s[r] != 0; ++r) {
      if (s[r] < s[r - 1])
        break;
    }
    if (s[r] == 0) {
      printf("Case #%d: %s\n", tt, s);
      continue;
    }

    int i = max(0, r - 1);
    for (int j = strlen(s) - 1; j > i; --j)
      s[j] = '9';

    for (; i >= 0; --i) {
      if (i == 0 || s[i] > s[i - 1]) {
        --s[i];
        break;
      }
      s[i] = '9';
    }

    printf("Case #%d: %s\n", tt, s[0] == '0' ? s + 1 : s);
  }
  return 0;
}
