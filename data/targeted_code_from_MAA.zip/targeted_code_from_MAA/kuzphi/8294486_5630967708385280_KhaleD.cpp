#include <algorithm>
#include <bits/stdc++.h>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
ofstream fout;

const double EPS = 1e-9;
typedef long double ld;
typedef double td_d;
typedef unsigned long long ull;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;

const int N = 100002;
int tc, d, n, r[N], speed[N];

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out");

  scanf("%d", &tc);
  for (int ans = (1); ans <= (int)(tc); ++ans) {
    scanf("%d%d", &d, &n);
    for (int i = (1); i <= (int)(n); ++i)
      scanf("%d%d", &r[i], &speed[i]);

    td_d maxT = 0;
    int i;
    for (i = (1); i <= (int)(n); ++i)
      maxT = max(maxT, 1.0 * (d - r[i]) / speed[i]);

    fout << "Case #" << ans << ": " << fixed << setprecision(6) << d / maxT
         << "\n";
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
