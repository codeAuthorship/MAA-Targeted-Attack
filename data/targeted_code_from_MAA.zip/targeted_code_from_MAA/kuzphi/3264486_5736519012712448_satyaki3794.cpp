// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
const int mod = 1000000007;
const double EPS = 1e-9;
const int MOD = 1000000007;

int main() {

  cin.tie(0);

  int t, x = 1;
  cin >> t;
  while (t--) {

    string str;
    cin >> str;

    int k;
    cin >> k;

    int n = (int)str.length(), ans = 0;
    for (int i = 0; i + k - 1 < n; i++)
      if (str[i] == '-') {
        ans++;
        for (int j = i; j < i + k; j++)
          if (str[j] == '-')
            str[j] = '+';
          else
            str[j] = '-';
      }

    for (int i = 0; i < n; i++)
      if (str[i] == '-')
        ans = -1;

    if (ans == -1)
      printf("Case #%d: IMPOSSIBLE\n", x++);
    else
      printf("Case #%d: %d\n", x++, ans);
  }

  return 0;
}
