
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const int MAXN = 1005;
const double EPS = 1e-9;
const int INF = 1000000000;

void work() {
  string s;
  int b;
  cin >> s >> b;
  int len = (int)s.size();
  int ans = 0;
  for (int t = 0; t <= len - b; ++t) {
    if (s[t] == '-') {
      ans++;
      for (int j = t; j < t + b; ++j) {
        s[j] = (s[j] == '-' ? '+' : '-');
      }
    }
  }
  {
    int t = len - b + 1;
    while (t < len) {
      if (s[t] == '-') {
        cout << "IMPOSSIBLE" << endl;
        return;
      }
      ++t;
    }
  }
  cout << ans << endl;
}

int main() {
  ios::sync_with_stdio(1);

  int q;
  scanf("%d ", &q);
  for (int t = 1; t <= q; ++t) {
    printf("Case #%d: ", t);
    work();
  }
  return 0;
}
