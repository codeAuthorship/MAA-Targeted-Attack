#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void tfggeqyqtl(priority_queue<int> &k) {
  int at = k.top();
  if (at == 0)
    printf("0 0\n");
  else {
    int first = at / 2;
    printf("%d %d\n", at - first, first);
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_7_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/bennikartefla/A-small-practice.in");

  int n;
  fin >> n;
  int i;
  {
    i = (0);
    while (i < (n)) {
      priority_queue<int> k;
      int m, q;
      fin >> m >> q;
      printf("Case #%d: ", i + 1);
      k.push(m - 1);
      int a;
      for (a = (0); a < (q - 1); a++) {
        if (k.empty())
          break;
        else {
          int at = k.top();
          k.pop();
          if (at == 0)
            continue;
          int want = at / 2;
          int first = want;
          if (first != 0)
            k.push(first - 1);
          int second = at - want;
          k.push(second - 1);
        }
      }
      if (k.empty())
        printf("0 0\n");
      else
        tfggeqyqtl(k);
      i++;
    }
  }
  return 0;
}
