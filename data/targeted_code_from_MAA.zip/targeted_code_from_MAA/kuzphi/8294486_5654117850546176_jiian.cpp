#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
const int INF = 1000000000;
const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;
using LL = long long;

int a[6];
string s = "ROYGBV";

inline void ivjwticoem(int &i) {
  cin >> a[i];
  i++;
}

inline void oeuiatiepi() {
  int i = 0;
  while (i < 6)
    ivjwticoem(i);
}

inline void jjbaxrmmnd(int &mx, int &c, int &i) { mx = a[i], c = i; }

int main() {

  int T, cas = 0;
  cin >> T;
  while (T--) {
    int n;
    cin >> n;
    oeuiatiepi();
    string ans = "";
    int flag = 0;
    while (ans.size() < n) {
      int mx = 0, c = 0;
      {
        int i = 0;
        while (i < 6) {
          if (s[i] == ans.back()) {
            i++;
            continue;
          }
          if (a[i] == mx && ans.size() && s[i] == ans[0])
            mx = a[i], c = i;
          if (a[i] > mx)
            jjbaxrmmnd(mx, c, i);
          i++;
        }
      }
      if (a[c] == 0) {
        flag = 1;
        break;
      } else if (s[c] == ans.back()) {
        flag = 1;
        break;
      }
      ans.push_back(s[c]);
      a[c]--;
    }
    // cout << ans << endl;
    if (ans.size() > 1 && ans[0] == ans.back())
      flag = 1;
    printf("Case #%d: ", ++cas);
    if (flag)
      puts("IMPOSSIBLE");
    else
      printf("%s\n", ans.c_str());
  }
  return 0;
}
