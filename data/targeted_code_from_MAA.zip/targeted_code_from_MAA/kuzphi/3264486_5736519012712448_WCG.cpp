#include <algorithm>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const int MOD = 1000000007;

inline void kuocdnmtpd(int &t) {
  string s;
  int k, res = 0;
  cin >> s >> k;
  for (int i = 0; i + k <= s.size(); ++i) {
    if (s[i] == '-') {
      for (int j = 0; j < k; ++j)
        s[i + j] = (s[i + j] == '-') ? '+' : '-';
      res++;
    }
  }
  for (int i = 0; i < s.size(); ++i)
    if (s[i] == '-')
      res = -1;

  printf("Case #%d: ", t);
  if (res == -1)
    printf("IMPOSSIBLE\n");
  else
    printf("%d\n", res);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_6_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/WCG/A-small-practice.in",
          "r", stdin);

  int c;

  scanf("%d ", &c);

  for (int t = 1; t <= c; ++t)
    kuocdnmtpd(t);

  return 0;
}
