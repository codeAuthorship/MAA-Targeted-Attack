#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;
const double eps = 1e-9;

int main() {

  int T, d = 0;
  scanf("%d ", &T);
  for (; T--;) {
    string s;
    cin >> s;
    reverse(s.begin(), s.end());
    int n = s.size();
    for (int i = 1; i < n; i++) {
      if (s[i] <= s[i - 1])
        continue;
      for (int b = 0; b < i; b++)
        s[b] = '9';
      int b = i;
      while (s[b] == '0')
        s[b] = '9', b++;
      s[b]--;
    }
    for (; s.back() == '0';) {
      s.pop_back();
    }
    reverse(s.begin(), s.end());
    printf("Case #%d: %s\n", ++d, s.c_str());
  }
  return 0;
}
