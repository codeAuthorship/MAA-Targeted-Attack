#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;

int n;
double m, s[2000], d[2000];
int main(void) {
  int t;
  cin >> t;
  for (int tt = 1; tt <= t; tt++) {
    cin >> m >> n;
    double lo = 0;
    for (int i = 0; i < n; ++i) {
      cin >> d[i] >> s[i];
      lo = max(lo, (m - d[i]) / s[i]);
    }

    // printf("%lf\n", lo);
    printf("Case #%d: %.8lf\n", tt, m / lo);
  }
  return 0;
}
