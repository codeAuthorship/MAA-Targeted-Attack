#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MAXN = 1005;
ifstream fin;

const double EPS = 1e-9;
typedef set<int> si;
typedef unsigned long long ull;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> ii;
typedef pair<ii, int> para;
const int inf = 1e9 + 7;
const int maxN = 100 + 5;

int t, v, ans;
int can[maxN][maxN];
string s[maxN];

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_15_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Mucosolvan/A-small-practice.in");

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    fin >> ans >> v;
    for (int i = (0); i <= ((ans)-1); ++i)
      fin >> s[i];

    int pom = -1;
    for (int i = (0); i <= ((ans)-1); ++i) {
      for (int j = (0); j <= ((v)-1); ++j) {
        if (s[i][j] != '?' && (pom == i || pom == -1)) {
          for (int r = (0); r <= ((ans)-1); ++r) {
            for (int m = (0); m <= ((v)-1); ++m) {
              if (s[r][m] == '?' && r <= i && m <= j)
                s[r][m] = s[i][j];
            }
          }
          pom = i;
        }
        // cout<<i<<" "<<j<<" "<<pom<<" "<<s[i][j]<<endl;
        if (pom != -1 && i > pom)
          break;
      }
      if (pom != -1 && i > pom)
        break;
    }

    for (int i = (0); i <= ((ans)-1); ++i) {
      int pos = -1;
      for (int j = (0); j <= ((v)-1); ++j) {
        if (s[i][j] != '?') {
          pos = j;
          break;
        }
      }

      if (pos != -1) {
        char first = s[i][pos];
        for (int j = (0); j <= ((v)-1); ++j) {
          if (s[i][j] == '?')
            s[i][j] = first;
          else
            first = s[i][j];
        }
      } else {
        for (int j = (0); j <= ((v)-1); ++j)
          s[i][j] = s[i - 1][j];
      }
    }

    printf("Case #%d: \n", x);
    for (int i = (0); i <= ((ans)-1); ++i) {
      printf("%s\n", s[i].c_str());
    }
  }
  return 0;
}
