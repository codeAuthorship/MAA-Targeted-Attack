#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const int INF = 1000000000;
const int mod = 1000000007;

void readData() {}

const int maxN = 1100;
double d;
long long n;
double s[maxN], k[maxN];

inline void xerhonhgco(double &y, double &m) { y = m; }

inline void rnzltllkra(double &y, double &m) { xerhonhgco(y, m); }

inline void wswhwczqpq() {
  int i = 0;
  while (i < n) {
    cin >> k[i] >> s[i];
    ++i;
  }
}

void solve(int test) {
  if (test == 29) {
    int f = 0;
  }
  cin >> d >> n;
  wswhwczqpq();

  double y = 0.0, r = 1e18;
  for (int t = 0; t < 400; ++t) {
    double m = (y + r) / 2.0;
    bool ok = true;

    double p = d / m;
    for (int j = 0; j < n; ++j) {
      if (k[j] + s[j] * p < d) {
        ok = false;
        break;
      }
    }

    if (ok)
      rnzltllkra(y, m);
    else {
      r = m;
    }
  }

  printf("Case #%d: %.10lf\n", test, (y + r) / 2.0);
}

int main(int argc, char *argv[]) {
  int ret_val = 0;
  int left_bound, right_bound;
  int t;
  cin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else {
      readData();
    }
    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
