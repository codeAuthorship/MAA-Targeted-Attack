#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double eps = 1e-9;
ifstream fin;

const int MOD = 1000000007;
typedef unsigned long long ull;
typedef vector<vector<int>> vvi;
typedef vector<int> VI;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> ii;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int d, n, start[maxN], p[maxN], t;

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Mucosolvan/A-small-practice.in");

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    fin >> d >> n;
    long double c = 0;
    for (int b = (0); b <= ((n)-1); ++b) {
      fin >> start[b] >> p[b];
      long double get = (long double)(d - start[b]) / (long double)p[b];
      c = max(c, get);
    }

    printf("Case #%d: ", x);
    cout << fixed << setprecision(12) << d / c << endl;
  }
  return 0;
}
