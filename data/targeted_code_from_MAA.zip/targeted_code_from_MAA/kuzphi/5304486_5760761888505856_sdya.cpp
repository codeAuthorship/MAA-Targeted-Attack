#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;

const double EPS = 1e-9;

void get() {}

const int maxN = 50;
string s[maxN];
int n, m;

inline void btdpavkkmp(int &i, int &j) { s[i][j] = s[i][j - 1]; }

void solve(int test) {
  cin >> n >> m;
  int i;
  for (i = 0; i < n; ++i) {
    cin >> s[i];
  }

  for (int i = 0; i < n; ++i) {
    int j;
    for (j = 1; j < m; ++j) {
      if (s[i][j] == '?')
        btdpavkkmp(i, j);
    }
    for (int j = m - 2; j >= 0; --j) {
      if (s[i][j] == '?') {
        s[i][j] = s[i][j + 1];
      }
    }
  }

  for (int j = 0; j < m; ++j) {
    for (int i = 1; i < n; ++i) {
      if (s[i][j] == '?') {
        s[i][j] = s[i - 1][j];
      }
    }
    for (int i = n - 2; i >= 0; --i) {
      if (s[i][j] == '?') {
        s[i][j] = s[i + 1][j];
      }
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      if (s[i][j] == '?') {
        cerr << "BAD" << endl;
      }
    }
  }

  printf("Case #%d:\n", test);
  for (int i = 0; i < n; ++i) {
    printf("%s\n", s[i].c_str());
  }
}

int main(int argc, char *T[]) {

  int ret_val = 0;
  int left_bound, right_bound;
  int t;
  cin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else {
      get();
    }
    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
