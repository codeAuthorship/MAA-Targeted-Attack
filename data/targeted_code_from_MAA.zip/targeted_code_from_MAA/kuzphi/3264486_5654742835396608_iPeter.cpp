#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const int INF = 1000000000;
const double EPS = 1e-9;
const int MOD = 1000000007;

int main(void) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_12_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/iPeter/A-small-practice.in", "r", stdin);

  int t;
  cin >> t;
  for (int tt = 1; tt <= t; tt++) {

    int n, ans;
    priority_queue<int> q;
    cin >> n >> ans;
    q.push(n);
    while (--ans) {
      int x = q.top();
      q.pop();
      q.push(x / 2);
      q.push((x - 1) / 2);
    }

    int v = q.top();
    printf("Case #%d: %d %d\n", tt, v / 2, (v - 1) / 2);
  }
  return 0;
}

/*
12
0 xoooooooooooox
1 xoooooxoooooox 6 5
2 xoooooxooxooox 3 2
3 xooxooxooxooox 2 2
4 xooxooxooxoxox 1 1
5 xxoxooxooxoxox 1 0
6 xxoxxoxooxoxox 1 0
7 xxoxxoxxoxoxox 1 0
                 0 0

x------------x 12
x-----1------x 6
x-----1--2---x 5
x--3--1--2---x 3
x--3--1--2-4-x 2
x5-3--1--2-4-x 2
*/
