#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;
const int MAXN = 1005;
const double EPS = 1e-9;

int main() {
  int j;

  cin >> j;

  {
    int t = 1;
    while (t <= j) {
      int p, get, o, y, g, b, v;
      cin >> p >> get >> o >> y >> g >> b >> v;
      string s = "";

      if ((get > p / 2) || (y > p / 2) || (b > p / 2)) {
        s = "IMPOSSIBLE";
      } else {
        vector<pair<int, string>> v;
        v.push_back({get, "R"});
        v.push_back({y, "Y"});
        v.push_back({b, "B"});
        sort(v.begin(), v.end());
        reverse(v.begin(), v.end());
        while (v[0].first > 0) {
          s += v[0].second;
          v[0].first--;
          if (v[1].first > v[2].first) {
            s += v[1].second;
            v[1].first--;
          } else {
            s += v[2].second;
            v[2].first--;
          }
        }
        while ((v[1].first > 0) || (v[2].first > 0)) {
          if (v[1].first > v[2].first) {
            s += v[1].second;
            v[1].first--;
          } else {
            s += v[2].second;
            v[2].first--;
          }
        }
      }
      printf("Case #%d: %s\n", t, s.c_str());
      ++t;
    }
  }

  return 0;
}
