#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int mod = 1000000007;
const double EPS = 1e-9;
const int INF = 1000000000;
const double eps = 1e-9;

ifstream fin("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/A-small-practice.in");
ofstream r("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline void statbqqkta(double &ans, long long &dest) {
  long long cur, speed;
  fin >> cur >> speed;
  ans = max(ans, 1.0 * (dest - cur) / speed);
}

void solve() {
  long long dest, nh;
  fin >> dest >> nh;
  double ans = 0;
  {
    int i = 0;
    while (i < nh) {
      statbqqkta(ans, dest);
      i++;
    }
  }
  r << fixed << setprecision(12);
  r << dest / ans << '\n';
}

int main() {

  cin.tie(0);
  int get;
  fin >> get;
  for (int i = 0; i < get; i++)
    r << "Case #" << i + 1 << ": ", solve();
  return 0;
}
