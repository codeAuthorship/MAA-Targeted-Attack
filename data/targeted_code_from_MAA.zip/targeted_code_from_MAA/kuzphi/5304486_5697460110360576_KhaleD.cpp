#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const int MAXN = 1005;
typedef long double ld;
typedef long long LL;
typedef pair<int, int> PII;
typedef pair<LL, LL> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 52;
int t, a[N][N], needed[N], id[N][N], uniq;
PII interval[N][N], intervalByID[N * N + 10];

int n; // number of nodes
int cap[1002 /* maximum number of nodes*/]
       [1002 /* maximum number of nodes*/]; // capacity
int path[1002 /* maximum number of nodes*/];
int pathLength;
bool visited[1002 /* maximum number of nodes*/];

bool intersect(PII a, PII b) {
  return (a.first >= b.first and a.first <= b.second) or
         (a.second >= b.first and a.second <= b.second);
}

// Implement in anyway that get a path: DFS, BFS, Dijkstra...whatever
inline bool nkidvfwaxo(int &curLen, int &maxcap, int &nkidv) {
  pathLength = curLen + 1;
  nkidv = maxcap;
  return true;
  return false;
}

int getPath(int StartNode, int TargetNode, int curLen, int maxcap,
            PII currentInterval) {
  path[curLen] = StartNode;
  if (StartNode == TargetNode) {
    int nkidv;
    if (nkidvfwaxo(curLen, maxcap, nkidv)) {
      return nkidv;
    }
  }

  int ret = 0;
  visited[StartNode] = true;

  for (int i = 0; i <= n + 1; i++) {
    if (visited[i] || cap[StartNode][i] <= 0)
      continue;
    PII pos = intervalByID[i];
    if (i and i <= n) {
      if (!intersect(interval[pos.first][pos.second], currentInterval))
        continue;
    }

    ret = getPath(i, TargetNode, curLen + 1, min(maxcap, cap[StartNode][i]),
                  make_pair(max(currentInterval.first,
                                interval[pos.first][pos.second].first),
                            min(currentInterval.second,
                                interval[pos.first][pos.second].second)));

    if (ret > 0)
      break; // We found a path with flow
  }
  return ret;
}

int maxFlow(int src, int sink, int numberOfNodes) {
  int total_flow = 0;
  n = numberOfNodes;

  for (; true;) {
    memset(visited, 0, sizeof visited);
    int newflow =
        getPath(src, sink, 0, 1000000000, make_pair(-1000000000, 1000000000));

    if (!newflow)
      break; // once no more paths, STOP

    for (int i = (1); i <= (int)(pathLength - 1); ++i) {
      int m = path[i - 1], n = path[i];

      cap[m][n] -= newflow;
      cap[n][m] += newflow; // Add reversed edge
    }
    total_flow += newflow;
  }

  return total_flow;
}

bool check(int i, int j) {
  int mx = a[i][j] / needed[i] * needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx and a[i][j] - 1e-6 <= 1.1 * mx)
    return true;
  mx = a[i][j] / needed[i] * needed[i] - needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx)
    if (a[i][j] - 1e-6 <= 1.1 * mx)
      return true;
  mx = a[i][j] / needed[i] * needed[i] + needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx and a[i][j] - 1e-6 <= 1.1 * mx)
    return true;
  return false;
}

inline void riwfzmhscn(int &j, int &i, int &p) {
  if (intersect(interval[i][j], interval[i + 1][p]))
    cap[id[i][j]][id[i + 1][p]] = 1;
}

int main() {

  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    int n, m;
    cin >> n >> m;
    for (int i = (1); i <= (int)(n); ++i)
      cin >> needed[i];
    for (int i = (1); i <= (int)(n); ++i)
      for (int j = (1); j <= (int)(m); ++j) {
        cin >> a[i][j];
        interval[i][j] = make_pair(ceil(a[i][j] / 1.1 / needed[i]),
                                   a[i][j] / 0.9 / needed[i]);
        id[i][j] = ++uniq;
        intervalByID[id[i][j]] = make_pair(i, j);
      }
    intervalByID[0] = make_pair(-1000000000, 1000000000);

    for (int i = (1); i <= (int)(n - 1); ++i)
      for (int j = (1); j <= (int)(m); ++j)
        if (check(i, j))
          for (int p = (1); p <= (int)(m); ++p)
            if (check(i + 1, p))
              riwfzmhscn(j, i, p);

    for (int j = (1); j <= (int)(m); ++j) {
      if (check(1, j))
        cap[0][id[1][j]] = 1;
      if (check(n, j))
        cap[id[n][j]][n * m + 1] = 1;
    }
    printf("Case #%d: %d\n", test, maxFlow(0, n * m + 1, n * m));

    uniq = 0;
    memset(cap, 0, sizeof cap);
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
