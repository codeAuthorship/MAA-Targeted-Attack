#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
ifstream d;

int tc;

int main() {
  ios::sync_with_stdio(false);

  d.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_1_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/4yn/A-small-practice.in");

  d >> tc;
  for (int t = 1; t <= tc; t++) {
    int n, q;
    d >> n >> q;
    int e[109], s[109];
    for (int i = 1; i <= n; i++) {
      d >> e[i] >> s[i];
    }
    int adj[109][109];
    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= n; j++) {
        d >> adj[i][j];
      }
    }
    int dist[109];
 
    {
      int i = 1;
      while (i < n) {
        dist[i] = adj[i][i + 1];
        i++;
      }
    }
    printf("Case #%d: ", t);
    {
      int nq = 0;
      for (; nq < q;) {
        int u, v;
        d >> u >> v;
        double time_taken[109];
        for (int i = 1; i <= n; i++)
          time_taken[i] = -1;

        time_taken[1] = 0;
        for (int i = 1; i < n; i++) {
    
          int dist_left = e[i];
          int speed = s[i];
          double cur_time = time_taken[i];
          for (int j = i + 1; j <= n; j++) {
 
            dist_left -= dist[j - 1];
            if (dist_left < 0)
              break;
            cur_time += (dist[j - 1] + 0.0) / s[i];
 
            if (time_taken[j] < 0) {
              time_taken[j] = cur_time;
            } else
              time_taken[j] = min(time_taken[j], cur_time);
          }
        }
        printf("%.7f\n", time_taken[v]);
        nq++;
      }
    }
  }
  return 0;
}
