#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const double eps = 1e-9;
const int mod = 1000000007;

typedef set<int> si;
typedef long double LD;
typedef vector<vector<int>> vvi;
typedef pair<int, int> PII;
typedef vector<int> VI;
typedef vector<PII> vii;
typedef long long LL;
const long double INF = 1000000000000;
const long double pi = acos(-1);
typedef pair<long double, int> di;

int mxdist[120];
int conspeed[120];
long double matrix[120][120];
long double matrix2[120][120];

void fill(int N) {
  bool vis[120];
  memset(vis, 0, sizeof(vis));
  vis[N] = 1;
  priority_queue<pair<long double, int>, vector<di>, greater<di>> q;
  q.push(pair<long double, int>(0, N));
  for (; !q.empty();) {
    int cur = q.top().second;
    LD range = q.top().first;
    q.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix[cur][i] != -1 && i != cur && !vis[i]) {
        LD thedist = matrix[cur][i];
        range += thedist;
        if (range > mxdist[N]) {
          range -= thedist;
          continue;
        }
        matrix2[N][i] = min(range / conspeed[N], matrix2[N][i]);
        q.push(pair<long double, int>(range, i));
        range -= thedist;
      }
    }
  }
}

long double query(int start, int end) {
  priority_queue<di, vector<di>, greater<di>> pq;
  pq.push(di(0, start));
  long double dist[150];
  bool vis[150];
  for (int i = (0); i < (150); i++)
    dist[i] = INF;
  memset(vis, 0, sizeof(vis));
  dist[start] = 0;
  while (!pq.empty()) {
    di cur = pq.top();
    pq.pop();
    for (int i = (0); i < (120); i++) {
      if (matrix2[cur.second][i] != -1) {
        LD ne = min(dist[i], cur.first + matrix2[cur.second][i]);
        if (ne >= dist[i])
          continue;
        dist[i] = ne;
        pq.push(di(dist[i], i));
      }
    }
  }
  return dist[end];
}

inline void flvzoaqzrd(int &i) {
  int dist, speed;
  cin >> dist >> speed;
  mxdist[i] = dist;
  conspeed[i] = speed;
}

int main() {

  int t;
  cin >> t;
  for (int ans = (0); ans < (t); ans++) {
    int n, q;
    memset(mxdist, 0, sizeof(mxdist));
    memset(conspeed, 0, sizeof(conspeed));
    for (int i = (0); i < (120); i++)
      for (int a = (0); a < (120); a++) {
        matrix[i][a] = -1;
      }
    for (int i = (0); i < (120); i++)
      for (int a = (0); a < (120); a++)
        matrix2[i][a] = INF;
    cin >> n >> q;
    for (int i = (0); i < (n); i++)
      flvzoaqzrd(i);
    for (int i = (0); i < (n); i++)
      for (int a = (0); a < (n); a++)
        cin >> matrix[i][a];
    for (int i = (0); i < (n); i++)
      fill(i);
    for (int i = (0); i < (120); i++)
      for (int a = (0); a < (120); a++)
        if (matrix2[i][a] == INF)
          matrix2[i][a] = -1;
    vector<PII> all(q);
    for (int i = (0); i < (q); i++)
      cin >> all[i].first >> all[i].second;
    printf("Case #%d: ", ans + 1);
    for (int i = (0); i < (q); i++) {
      cout << setprecision(9) << fixed
           << query(all[i].first - 1, all[i].second - 1) << " ";
    }
    printf("\n");
  }
  return 0;
}
