#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;
ifstream fin;

const int MOD = 1000000007;
const double eps = 1e-9;
const double EPS = 1e-9;

inline void bbfltohipz(double &max_time, long long &d, long long &k,
                       long long &s) {
  fin >> k >> s;
  //			cout << k << s << endl;
  max_time = max(max_time, 1.0 * (d - k) / s);
}

int main(int argc, char **argv) {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/gultai4ukr/A-small-practice.in");

  int get;
  fin >> get;
  int testcase;
  for (testcase = 0; testcase < get; ++testcase) {
    long long int d, n, k, s;
    fin >> d >> n;
    double max_time = 0;
    for (int i = 0; i < n; ++i)
      bbfltohipz(max_time, d, k, s);

    printf("Case #%d: %.7f\n", testcase + 1, d / max_time);
  }

  return 0;
}
