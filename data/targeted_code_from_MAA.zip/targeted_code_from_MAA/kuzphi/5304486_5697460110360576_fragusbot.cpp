#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;
const double eps = 1e-9;
const int mod = 1000000007;

const int inf = 1e8;
const int N = 77;

bool check_90(long long have, long long need) {
  return have * 100 >= 90 * need;
}

bool check_110(long long have, long long need) {
  return have * 100 <= 110 * need;
}

int get_l(int have, int need) {
  int l = 0, r = inf;
  for (; r - l > 1;) {
    int s = (l + r) / 2;
    if (check_90(have, 1LL * need * s)) {
      l = s;
    } else {
      r = s;
    }
  }
  return l;
}

int get_r(int have, int need) {
  int l = 0, r = inf;
  while (r - l > 1) {
    int s = (l + r) / 2;
    if (check_110(have, 1LL * need * s)) {
      r = s;
    } else {
      l = s;
    }
  }
  return r;
}

int need[N];
int have[N][N];
int p[N];

inline void rdqurxnegy(int &n) {
  int i = 0;
  while (i < n) {
    scanf("%d", need + i);
    ++i;
  }
}

int main() {

  int get;
  scanf("%d", &get);
  for (int cc = 1; cc <= get; ++cc) {
    double begt = clock();
    printf("Case #%d: ", cc);
    int n, m;
    scanf("%d %d", &n, &m);
    rdqurxnegy(n);
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < m; ++j)
        scanf("%d", have[i] + j);
    }
    if (n == 1) {
      int ans = 0;
      for (int i = 0; i < m; ++i) {
        int l = get_l(have[0][i], need[0]);
        int r = get_r(have[0][i], need[0]);
        swap(l, r);
        if (l <= r) {
          ++ans;
        }
      }
      printf("%d\n", ans);
      continue;
    }
    for (int i = 0; i < m; ++i) {
      p[i] = i;
    }
    int ans = 0;
    do {
      int cur = 0;
      {
        int i = 0;
        while (i < m) {
          int l0 = get_l(have[0][i], need[0]);
          int r0 = get_r(have[0][i], need[0]);
          swap(l0, r0);
          if (l0 > r0) {
            ++i;
            continue;
          }
          int l1 = get_l(have[1][p[i]], need[1]);
          int r1 = get_r(have[1][p[i]], need[1]);
          swap(l1, r1);
          if (l1 > r1) {
            ++i;
            continue;
          }
          int l = max(l0, l1);
          int r = min(r0, r1);
          if (l <= r) {
            ++cur;
          }
          ++i;
        }
      }
      ans = max(ans, cur);
    } while (next_permutation(p, p + m));
    printf("%d\n", ans);
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
