#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
using namespace std;
const int INF = 1000000000;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

int main() {

  int ret_val = 0;
  cin.tie(0);

  int T;
  cin >> T;
  for (int r = (1); r < (T + 1); ++r) {
    int H, W;
    cin >> H >> W;
    VS vs(H);
    for (int y = (0); y < (H); ++y)
      cin >> vs[y];

    set<char> memo;
    {
      int y = (0);
      while (y < (H)) {
        for (int x = (0); x < (W); ++x) {
          if (vs[y][x] != '?' && !memo.count(vs[y][x])) {
            memo.insert(vs[y][x]);

            int lx, rx, ty, by;
            for (lx = x - 1; lx >= 0; --lx)
              if (vs[y][lx] != '?')
                break;
            ++lx;
            for (rx = x + 1; rx < W; ++rx)
              if (vs[y][rx] != '?')
                break;

            for (ty = y - 1; ty >= 0; --ty) {
              bool ok = true;
              for (int xx = lx; xx < rx; ++xx) {
                if (vs[ty][xx] != '?')
                  ok = false;
              }
              if (!ok)
                break;
            }
            ++ty;
            for (by = y + 1; by < H; ++by) {
              int ok = 1;
              for (int xx = lx; xx < rx; ++xx) {
                if (vs[by][xx] != '?')
                  ok = false;
              }
              if (!ok)
                break;
            }

            for (int yy = (ty); yy < (by); ++yy) {
              int xx = (lx);
              while (xx < (rx)) {
                vs[yy][xx] = vs[y][x];
                ++xx;
              }
            }
          }
        }
        ++y;
      }
    }
    printf("Case #%d:\n", r);
    {
      int y = (0);
      while (y < (H)) {
        printf("%s\n", vs[y].c_str());
        ++y;
      }
    }
  }
  return ret_val;
}
