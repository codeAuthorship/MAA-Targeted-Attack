#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
ifstream fin;

const int INF = 1000000000;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll do_llbiz_fct(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;) {
    a = b;
    b = t;
  }
  return b;
}

ll fast_exp(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool do__Boceo_fct(int i, ll mask) { return (mask >> i) & 1; }

int solve(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (do__Boceo_fct(i, mask))
      ++ans;
  return ans;
}

int get(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (do__Boceo_fct(i++, mask))
      return i - 1;
  return ret_val;
}

inline void umqcztdene(int &j) {
  ll n, k;
  fin >> n >> k;
  ll s = 0, i = -1;
  while (s < k)
    ++i, s += 1ll << i;
  ll C = 1ll << i;
  ll left = n - s + C;
  ll pos = k - s + C;
  ll base = left / (s - C + 1);
  ll high = left % (s - C + 1);
  if (pos <= high)
    base += 1;
  printf("Case #%d: %lld %lld\n", j, base / 2, (base - 1) / 2);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/ibrahim5253/A-small-practice.in");

  int ret_val = 0;

  int t;
  fin >> t;
  for (int j = 1; j <= t; ++j)
    umqcztdene(j);
  return ret_val;
}
