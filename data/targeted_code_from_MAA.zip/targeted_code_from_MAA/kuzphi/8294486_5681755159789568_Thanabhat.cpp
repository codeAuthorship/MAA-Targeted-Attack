#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int mod = 1000000007;

const int INF = 1000000000;
const int MAXN = 1005;
const double EPS = 1e-9;

inline void eroivrdcgz(long double &sss, long double &ans, long double dp[105],
                       int &j) {
  sss = ans + dp[j + 1];
 
}

inline void nhhnfhsyfr(long long d[105], int &i) { cin >> d[i]; }

int solve(int cc) {
  long long n, q, e[105], s[105], d[105], temp;
  cin >> n >> q;
  for (int i = 0; i < n; i++)
    cin >> e[i] >> s[i];

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (j == i + 1) {
        nhhnfhsyfr(d, i);
      } else {
        cin >> temp;
      }
    }
  }
  cin >> temp >> temp;
 

  long double dp[105];
  for (int i = 0; i < n; i++) {
    dp[i] = 1e11;
  }
  dp[n - 1] = 0;
  for (int i = n - 2; i >= 0; i--) {
    long double sss = 0;
    long long ee = e[i];
    long double ans = 0;
    for (int j = i; j < n - 1; j++) {
      ee -= d[j];
      if (ee < 0) {
        break;
      }
      ans += (1.0 * d[j]) / s[i];
 
      if (j == i || ans + dp[j + 1] < sss) {
        eroivrdcgz(sss, ans, dp, j);
      }
    }
    dp[i] = sss;
 
  }
  cout << "Case #" << cc << ": " << fixed << dp[0] << endl;
  return 1;
}

int main() {

  int get;
  cin >> get;
  cout.precision(7);
  for (int i = 1; i <= get; i++) {
    solve(i);
  }
  return 0;
}
