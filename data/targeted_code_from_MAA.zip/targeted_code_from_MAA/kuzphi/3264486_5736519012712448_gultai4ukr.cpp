#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;

int main(int argc, char **T) {

  int t;
  scanf("%d ", &t);
  for (int testcase = 0; testcase < t; ++testcase) {
    char s[1000];
    int k;
    cin >> s >> k;
    int n = strlen(s);

    vector<bool> v;
    for (int solve = 0; solve < n; ++solve) {
      v.push_back(s[solve] == '+');
    }

    int cnt = 0;
    for (int solve = 0; solve < n - k + 1; ++solve) {
      if (!v[solve]) {
        int j;
        for (j = solve; j < solve + k; ++j)
          v[j] = !v[j];

        cnt++;
      }

      //			FORi(j,0,n){
      //				cout << v[j];
      //			}
      //			cout << endl;
    }

    for (int solve = n - k; solve < n; ++solve) {
      if (!v[solve])
        cnt = -1;
    }

    printf("Case #%d: ", testcase + 1);
    if (cnt == -1) {
      printf("IMPOSSIBLE\n");
    } else {
      printf("%d\n", cnt);
    }
  }

  return 0;
}
