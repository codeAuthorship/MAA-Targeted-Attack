#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
const int mod = 1000000007;
const long double PI = 3.1415926535897932384626433832795;

ofstream y("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

const int SZ = 105;

int n, q;
long long cost[SZ];
long long hspeed[SZ], hrange[SZ];

inline void uukbjhnhqm(int &i, double dprange[105], double &get, double dp[105],
                       int &j) {
  if (dprange[j] >= cost[i - 1])
    dp[j] += 1.0 * cost[i - 1] / hspeed[j], dprange[j] -= cost[i - 1];
  else {
    dp[j] = 1e15, dprange[j] = 0;
  }
  get = min(get, dp[j]);
}

inline void djkctkaygc() {
  int a, b;
  scanf("%d %d ", &a, &b);
}

inline void wtsgdwsfre(double dp[105], double dprange[105], int &i) {
  double get = 1e15;
  for (int j = 0; j < i; j++)
    uukbjhnhqm(i, dprange, get, dp, j);
  dp[i] = get, dprange[i] = hrange[i];
}

void solve() {
  scanf("%d %d ", &n, &q);
  for (int i = 0; i < n; i++)
    scanf("%lld %lld ", &hrange[i], &hspeed[i]);
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {
      int tmp;
      scanf("%d ", &tmp);
      if (j == i + 1)
        cost[i] = tmp;
    }
  for (int i = 0; i < q; i++)
    djkctkaygc();
  double dp[SZ] = {}, dprange[SZ] = {};
  dprange[0] = hrange[0];
  for (int i = 1; i < n; i++)
    wtsgdwsfre(dp, dprange, i);
  y << dp[n - 1] << '\n';
  cout << dp[n - 1] << '\n';
}

int main() {

  cin.tie(0);
  y << fixed << setprecision(12);
  int t;
  scanf("%d ", &t);
  for (int i = 0; i < t; i++)
    y << "Case #" << i + 1 << ": ", solve();
  return 0;
}
