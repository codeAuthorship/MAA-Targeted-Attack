#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
const double eps = 1e-9;
const int MOD = 1000000007;
const long double PI = 3.1415926535897932384626433832795;

ifstream T("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/A-small-practice.in");
ofstream n("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline void idmpslatxj(int ingL[100],
                       vector<pair<int, pair<int, int>>> packV[100],
                       int packs[100][100], int &i, int &j) {
  T >> packs[i][j];
  int low = (10 * packs[i][j] + 11 * ingL[i] - 1) / (11 * ingL[i]);
  int high = (10 * packs[i][j]) / (9 * ingL[i]);
  packV[i].push_back({packs[i][j], {low, high}});
  cout << packs[i][j] << ' ' << low << ' ' << high << '\n';
}

void solve() {
  int ing, per, ingL[100], packs[100][100];
  vector<pair<int, pair<int, int>>> packV[100];
  T >> ing >> per;
  for (int i = 0; i < ing; i++) {
    T >> ingL[i];
  }
  for (int i = 0; i < ing; i++) {
    for (int j = 0; j < per; j++)
      idmpslatxj(ingL, packV, packs, i, j);
    sort(packV[i].begin(), packV[i].end());
  }
  int inds[100] = {}, imax = 0, y = 0;
  cout << "good here" << endl;
  for (; imax < per;) {
    int curL = 0, curH = 1 << 30;
    int curLi = 0, curHi = 0;
    for (int i = 0; i < ing; i++) {
      if (packV[i][inds[i]].second.first > curL)
        curL = packV[i][inds[i]].second.first, curLi = i;
      if (packV[i][inds[i]].second.second < curH)
        curH = packV[i][inds[i]].second.second, curHi = i;
    }
    cout << "cur " << curLi << ' ' << curHi << '\n';
    if (curH < curL) {
      inds[curHi]++;
      imax = max(imax, inds[curHi]);
    } else {
      y++;
      for (int i = 0; i < ing; i++)
        inds[i]++;
      imax++;
    }
  }
  n << y << '\n';
}

int main() {
  int get;
  T >> get;
  for (int i = 0; i < get; i++) {
    n << "Case #" << i + 1 << ": ", solve();
  }
  return 0;
}
