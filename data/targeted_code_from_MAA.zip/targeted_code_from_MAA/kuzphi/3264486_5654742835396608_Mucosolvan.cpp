#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t, ans[5];

void solve(int n, int k) {
  if (n == k) {
    printf("0 0\n");
    return;
  }

  int pot = 1;

  int a = n, b = 0;
  ans[0] = 1;
  ans[1] = 0;
  for (; pot < k;) {
    int newA = 0, newB = 0;
    newA = a / 2;
    ans[2] = ans[0];
    if (a - newA - 1 != newA && newA != 1) {
      ans[3] = ans[0];
      newB = a - newA - 1;
    } else {
      if (a != 2)
        ans[2] += ans[0];
    }

    if (b > 1) {
      if (b % 2 == 0) {
        if (b != 2) {
          newB = b - (b / 2) - 1;
          ans[3] += ans[1];
        }
        ans[2] += ans[1];
      } else {
        ans[3] += ans[1] * 2;
      }
    } else {
      ans[2] += ans[1];
      if (a != n && b != 0)
        k++;
    }

    a = newA;
    b = newB;
    ans[0] = ans[2];
    ans[1] = ans[3];
    ans[2] = ans[3] = 0;
    // cout<<a<<" "<<b<<" "<<cnt[0]<<" "<<cnt[1]<<" "<<k<<" "<<pot<<endl;
    k -= pot;
    pot *= 2;
  }
  // cout<<a<<" "<<b<<" "<<cnt[0]<<" "<<cnt[1]<<" "<<k<<endl;
  if (k > ans[0])
    a = b;
  printf("%d %d\n", a / 2, max(0, a - (a / 2) - 1));
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_15_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/Mucosolvan/A-small-practice.in");

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    int n, k;
    fin >> n >> k;
    printf("Case #%d: ", x);
    solve(n, k);
  }
  return 0;
}
