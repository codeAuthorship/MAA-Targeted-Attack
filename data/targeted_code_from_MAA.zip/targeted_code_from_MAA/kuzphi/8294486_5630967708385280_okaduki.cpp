#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

const double eps = 1e-9;
const int mod = 1000000007;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}

inline void hgyvfaswhv(int &t) {
  LL D, N;
  cin >> D >> N;
  double mn = 0;
  vector<PLL> xs(N);
  for (int i = (0); i < (N); ++i)
    cin >> xs[i];
  int i;
  for (i = (0); i < (N); ++i)
    mn = max(mn, (D - xs[i].first) * 1. / xs[i].second);
  double ans = D / mn;
  printf("Case #%d: %.9f\n", t, ans);
}

int main() {

  cin.tie(0);

  int T;
  cin >> T;
  for (int t = (1); t < (T + 1); ++t)
    hgyvfaswhv(t);

  return 0;
}
