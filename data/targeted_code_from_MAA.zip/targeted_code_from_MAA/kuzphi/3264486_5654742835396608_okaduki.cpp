#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T> ostream &solve(ostream &n, const pair<S, T> &p) {
  return n << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}

int main() {

  cin.tie(0);

  int T;
  cin >> T;

  for (int t_ = (1); t_ < (T + 1); ++t_) {
    LL N, K;
    cin >> N >> K;

    vector<bool> xs(N + 2);
    xs[0] = xs[N + 1] = true;
    tuple<LL, LL, LL> ans;
    for (int k = (0); k < (K); ++k) {
      tuple<LL, LL, LL> mx(-1, -1, -1);
      for (int i = (0); i < (N + 2); ++i) {
        if (xs[i]) {
          continue;
        }
        LL l, r;
        for (l = i - 1; !xs[l]; --l)
          ;
        for (r = i + 1; !xs[r]; ++r)
          ;
        l = i - l - 1;
        r = r - i - 1;
        tuple<LL, LL, LL> t(min(l, r), max(l, r), -i);
        maxi(mx, t);
      }
      xs[-get<2>(mx)] = 1;
      ans = mx;
    }
    printf("Case #%d: %lld %lld\n", t_, get<1>(ans), get<0>(ans));
  }

  return 0;
}
