#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const double EPS = 1e-9;

void open() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_8_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/ccsnoopy/A-small-practice.in",
          "r", stdin);
}

int main(void) {
  open();
  int tc;
  cin >> tc;
  for (int ct = 1; ct <= tc; ct++) {
    printf("Case #%d: ", ct);
    char a[100];
    cin >> a;
    bool valid = true;
    int len = strlen(a);
    for (int i = 0; i < len - 1; i++) {
      if (a[i] > a[i + 1]) {
        valid = false;
        int idx = i;
        int carry = 1;
        while (i >= 0 && carry) {
          if (a[i] != '0') {
            a[i]--;
            carry = 0;
          } else {
            a[i] = '9';
            carry = 1;
          }

          if (i > 0 && a[i - 1] > a[i]) {
            carry = 1;
            a[i] = '9';
          }

          i--;
        }

        for (int j = 0; j <= idx; j++) {
          if (j == 0)
            if (a[j] == '0') {
              continue;
            }
          printf("%c", a[j]);
        }

        for (int j = idx + 1; j < len; j++) {
          printf("9");
        }
        printf("\n");
        break;
      }
    }

    if (valid) {
      printf("%s\n", a);
    }

    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
