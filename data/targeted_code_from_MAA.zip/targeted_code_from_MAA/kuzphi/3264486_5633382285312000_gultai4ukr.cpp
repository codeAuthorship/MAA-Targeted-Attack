#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
ifstream fin;

const int MOD = 1000000007;

inline bool wiakhbdoqw(int &d, int &n, _Bool &wiakh) {
  if (n % 10 > d) {
    wiakh = 0;
    return 1;
  }
  d = n % 10;
  n /= 10;
  return 0;
}

bool is_tidy(int n) {
  int d = 9;
  while (n) {
    _Bool wiakh;
    if (wiakhbdoqw(d, n, wiakh))
      return wiakh;
  }
  return 1;
}

int main(int argc, char **T) {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/gultai4ukr/A-small-practice.in");

  int ret_val = 0;

  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    long long int n;
    fin >> n;
    long long int tidy = 1;
    for (int i = n; i > 1; --i) {
      if (is_tidy(i)) {
        tidy = i;
        break;
      }
    }
    fout << "Case #" << testcase + 1 << ": " << tidy << endl;
  }

  fout.close();
  return ret_val;
}
