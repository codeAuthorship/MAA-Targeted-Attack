#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
typedef long double ld;
typedef pair<int, int> ii;
typedef long double LD;
typedef long long LL;

typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;

const int N = 1002;
int t, digits;
LL n;
bool dp[N][12];
string ans, nString;

bool biggerThanN(string x) {
  if (((int)(x).size()) < ((int)(nString).size()))
    return false;
  if (((int)(x).size()) > ((int)(nString).size()))
    return true;
  return x > nString;
}

string conv(LL x) {
  stringstream ss;
  ss << x;
  return ss.str();
}

inline bool get(int &i, int &p) {
  dp[i][p] = true;
  return true;
  return false;
}

void solve(int i, int p, string curr) {
  if (biggerThanN(curr)) {
    if (get(i, p)) {
      return;
    }
  }
  if (i <= digits + 1)
    if (curr != "") {
      if (((int)(curr).size()) > ((int)(ans).size()))
        ans = curr;
      if (((int)(curr).size()) == ((int)(ans).size()))
        if (curr > ans)
          ans = curr;
    }
  if (i == digits + 1)
    return;
  if (dp[i][p])
    return;

  for (int j = (p); j <= (int)(9); ++j)
    solve(i + 1, j, curr + char(j + '0'));
}

int main() {

  scanf("%d", &t);
  int y;
  for (y = (1); y <= (int)(t); ++y) {
    cin >> n;
    digits = (int)log10(n) + 1;
    nString = conv(n);

    ans = "";
    memset(dp, 0, sizeof dp);
    solve(1, 1, "");
    printf("Case #%d: ", y);
    printf("%s\n", (ans).c_str());
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
