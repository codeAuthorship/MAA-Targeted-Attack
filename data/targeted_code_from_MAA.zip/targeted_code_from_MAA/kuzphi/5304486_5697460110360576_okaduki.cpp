#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;

const double eps = 1e-9;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &q, pair<S, T> &p) {
  return q >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &a, const pair<S, T> &p) {
  return a << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

inline void wbunbppcfy(VVL &qs, int &i, VL &rs, LL &ans) {
  int lb_k = ceil(qs[0][i] * 1. / (rs[0] * 1.1));
  int ub_k = floor(qs[0][i] * 1. / (rs[0] * 0.9));
  if (lb_k <= ub_k)
    ++ans;
}

int main() {

  cin.tie(0);

  int T;
  cin >> T;
  {
    int n = (1);
    while (n < (T + 1)) {
      int N, P;
      cin >> N >> P;
      VL rs(N);
      for (int i = (0); i < (N); ++i)
        cin >> rs[i];
      VVL qs(N, VL(P));
      for (int i = (0); i < (N); ++i) {
        for (int j = (0); j < (P); ++j)
          cin >> qs[i][j];
        sort(begin(((qs[i]))), end(((qs[i]))));
      }

      LL ans = 0;
      if (N == 1) {
        for (int i = (0); i < (P); ++i)
          wbunbppcfy(qs, i, rs, ans);
      } else {
        int i2 = 0;
        for (int i1 = (0); i1 < (P); ++i1) {
          int lb_k = ceil(qs[0][i1] * 1. / (rs[0] * 1.1));
          int ub_k = floor(qs[0][i1] * 1. / (rs[0] * 0.9));

          while (i2 < P) {
            int lb2_k = (int)ceil(qs[1][i2] * 1. / (rs[1] * 1.1));
            int ub2_k = (int)floor(qs[1][i2] * 1. / (rs[1] * 0.9));
            if (lb_k <= ub2_k && lb2_k <= ub_k) {
              ++ans;
              ++i2;
              break;
            } else if (ub_k < lb2_k)
              break;

            ++i2;
          }
        }
      }

      printf("Case #%d: %lld\n", n, ans);
      ++n;
    }
  }

  return 0;
}
