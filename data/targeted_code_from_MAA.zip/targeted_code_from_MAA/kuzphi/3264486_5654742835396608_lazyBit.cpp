#include <bitset>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
 

using namespace std;
const int MOD = 1000000007;
ifstream fin;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;            
typedef unsigned long long ULL;  

const double pi = acos(-1.0);  
const double eps = 1e-11;     
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &get(const T &v) {
    cerr << v << " ";
    return *this;
  }
} p;

void solve(int *ans, int n) {
  printf("[");
  for (int i = 0; i < n; i++) {
    printf("%d ", ans[i]);
  }
  printf("]\n");
}

char str[50];

long long pow2(int a, long long int b) {
  long long x = 1, y = a;
  while (b > 0) {
    if (b % 2 == 1) {
      x = (x * y);
    }
    y = (y * y);
    b /= 2;
  }
  return x;
}
LL dist[2];
inline void iqniculghb(LL &tempx, LL &tempx1, LL &x1, LL tempdist[2]) {
  tempx = (x1 - 1) / 2;
  tempx1 = x1 / 2;
  tempdist[0] += dist[1];
  tempdist[1] += dist[1];
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/lazyBit/A-small-practice.in");

 
  int j, l, r, t, s = 0, d;
  LL n, k, x, x1, level, used, prevLevel, rem;
  fin >> t;
  ;
  int c = 1;
  while (t--) {
    fin >> n;
    fin >> k;
    x = n;
    x1 = n;
    level = log2(k);
    dist[0] = 1;
    dist[1] = 0;
    LL tempx, tempx1;
    LL tempdist[2];
    {
      int i = 1;
      while (i <= level) {
        tempdist[0] = 0;
        tempdist[1] = 0;
        if (x & 1) {
          tempx = x / 2;
          tempx1 = tempx;
          tempdist[0] = 2 * dist[0];
        } else {
          tempx = (x - 1) / 2;
          tempx1 = tempx + 1;
          tempdist[0] = dist[0];
          tempdist[1] = dist[0];
        }

        if (dist[1] > 0) {
          if (!(x1 & 1))
            iqniculghb(tempx, tempx1, x1, tempdist);
          else {
            tempx1 = x1 / 2;
            tempdist[1] += 2 * dist[1];
          }
        }
        x = tempx;
        x1 = tempx1;
        dist[0] = tempdist[0];
        dist[1] = tempdist[1];
        i++;
      }
    }
    prevLevel = pow2(2, level) - 1;
    rem = k - prevLevel;
 
    if (rem > dist[1]) {
      used = x;
    } else {
      used = x1;
    }
  
    if (used & 1) {
      printf("Case #%d: %lld %lld\n", c++, used / 2, used / 2);
    } else {
      printf("Case #%d: %lld %lld\n", c++, used / 2, (used - 1) / 2);
    }
  }
  return (0);
}
