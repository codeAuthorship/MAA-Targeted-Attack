#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

bool comp(pair<int, char> &l, pair<int, char> &r) { return l.first < r.first; }

inline void zdriddhokp(pair<int, char> col[3], int &i) {
  printf("%c\n", col[i].second);
}

inline void auhithyatl(pair<int, char> col[3], int &odd) {
  printf("%c%c", col[2].second, col[odd % 2].second);
  col[2].first--;
  col[odd % 2].first--;
  odd++;
}

inline void vywdzvfbpa(pair<int, char> col[3], int &i) {
  if (col[i].first)
    zdriddhokp(col, i);
}

int main(int argc, char **T) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_14_Usenix_RF_1.0_True_MCTS_Classic_True/kuzphi/gultai4ukr/A-small-practice.in");

  int t;
  fin >> t;
  int c;
  for (c = 0; c < t; ++c) {
    int n, r, o, y, g, b, v;
    fin >> n >> r >> o >> y >> g >> b >> v;
    int m = max(r, max(y, b));
    printf("Case #%d: ", c + 1);

    pair<int, char> col[] = {{r, 'R'}, {y, 'Y'}, {b, 'B'}};
    sort(col, &col[3], comp);

    if (r + y + b == 1) {
      for (int i = 0; i < 3; ++i)
        vywdzvfbpa(col, i);
      continue;
    }

    if (m > (r + y + b) / 2.0) {
      printf("IMPOSSIBLE\n");
      continue;
    }

    while (col[1].first > col[0].first) {
      printf("%c%c", col[2].second, col[1].second);
      col[2].first--;
      col[1].first--;
    }
    int odd = 0;
    for (; col[2].first;)
      auhithyatl(col, odd);
    while (col[odd % 2].first) {
      printf("%c", col[odd % 2].second);
      col[odd % 2].first--;
      odd++;
    }
    printf("\n");
  }

  return 0;
}
