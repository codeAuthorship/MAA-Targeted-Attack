#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const double eps = 1e-9;
const int INF = 1000000000;
const int MAXN = 1005;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;
const int M = 50;
const int N = 50;

int t, r, o, y, g, b, v, ans[maxN], sum;
set<pair<int, int>, greater<pair<int, int>>> s;

int main() {

  scanf("%d ", &t);
  for (int test = (1); test <= ((t)); ++test) {
    scanf("%d %d %d %d %d %d %d ", &sum, &r, &o, &y, &g, &b, &v);
    s.clear();
    if (r > 0)
      s.insert(pair<int, int>(r, 1));
    if (y > 0)
      s.insert(pair<int, int>(y, 2));
    if (b > 0)
      s.insert(pair<int, int>(b, 3));
    int d = max(r, y);
    d = max(d, b);
    printf("Case #%d: ", test);
    // s.clear();
    if (d > sum / 2) {
      printf("IMPOSSIBLE");
    } else {
      pair<int, int> x = *s.begin();
      s.erase(s.begin());
      ans[0] = x.second;
      s.insert(pair<int, int>(x.first - 1, x.second));

      int cnt = 1;
      for (; cnt < sum;) {
        pair<int, int> x = *s.begin();
        if (x.second == ans[cnt - 1]) {
          pair<int, int> tmp = x;
          s.erase(s.begin());
          x = *s.begin();
          ans[cnt] = x.second;
          s.erase(s.begin());
          if (x.first > 0)
            s.insert(pair<int, int>(x.first - 1, x.second));
          s.insert(tmp);
        } else {
          // cout<<x.st<<" "<<x.nd<<endl;
          ans[cnt] = x.second;
          s.erase(s.begin());
          if (x.first > 0)
            s.insert(pair<int, int>(x.first - 1, x.second));
        }
        cnt++;
      }
      if (ans[sum - 1] == ans[0]) {
        swap(ans[sum - 1], ans[sum - 2]);
        if (ans[sum - 2] == ans[sum - 3])
          printf("IMPOSSIBLE");
        else {
          for (int i = (0); i <= ((sum)-1); ++i) {
            if (ans[i] == 1)
              printf("R");
            if (ans[i] == 2)
              printf("Y");
            if (ans[i] == 3)
              printf("B");
          }
        }
      } else {
        for (int i = (0); i <= ((sum)-1); ++i) {
          if (ans[i] == 1)
            printf("R");
          if (ans[i] == 2)
            printf("Y");
          if (ans[i] == 3)
            printf("B");
        }
      }
    }
    printf("\n");
  }
  return 0;
}
