#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

char s[1 << 10];
int n, solve;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, j, ans;
  cin >> t;
  int c;
  for (c = 0; c < t; c++) {
    cin >> s >> solve;
    n = strlen(s);
    ans = 0;
    for (int i = 0; i < n; i++) {
      if (s[i] == '-') {
        if (i + solve > n) {
          ans = -1;
          break;
        }
        ans++;
        for (j = i; j < i + solve; j++) {
          if (s[j] == '-') {
            s[j] = '+';
          } else {
            s[j] = '-';
          }
        }
      }
    }
    printf("Case #%d: ", c + 1);
    if (ans != -1) {
      printf("%d\n", ans);
    } else {
      printf("IMPOSSIBLE\n");
    }
  }
  return 0;
}
