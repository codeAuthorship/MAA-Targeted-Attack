#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           // NOTES:int64
typedef unsigned long long ULL; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {};

void solve(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

double besttime[1010];
LL right_bound[110], d[110], dist[110][110], a[110], b[110], dd[110];
long double best[110][110];
inline void nffeftragh(int &i, int &j) {
  best[i][j] = besttime[j] + ((dd[i] - dd[j]) * 1.0) / d[j];
}

inline void serwpcptjq(int &i, int &j) { best[i][j] = 1e18; }

inline void ayhovpjxip(int &i, int &j) {
  cin >> dist[i][j];
  ;
  j++;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);
  ;
  // output;

  long long n, k, l, m, t, s = 0, argv, q;
  int i, j;
  cin >> t;
  int ct = 1;
  for (; t--;) {
    cin >> n;
    ;
    cin >> q;
    ;
    for (i = 0; i < n; i++) {
      cin >> right_bound[i];
      ;
      cin >> d[i];
      ;
    }
    for (i = 0; i < n; i++) {
      {
        j = 0;
        while (j < n)
          ayhovpjxip(i, j);
      }
    }
    for (i = 0; i < q; i++) {
      cin >> a[i];
      ;
      cin >> b[i];
      ;
    }
    dd[0] = 0;
    for (i = 1; i < n; i++)
      dd[i] = dd[i - 1] + dist[i - 1][i];

    besttime[0] = 0.0;
    long double r;
    for (i = 1; i < n; i++) {
      r = 1e18;
      {
        j = 0;
        for (; j < i;) {
          if (dd[i] - dd[j] <= right_bound[j])
            nffeftragh(i, j);
          else
            serwpcptjq(i, j);
          r = min(r, best[i][j]);
          j++;
        }
      }
      besttime[i] = r;
    }
    // if(besttime[n-1]<0) {
    // 	cerr<<n<<' '<<q<<endl;
    // }
    printf("Case #%d: %0.6lf\n", ct++, besttime[n - 1]);
  }
  return (0);
}
