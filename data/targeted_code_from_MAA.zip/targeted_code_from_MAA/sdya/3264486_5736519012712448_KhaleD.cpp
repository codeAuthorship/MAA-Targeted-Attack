#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <string>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;

const int N = 200002;
int t, n, left_bound;
char a[N];

bool solve() {
  {
    int i = (0);
    while (i <= (int)(n - 1)) {
      if (a[i] == '-')
        return 0;
      ++i;
    }
  }
  return true;
}

inline void dltcftshbw(int &testCase) {
  cin >> a;
  n = strlen(a);
  cin >> left_bound;

  int argv = 0;
  int i;
  for (i = (0); i <= (int)(n - left_bound); ++i)
    if (a[i] == '-') {
      ++argv;
      for (int readData = (i); readData <= (int)(i + left_bound - 1);
           ++readData)
        a[readData] = a[readData] == '-' ? '+' : '-';
    }

  if (solve())
    printf("Case #%d: %d\n", testCase, argv);
  else
    printf("Case #%d: IMPOSSIBLE\n", testCase);
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  {
    int testCase = (1);
    while (testCase <= (int)(t)) {
      dltcftshbw(testCase);
      ++testCase;
    }
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
