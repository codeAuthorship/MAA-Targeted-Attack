
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

const int N = 100;

int n, m;

void handle_line(string &s) {
  char last = '?';
  for (int i = 0; i < m; ++i) {
    if (s[i] == '?') {
      s[i] = last;
    } else {
      last = s[i];
    }
  }
  for (int i = m - 1; i >= 0; --i) {
    if (s[i] == '?') {
      s[i] = last;
    } else {
      last = s[i];
    }
  }
}

string s[N];

void solve() {
  cin >> n >> m;
  string qs;
  for (int i = 1; i <= m; ++i) {
    qs.push_back('?');
  }
  int st = -1;
  for (int i = 1; i <= n; ++i) {
    cin >> s[i];
    if (s[i] != qs) {
      st = i;
    }
  }
  handle_line(s[st]);
  for (int i = st - 1; i >= 1; --i) {
    if (s[i] == qs) {
      s[i] = s[i + 1];
    } else {
      handle_line(s[i]);
    }
  }
  for (int i = st + 1; i <= n; ++i) {
    if (s[i] == qs) {
      s[i] = s[i - 1];
    } else {
      handle_line(s[i]);
    }
  }
  for (int i = 1; i <= n; ++i) {
    cout << s[i] << endl;
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    printf("Case #%d:\n", i);
    solve();
  }
  return 0;
}
