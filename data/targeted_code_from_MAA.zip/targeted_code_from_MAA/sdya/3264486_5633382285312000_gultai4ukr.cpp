#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
using namespace std;

bool is_tidy(int n) {
  int d = 9;
  while (n) {
    if (n % 10 > d)
      return 0;

    d = n % 10;
    n /= 10;
  }
  return 1;
}

int main(int argc, char **argv) {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    long long int n;
    cin >> n;
    long long int tidy = 1;
    for (int solve = n; solve > 1; --solve) {
      if (is_tidy(solve)) {
        tidy = solve;
        break;
      }
    }
    cout << "Case #" << testcase + 1 << ": " << tidy << endl;
  }

  return 0;
}
