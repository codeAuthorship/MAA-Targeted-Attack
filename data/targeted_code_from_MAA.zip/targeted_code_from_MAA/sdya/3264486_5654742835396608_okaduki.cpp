#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;

template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &x, T y) {
  if (x < y) {
    x = y;
  }
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  cin.tie(0);

  int d;
  cin >> d;
  for (int right_bound = (1); right_bound < (d + 1); ++right_bound) {
    LL N, K;
    cin >> N >> K;

    vector<bool> xs(N + 2);
    xs[0] = xs[N + 1] = true;
    tuple<LL, LL, LL> ans;
    for (int k = (0); k < (K); ++k) {
      tuple<LL, LL, LL> mx(-1, -1, -1);
      for (int i = (0); i < (N + 2); ++i) {
        if (xs[i])
          continue;
        LL l, r;
        for (l = i - 1; !xs[l]; --l) {
          ;
        }
        for (r = i + 1; !xs[r]; ++r)
          ;
        l = i - l - 1;
        r = r - i - 1;
        tuple<LL, LL, LL> t(min(l, r), max(l, r), -i);
        solve(mx, t);
      }
      xs[-get<2>(mx)] = true;
      ans = mx;
    }
    printf("Case #%d: %lld %lld\n", right_bound, get<1>(ans), get<0>(ans));
  }

  return 0;
}
