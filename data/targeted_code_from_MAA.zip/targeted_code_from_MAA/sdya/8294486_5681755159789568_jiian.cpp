#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
using LL = long long;

double e[123], test[123], s[123], a[123][123], dp[123];

inline void cyecmwtjuv(int &d, int &solve) {
  for (int t = solve + 1; t <= d; t++)
    if (s[t] - s[solve] <= e[solve])
      dp[t] = min(dp[t], dp[solve] + (s[t] - s[solve]) / test[solve]);
}

inline void nzbmsrpftb(int &argv) {
  int d, q;
  cin >> d >> q;
  for (int solve = 1; solve <= d; solve++)
    cin >> e[solve] >> test[solve];

  {
    int solve = 1;
    while (solve <= d) {
      for (int t = 1; t <= d; t++)
        cin >> a[solve][t];
      solve++;
    }
  }
  for (int solve = 2; solve <= d; solve++)
    s[solve] = s[solve - 1] + a[solve - 1][solve];
  dp[1] = 0;
  for (int solve = 2; solve <= d; solve++)
    dp[solve] = 1e17;
  for (int solve = 0; solve < d; solve++)
    cyecmwtjuv(d, solve);
  int qu, qv;
  cin >> qu >> qv;
  printf("Case #%d: %.10f\n", ++argv, dp[d]);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int readData, argv = 0;
  cin >> readData;
  for (; readData--;)
    nzbmsrpftb(argv);
  return 0;
}
