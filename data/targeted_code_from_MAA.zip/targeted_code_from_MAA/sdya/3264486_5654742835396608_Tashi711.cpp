
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

struct node {
  long long u, v;
  node(int _u = 0, int _v = 0) : u(_u), v(_v) {}
  bool operator<(const node &r) const { return u < r.u; }
};

inline void vptorrluhn(long long &sum, long long &l,
                       map<long long, long long> &f, long long &r) {
  long long u = f.rbegin()->first, readData = f.rbegin()->second;
  f.erase(u);
  sum += readData;
  l = (u - 1) / 2;
  r = u / 2;
  f[l] += readData;
  f[r] += readData;
}

void solve() {
  long long n, k;
  cin >> n >> k;
  map<long long, long long> f;
  f[n] = 1;
  long long sum = 0;
  long long l = (n - 1) / 2, r = n / 2;
  while (sum < k)
    vptorrluhn(sum, l, f, r);
  printf("%lld %lld\n", r, l);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    printf("Case #%d: ", i);
    solve();
  }
  return 0;
}
