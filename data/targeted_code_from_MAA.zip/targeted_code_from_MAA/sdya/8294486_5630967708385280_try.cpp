#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, d, n, k, s;
  double m;
  cin >> t;
  for (int test = 0; test < t; test++) {
    cin >> d >> n;
    m = 0.0;
    for (int solve = 0; solve < n; solve++) {
      cin >> k >> s;
      m = max(m, 1.0 * (d - k) / s);
    }
    printf("Case #%d: %.6f\n", test + 1, d / m);
  }
  return 0;
}
