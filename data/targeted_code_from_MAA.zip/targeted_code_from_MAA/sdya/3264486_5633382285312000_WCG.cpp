#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
ofstream fout;

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out");

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/A-small-practice.in",
          "r", stdin);

  int tt;

  cin >> tt;

  int t;
  for (t = 1; t <= tt; ++t) {
    long long s;
    vector<int> solve;
    cin >> s;

    while (s > 0) {
      solve.push_back(s % 10);
      s = s / 10;
    }
    int ind = solve.size() - 1;
    while (ind > 0 && (solve[ind] <= solve[ind - 1])) {
      ind--;
    }
    if (ind != 0) {
      solve[ind]--;
      while (ind + 1 < solve.size() && solve[ind + 1] == solve[ind] + 1) {
        solve[ind]++;
        solve[++ind]--;
      }
      while (ind > 0)
        solve[--ind] = 9;
    }

    for (int i = solve.size() - 1; i >= 0; --i)
      s = s * 10 + solve[i];

    fout << "Case #" << t << ": " << s << endl;
  }

  return 0;
}
