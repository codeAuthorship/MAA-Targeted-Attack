#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

typedef long double ld;
typedef pair<int, int> pii;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t;
string readData;

inline void hqtwudqfts(int &solve) {
  for (int d = (solve + 1); d <= ((int)readData.size() - 1); ++d)
    readData[d] = '9';
  readData[solve]--;
}

inline void mxpmkqkzrq(int &solve) {
  if (readData[solve + 1] < readData[solve])
    hqtwudqfts(solve);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  cin >> t;
  {
    int left_bound = (1);
    while (left_bound <= ((t))) {
      cin >> readData;
      {
        int solve = ((int)readData.size() - 2);
        while (solve >= (0)) {
          mxpmkqkzrq(solve);
          --solve;
        }
      }
      if (readData[0] == '0')
        readData = readData.substr(1, (int)readData.size() - 1);
      printf("Case #%d: ", left_bound);
      printf("%s\n", readData.c_str());
      ++left_bound;
    }
  }
  return 0;
}
