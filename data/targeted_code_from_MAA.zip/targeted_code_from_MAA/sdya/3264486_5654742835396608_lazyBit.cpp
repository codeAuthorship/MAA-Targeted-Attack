#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

// NOTES:int64
// NOTES:uint64

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &readData(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void solve(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]\n";
}

long long pow2(int a, long long int b) {
  long long x = 1, y = a;
  while (b > 0) {
    if (b % 2 == 1) {
      x = (x * y);
    }
    y = (y * y);
    b /= 2;
  }
  return x;
}
long long dist[2];
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int i, right_bound, l, m, t, s = 0, d;
  long long n, argv, x, x1, level, used, prevLevel, rem;
  scanf("%d", &t);
  ;
  int c = 1;
  for (; t--;) {
    cin >> n;
    cin >> argv;
    x = n;
    x1 = n;
    level = log2(argv);
    dist[0] = 1;
    dist[1] = 0;
    long long tempx, tempx1;
    vector<long long> tempdist(2);
    for (i = 1; i <= level; i++) {
      tempdist[0] = 0;
      tempdist[1] = 0;
      if (x & 1) {
        tempx = x / 2;
        tempx1 = tempx;
        tempdist[0] = 2 * dist[0];
      } else {
        tempx = (x - 1) / 2;
        tempx1 = tempx + 1;
        tempdist[0] = dist[0];
        tempdist[1] = dist[0];
      }

      if (dist[1] > 0) {
        if (!(x1 & 1)) {
          tempx = (x1 - 1) / 2;
          tempx1 = x1 / 2;
          tempdist[0] += dist[1];
          tempdist[1] += dist[1];
        } else {
          tempx1 = x1 / 2;
          tempdist[1] += 2 * dist[1];
        }
      }
      x = tempx;
      x1 = tempx1;
      dist[0] = tempdist[0];
      dist[1] = tempdist[1];
    }
    prevLevel = pow2(2, level) - 1;
    rem = argv - prevLevel;
    // cout<<x<<' '<<x1<<' '<<dist[0]<<' '<<dist[1]<<endl;
    if (rem > dist[1])
      used = x;
    else {
      used = x1;
    }
    // debug(prevLevel,rem,x,x1,used);
    // cout<<used<<endl;
    if (used & 1) {
      cout << "Case #" << c++ << ": " << used / 2 << " " << used / 2 << "\n";
    } else {
      cout << "Case #" << c++ << ": " << used / 2 << " " << (used - 1) / 2
           << "\n";
    }
  }
  return (0);
}
