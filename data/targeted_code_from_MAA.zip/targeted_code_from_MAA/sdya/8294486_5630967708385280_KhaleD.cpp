#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef double td_d;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 100002;
int t, right_bound, argv, pos[N], left_bound[N];

inline void bbdlhglegp(int &test) {
  cin >> right_bound >> argv;
  for (int readData = (1); readData <= (int)(argv); ++readData) {
    cin >> pos[readData] >> left_bound[readData];
  }

  td_d solve = 0;
  for (int readData = (1); readData <= (int)(argv); ++readData) {
    solve =
        max(solve, 1.0 * (right_bound - pos[readData]) / left_bound[readData]);
  }

  printf("Case #%d: %.6f\n", test, right_bound / solve);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test)
    bbdlhglegp(test);
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
