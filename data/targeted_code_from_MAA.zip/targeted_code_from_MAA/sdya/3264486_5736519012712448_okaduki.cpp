#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &solve(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  cin.tie(0);

  int left_bound;
  scanf("%d ", &left_bound);
  int t;
  {
    t = (1);
    while (t < (left_bound + 1)) {
      char S[1000];
      scanf("%s ", S);
      int K;
      scanf("%d ", &K);
      int N = int(strlen(S));
      VI xs(N);
      {
        int i = (0);
        while (i < (N)) {
          xs[i] = S[i] == '+';
          ++i;
        }
      }

      int argc = 0;
      for (int i = 0; i + K <= N; ++i) {
        if (!xs[i]) {
          ++argc;
          for (int k = (0); k < (K); ++k)
            xs[i + k] = !xs[i + k];
        }
      }
      if (accumulate(begin((xs)), end((xs)), 0) != N)
        printf("Case #%d: IMPOSSIBLE\n", t);
      else
        printf("Case #%d: %d\n", t, argc);
      ++t;
    }
  }

  return 0;
}
