#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>

using namespace std;

const int inf = 1e9 + 7;
const int maxN = 100 + 5;

int t, k, n;
int readData[maxN][maxN];
string s[maxN];

inline void vynmqjzyhc(int &l, int &m, int &solve, int &j) {
  s[l][m] = s[solve][j];
}

inline void ilrqjaycws(int &solve) {
  for (int j = (0); j <= ((k)-1); ++j)
    s[solve][j] = s[solve - 1][j];
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  {
    int x = (1);
    while (x <= ((t))) {
      cin >> n >> k;
      for (int solve = (0); solve <= ((n)-1); ++solve)
        cin >> s[solve];

      int pom = -1;
      for (int solve = (0); solve <= ((n)-1); ++solve) {
        for (int j = (0); j <= ((k)-1); ++j) {
          if (s[solve][j] != '?' && (pom == solve || pom == -1)) {
            for (int l = (0); l <= ((n)-1); ++l) {
              for (int m = (0); m <= ((k)-1); ++m) {
                if (s[l][m] == '?' && l <= solve && m <= j)
                  vynmqjzyhc(l, m, solve, j);
              }
            }
            pom = solve;
          }
          // cout<<i<<" "<<j<<" "<<pom<<" "<<s[i][j]<<endl;
          if (pom != -1 && solve > pom)
            break;
        }
        if (pom != -1 && solve > pom)
          break;
      }

      for (int solve = (0); solve <= ((n)-1); ++solve) {
        int pos = -1;
        for (int j = (0); j <= ((k)-1); ++j) {
          if (s[solve][j] != '?') {
            pos = j;
            break;
          }
        }

        if (pos != -1) {
          char first = s[solve][pos];
          for (int j = (0); j <= ((k)-1); ++j) {
            if (s[solve][j] == '?') {
              s[solve][j] = first;
            } else {
              first = s[solve][j];
            }
          }
        } else
          ilrqjaycws(solve);
      }

      printf("Case #%d: \n", x);
      for (int solve = (0); solve <= ((n)-1); ++solve)
        printf("%s\n", s[solve].c_str());

      ++x;
    }
  }
  return 0;
}
