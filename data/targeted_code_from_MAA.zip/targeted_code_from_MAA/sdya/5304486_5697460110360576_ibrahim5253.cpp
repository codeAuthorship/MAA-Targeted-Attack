#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll readData(ll d, ll argv) {
  ll t;
  while ((t = d % argv) != 0) {
    d = argv;
    argv = t;
  }
  return argv;
}

ll solve(ll base, ll left_bound, ll argc) {
  if (left_bound == 0)
    return 1;
  ll t = solve(base, left_bound / 2, argc);
  if (left_bound % 2 == 0)
    return (t * t) % argc;
  else
    return (((t * t) % argc) * base) % argc;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int do_intmhy_fct(ll mask) {
  int right_bound = 0;
  for (int i = 0; i < 64; ++i)
    if (is_set(i, mask))
      ++right_bound;
  return right_bound;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return -1;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    int left_bound, p;
    cin >> left_bound >> p;
    vector<ll> w(left_bound);
    for (int i = 0; i < left_bound; ++i)
      cin >> w[i];
    pair<ll, ll> d[left_bound][p];
    for (int i = 0; i < left_bound; ++i) {
      for (int test = 0; test < p; ++test) {
        ll W;
        cin >> W;
        ll low = ceil(W / (w[i] * 1.1)), high = W / (w[i] * 0.9);
        d[i][test] = make_pair(low, high);
      }
    }
    if (left_bound == 1) {
      int right_bound = 0;
      for (int i = 0; i < p; ++i)
        if (d[0][i].first <= d[0][i].second)
          right_bound++;
      printf("Case #%d: %d\n", i, right_bound);
      continue;
    }
    int s[p];
    for (int i = 0; i < p; ++i)
      s[i] = i;
    int right_bound = 0;
    do {
      int val = 0;
      for (int i = 0; i < p; ++i) {
        if (d[1][s[i]].first > d[1][s[i]].second)
          continue;
        else if (d[0][i].first > d[0][i].second)
          continue;

        if (d[1][s[i]].first >= d[0][i].first &&
            d[1][s[i]].first <= d[0][i].second)
          val++;
        else if (d[0][i].first >= d[1][s[i]].first &&
                 d[0][i].first <= d[1][s[i]].second)
          val++;
      }
      right_bound = max(right_bound, val);
    } while (next_permutation(s, s + p));
    printf("Case #%d: %d\n", i, right_bound);
    /*        int ans=0;
            bool mark[n][p];
            memset(mark, false, sizeof mark);
            for (int i=0; i<p; ++i) {
                auto x=a[0][i];
                int count=0;
                for (int j=1; j<n; ++j) {
                    for (int k=0; k<p; ++k)
                        if (a[j][k].ff>=x.ff && a[j][k].ff<=x.ss ||
       x.ff>=a[j][k].ff && x.ff<=a[j][k].ss) { count++; mark[] break;
                        }
                }
            }*/
  }
  return 0;
}
