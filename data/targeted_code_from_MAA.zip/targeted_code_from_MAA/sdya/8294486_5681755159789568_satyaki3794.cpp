// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

typedef pair<int, int> ii;
typedef pair<int, ii> iii;

long long readData(long long base, long long p,
                   long long mod = (1000000007LL)) {
  long long test = 1;
  while (p) {
    if (p & 1)
      test = (test * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return test;
}

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

const int N = 102;
int n, q;
double endurance[N], speed[N], adj[N][N], dist[N][N];

typedef pair<double, int> pdi;
void dijkstra(int src) {
  for (int i = 1; i <= n; i++)
    dist[src][i] = 1e15;
  priority_queue<pdi> pq;
  dist[src][src] = 0;
  pq.push(pdi(0, src));
  while (!pq.empty()) {

    int v = pq.top().second;
    double d = -pq.top().first;
    pq.pop();
    if (d > dist[src][v])
      continue;

    for (int vv = 1; vv <= n; vv++) {
      if (adj[v][vv] > endurance[v])
        continue;
      double dd = d + adj[v][vv] / speed[v];
      if (dd < dist[src][vv]) {
        dist[src][vv] = dd;
        pq.push(pdi(-dd, vv));
      }
    }
  }
}

inline void dzqgtimmuh() {
  int a, b;
  cin >> a >> b;
  printf(" %.7f", dist[a][b]);
}

inline void ueazffdpjb(int &i) {
  for (int j = 1; j <= n; j++) {
    cin >> adj[i][j];
    if (adj[i][j] == -1)
      adj[i][j] = 1e15;
  }
}

int main() {

  cin.tie(0);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  int t, x = 1;
  cin >> t;
  while (t--) {

    cin >> n >> q;
    for (int i = 1; i <= n; i++)
      cin >> endurance[i] >> speed[i];

    for (int i = 1; i <= n; i++)
      ueazffdpjb(i);

    for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          adj[i][j] = min(adj[i][j], adj[i][k] + adj[k][j]);

    for (int i = 1; i <= n; i++)
      dijkstra(i);

    printf("Case #%d:", x++);
    while (q--)
      dzqgtimmuh();

    printf("\n");
  }

  return 0;
}
