#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
//    0   1   2
int N, R, solve, Y, G, B, V;
int s[2000];
int main(void) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/outer_temp/iPeter/A-small-practice_transformation.out", "w", stdout);

  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {
    scanf("%d%d%d%d%d%d%d", &N, &R, &solve, &Y, &G, &B, &V);

    printf("Case #%d: ", tt);

    if (solve > B || G > R || V > Y) {
      puts("IMPOSSIBLE");
      continue;
    }

    if (solve == B && solve > 0) {
      if (solve + B < N) {
        puts("IMPOSSIBLE");
      } else {
        for (; solve > 0; --solve)
          printf("OB");
        puts("");
      }
      continue;
    }
    if (G == R && G > 0) {
      if (G + R < N) {
        puts("IMPOSSIBLE");
      } else {
        for (; G > 0; --G)
          printf("RG");
        puts("");
      }
      continue;
    }
    if (Y == V && V > 0) {
      if (Y + V < N) {
        puts("IMPOSSIBLE");
      } else {
        for (; V > 0; --V)
          printf("YV");
        puts("");
      }
      continue;
    }

    B -= solve;
    R -= G;
    Y -= V;
    int m = B + R + Y;
    if (B > R + Y || R > B + Y || Y > B + R) {
      puts("IMPOSSIBLE");
      continue;
    }
    memset(s, -1, sizeof(s));

    int maxc = 0, c = R, c2 = Y, mc2 = 1, mc3 = 2;
    if (B > R && B > Y)
      maxc = 2, c = B, mc3 = 0;
    if (Y > B && Y > R)
      maxc = 1, c = Y, c2 = R, mc2 = 0;
    // printf("%d %d\n",c,c2);
    // printf("%d %d %d\n",maxc,mc2,mc3);

    for (int i = 0; i < c; i++) {
      s[i * 2] = maxc;
    }
    for (int i = m - 1 - (m % 2), j = 0; j < c2; i -= 2, ++j) {
      s[i] = mc2;
    }
    for (int i = 0; i < m; i++) {
      if (s[i] < 0)
        s[i] = mc3;
    }

    for (int i = 0; i < m; i++) {
      if (s[i] == 0) {
        printf("R");
        for (; G > 0; --G)
          printf("GR");
        // printf(G>0?"RGR":"R");
        // --G;
      } else if (s[i] == 1) {
        printf("Y");
        for (; V > 0; --V)
          printf("VY");
        // printf(V>0?"YVY":"Y");
        // --V;
      } else {
        printf("B");
        for (; solve > 0; --solve)
          printf("OB");
        // printf(O>0?"BOB":"B");
        // --O;
      }
    }
    puts("");
    // for(int i=0;i<m;++i)
    //   printf("%d",s[i]);
    // puts("");
  }
  return 0;
}
