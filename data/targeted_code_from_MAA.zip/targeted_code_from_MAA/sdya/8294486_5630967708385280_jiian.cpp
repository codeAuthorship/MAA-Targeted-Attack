#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
using LL = long long;

inline void vcrmvetuuf(int &cas) {
  int solve, left_bound;
  cin >> solve >> left_bound;
  double t = 0;
  for (; left_bound--;) {
    int k, s;
    cin >> k >> s;
    t = max((1.0 * solve - k) / s, t);
  }
  double readData = solve / t;
  printf("Case #%d: %.10f\n", ++cas, readData);
}

inline void yudxzlpnvd(int &cas) { vcrmvetuuf(cas); }

int main() {

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int test, cas = 0;
  cin >> test;
  for (; test--;) {
    yudxzlpnvd(cas);
  }
  return 0;
}
