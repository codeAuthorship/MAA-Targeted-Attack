#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL; // NOTES:int64
                      // NOTES:uint64

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &operator,(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void debugarr(int *left_bound, int n) {
  cout << "[";
  {
    int i = 0;
    while (i < n) {
      cout << left_bound[i] << " ";
      i++;
    }
  }
  cout << "]" << endl;
}

char str[50];

bool containszero(int test) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  while (i < test) {
    if (str[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void ogxbhmatae(int &test, int &j, int &i) {
  for (j = i; j < test; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

inline void tievkkvgpu(int &test, int &j, int &i) {
  for (j = i; j < test; j++)
    str[j] = '9';
  str[i - 1] = (char)(str[i - 1] - 1);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, argc, test, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    int p = 0;
    test = strlen(str);
    if (!containszero(test)) {
      for (i = test - 1; i > 0; i--) {
        if (str[i] < str[i - 1])
          tievkkvgpu(test, j, i);
      }
    }
    while (containszero(test)) {
      for (i = 0; i < test; i++) {
        if (str[i] == '0') {
          for (j = i; j < test; j++)
            str[j] = '9';
          str[i - 1] = (char)(str[i - 1] - 1);
          break;
        }
      }
      if (!containszero(test)) {
        for (i = test - 1; i > 0; i--) {
          if (str[i] < str[i - 1])
            ogxbhmatae(test, j, i);
        }
      }
    }
    printf("Case #%d: ", c++);
    i = 0;
    while (str[i] == '0') {
      i++;
      continue;
    }
    while (i < test)
      cout << str[i++];

    printf("\n");
  }
  return (0);
}
