#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int tc;

inline void mlsjlzjrak(std::string &solve, int &j) {
  if (solve[j] == '-')
    solve[j] = '+';
  else
    solve[j] = '-';
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  scanf("%d ", &tc);
  int t;
  for (t = 1; t <= tc; t++) {
    string solve;
    int k, fl = 0;
    cin >> solve >> k;
    for (int i = 0; i < solve.size() - k + 1; i++) {
      if (solve[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + k; j++)
          mlsjlzjrak(solve, j);
      }
    }
    int f = 1;
    for (int i = solve.size() - k + 1; i < solve.size(); i++) {
      if (solve[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
  return 0;
}
