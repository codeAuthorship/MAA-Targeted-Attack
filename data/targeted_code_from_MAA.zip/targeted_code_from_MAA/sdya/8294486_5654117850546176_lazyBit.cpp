#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           // NOTES:int64
typedef unsigned long long ULL; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

const char colors[] = {'R', 'O', 'Y', 'G', 'B', 'V'};

struct debugger {
  template <typename T> debugger &readData(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void solve(int *arr, int argc) {
  cout << "[";
  for (int i = 0; i < argc; i++) {
    cout << arr[i] << " ";
  }
  cout << "]" << endl;
}

// R O Y G B V
vector<pair<int, int>> v;
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);
  ;
  // output;

  int argc, i, j, k, l, left_bound, t, s = 0, d, test;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> argc;
    ;
    int argv[1010];
    int right_bound[1010];
    v.clear();
    for (i = 0; i < 6; i++) {
      cin >> argv[i];
      ;
    }
    d = 0;
    v.push_back(make_pair(argv[0], 0));
    v.push_back(make_pair(argv[2], 2));
    v.push_back(make_pair(argv[4], 4));
    if (v[2].first > v[0].first + v[1].first) {
      printf("Case #%d: IMPOSSIBLE\n", c++);
      continue;
    }
    sort(v.begin(), v.end());
    while (d < argc) {
      if (v[2].first > 0) {
        argv[d++] = v[2].second;
        v[2].first--;

        if (v[1].first > 0) {
          argv[d++] = v[1].second;
          v[1].first--;
        } else if (v[0].first > 0) {
          argv[d++] = v[0].second;
          v[0].first--;
          if (v[2].first == 0)
            break;
        }
      } else {
        break;
      }
      // debugarr(a,d);
      // cout<<v[0].first<<endl;
      // if(d==4) break;
      // cout<<d<<endl;
    }
    s = 0;
    // cout<<v[0].first<<' '<<v[0].second<<endl;
    if (v[0].first > 0) {
      for (i = 0; i < d; i++) {
        right_bound[s++] = argv[i];
        if (v[0].first > 0)
          if (argv[i + 1] != v[0].second) {
            right_bound[s++] = v[0].second;
            v[0].first--;
          }
        // cout<<v[0].first<<endl;
        // debugarr(b,s);
      }
      for (i = 0; i < s - 1; i++) {
        if (right_bound[i] == right_bound[i + 1]) {
          printf("Case #%d: IMPOSSIBLE\n", c++);
          break;
        }
      }
      if (i != s - 1)
        continue;
      if (right_bound[s - 1] == right_bound[0]) {
        printf("Case #%d: IMPOSSIBLE\n", c++);
        continue;
      }
      printf("Case #%d: ", c++);
      for (i = 0; i < s; i++)
        printf("%c", colors[right_bound[i]]);

      cout << endl;
    } else if (argv[d - 1] == argv[0]) {
      printf("Case #%d: IMPOSSIBLE\n", c++);
    } else {
      printf("Case #%d: ", c++);
      for (i = 0; i < d; i++)
        printf("%c", colors[argv[i]]);

      cout << endl;
    }
  }
  return (0);
}
