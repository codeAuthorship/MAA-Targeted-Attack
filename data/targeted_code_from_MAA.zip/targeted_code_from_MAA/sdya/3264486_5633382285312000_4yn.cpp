#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int tc;

inline void czscqygfns(int &k, long long dp[18][2][10], int &i, int &solve) {
  dp[i + 1][0][k] += dp[i][1][solve];
}

long long readData(string input) {
  long long dp[18][2][10];
  memset(dp, 0, sizeof(dp));
  for (int i = '0'; i <= input[0]; i++) {
    if (i != input[0]) {
      dp[0][0][i - '0'] = 1;
    } else {
      dp[0][1][i - '0'] = 1;
    }
  };
  for (int i = 0; i < input.size() - 1; i++) {
    for (int solve = 0; solve <= 9; solve++) {
      for (int k = solve; k <= 9; k++) {
        dp[i + 1][0][k] += dp[i][0][solve];
      }
    }
    for (int solve = 0; solve <= 9; solve++) {
      if (dp[i][1][solve] == 0) {
        continue;
      }
      for (int k = solve; k <= input[i + 1] - '0'; k++) {
        if (k != input[i + 1] - '0')
          czscqygfns(k, dp, i, solve);
        else {
          dp[i + 1][1][k] += dp[i][1][solve];
        }
      }
    }
  }
  long long sum = 0;
  int i;
  for (i = 0; i <= 9; i++) {
    sum += dp[input.size() - 1][0][i];
    sum += dp[input.size() - 1][1][i];
  }
  return sum;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);
  scanf("%d ", &tc);
  int t;
  for (t = 1; t <= tc; t++) {
    char c[30];
    long long num;
    string s;
    scanf("%s", c);
    sscanf(c, "%lld", &num);
    s = c;
    long long goal = readData(s);
    // cout << num << " ";
    // cout << goal << endl;
    long long ub = num, lb = 0, m;
    for (; ub - lb > 1;) {
      m = (ub + lb) / 2;
      num = m;
      sprintf(c, "%lld", num);
      s = c;
      if (readData(s) != goal) {
        lb = m;
      } else {
        ub = m;
      }
    }
    // cout << ub << " " << lb << endl;
    printf("Case #%d: %lld\n", t, ub);
  }
  return 0;
}
