#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

bool comp(pair<int, char> &l, pair<int, char> &r) { return l.first < r.first; }

int main(int argc, char **argv) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  int testcase;
  {
    testcase = 0;
    while (testcase < t) {
      int readData, r, o, y, g, b, test;
      cin >> readData >> r >> o >> y >> g >> b >> test;
      int solve = max(r, max(y, b));
      cout << "Case #" << testcase + 1 << ": ";

      pair<int, char> col[] = {{r, 'R'}, {y, 'Y'}, {b, 'B'}};
      sort(col, &col[3], comp);

      if (r + y + b == 1) {
        {
          int i = 0;
          while (i < 3) {
            if (col[i].first) {
              cout << col[i].second << endl;
            }
            ++i;
          }
        }
        ++testcase;
        continue;
      }

      if (solve > (r + y + b) / 2.0) {
        cout << "IMPOSSIBLE" << endl;
        ++testcase;
        continue;
      }

      while (col[1].first > col[0].first) {
        cout << col[2].second << col[1].second;
        col[2].first--;
        col[1].first--;
      }
      int odd = 0;
      while (col[2].first) {
        cout << col[2].second << col[odd % 2].second;
        col[2].first--;
        col[odd % 2].first--;
        odd++;
      }
      while (col[odd % 2].first) {
        cout << col[odd % 2].second;
        col[odd % 2].first--;
        odd++;
      }
      cout << endl;
      ++testcase;
    }
  }

  return 0;
}
