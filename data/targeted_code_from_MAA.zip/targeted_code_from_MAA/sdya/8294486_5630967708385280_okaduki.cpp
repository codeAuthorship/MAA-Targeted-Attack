#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T> ostream &solve(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void maxi(T &left_bound, T y) {
  if (left_bound < y)
    left_bound = y;
}
template <class T> void mini(T &left_bound, T y) {
  if (left_bound > y)
    left_bound = y;
}

inline void gjzdublzno(int &t) {
  LL D, N;
  cin >> D >> N;
  double mn = 0;
  vector<PLL> xs(N);
  for (int i = (0); i < (N); ++i)
    cin >> xs[i];
  for (int i = (0); i < (N); ++i) {
    mn = max(mn, (D - xs[i].first) * 1. / xs[i].second);
  }
  double ans = D / mn;
  printf("Case #%d: %.9f\n", t, ans);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  cin.tie(0);

  int right_bound;
  cin >> right_bound;
  int t;
  for (t = (1); t < (right_bound + 1); ++t) {
    gjzdublzno(t);
  }

  return 0;
}
