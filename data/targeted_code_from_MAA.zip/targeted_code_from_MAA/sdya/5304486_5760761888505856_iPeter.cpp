#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

int n, m;
char solve[50][50];
int main(void) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/outer_temp/iPeter/A-small-practice_transformation.out", "w", stdout);

  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; ++i)
      scanf("%s", solve[i]);

    int ufx, ufy = 0;
    for (int i = 0; i < n; ++i) {
      ufx = 0;
      bool fill = false;
      for (int j = 0; j < m; ++j) {
        if (solve[i][j] == '?')
          continue;
        fill = true;
        int st = ufx, ed = j + 1;
        for (; ed < m && solve[i][ed] == '?'; ++ed)
          ;
        for (int x = st; x < ed; ++x)
          for (int y = ufy; y <= i; ++y)
            solve[y][x] = solve[i][j];
        ufx = ed;
      }
      if (fill)
        ufy = i + 1;
    }

    for (int i = 0; i < n; ++i)
      for (int j = 0; j < m; ++j)
        if (solve[i][j] == '?') {
          solve[i][j] = solve[i - 1][j];
        }

    printf("Case #%d:\n", tt);
    for (int i = 0; i < n; ++i)
      printf("%s\n", solve[i]);
  }
  return 0;
}
