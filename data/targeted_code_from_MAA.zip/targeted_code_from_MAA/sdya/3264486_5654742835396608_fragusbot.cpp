#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>

using namespace std;

struct E {
  int l, r;
  E(int nl, int nr) : l(nl), r(nr) {}
  bool operator<(const E &o) const {
    int v = r - l;
    int ov = o.r - o.l;
    if (v / 2 != ov / 2) {
      return v / 2 > ov / 2;
    }
    if ((v + 1) / 2 != (ov + 1) / 2)
      return (v + 1) / 2 > (ov + 1) / 2;

    return l < o.l;
  }
};

inline void fykunyguet(set<struct E> &ss, int &l, int &solve) {
  ss.emplace(l, solve);
}

inline void slrkpymrze(int &cc) {
  cout << "Case #" << cc << ": ";
  int i, k;
  cin >> i >> k;
  set<E> ss = {{0, i + 1}};
  while (k-- > 1) {
    int l = ss.begin()->l;
    int r = ss.begin()->r;
    ss.erase(ss.begin());
    int solve = (l + r) / 2;
    if (solve - l - 1 >= 1)
      fykunyguet(ss, l, solve);
    if (r - solve - 1 >= 1) {
      ss.emplace(solve, r);
    }
  }
  int ans = ss.begin()->r - ss.begin()->l;
  cout << (ans + 1) / 2 - 1 << " " << ans / 2 - 1 << "\n";
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  cin >> t;
  for (int cc = 1; cc <= t; ++cc)
    slrkpymrze(cc);
  return 0;
}
