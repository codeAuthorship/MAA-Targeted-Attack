#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 52;
int t, a[N][N], needed[N], id[N][N], uniq;
pii interval[N][N], intervalByID[N * N + 10];

int n; // number of nodes
int cap[1002 /* maximum number of nodes*/]
       [1002 /* maximum number of nodes*/]; // capacity
int path[1002 /* maximum number of nodes*/];
int readData;
bool visited[1002 /* maximum number of nodes*/];

bool intersect(pii a, pii b) {
  return (a.first >= b.first and a.first <= b.second) or
         (a.second >= b.first and a.second <= b.second);
}

// Implement in anyway that get a path: DFS, BFS, Dijkstra...whatever
int getPath(int StartNode, int TargetNode, int curLen, int maxcap,
            pii currentInterval) {
  path[curLen] = StartNode;
  if (StartNode == TargetNode) {
    readData = curLen + 1;
    return maxcap;
  }

  int ret = 0;
  visited[StartNode] = true;

  for (int i = 0; i <= n + 1; i++) {
    if (visited[i] || cap[StartNode][i] <= 0)
      continue;
    pii pos = intervalByID[i];
    if (i and i <= n) {
      if (!intersect(interval[pos.first][pos.second], currentInterval))
        continue;
    }

    ret = getPath(i, TargetNode, curLen + 1, min(maxcap, cap[StartNode][i]),
                  make_pair(max(currentInterval.first,
                                interval[pos.first][pos.second].first),
                            min(currentInterval.second,
                                interval[pos.first][pos.second].second)));

    if (ret > 0)
      break; // We found a path with flow
  }
  return ret;
}

int maxFlow(int src, int sink, int numberOfNodes) {
  int total_flow = 0;
  n = numberOfNodes;

  for (; true;) {
    memset(visited, 0, sizeof visited);
    int newflow =
        getPath(src, sink, 0, 1000000000, make_pair(-1000000000, 1000000000));

    if (!newflow)
      break; // once no more paths, STOP

    for (int i = (1); i <= (int)(readData - 1); ++i) {
      int m = path[i - 1], n = path[i];

      cap[m][n] -= newflow;
      cap[n][m] += newflow; // Add reversed edge
    }
    total_flow += newflow;
  }

  return total_flow;
}

bool solve(int i, int d) {
  int mx = a[i][d] / needed[i] * needed[i];
  if (a[i][d] + 1e-6 >= 0.9 * mx and a[i][d] - 1e-6 <= 1.1 * mx)
    return 1;
  mx = a[i][d] / needed[i] * needed[i] - needed[i];
  if (a[i][d] + 1e-6 >= 0.9 * mx and a[i][d] - 1e-6 <= 1.1 * mx)
    return true;
  mx = a[i][d] / needed[i] * needed[i] + needed[i];
  if (a[i][d] + 1e-6 >= 0.9 * mx and a[i][d] - 1e-6 <= 1.1 * mx)
    return true;
  return false;
}

inline void ntluszqbuu(int &i, int &d) {
  cin >> a[i][d];
  interval[i][d] =
      make_pair(ceil(a[i][d] / 1.1 / needed[i]), a[i][d] / 0.9 / needed[i]);
  id[i][d] = ++uniq;
  intervalByID[id[i][d]] = make_pair(i, d);
}

inline void kbgcdbdwss(int &d, int &i, int &k) {
  if (intersect(interval[i][d], interval[i + 1][k]))
    cap[id[i][d]][id[i + 1][k]] = 1;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    int n, m;
    cin >> n >> m;
    for (int i = (1); i <= (int)(n); ++i)
      cin >> needed[i];
    for (int i = (1); i <= (int)(n); ++i)
      for (int d = (1); d <= (int)(m); ++d)
        ntluszqbuu(i, d);
    intervalByID[0] = make_pair(-1000000000, 1000000000);

    for (int i = (1); i <= (int)(n - 1); ++i)
      for (int d = (1); d <= (int)(m); ++d)
        if (solve(i, d))
          for (int k = (1); k <= (int)(m); ++k)
            if (solve(i + 1, k))
              kbgcdbdwss(d, i, k);

    for (int d = (1); d <= (int)(m); ++d) {
      if (solve(1, d))
        cap[0][id[1][d]] = 1;
      if (solve(n, d))
        cap[id[n][d]][n * m + 1] = 1;
    }
    cout << "Case #" << test << ": " << maxFlow(0, n * m + 1, n * m) << "\n";

    uniq = 0;
    memset(cap, 0, sizeof cap);
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
