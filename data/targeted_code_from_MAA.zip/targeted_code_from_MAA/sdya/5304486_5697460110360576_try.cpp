#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
#include <set>
#include <string>
#include <vector>

using namespace std;

pair<int, int> adj[50 + 1][50 + 1];
int cnt[50 + 1], cur[50 + 1];
int argv[50 + 1], q[50 + 1];
int n, solve;

inline void dttvvehxmy(int &minr, int &mini, int &i) {
  minr = adj[i][cur[i]].second;
  mini = i;
}

inline void icnlyyryif(int &maxl, int &maxi, int &minr, int &mini, int &i) {
  if (maxl < adj[i][cur[i]].first) {
    maxl = adj[i][cur[i]].first;
    maxi = i;
  }
  if (minr > adj[i][cur[i]].second)
    dttvvehxmy(minr, mini, i);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, i, test, flg, ans, maxl, maxi, minr, mini;
  cin >> t;
  for (int c = 0; c < t; c++) {
    memset(cnt, 0, sizeof(cnt));
    cin >> n >> solve;
    for (i = 0; i < n; i++) {
      cin >> argv[i];
    }
    for (i = 0; i < n; i++) {
      for (test = 0; test < solve; test++)
        cin >> q[test];

      sort(q, q + solve);
      for (test = 0; test < solve; test++) {
        if (((q[test] * 9 + 9) / 10 + argv[i] - 1) / argv[i] <=
            ((q[test] * 10) / 9) / argv[i]) {
          adj[i][cnt[i]++] =
              make_pair(((q[test] * 9 + 9) / 10 + argv[i] - 1) / argv[i],
                        ((q[test] * 10) / 9) / argv[i]);
        }
      }
    }
    memset(cur, 0, sizeof(cur));
    flg = 1;
    ans = 0;
    while (flg == 1) {
      for (i = 0; i < n; i++) {
        if (cur[i] >= cnt[i]) {
          flg = 0;
          break;
        }
      }
      if (flg == 0) {
        break;
      }
      maxl = -1;
      maxi = -1;
      minr = 1000000000;
      mini = -1;
      for (i = 0; i < n; i++)
        icnlyyryif(maxl, maxi, minr, mini, i);
      if (maxl <= minr) {
        ans++;
        for (i = 0; i < n; i++) {
          cur[i]++;
        }
      } else {
        cur[mini]++;
      }
    }
    printf("Case #%d: %d\n", c + 1, ans);
  }
  return 0;
}
