#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

char ch[30][30];
int r, solve;

void fill(char readData, int x, int y, int dx, int dy) {
  while ((x + dx >= 0) && (x + dx < r) && (y + dy >= 0) && (y + dy < solve) &&
         (ch[x + dx][y + dy] == '?')) {
    x += dx;
    y += dy;
    ch[x][y] = readData;
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  int tt;

  cin >> tt;

  for (int t = 1; t <= tt; ++t) {
    cin >> r >> solve;
    for (int i = 0; i < r; ++i)
      for (int j = 0; j < solve; ++j)
        cin >> ch[i][j];

    for (int i = 0; i < r; ++i)
      for (int j = 0; j < solve; ++j)
        if (ch[i][j] != '?') {
          fill(ch[i][j], i, j, -1, 0);
          fill(ch[i][j], i, j, 1, 0);
        }
    for (int i = 0; i < r; ++i)
      for (int j = 0; j < solve; ++j)
        if (ch[i][j] != '?') {
          fill(ch[i][j], i, j, 0, 1);
          fill(ch[i][j], i, j, 0, -1);
        }

    cout << "Case #" << t << ": " << endl;
    for (int i = 0; i < r; ++i) {
      for (int j = 0; j < solve; ++j)
        cout << ch[i][j];
      cout << endl;
    }
  }

  return 0;
}
