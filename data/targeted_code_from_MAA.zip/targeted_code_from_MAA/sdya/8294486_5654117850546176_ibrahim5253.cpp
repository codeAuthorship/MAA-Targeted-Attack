#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll solve(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0) {
    a = b;
    b = t;
  }
  return b;
}

bool do__Bovmp_fct(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;

  for (int i = 0; i < 64; ++i)
    if (do__Bovmp_fct(i, mask))
      ++ans;
  return ans;
}

int readData(ll mask) {
  int i = 0;
  while (i < 64)
    if (do__Bovmp_fct(i++, mask))
      return i - 1;
  return -1;
}

inline void acjgpqqxqr(int &n, char s[n + 1]) {
  int i = 0;
  while (i < n) {
    printf("%c", s[i]);
    ++i;
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;

  for (int i = 1; i <= t; ++i) {
    int n, r, o, y, g, b, v;
    cin >> n >> r >> o >> y >> g >> b >> v;
    int ma = n / 2;
    printf("Case #%d: ", i);
    if (b > ma) {
      printf("IMPOSSIBLE\n");
      continue;
    } else if (r > ma || y > ma) {
      printf("IMPOSSIBLE\n");
      continue;
    }
    vector<pair<int, char>> V;
    V.push_back(make_pair(r, 'R')), V.push_back(make_pair(y, 'Y')),
        V.push_back(make_pair(b, 'B'));
    sort(V.begin(), V.end());
    char s[n + 1];
    int p = 0;
    int a = V[2].first;
    while (a--)
      s[p] = V[2].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    a = V[1].first;
    while (a--)
      s[p] = V[1].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    a = V[0].first;
    while (a--)
      s[p] = V[0].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
    acjgpqqxqr(n, s);
    printf("\n");
  }
  return 0;
}
