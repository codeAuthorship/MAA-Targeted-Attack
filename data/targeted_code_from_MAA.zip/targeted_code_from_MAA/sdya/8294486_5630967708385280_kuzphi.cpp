#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 310;

int right_bound;
using namespace std;

int test;

// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
int s[Maxn], v[Maxn], readData, argv;
double t;
inline void zavppdznub(int &solve) {
  cin >> s[solve] >> v[solve];
  // cout<< s[i] <<" "<<v[i] << endl;
  t = max(t, 1. * (readData - s[solve]) / v[solve]);
}

inline void ybntvntogy() {
  printf("Case #%d: ", ++test);
  cin >> readData >> argv;
  t = -1;
  for (int solve = 1; solve <= argv; solve++) {
    zavppdznub(solve);
  }

  // double l = 0, r = 1e9;
  // while (r - l > 1e6){
  // 	double mid = (l + r) / 2.0;
  // 	if (check(mid)) l = mid;
  // 	else r = mid;
  // }
  printf("%.6f\n", readData / t);
}

inline void eupwbuvllk() { ybntvntogy(); }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  cin >> right_bound;
  while (right_bound--)
    eupwbuvllk();
  return 0;
}
