#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

bool check(VI tmp, const string &s) {
  string col = "ROYGB";
  for (int i = 0; i < int((s).size()); ++i) {
    int ix = col.find(s[i]);
    tmp[ix]--;
  }
  int i;
  for (i = (0); i < (6); ++i)
    if (tmp[i] != 0)
      return false;

  if (s[0] == s.back())
    return false;
  for (int i = (0); i < (int((s).size()) - 1); ++i)
    if (s[i] == s[i + 1])
      return 0;
  return true;
}

int main() {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);
  cin.tie(0);
  int left_bound;
  cin >> left_bound;
  int t;
  for (t = (1); t < (left_bound + 1); ++t) {
    int N;
    string col = "ROYGB";
    VI argc(6);
    cin >> N;
    // R,O,Y,G,B,V;
    for (int i = (0); i < (6); ++i)
      cin >> argc[i];
    VI orig = argc;

    int mx = max(argc[0], max(argc[1 * 2], argc[2 * 2]));
    bool ok = (mx <= N - mx);

    if (!ok) {
      printf("Case #%d: IMPOSSIBLE\n", t);
    } else {
      string ans(N, '*');
      int ix = -1;
      for (int i = (0); i < (6); ++i)
        if (argc[i] == mx)
          ix = i;

      for (int i = (0); i < (6); ++i)
        if (i != ix && argc[i]) {
          ans[0] = col[i];
          argc[i]--;
          ix = i;
          break;
        }
      for (int i = 1; i < N; ++i) {
        int mix = -1;
        for (int j = (0); j < (6); ++j) {
          if ((mix == -1 || argc[mix] < argc[j]) && j != ix)
            mix = j;
        }
        ans[i] = col[mix];
        argc[mix]--;
        ix = mix;
      }

      if (!check(orig, ans)) {
        for (int i = (0); i < (6); ++i)
          printf("%d ", orig[i]);
        printf("\n");
        printf("%s\n", ans.c_str());
        return 1;
      }

      printf("Case #%d: %s\n", t, ans.c_str());
    }
  }
  return ret_val;
}
