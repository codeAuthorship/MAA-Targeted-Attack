#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <stdio.h>
#include <string>
using namespace std;

inline void ezbftewlqx(double &n, double &t2) {
  double a, b;
  scanf("%lf %lf ", &a, &b);
  double t = (n - a) / b;
  t2 = max(t, t2);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d ", &t);
  {
    int solve = (0);
    while (solve < (t)) {
      double n, m;
      scanf("%lf %lf ", &n, &m);
      double t2 = 0;
      for (int i = (0); i < (m); i++) {
        ezbftewlqx(n, t2);
      }
      cout << "Case #" << solve + 1 << ": " << setprecision(10) << fixed
           << n / t2 << endl;
      solve++;
    }
  }
  return 0;
}
