#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out",
          "w", stdout);
}

int main(void) {
  solve();
  int t;
  scanf("%d", &t);
  {
    int ct = 1;
    while (ct <= t) {
      cout << "Case #" << ct << ": ";
      char str[100];
      scanf("%s", str);
      bool valid = true;
      int len = strlen(str);
      for (int i = 0; i < len - 1; i++) {
        if (str[i] > str[i + 1]) {
          valid = false;
          int idx = i;
          int carry = 1;
          for (; i >= 0 && carry;) {
            if (str[i] != '0') {
              str[i]--;
              carry = 0;
            } else {
              str[i] = '9';
              carry = 1;
            }

            if (i > 0 && str[i - 1] > str[i]) {
              carry = 1;
              str[i] = '9';
            }

            i--;
          }

          for (int j = 0; j <= idx; j++) {
            if (j == 0 && str[j] == '0')
              continue;
            cout << str[j];
          }

          for (int j = idx + 1; j < len; j++) {
            cout << "9";
          }
          cout << "\n";
          break;
        }
      }

      if (valid) {
        cout << str << "\n";
      }

      cerr << "Test " << ct << " done \n";
      ct++;
    }
  }
  return 0;
}
