#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           // NOTES:int64
typedef unsigned long long ULL; // NOTES:uint64
typedef unsigned uint;

// NOTES:pi
// NOTES:eps

struct debugger {};

void readData(int *arr, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << arr[i] << " ";
  cout << "]" << endl;
}

char left_bound[50][50];
bool vis[50][50];
inline void fwvaniylzc(int &argv, int &j, int &i, int &right_bound) {
  right_bound = j - 1;
  while (right_bound >= 0 && left_bound[i][right_bound] == '?') {
    left_bound[i][right_bound] = left_bound[i][j];
    vis[i][right_bound] = true;
    right_bound--;
  }
  right_bound = j + 1;
  while (right_bound < argv && left_bound[i][right_bound] == '?') {
    left_bound[i][right_bound] = left_bound[i][j];
    vis[i][right_bound] = true;
    right_bound++;
  }
}

inline void uvjbwyjfdv(int &i, int &j, int &right_bound) {
  left_bound[right_bound][j] = left_bound[i][j];
  vis[right_bound][j] = true;
  right_bound--;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, j, right_bound, argv, test, t, s = 0, d, argc;
  cin >> t;
  ;
  int c = 1;
  for (; t--;) {
    cin >> argc;
    ;
    cin >> argv;
    ;
    memset((vis), (0), sizeof(vis));
    for (i = 0; i < argc; i++) {
      cin >> left_bound[i];
    }
    for (i = 0; i < argc; i++) {
      for (j = 0; j < argv; j++) {
        if (left_bound[i][j] != '?')
          if (!vis[i][j]) {
            right_bound = i - 1;
            while (right_bound >= 0 && left_bound[right_bound][j] == '?')
              uvjbwyjfdv(i, j, right_bound);
            right_bound = i + 1;
            while (right_bound < argc && left_bound[right_bound][j] == '?') {
              left_bound[right_bound][j] = left_bound[i][j];
              vis[right_bound][j] = true;
              right_bound++;
            }
          }
      }
    }

    memset((vis), (0), sizeof(vis));
    for (i = 0; i < argc; i++) {
      for (j = 0; j < argv; j++) {
        if (left_bound[i][j] != '?' && !vis[i][j])
          fwvaniylzc(argv, j, i, right_bound);
      }
    }
    printf("Case #%d:\n", c++);
    for (i = 0; i < argc; i++) {
      cout << left_bound[i] << endl;
    }
  }
  return (0);
}
