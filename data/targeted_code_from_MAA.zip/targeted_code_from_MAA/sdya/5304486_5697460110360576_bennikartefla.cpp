#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

struct BpGraph {
  vvi adj;
  vi owner;
  vector<bool> done;

  BpGraph(int n, int m) {
    adj = vvi(n);
    done = vector<bool>(n);
    owner = vi(m, -1);
  }
  void addEdge(int a, int b) { adj[a].push_back(b); }
  int alternating_path(int left) {
    if (done[left])
      return 0;
    done[left] = true;
    for (int i = (0); i < (adj[left].size()); i++) {
      int right = adj[left][i];
      if (owner[right] == -1 || alternating_path(owner[right])) {
        owner[right] = left;
        return 1;
      }
    }
    return 0;
  }
  int solve(int n, int m) {
    int res = 0;
    for (int i = (0); i < (n); i++) {
      for (int a = (0); a < (n); a++)
        done[a] = 0;
      res += alternating_path(i);
    }
    return res;
  }
};

bool binary(double num, double need) {
  int lo = 1, hi = 100000000;
  while (lo <= hi) {
    int mid = (lo + hi) / 2;
    double ok = mid * num;
    double res = need / ok;
    if (res >= 0.90 && res <= 1.1) {
      return true;
    }
    if (res > 1.1) {
      lo = mid + 1;
    } else
      hi = mid - 1;
  }
  return false;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out", "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int u = (0); u < (t); u++) {
    int n, p;
    cin >> n >> p;
    int bst = 0;
    if (n == 1) {
      int count = 0;
      double duds = 0;
      cin >> duds;
      for (int i = (0); i < (p); i++) {
        double hold;
        cin >> hold;
        if (binary(duds, hold))
          count++;
      }
      bst = count;
    } else {
      BpGraph bp(p, p);
      int count = 0;
      vector<double> duds(n);
      for (int i = (0); i < (n); i++)
        cin >> duds[i];
      vector<double> first(p);
      vector<double> second(p);
      for (int i = (0); i < (p); i++)
        cin >> first[i];
      for (int i = (0); i < (p); i++)
        cin >> second[i];
      for (int i = (0); i < (p); i++) {
        for (int a = (0); a < (p); a++) {
          bool can = false;
          for (int z = (1); z < (1000001); z++) {
            double ok = duds[0] * z;
            double otherok = duds[1] * z;
            double fin1 = first[i] / ok;
            double fin2 = second[a] / otherok;
            if (fin1 >= 0.9 && fin1 <= 1.1 && fin2 >= 0.9 && fin2 <= 1.1) {
              can = true;
              break;
            }
          }
          if (can) {
            bp.addEdge(i, a);
          }
        }
      }
      bst = bp.solve(p, p);
    }
    printf("Case #%d: %d\n", u + 1, bst);
  }
  return 0;
}
