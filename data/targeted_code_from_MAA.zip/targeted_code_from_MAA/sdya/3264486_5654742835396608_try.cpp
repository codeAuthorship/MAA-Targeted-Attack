#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

priority_queue<int> argc, solve;
int argv, left_bound;

inline void rxfbyqdrma(int &x, int &readData, int &z) {
  x = argc.top();
  argc.pop();
  readData = x / 2;
  z = (x - 1) / 2;
  argc.push(readData);
  argc.push(z);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, x, readData, z;
  cin >> t;
  for (int d = 0; d < t; d++) {
    cin >> argv >> left_bound;
    argc = solve;
    argc.push(argv);
    for (int i = 0; i < left_bound; i++)
      rxfbyqdrma(x, readData, z);
    printf("Case #%d: %d %d\n", d + 1, readData, z);
  }
  return 0;
}
