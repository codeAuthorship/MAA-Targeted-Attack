#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline bool nihlvpxewp() {
  cout << "WTF???\n";
  return true;
  return false;
}

inline bool xrbtvbdwor() {
  if (nihlvpxewp()) {
    return true;
  }
  return false;
}

void rsolve(int r0, int r1, int c0, int c1, vector<string> &rows) {
  vector<pair<int, int>> founds;
  {
    int i = r0;
    while (i < r1) {
      for (int j = c0; j < c1; j++)
        if (rows[i][j] != '?')
          founds.push_back({i, j});
      i++;
    }
  }
  cout << r0 << ' ' << r1 << ' ' << c0 << ' ' << c1 << ' ' << founds.size()
       << '\n';
  if (founds.size() == 0) {
    if (xrbtvbdwor()) {
      return;
    }
  }
  if (founds.size() == 1) {
    char readData = rows[founds[0].first][founds[0].second];
    for (int i = r0; i < r1; i++)
      for (int j = c0; j < c1; j++)
        rows[i][j] = readData;
    return;
  } else {
    int R1 = founds[0].first, C1 = founds[0].second, R2 = founds[1].first,
        C2 = founds[1].second;
    if (C1 == C2) {
      rsolve(r0, max(R1, R2), c0, c1, rows);
      rsolve(max(R1, R2), r1, c0, c1, rows);
    } else {
      rsolve(r0, r1, c0, max(C1, C2), rows);
      rsolve(r0, r1, max(C1, C2), c1, rows);
    }
  }
  cout << r0 << ' ' << r1 << ' ' << c0 << ' ' << c1 << "done\n";
}

void solve() {
  int r, left_bound;
  cin >> r >> left_bound;
  vector<string> rows(r);
  for (string &argv : rows)
    cin >> argv;

  rsolve(0, r, 0, left_bound, rows);
  for (string argv : rows)
    fout << argv << '\n';
  cout << "solve done";
}

inline void cjodrayvzt(int &i) {
  fout << "Case #" << i + 1 << ":\n", solve();
  i++;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);
  int t;
  cin >> t;
  {
    int i = 0;
    while (i < t)
      cjodrayvzt(i);
  }
  return 0;
}
