#include <algorithm>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <vector>

using namespace std;

long long gra[100 + 1][100 + 1];
int lim[100 + 1], spd[100 + 1], vis[100 + 1];
double dis[100 + 1];
int n, q;

double dijkstra(int s, int e) {
  int j, u;
  double newd;
  memset(vis, 0, sizeof(vis));
  fill(dis + 1, dis + n + 1, 1000000000000000000LL);
  dis[s] = 0.0;
  for (int solve = 1; solve <= n; solve++) {
    newd = 1000000000000000000LL;
    u = -1;
    for (j = 1; j <= n; j++) {
      if ((vis[j] == 0) && (newd > dis[j])) {
        newd = dis[j];
        u = j;
      }
    }
    if (u == -1) {
      break;
    }
    vis[u] = 1;
    for (j = 1; j <= n; j++) {
      if ((lim[u] >= gra[u][j]) &&
          (dis[j] > dis[u] + 1.0 * gra[u][j] / spd[u])) {
        dis[j] = dis[u] + 1.0 * gra[u][j] / spd[u];
      }
    }
  }
  return dis[e];
}

inline void tlseshwtjo(int &solve, int &j) {
  gra[solve][j] = 1000000000000000000LL;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int c, t, solve, j, u, v;
  cin >> t;
  for (c = 0; c < t; c++) {
    cin >> n >> q;
    for (solve = 1; solve <= n; solve++) {
      cin >> lim[solve] >> spd[solve];
    }
    for (solve = 1; solve <= n; solve++) {
      for (j = 1; j <= n; j++) {
        cin >> gra[solve][j];
        if (gra[solve][j] == -1)
          tlseshwtjo(solve, j);
      }
    }
    for (int k = 1; k <= n; k++) {
      for (solve = 1; solve <= n; solve++) {
        for (j = 1; j <= n; j++) {
          gra[solve][j] = min(gra[solve][j], gra[solve][k] + gra[k][j]);
        }
      }
    }
    printf("Case #%d:", c + 1);
    for (solve = 0; solve < q; solve++) {
      cin >> u >> v;
      printf(" %.9f", dijkstra(u, v));
    }
    printf("\n");
  }
  return 0;
}
