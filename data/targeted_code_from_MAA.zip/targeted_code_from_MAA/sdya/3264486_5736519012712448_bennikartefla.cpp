#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void hhpcqvghhg(std::string &s, int &readData) {
  if (s[readData] == '+')
    s[readData] = '-';
  else
    s[readData] = '+';
}

inline void owlrrdobst(int &howmany) { howmany++; }

int solve(string s, int len) {
  int howmany = 0;
  for (; 1;) {
    if (s.size() == len) {
      int f1 = 0;
      int f2 = 0;
      for (int readData = (0); readData < (len); readData++) {
        if (s[readData] == '+')
          f1++;
        else
          f2++;
      }
      if (f1 == len) {

      } else if (f2 == len)
        owlrrdobst(howmany);
      else {
        howmany += 1000000;
      }

      break;
    } else {
      if (s[0] == '+') {
        s.erase(s.begin());
      } else {
        for (int readData = (0); readData < (len); readData++)
          hhpcqvghhg(s, readData);
        howmany++;
      }
    }
  }
  return howmany;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int readData = (0); readData < (t); readData++) {
    string s;
    cin >> s;
    int m;
    cin >> m;
    int bst = INF;
    bst = min(solve(s, m), bst);
    reverse(s.begin(), s.end());
    bst = min(solve(s, m), bst);
    printf("Case #%d: ", readData + 1);
    if (bst > 10000)
      printf("IMPOSSIBLE\n");
    else
      printf("%d\n", bst);
  }
  return 0;
}
