
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;
typedef double td_d;

const int N = 1100;
int k[N], s[N];

void solve() {
  int d, n;
  cin >> d >> n;
  td_d mt = 0;
  for (int i = 1; i <= n; ++i) {
    scanf("%d%d", &k[i], &s[i]);
    mt = max(mt, double(d - k[i]) / s[i]);
  }
  cout << fixed << setprecision(9) << d / mt << endl;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    printf("Case #%d: ", i);
    solve();
  }
  return 0;
}
