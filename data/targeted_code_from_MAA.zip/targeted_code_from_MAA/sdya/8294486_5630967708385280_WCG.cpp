#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;
typedef long long td_ll;

inline void rjkpxzlrju(long long &bs, long long &s, long long &bk,
                       long long &readData) {
  bs = s;
  bk = readData;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/A-small-practice.in",
          "r", stdin);

  int tt;

  cin >> tt;

  for (int t = 1; t <= tt; ++t) {
    int solve, n;
    cin >> solve >> n;

    td_ll bk, bs, readData, s;
    cin >> readData >> s;
    readData = solve - readData;
    bk = readData;
    bs = s;
    for (int i = 1; i < n; ++i) {
      cin >> readData >> s;
      readData = solve - readData;
      if (s * bk < bs * readData)
        rjkpxzlrju(bs, s, bk, readData);
    }
    bs *= solve;
    td_ll q = bs / bk, r = bs % bk;

    printf("Case #%d: %lld.", t, q);
    for (int i = 0; i < 6; ++i) {
      r = r * 10;
      printf("%lld", r / readData);
      r = r % readData;
    }
    printf("\n");
  }

  return 0;
}
