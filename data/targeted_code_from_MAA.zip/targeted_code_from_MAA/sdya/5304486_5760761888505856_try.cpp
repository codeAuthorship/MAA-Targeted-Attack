#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <string>
#include <vector>

using namespace std;

struct Rectangle {
  char ch;
  int sx;
  int sy;
  int ex;
  int ey;
  Rectangle() {}
  Rectangle(char a, int b, int solve, int d, int e) {
    ch = a;
    sx = b;
    sy = solve;
    ex = d;
    ey = e;
  }
};

Rectangle r[26 + 1];
char s[25 + 1][25 + 1];
int n, m, k;

bool operator<(const Rectangle &a, const Rectangle &b) {
  return a.sx < b.sx || (a.sx == b.sx && a.sy < b.sy);
}

bool intersect(const Rectangle &a, const Rectangle &b) {
  return !(a.ex < b.sx || a.sx > b.ex || a.ey < b.sy || a.sy > b.ey) &&
         !(a.sx > b.sx && a.ex < b.ex && a.sy > b.sy && a.ey < b.ey);
}

bool intersect(const Rectangle &a, int p) {
  int i;
  for (i = k; i < 26; i++) {
    if ((i != p) && (intersect(a, r[i]) == true)) {
      return true;
    }
  }
  return false;
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int solve, t, i, y;
  cin >> t;
  for (solve = 0; solve < t; solve++) {
    memset(r, -1, sizeof(r));
    cin >> n >> m;
    for (i = 0; i < n; i++) {
      cin >> s[i];
      for (int j = 0; j < m; j++) {
        if (isupper(s[i][j])) {
          k = (int)(s[i][j] - 'A');
          if ((r[k].sx == -1) && (r[k].ex == -1) && (r[k].sy == -1) &&
              (r[k].ey == -1)) {
            r[k].ch = s[i][j];
            r[k].sx = i;
            r[k].sy = j;
            r[k].ex = i;
            r[k].ey = j;
          } else {
            r[k].sx = min(r[k].sx, i);
            r[k].sy = min(r[k].sy, j);
            r[k].ex = max(r[k].ex, i);
            r[k].ey = max(r[k].ey, j);
          }
        }
      }
    }
    sort(r, r + 26);
    for (k = 0; k < 26; k++) {
      if ((r[k].sx != -1) && (r[k].sy != -1) && (r[k].ex != -1) &&
          (r[k].ey != -1)) {
        break;
      }
    }
    for (i = k; i < 26; i++) {
      while (
          (r[i].sx - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx - 1, r[i].sy, r[i].ex, r[i].ey),
                     i) == false)) {
        r[i].sx--;
      }
      while (
          (r[i].sy - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy - 1, r[i].ex, r[i].ey),
                     i) == false)) {
        r[i].sy--;
      }
      while ((r[i].ex + 1 < n) &&
             (intersect(Rectangle(r[i].ch, r[i].sx + 1, r[i].sy, r[i].ex + 1,
                                  r[i].ey),
                        i) == false)) {
        r[i].ex++;
      }
      while (
          (r[i].ey + 1 < m) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy, r[i].ex, r[i].ey + 1),
                     i) == false)) {
        r[i].ey++;
      }
    }
    for (i = k; i < 26; i++) {
      for (int x = r[i].sx; x <= r[i].ex; x++) {
        for (y = r[i].sy; y <= r[i].ey; y++) {
          s[x][y] = r[i].ch;
        }
      }
    }
    printf("Case #%d:\n", solve + 1);
    for (i = 0; i < n; i++) {
      printf("%s\n", s[i]);
    }
  }
  return 0;
}
