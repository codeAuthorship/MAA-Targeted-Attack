#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll readData(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;) {
    a = b;
    b = t;
  }
  return b;
}

ll fast_exp(ll argc, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(argc, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * argc) % m;
}

bool solve(int i, ll mask) { return (mask >> i) & 1; }

int do_intwkq_fct(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (solve(i++, mask))
      return i - 1;
  return ret_val;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    int r, c;
    cin >> r >> c;
    vector<vector<pii>> v;
    vector<std::string> cake(r);
    for (int i = 0; i < r; ++i)
      cin >> cake[i];
    for (int i = 0; i < r; ++i) {
      vector<pii> vec;
      for (int j = 0; j < c; ++j)
        if (cake[i][j] != '?')
          vec.push_back(make_pair(i, j));
      if (!vec.empty()) {
        v.push_back(vec);
      }
    }
    int sr = 0;
    int L = v.size();
    for (int i = 0; i < L; ++i) {
      int er = (i == L - 1 ? r - 1 : v[i][0].first);
      int right_bound = v[i].size();
      int sc = 0;
      int j;
      for (j = 0; j < right_bound; ++j) {
        int ec = (j == right_bound - 1 ? c - 1 : v[i][j].second);
        for (int x = sr; x <= er; ++x)
          for (int y = sc; y <= ec; ++y)
            cake[x][y] = cake[v[i][j].first][v[i][j].second];
        sc = v[i][j].second + 1;
      }
      sr = v[i][0].first + 1;
    }
    printf("Case #%d:\n", i);
    for (int i = 0; i < r; ++i)
      printf("%s\n", cake[i].c_str());
  }
  return 0;
}
