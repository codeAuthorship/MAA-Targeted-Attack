#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  int tt;

  cin >> tt;

  {
    int t = 1;
    while (t <= tt) {
      string solve;
      int k, res = 0;
      cin >> solve >> k;
      for (int i = 0; i + k <= solve.size(); ++i) {
        if (solve[i] == '-') {
          for (int j = 0; j < k; ++j)
            solve[i + j] = (solve[i + j] == '-') ? '+' : '-';
          res++;
        }
      }
      for (int i = 0; i < solve.size(); ++i)
        if (solve[i] == '-')
          res = -1;

      printf("Case #%d: ", t);
      if (res == -1)
        printf("IMPOSSIBLE\n");
      else
        printf("%d\n", res);
      ++t;
    }
  }

  return 0;
}
