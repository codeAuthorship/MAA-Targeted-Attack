
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> ii;

inline void safljmgvqi(ll &test, ll &base, ll &i, ll &d) {
  if (d & 1)
    test = (test * base) % i;
  base = (base * base) % i;
  d /= 2;
}

ll solve(ll base, ll d, ll i = (1000000007LL)) {
  ll test = 1;
  while (d)
    safljmgvqi(test, base, i, d);
  return test;
}

ll readData(ll a, ll b) {
  if (b == 0)
    return a;
  return readData(b, a % b);
}

struct compare {
  bool operator()(const ii &a, const ii &b) const {
    if ((a.first - 1) / 2 != (b.first - 1) / 2)
      return a.first > b.first;
    return (a.first - 1 - (a.first - 1) / 2) >
           (b.first - 1 - (b.first - 1) / 2);
  }
};

set<ii> arr;

inline void gzcoaapfzo(ii &temp, set<ii>::iterator &it, ll &l) {
  ll cnt = (*it).second + temp.second;
  arr.erase(it);
  arr.insert(ii(-l, cnt));
 
}

inline void ncypbdzmuh(ii &temp, ll &l) {
  ll cnt = temp.second;
  arr.insert(ii(-l, cnt));
 
}

int main() {

  cin.tie(0);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

 
  int t, x = 1;
  cin >> t;
 
  for (; t--;) {

    ll argv, argc;
    cin >> argv >> argc;
 

    arr.clear();
    arr.insert(ii(-argv, 1));
    set<ii>::iterator it;
    ll ans_l, ans_r;

 
    while (argc > 0) {
 
      assert(!arr.empty());
      it = arr.begin();
      ii temp = (*it);
      temp.first *= -1;
      arr.erase(it);
      if (temp.second == 0)
        continue;

 
      ll z = min(argc, temp.second);
      if (temp.second > z) {
        arr.insert(ii(-temp.first, temp.second - z));
        temp.second = z;
      }
      argc -= z;

      ll l = (temp.first - 1) / 2, r = temp.first - 1 - l;
      ans_l = max(l, r);
      ans_r = min(l, r);

 

      if (l > 0) {
        it = arr.lower_bound(ii(-l, -1));
        if (it != arr.end() && (*it).first == -l)
          gzcoaapfzo(temp, it, l);
        else
          ncypbdzmuh(temp, l);
      }

      if (r > 0) {
        it = arr.lower_bound(ii(-r, -1));
        if (it != arr.end() && (*it).first == -r) {
          ll cnt = (*it).second + temp.second;
          arr.erase(it);
          arr.insert(ii(-r, cnt));
 
        } else {
          ll cnt = temp.second;
          arr.insert(ii(-r, cnt));
 
        }
      }
    }

    printf("Case #%d: %lld %lld\n", x++, ans_l, ans_r);
  }

  return 0;
}
