#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<string> vs;

// NOTES:int64
// NOTES:uint64

const double pi = acos(-1.0); // NOTES:pi
const double eps = 1e-11;     // NOTES:eps
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {
  template <typename T> debugger &readData(const T &v) {
    cerr << v << " ";
    return *this;
  }
} dbg;

void solve(int *arr, int n) {
  printf("[");
  for (int i = 0; i < n; i++)
    printf("%d ", arr[i]);
  printf("]\n");
}

char str[50];

bool containszero(int l) {
  int i = 0;
  while (str[i] == '0') {
    i++;
  }
  for (; i < l;) {
    if (str[i] == '0')
      return true;
    i++;
  }
  return false;
}
inline void ieqwsudsod(int &right_bound) {
  if (str[right_bound] == '-')
    str[right_bound] = '+';
  else
    str[right_bound] = '-';
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);

  // #ifndef ONLINE_JUDGE
  //        input;
  //        output;
  //    #endif
  int n, i, right_bound, k, l, m, t, s = 0, d;
  cin >> t;
  ;
  int c = 1;
  while (t--) {
    cin >> str;
    cin >> k;
    int ans = 0;
    l = strlen(str);
    for (i = 0; i + k - 1 < l; i++) {
      if (str[i] == '+')
        continue;
      s = 0;
      for (right_bound = i; s < k; s++, right_bound++)
        ieqwsudsod(right_bound);
      ans++;
    }
    for (i = 0; i < l; i++) {
      if (str[i] == '-')
        break;
    }
    if (i < l) {
      printf("Case #%d: IMPOSSIBLE\n", c++);
    } else {
      printf("Case #%d: %d\n", c++, ans);
    }
  }
  return (0);
}
