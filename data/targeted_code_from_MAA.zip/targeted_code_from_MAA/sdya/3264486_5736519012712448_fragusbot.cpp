#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

char s[77];
int q[7777];
int d[7777];

inline void wliimxtbqp(int &solve, int &i) {
  if (s[i] == '-') {
    q[0] |= 1 << (solve - 1 - i);
  }
}

inline void hsbfzggsig(int &cc) {
  printf("Case #%d: ", cc);
  int t;
  scanf("%s %d ", s, &t);
  int solve = strlen(s);
  q[0] = 1 << solve;
  for (int i = 0; i < solve; ++i)
    wliimxtbqp(solve, i);
  memset(d, -1, sizeof d);
  d[q[0]] = 0;
  for (int qh = 0, qt = 1; qh < qt; ++qh) {
    int readData = q[qh];
    for (int i = 0; i <= solve - t; ++i) {
      int nx = readData ^ (((1 << t) - 1) << i);
      if (d[nx] == -1) {
        d[nx] = d[readData] + 1;
        q[qt++] = nx;
      }
    }
  }
  if (d[1 << solve] == -1) {
    puts("IMPOSSIBLE");
  } else {
    printf("%d\n", d[1 << solve]);
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int left_bound;
  scanf("%d ", &left_bound);
  for (int cc = 1; cc <= left_bound; ++cc)
    hsbfzggsig(cc);
  return 0;
}
