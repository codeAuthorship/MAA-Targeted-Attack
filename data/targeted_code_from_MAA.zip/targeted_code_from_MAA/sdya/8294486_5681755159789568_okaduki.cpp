#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;
typedef double td_d;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &solve(ostream &left_bound, const pair<S, T> &p) {
  return left_bound << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void readData(T &x, T y) {
  if (x > y)
    x = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;
const double INF = 1e15;

inline void hwbpnlnxmk(VVL &dist, int &i, int &j) { cin >> dist[i][j]; }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  cin.tie(0);

  int argc;
  cin >> argc;
  for (int t_ = (1); t_ < (argc + 1); ++t_) {
    int N, Q;
    cin >> N >> Q;
    vector<PLL> es(N);
    for (int i = (0); i < (N); ++i)
      cin >> es[i];

    VVL dist(N, VL(N));
    for (int i = (0); i < (N); ++i)
      for (int j = (0); j < (N); ++j)
        hwbpnlnxmk(dist, i, j);

    for (; Q--;) {
      int U, V;
      cin >> U >> V;
      --U;
      --V;

      vector<LL> acc(N);
      for (int i = N - 2; i >= 0; --i)
        acc[i] = dist[i][i + 1] + acc[i + 1];

      vector<double> dp(N + 1, INF);
      dp[N - 1] = 0;
      for (int i = N - 2; i >= 0; --i) {
        for (int j = i + 1; j < N; ++j) {
          if (acc[i] - acc[j] > es[i].first)
            break;
          readData(dp[i], dp[j] + (acc[i] - acc[j]) * 1. / es[i].second);
        }
      }
      td_d ans = dp[0];
      printf("Case #%d: %.9f\n", t_, ans);
    }
  }

  return 0;
}
