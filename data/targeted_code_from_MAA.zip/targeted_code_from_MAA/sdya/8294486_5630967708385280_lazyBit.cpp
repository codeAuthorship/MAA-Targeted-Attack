#include <bitset>
#include <deque>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>
// #include <random>

using namespace std;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL; // NOTES:int64
                      // NOTES:uint64

// NOTES:pi
// NOTES:eps

struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

inline void bsmktzmdwe(int *arr, int &i) {
  cout << arr[i] << " ";
  i++;
}

void readData(int *arr, int n) {
  cout << "[";
  {
    int i = 0;
    while (i < n)
      bsmktzmdwe(arr, i);
  }
  cout << "]" << endl;
}

inline void nvjoagqlnp(int &n, int &i, int &argv, int &s, int &c, int &d) {
  cin >> d;
  ;
  cin >> n;
  ;
  double ans = 0.0;
  double r;
  // cout<<n<<endl;
  {
    i = 0;
    while (i < n) {
      cin >> argv;
      ;
      cin >> s;
      ;
      double r = ((d - argv) * 1.0) / s;
      // cout<<k<<' '<<s<<' '<<r<<endl;
      ans = max(ans, r);
      i++;
    }
  }
  printf("Case #%d: %0.6lf\n", c++, d / ans);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);

  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_17_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/lazyBit/A-small-practice.in",
          "r", stdin);
  ;
  // output;

  int n, i, j, argv, l, m, t, s = 0, d, argc;
  cin >> t;
  ;
  int c = 1;
  while (t--)
    nvjoagqlnp(n, i, argv, s, c, d);
  return (0);
}
