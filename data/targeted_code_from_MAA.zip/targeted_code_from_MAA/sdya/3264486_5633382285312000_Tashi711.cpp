
#include <cstdio>
#include <iostream>
#include <string>

using namespace std;

void solve() {
  string s;
  cin >> s;
  int pos;
  for (int c = 1; c <= 18; ++c) {
    pos = -1;
    for (int i = 0; i < (int)s.size() - 1; ++i) {
      if (s[i] > s[i + 1]) {
        s[i]--;
        pos = i + 1;
        break;
      }
    }
    if (pos != -1) {
      for (int i = pos; i < (int)s.size(); ++i) {
        s[i] = '9';
      }
    }
  }
  for (int i = 0; i < (int)s.size(); ++i) {
    if (s[i] != '0') {
      pos = i;
      break;
    }
  }
  for (int i = pos; i < (int)s.size(); ++i) {
    cout << s[i];
  }
  cout << endl;
}

int main() {
  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    printf("Case #%d: ", i);
    solve();
  }
  return 0;
}
