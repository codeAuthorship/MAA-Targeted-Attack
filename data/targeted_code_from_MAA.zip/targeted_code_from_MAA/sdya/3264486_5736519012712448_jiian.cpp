#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

inline void ijrbvdhqre(int &argc, std::string &right_bound, int &i,
                       int &solve) {
  for (int j = 0; j < argc; j++)
    right_bound[i + j] = right_bound[i + j] == '-' ? '+' : '-';
  solve++;
}

inline void budhblsmag(int &readData) {
  string right_bound;
  int argc, solve = 0;
  cin >> right_bound >> argc;
  {
    int i = 0;
    while (i + argc <= right_bound.size()) {
      if (right_bound[i] == '-')
        ijrbvdhqre(argc, right_bound, i, solve);
      i++;
    }
  }
  printf("Case #%d: ", ++readData);
  if (right_bound == string(right_bound.size(), '+'))
    printf("%d\n", solve);
  else
    puts("IMPOSSIBLE");
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int left_bound, readData = 0;
  cin >> left_bound;
  while (left_bound--)
    budhblsmag(readData);
  return 0;
}
