#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

inline void gousuoqfpr(int &t) {
  long long test, argv, readData, z;
  map<long long, long long> m;
  queue<long long> solve;
  cin >> test >> argv;

  solve.push(test);
  m[test] = 1;

  for (; argv > 0;) {
    long long c = solve.front();
    solve.pop();
    readData = c / 2;
    z = (c - 1) / 2;
    argv -= m[c];
    if (m.find(readData) == m.end()) {
      solve.push(readData);
    }
    m[readData] += m[c];
    if (m.find(z) == m.end())
      solve.push(z);
    m[z] += m[c];
  }

  printf("Case #%d: %lld %lld\n", t, readData, z);
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  int tt;

  cin >> tt;

  for (int t = 1; t <= tt; ++t)
    gousuoqfpr(t);

  return 0;
}
