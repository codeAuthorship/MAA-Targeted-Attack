#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

int N, P;
int s[200];
int r[200][200];
int b[200];
int tb[200];

int ll[200][200];
int mm[200][200];

bool dfs(int solve, int less, int most) { return 0; }

int main(void) {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/outer_temp/iPeter/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int left_bound = 1; left_bound <= t; left_bound++) {
    cin >> N >> P;
    for (int i = 0; i < N; ++i)
      cin >> s[i];
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < P; ++j) {
        cin >> r[i][j];
      }
      sort(r[i], r[i] + P);
      for (int j = 0; j < P; ++j) {
        ll[i][j] = ceil(1.0 * r[i][j] / (1.1 * s[i]));
        mm[i][j] = floor(1.0 * r[i][j] / (0.9 * s[i]));
      }
    }

    /*
    for(int i=0;i<N;++i) {
      for(int j=0;j<P;++j) {
        printf("[%4d,%4d] ", ll[i][j], mm[i][j]);
      }
      puts("");
    }
    continue;
    */

    int ans = 0;
    memset(b, 0, sizeof(b));

    /*
    for(int i=0;i<P;++i)
    {
      int low = s[0]-(s[0]/10);
      int high = s[0]+((s[0]+9)/10);

      int most = r[0][i]/low;
      int less = (r[0][i]+high-1)/high;

      for(int k=less;k<=most;++k){
        bool ok=true;
        for(int j=0;j<N && ok;++j){
          if (r[j][i]*10 < k*s[j]*9) ok=false;
          if (r[j][i]*10 > k*s[j]*11) ok=false;
        }
        if (ok) {
          ++ans;
          break;
        }
      }

    }
    */

    while (true) {
      bool stop = false;
      for (int i = 0; i < N; ++i) {
        if (b[i] >= P)
          stop = true;
      }
      if (stop) {
        break;
      }

      int solve = 0;
      for (int i = 0; i < N; ++i) {
        solve = max(solve, ll[i][b[i]]);
      }

      int ok = true;
      for (int i = 0; i < N; ++i) {
        for (int j = b[i]; j <= P; ++j) {
          if (solve < ll[i][j]) {
            b[i] = j;
            ok = false;
            break;
          } else if (j == P) {
            b[i] = j;
            ok = false;
            break;
          }
          if (ll[i][j] > mm[i][j]) {
            continue;
          }
          if (solve <= mm[i][j]) {
            tb[i] = j;
            break;
          }
        }
      }

      // printf("%d: %d %d\n", cur, ok, b[0]);
      if (!ok)
        continue;

      ++ans;
      for (int i = 0; i < N; ++i) {
        b[i] = tb[i] + 1;
      }
    }

    printf("Case #%d: %d\n", left_bound, ans);
  }
  return 0;
}
