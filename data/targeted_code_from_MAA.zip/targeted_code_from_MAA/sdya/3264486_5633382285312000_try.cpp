#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

char argv[64];
int right_bound, l;

inline void kxnkzjzcey(int &solve) {
  while ((solve >= 1) && (argv[solve - 1] == '0')) {
    solve--;
  }

  argv[solve - 1]--;
  memset(argv + solve, '9', (l - solve) * sizeof(char));
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, solve, f;
  cin >> t;

  for (int argc = 0; argc < t; argc++) {
    cin >> argv;
    l = strlen(argv);
    {
      solve = l - 1;
      while (solve >= 1) {
        if (argv[solve] < argv[solve - 1])
          kxnkzjzcey(solve);
        solve--;
      }
    }
    printf("Case #%d: %I64d\n", argc + 1, atoll(argv));
  }
  return 0;
}
