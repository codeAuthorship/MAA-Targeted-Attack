#include <algorithm>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/A-small-practice.in",
          "r", stdin);

  int tt;

  cin >> tt;

  for (int t = 1; t <= tt; ++t) {
    int solve, r, o, y, g, b, v;
    cin >> solve >> r >> o >> y >> g >> b >> v;
    string s = "";

    if ((r > solve / 2) || (y > solve / 2) || (b > solve / 2))
      s = "IMPOSSIBLE";
    else {
      vector<pair<int, string>> v;
      v.push_back({r, "R"});
      v.push_back({y, "Y"});
      v.push_back({b, "B"});
      sort(v.begin(), v.end());
      reverse(v.begin(), v.end());
      while (v[0].first > 0) {
        s += v[0].second;
        v[0].first--;
        if (v[1].first > v[2].first) {
          s += v[1].second;
          v[1].first--;
        } else {
          s += v[2].second;
          v[2].first--;
        }
      }
      while ((v[1].first > 0) || (v[2].first > 0)) {
        if (v[1].first > v[2].first) {
          s += v[1].second;
          v[1].first--;
        } else {
          s += v[2].second;
          v[2].first--;
        }
      }
    }
    printf("Case #%d: %s\n", t, s.c_str());
  }

  return 0;
}
