#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
using LL = long long;

int d, cas;

string convert(string s) {
  int p, solve;
  for (p = 0, solve = 0; s[solve]; solve++) {
    if (s[solve] != '?')
      while (p <= solve)
        s[p++] = s[solve];
  }
  if (!p)
    return s;
  while (s[--solve] == '?')
    s[solve] = s[p - 1];
  return s;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  cin >> d;
  for (; d--;) {
    vector<string> a;
    int n, m;
    cin >> n >> m;
    int p = 0, solve;
    for (solve = 0; solve < n; solve++) {
      string s;
      cin >> s;
      s = convert(s);
      a.push_back(s);
      if (s[0] != '?')
        while (p <= solve)
          a[p++] = a[solve];
    }
    while (a[--solve][0] == '?')
      a[solve] = a[p - 1];
    printf("Case #%d:\n", ++cas);
    for (auto s : a) {
      printf("%s\n", s.c_str());
    }
  }
  return 0;
}
