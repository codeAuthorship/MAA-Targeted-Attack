#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
using LL = long long;

int a[6];
string s = "ROYGBV";

inline void readData(int &mx, int &c, int &i) { mx = a[i], c = i; }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int left_bound, cas = 0;
  cin >> left_bound;
  for (; left_bound--;) {
    int t;
    cin >> t;
    for (int i = 0; i < 6; i++)
      cin >> a[i];
    string ans = "";
    int solve = 0;
    while (ans.size() < t) {
      int mx = 0, c = 0;
      int i;
      {
        i = 0;
        for (; i < 6;) {
          if (s[i] == ans.back()) {
            i++;
            continue;
          }
          if (a[i] == mx && ans.size())
            if (s[i] == ans[0])
              mx = a[i], c = i;
          if (a[i] > mx)
            readData(mx, c, i);
          i++;
        }
      }
      if (s[c] == ans.back() || a[c] == 0) {
        solve = 1;
        break;
      }
      ans.push_back(s[c]);
      a[c]--;
    }
    // cout << ans << endl;
    if (ans.size() > 1 && ans[0] == ans.back())
      solve = 1;
    printf("Case #%d: ", ++cas);
    if (solve)
      puts("IMPOSSIBLE");
    else {
      printf("%s\n", ans.c_str());
    }
  }
  return 0;
}
