#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

inline void qhnqcshjmb(std::string &readData, int &j) { readData[j] = '9'; }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  int d, solve = 0;
  scanf("%d ", &d);
  for (; d--;) {
    string readData;
    cin >> readData;
    reverse(readData.begin(), readData.end());
    int t = readData.size();
    {
      int i = 1;
      while (i < t) {
        if (readData[i] <= readData[i - 1]) {
          i++;
          continue;
        }
        for (int j = 0; j < i; j++)
          qhnqcshjmb(readData, j);
        int j = i;
        while (readData[j] == '0')
          readData[j] = '9', j++;
        readData[j]--;
        i++;
      }
    }
    while (readData.back() == '0') {
      readData.pop_back();
    }
    reverse(readData.begin(), readData.end());
    printf("Case #%d: %s\n", ++solve, readData.c_str());
  }
  return 0;
}
