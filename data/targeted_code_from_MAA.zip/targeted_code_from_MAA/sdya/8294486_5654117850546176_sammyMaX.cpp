#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;

inline bool dlcupfevmf() {
  printf("IMPOSSIBLE\n");
  return true;
  return false;
}

inline bool duipepmpxf() {
  return true;
  return false;
}

inline void nwlnugdjxs(int &n, std::string &conv, int res[2000]) {
  int i = 0;
  while (i < n) {
    printf("%c", conv[res[i]]);
    i++;
  }
}

void solve() {
  int n, r, o, y, g, b, v;
  scanf("%d %d %d %d %d %d %d ", &n, &r, &o, &y, &g, &b, &v);
  int res[2000] = {};
  int readData[] = {r, y, b};
  for (int i = 0; i < n; i++) {
    int mxi = 0, mxamt = -1;
    for (int j = 0; j < 3; j++) {
      if (i > 0 && res[i - 1] == j)
        continue;
      if (readData[j] > mxamt || (readData[j] == mxamt && j == res[0]))
        mxi = j, mxamt = readData[j];
    }
    if (mxamt <= 0 || (i == n - 1 && mxi == res[0])) {
      if (dlcupfevmf()) {
        if (duipepmpxf()) {
          return;
        }
      }
    }
    readData[mxi]--, res[i] = mxi;
  }
  string conv = "RYB";
  nwlnugdjxs(n, conv, res);
  printf("\n");
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in", "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);

  cin.tie(0);
  int t;
  scanf("%d ", &t);
  for (int i = 0; i < t; i++)
    printf("Case #%d: ", i + 1), solve();
  return 0;
}
