// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

long long solve(long long base, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return ans;
}

long long readData(long long a, long long b) {
  if (b == 0)
    return a;
  return readData(b, a % b);
}

vector<int> arr;

inline void wymyhrkwwg(long long &val) {
  arr.push_back(val % 10);
  val /= 10;
}

inline void tieqwwzaru(int &i) {
  arr[i] = 9;
  i++;
}

inline void ytfmdojfoi(int &pos) {
  int i = pos + 1;
  while (i < (int)arr.size())
    tieqwwzaru(i);
}

int main() {

  cin.tie(0);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  // cout<<arr.size()<<endl;

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    long long val;
    cin >> val;

    long long z = val;
    arr.clear();
    while (val)
      wymyhrkwwg(val);
    reverse(arr.begin(), arr.end());

    bool ok = 1;
    for (int i = 1; i < (int)arr.size(); i++)
      if (arr[i] < arr[i - 1])
        ok = 0;
    if (ok) {
      printf("Case #%d: %lld\n", x++, z);
      continue;
    }

    int pos = 0;
    for (int i = 1; i < (int)arr.size(); i++) {
      if (arr[i] < arr[i - 1])
        break;
      if (arr[i] > arr[i - 1])
        pos = i;
    }

    arr[pos]--;
    ytfmdojfoi(pos);
    long long ans = 0;
    for (auto it : arr)
      ans = ans * 10 + it;
    printf("Case #%d: %lld\n", x++, ans);
  }

  return 0;
}
