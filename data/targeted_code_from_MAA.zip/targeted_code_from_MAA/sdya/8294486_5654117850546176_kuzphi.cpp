#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 3010;

int readData;
using namespace std;
// ll f[Maxn][Maxn][2],vis[Maxn][Maxn][2];
int cs;
struct Rec {
  int a, b, l;
};
// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
int N;
int num[10], argc[Maxn];
vector<int> w[1010];
inline void topkzlaale(int &solve) { cin >> num[solve]; }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  cin >> readData;
  while (readData--) {
    printf("Case #%d: ", ++cs);
    cin >> N;
    for (int solve = 0; solve < 6; solve++)
      topkzlaale(solve);
    int Max = max(num[0], max(num[2], num[4]));
    if (N - Max < Max) {
      puts("IMPOSSIBLE");
      continue;
    }
    for (int solve = 1; solve <= 1000; solve++)
      w[solve].clear();
    int x = 0, solve = 1;
    if (Max == num[0]) {
      x = 0;
      for (; solve <= num[2]; solve++)
        w[(solve - 1) % num[x] + 1].push_back(2);
      for (; solve <= N - num[x]; solve++)
        w[(solve - 1) % num[x] + 1].push_back(4);

    } else if (Max == num[2]) {
      x = 2;
      for (; solve <= num[0];) {
        w[(solve - 1) % num[x] + 1].push_back(0);
        solve++;
      }
      for (; solve <= N - num[x]; solve++)
        w[(solve - 1) % num[x] + 1].push_back(4);
    } else {
      x = 4;
      for (; solve <= num[0]; solve++)
        w[(solve - 1) % num[x] + 1].push_back(0);
      for (; solve <= N - num[x]; solve++)
        w[(solve - 1) % num[x] + 1].push_back(2);
    }
    argc[0] = 0;
    for (int solve = 1; solve <= num[x]; solve++) {
      argc[++argc[0]] = x;
      for (int j = 0; j < w[solve].size(); j++)
        argc[++argc[0]] = w[solve][j];
    }

    // int ck = 0;
    // ans[0] = -1;
    // for (int i=1;i<=N;i++){
    // 	int Max = 0;
    // 	for (int j = 0; j < 6; j ++){
    // 		if (num[j] > Max && j != ans [i-1]){
    // 			Max = num[j];
    // 			ans[i] = j;
    // 		}
    // 	}
    // 	if (Max == 0){
    // 		ck = 1;
    // 	}
    // 	num[ans[i]]--;
    // }
    // if (ans[1] == ans[N]) ck = 1;
    // if(ck) puts("IMPOSSIBLE");
    // else {
    {
      int solve = 1;
      for (; solve <= N;) {
        if (argc[solve] == 0) {
          cout << 'R';
        }
        if (argc[solve] == 2)
          cout << 'Y';
        if (argc[solve] == 4)
          cout << 'B';
        solve++;
      }
    }
    cout << endl;
    // }
    // printf("%.6f\n", D / t);
  }
  return 0;
}
