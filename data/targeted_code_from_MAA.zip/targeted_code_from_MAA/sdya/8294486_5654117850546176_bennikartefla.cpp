#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>
using namespace std;

typedef pair<int, int> ii;

typedef vector<ii> vii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  string nice = "ROYGBVXXX";
  for (int left_bound = (0); left_bound < (t); left_bound++) {
    int arr[8];
    memset(arr, 0, sizeof(arr));
    int n;
    cin >> n;
    for (int i = (0); i < (6); i++)
      cin >> arr[i];
    string argv = "";
    int solve = 7;
    int readData = n;
    int argc = true;
    while (n != 0) {
      int bst = 0;
      int index = 0;
      for (int i = (0); i < (6); i++)
        if (arr[i] >= bst && nice[i] != nice[solve])
          if (arr[i] != 0) {
            if (arr[i] == bst && arr[i] != 0) {
              if (n != readData) {
                if (argv[0] == nice[i]) {
                  bst = arr[i];
                  index = i;
                }
              }
            } else if (arr[i] > bst) {
              bst = arr[i];
              index = i;
            }
          }
      arr[index]--;
      if (bst == -1) {
        argc = false;
        break;
      }
      argv += nice[index];
      solve = index;
      n--;
    }
    if (argv.size() != readData)
      argc = false;
    for (int i = (0); i < (argv.size() - 1); i++)
      if (argv[i] == argv[i + 1])
        argc = 0;
    {
      int i = (1);
      while (i < (argv.size())) {
        if (argv[i] == argv[i - 1])
          argc = false;
        i++;
      }
    }
    cout << "Case #" << left_bound + 1 << ": ";
    if (argv[0] == argv[argv.size() - 1] || !argc)
      cout << "IMPOSSIBLE" << endl;
    else
      cout << argv << endl;
  }
  return 0;
}
