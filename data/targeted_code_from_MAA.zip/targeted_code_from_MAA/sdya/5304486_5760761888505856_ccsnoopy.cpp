#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <stdio.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
}

inline void viocwaiobq(int &minx) { minx--; }

inline void evldcdktdm(std::string ret[30], int &k, int &l,
                       std::string test[30], int &i, int &j) {
  ret[k][l] = test[i][j];
}

int main(void) {
  solve();
  int t;
  scanf("%d", &t);

  for (int ct = 1; ct <= t; ct++) {
    int r, c;
    scanf("%d", &r);
    scanf("%d", &c);
    string test[30];
    string ret[30];
    for (int i = 0; i < r; i++) {
      cin >> test[i];
      // if(ct == 74){
      // 	cerr << str[i] << endl;
      // }
      ret[i] = test[i];
    }

    for (int i = 0; i < r; i++) {
      for (int j = 0; j < c; j++) {
        if (test[i][j] == '?')
          continue;
        int minx, maxx;
        minx = maxx = i;
        int miny, maxy;
        miny = maxy = j;
        while (miny > 0 && test[i][miny - 1] == '?' && ret[i][miny - 1] == '?')
          miny--;
        while (maxy < c - 1 && test[i][maxy + 1] == '?' &&
               ret[i][maxy + 1] == '?')
          maxy++;
        while (minx > 0) {
          int valid = true;
          for (int k = miny; k <= maxy; k++) {
            if (test[minx - 1][k] != '?' || ret[minx - 1][k] != '?') {
              valid = false;
              break;
            }
          }
          if (valid)
            viocwaiobq(minx);
          else
            break;
        }
        bool adabawah = false;
        for (int k = i + 1; k < r; k++) {
          for (int l = 0; l < c; l++) {
            if (test[k][l] != '?') {
              adabawah = 1;
              break;
            }
          }
        }
        if (!adabawah) {
          maxx = r - 1;
        }

        for (int k = minx; k <= maxx; k++) {
          for (int l = miny; l <= maxy; l++)
            evldcdktdm(ret, k, l, test, i, j);
        }
      }
    }

    printf("Case #%d: \n", ct);
    for (int i = 0; i < r; i++) {
      printf("%s\n", ret[i].c_str());
    }

    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
