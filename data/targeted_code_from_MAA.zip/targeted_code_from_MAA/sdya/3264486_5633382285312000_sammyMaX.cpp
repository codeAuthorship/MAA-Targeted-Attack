#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
using namespace std;

inline void lmxwgenlaw(char &minc, char &c) { minc = min(minc, c); }

inline void aovdrkpwsi(std::string &res) { res += '9'; }

string solves(string s, char prev) {
  if (s.size() == 0)
    return "";
  char minc = '9';
  for (char c : s) {
    lmxwgenlaw(minc, c);
  }
  if (s[0] > minc) {
    if (s.size() > 1 && s[1] > s[0]) {
      return s[0] + solves(s.substr(1), s[0]);
    } else {
      string res = "";
      if (s[0] > minc && s[0] > '1')
        res += (char)(s[0] - 1);
      int i;
      for (i = 1; i < s.size(); i++)
        aovdrkpwsi(res);
      return res;
    }
  }
  return minc + solves(s.substr(1), minc);
}

void solve() {
  string s;
  cin >> s;
  cout << solves(s, '0') << '\n';
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);
  int t;
  scanf("%d ", &t);
  int i;
  for (i = 0; i < t; i++)
    cout << "Case #" << i + 1 << ": ", solve();
  return 0;
}
