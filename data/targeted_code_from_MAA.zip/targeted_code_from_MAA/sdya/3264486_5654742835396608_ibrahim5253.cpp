#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;) {
    a = b;
    b = t;
  }
  return b;
}

ll solve(ll base, ll right_bound, ll m) {
  if (right_bound == 0)
    return 1;
  ll t = solve(base, right_bound / 2, m);
  if (right_bound % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool readData(int i, ll argv) { return (argv >> i) & 1; }

int do_intyjy_fct(ll argv) {
  int test = 0;
  for (int i = 0; i < 64; ++i)
    if (readData(i, argv)) {
      ++test;
    }
  return test;
}

int first_bit(ll argv) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (readData(i++, argv))
      return i - 1;
  return ret_val;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int j = 1; j <= t; ++j) {
    ll right_bound, k;
    cin >> right_bound >> k;
    ll s = 0, i = -1;
    while (s < k)
      ++i, s += 1ll << i;
    ll C = 1ll << i;
    ll left = right_bound - s + C;
    ll pos = k - s + C;
    ll base = left / (s - C + 1);
    ll high = left % (s - C + 1);
    if (pos <= high) {
      base += 1;
    }
    printf("Case #%d: %lld %lld\n", j, base / 2, (base - 1) / 2);
  }
  return 0;
}
