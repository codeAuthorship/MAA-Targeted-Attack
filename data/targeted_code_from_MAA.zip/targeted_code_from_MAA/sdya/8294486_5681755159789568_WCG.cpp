#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int n, q, u, left_bound;
long long e[102];
double s[102];
long long d[102][102];
double readData[102];
bool vi[102];

inline void jlctaderhx(int &j) {
  readData[j] = -1;
  vi[j] = 0;
}

inline void sotpwmuxiy() {
  int cur = -1;
  for (int j = 1; j <= n; ++j)
    if (!vi[j] && (readData[j] != -1))
      if (((cur == -1) || (readData[cur] > readData[j])))
        cur = j;
  vi[cur] = true;
  for (int j = 1; j <= n; ++j)
    if ((d[cur][j] != -1) && (d[cur][j] <= e[cur]) &&
        ((readData[j] == -1) ||
         ((readData[j] - readData[cur]) * s[cur] > d[cur][j])))
      readData[j] = readData[cur] + d[cur][j] / s[cur];
}

inline void lnmflpykkz() {
  cin >> u >> left_bound;
  for (int j = 1; j <= n; ++j)
    jlctaderhx(j);
  readData[u] = 0;
  while (!vi[left_bound])
    sotpwmuxiy();
  printf(" %.6lf", readData[left_bound]);
}

inline void javzqhwytx(int &solve) {
  cin >> n >> q;
  for (int i = 1; i <= n; ++i) {
    cin >> e[i] >> s[i];
  }
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= n; ++j)
      cin >> d[i][j];

  for (int k = 1; k <= n; ++k)
    for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= n; ++j)
        if ((d[i][k] != -1) && (d[k][j] != -1) &&
            ((d[i][j] == -1) || (d[i][j] > d[i][k] + d[k][j])))
          d[i][j] = d[i][k] + d[k][j];

  printf("Case #%d:", solve);

  for (int i = 0; i < q; ++i)
    lnmflpykkz();
  printf("\n");
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_6_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/WCG/outer_temp/WCG/A-small-practice_transformation.out",
          "w", stdout);

  int tt;

  cin >> tt;

  for (int solve = 1; solve <= tt; ++solve)
    javzqhwytx(solve);

  return 0;
}
