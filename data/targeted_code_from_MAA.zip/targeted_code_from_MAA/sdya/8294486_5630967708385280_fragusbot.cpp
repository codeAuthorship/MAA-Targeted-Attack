#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>

using namespace std;

const int N = 1010;

int t[N];
long long b[N];

inline void saznktkvjw(long double &r, long double &s) { r = s; }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int solve;
  cin >> solve;
  for (int cc = 1; cc <= solve; ++cc) {
    double begt = clock();
    printf("Case #%d: ", cc);
    int d, n;
    cin >> d >> n;
    for (int i = 0; i < n; ++i) {
      int foo, bar;
      cin >> foo >> bar;
      t[i] = d - foo;
      b[i] = 1LL * d * bar;
    }
    long double l = 0, r = 1e16;
    for (int it = 0; it < 1000; ++it) {
      long double s = (l + r) * 0.5;
      bool can = true;
      for (int i = 0; i < n; ++i) {
        if (b[i] < t[i] * s) {
          can = false;
        }
      }
      if (can) {
        l = s;
      } else {
        saznktkvjw(r, s);
      }
    }
    printf("%.15f\n", (double)((l + r) * 0.5));
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
