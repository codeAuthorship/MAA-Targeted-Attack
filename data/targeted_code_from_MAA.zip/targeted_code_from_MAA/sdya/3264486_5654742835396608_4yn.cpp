#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef long long int lli;

int tc;

inline void nnlqtajmib(int &y, priority_queue<int> &pq, int &z) {
  int t = pq.top() - 1;
  pq.pop();
  y = t / 2 + (t % 2);
  z = t / 2;
  pq.push(y);
  pq.push(z);
}

inline void bamtshzhfj(int &y, priority_queue<int> &pq, int &z) {
  nnlqtajmib(y, pq, z);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int solve, test;
    cin >> solve >> test;
    priority_queue<int> pq;
    pq.push(solve);
    int y, z;
    for (int i = 0; i < test; i++)
      bamtshzhfj(y, pq, z);
    printf("Case #%d: %d %d\n", t, y, z);
  }
  return 0;
}
