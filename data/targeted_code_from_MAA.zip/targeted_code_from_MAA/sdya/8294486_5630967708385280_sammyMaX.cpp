#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
using namespace std;

inline void nyblvnptpt(double &res, long long &dest) {
  long long cur, speed;
  cin >> cur >> speed;
  res = max(res, 1.0 * (dest - cur) / speed);
}

void solve() {
  long long dest, nh;
  cin >> dest >> nh;
  double res = 0;
  int i;
  for (i = 0; i < nh; i++)
    nyblvnptpt(res, dest);

  printf("%.12f\n", dest / res);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);
  cin.tie(0);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++) {
    printf("Case #%d: ", i + 1), solve();
  }
  return 0;
}
