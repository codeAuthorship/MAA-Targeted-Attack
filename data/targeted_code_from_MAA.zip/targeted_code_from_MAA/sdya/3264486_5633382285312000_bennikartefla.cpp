#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void uytigkvvjq(std::string &argv, int &i, vector<int> &k) {
  char m = argv[i];
  k.push_back(m - '0');
}

bool check(int left_bound) {
  string argv = to_string(left_bound);
  vector<int> k;
  for (int i = (0); i < (argv.size()); i++)
    uytigkvvjq(argv, i, k);
  vector<int> solve = k;
  sort(solve.begin(), solve.end());
  for (int i = (0); i < (k.size()); i++) {
    if (k[i] != solve[i])
      return false;
  }
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  ofstream argc("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  int i;
  for (i = (0); i < (t); i++) {
    int m;
    cin >> m;
    for (int left_bound = m; left_bound >= 0; left_bound--) {
      if (check(left_bound)) {
        argc << "Case #" << i + 1 << ": " << left_bound << endl;
        break;
      }
    }
  }
  return 0;
}
