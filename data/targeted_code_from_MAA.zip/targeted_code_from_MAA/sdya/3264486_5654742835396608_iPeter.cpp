#include <algorithm>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

int main(void) {
  int ret_val = 0;
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/outer_temp/iPeter/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  cin >> t;
  for (int tt = 1; tt <= t; tt++) {

    int n, k;
    priority_queue<int> solve;
    cin >> n >> k;
    solve.push(n);
    while (--k) {
      int x = solve.top();
      solve.pop();
      solve.push(x / 2);
      solve.push((x - 1) / 2);
    }

    int v = solve.top();
    printf("Case #%d: %d %d\n", tt, v / 2, (v - 1) / 2);
  }
  return ret_val;
}

 
