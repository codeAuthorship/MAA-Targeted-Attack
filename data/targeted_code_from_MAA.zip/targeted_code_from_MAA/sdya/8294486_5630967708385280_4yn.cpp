#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int tc;

long long d, n, a, b;
vector<pair<long long, long long>> ks;

inline void rljxnburnv(double &ub) {
  cin >> a >> b;
  ks.push_back(pair<long long, long long>(a, b));
  if (ub == 0) {
    if (a != d) {
      ub = d * b / (d - a + 0.0);
    }
  } else if (a != d) {
    ub = min(ub, d * b / (d - a + 0.0));
  }
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    cin >> d >> n;
    double lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int solve = 0; solve < n; solve++)
      rljxnburnv(ub);
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int solve = 0; solve < n; solve++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[solve].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[solve].first / (ex - ks[solve].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    printf("Case #%d: %.7f\n", t, ub);
  }
  return 0;
}
