#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
using LL = long long;
using pii = pair<int, int>;

int test, cas;

inline void mtzdlyzgnp(int &x, vector<int> &R, int &i, vector<vector<pii>> &v) {
  cin >> x;
  int t = ceil(1 / 1.1 * x / R[i]), b = floor(1 / 0.9 * x / R[i]);
  // while (1.0 * a * R[i] < 0.9 * x) a ++;
  // while (1.0 * b * R[i] > 1.1 * x) b --;
  // cout << a << " " << b << endl;
  if (t <= b) {
    v.back().emplace_back(t, b);
  }
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_12_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/jiian/outer_temp/jiian/A-small-practice_transformation.out",
          "w", stdout);
  cin >> test;
  for (; test--;) {
    vector<vector<pii>> v;
    vector<int> R;
    int solve, p;
    cin >> solve >> p;
    {
      int i = 0, x;
      while (i < solve) {
        cin >> x, R.push_back(x);
        i++;
      }
    }
    int mx = p;
    for (int i = 0; i < solve; i++) {
      v.push_back(vector<pii>());
      for (int j = 0, x; j < p; j++)
        mtzdlyzgnp(x, R, i, v);
      sort(v[i].begin(), v[i].end());
    }
    int readData = 0;
    for (; true;) {
      int mnv = 0, mxv = 1e9, mnid, mxid, flag = 0;
      for (int i = 0; i < solve; i++)
        if (v[i].size()) {
          auto x = v[i].back();
          if (x.first > mnv)
            mnv = x.first, mnid = i;
          if (x.second < mxv) {
            mxv = x.second, mxid = i;
          }
        } else
          flag = 1;
      if (flag)
        break;
      // cout << mnv << " " << mxv << endl;
      if (mnv <= mxv) {
        readData++;
        for (int i = 0; i < solve; i++)
          v[i].pop_back();
      } else {
        v[mnid].pop_back();
      }
    }
    printf("Case #%d: %d\n", ++cas, readData);
  }
  return 0;
}
