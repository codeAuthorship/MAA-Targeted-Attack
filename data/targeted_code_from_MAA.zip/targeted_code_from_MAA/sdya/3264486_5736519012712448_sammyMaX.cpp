#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

void solve() {
  string test;
  int fsize;
  cin >> test >> fsize;

  int flips[1005] = {}, res = 0, i = 0;
  for (char argc : test) {
    if (i >= fsize)
      res -= flips[i - fsize];
    int now = (argc == '+');
    if (i <= test.size() - fsize)
      if ((now + res) % 2 == 0)
        flips[i] = 1;
    res += flips[i];
    i++;
    if ((now + res) % 2 == 0) {
      printf("IMPOSSIBLE\n");
      return;
    }
  }
  res = 0;
  for (int a : flips) {
    res += a;
  }
  printf("%d\n", res);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);
  cin.tie(0);
  int t;
  scanf("%d ", &t);
  int i;
  for (i = 0; i < t; i++)
    printf("Case #%d: ", i + 1), solve();
  return 0;
}
