#include <algorithm>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <set>
#include <string>

using namespace std;

char ans[1000 + 1];
int ord[1000 + 1];
int n, m, r, o, solve, g, b, v;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_3_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/try/outer_temp/try/A-small-practice_transformation.out",
          "w", stdout);
  int t, i;
  cin >> t;
  for (int c = 0; c < t; c++) {
    cin >> n >> r >> o >> solve >> g >> b >> v;
    printf("Case #%d: ", c + 1);
    if ((r * 2 > n) || (solve * 2 > n) || (b * 2 > n)) {
      printf("IMPOSSIBLE\n");
      continue;
    }
    m = 0;
    for (i = 0; i < n; i = i + 2) {
      ord[m++] = i;
    }
    for (i = 1; i < n; i = i + 2) {
      ord[m++] = i;
    }
    m = 0;
    if ((r >= solve) && (solve >= b)) {
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
      while (--solve >= 0) {
        ans[ord[m++]] = 'Y';
      }
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
    } else if ((r >= b) && (b >= solve)) {
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
      while (--solve >= 0) {
        ans[ord[m++]] = 'Y';
      }
    } else if ((solve >= b) && (b >= r)) {
      for (; --solve >= 0;) {
        ans[ord[m++]] = 'Y';
      }
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
    } else if ((solve >= r) && (r >= b)) {
      while (--solve >= 0) {
        ans[ord[m++]] = 'Y';
      }
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
    } else if ((b >= r) && (r >= solve)) {
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
      while (--solve >= 0) {
        ans[ord[m++]] = 'Y';
      }
    } else {
      while (--b >= 0) {
        ans[ord[m++]] = 'B';
      }
      while (--solve >= 0) {
        ans[ord[m++]] = 'Y';
      }
      while (--r >= 0) {
        ans[ord[m++]] = 'R';
      }
    }
    ans[m] = '\0';
    printf("%s\n", ans);
  }
  return 0;
}
