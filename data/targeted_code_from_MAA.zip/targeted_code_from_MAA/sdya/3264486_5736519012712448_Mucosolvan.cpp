#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>

using namespace std;

int solve, k;
string s;

inline void aifqnwyodr(int &i) {
  int j = (i);
  while (j <= (i + k - 1)) {
    if (s[j] == '+')
      s[j] = '-';
    else
      s[j] = '+';
    ++j;
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  cin >> solve;
  for (int x = (1); x <= ((solve)); ++x) {
    cin >> s >> k;
    int test = 0;
    {
      int i = (0);
      while (i <= (((int)s.size() - k + 1) - 1)) {
        if (s[i] == '-') {
          aifqnwyodr(i);
          test++;
        }
        ++i;
      }
    }
    for (int i = (0); i <= (((int)s.size()) - 1); ++i)
      if (s[i] == '-') {
        test = -1;
        break;
      }
    printf("Case #%d: ", x);
    if (test == -1)
      printf("IMPOSSIBLE\n");
    else
      printf("%d\n", test);
  }
  return 0;
}
