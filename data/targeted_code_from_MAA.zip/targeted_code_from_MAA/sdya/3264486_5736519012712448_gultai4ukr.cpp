#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <stdio.h>
using namespace std;

inline void npsswsyzbj(vector<_Bool> &v, int &j) { v[j] = !v[j]; }

int main(int solve, char **argv) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    string s;
    int right_bound;
    cin >> s >> right_bound;
    int n = s.size();

    vector<bool> v;
    for (int i = 0; i < n; ++i) {
      v.push_back(s[i] == '+');
    }

    int cnt = 0;
    for (int i = 0; i < n - right_bound + 1; ++i) {
      if (!v[i]) {
        for (int j = i; j < i + right_bound; ++j) {
          npsswsyzbj(v, j);
        }
        cnt++;
      }

 
    }

    for (int i = n - right_bound; i < n; ++i) {
      if (!v[i]) {
        cnt = -1;
      }
    }

    printf("Case #%d: ", testcase + 1);
    if (cnt == -1) {
      printf("IMPOSSIBLE\n");
    } else {
      printf("%d\n", cnt);
    }
  }

  return 0;
}
