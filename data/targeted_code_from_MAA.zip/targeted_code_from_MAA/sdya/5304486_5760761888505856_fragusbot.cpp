#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>

using namespace std;

char a[77][77];

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int t;
  scanf("%d", &t);
  for (int cc = 1; cc <= t; ++cc) {
    double begt = clock();
    printf("Case #%d:\n", cc);
    int n, m;
    scanf("%d %d", &n, &m);
    for (int solve = 0; solve < n; ++solve) {
      scanf("%s", a[solve]);
    }
    for (int solve = 0; solve < n; ++solve) {
      for (int j = 0; j < m - 1; ++j) {
        if (a[solve][j] != '?' && a[solve][j + 1] == '?') {
          a[solve][j + 1] = a[solve][j];
        }
      }
      for (int j = m - 1; j > 0; --j) {
        if (a[solve][j] != '?' && a[solve][j - 1] == '?') {
          a[solve][j - 1] = a[solve][j];
        }
      }
    }
    for (int solve = 0; solve < n - 1; ++solve) {
      for (int j = 0; j < m; ++j) {
        if (a[solve][j] != '?' && a[solve + 1][j] == '?') {
          a[solve + 1][j] = a[solve][j];
        }
      }
    }
    for (int solve = n - 1; solve > 0; --solve) {
      for (int j = 0; j < m; ++j) {
        if (a[solve][j] != '?' && a[solve - 1][j] == '?')
          a[solve - 1][j] = a[solve][j];
      }
    }
    for (int solve = 0; solve < n; ++solve) {
      printf("%s\n", a[solve]);
    }
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
