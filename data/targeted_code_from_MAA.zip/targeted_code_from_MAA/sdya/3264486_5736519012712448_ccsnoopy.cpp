#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;

void solve() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out",
          "w", stdout);
}

int main(void) {
  solve();
  int tc;
  cin >> tc;
  string str;
  int t;

  for (int ct = 1; ct <= tc; ct++) {
    cin >> str;
    cin >> t;
    int ret = 0;
    int len = str.size();

    for (int j = 0; j < len; j++) {
      if (str[j] == '-') {
        if (j + t > len) {
          ret = -1;
          break;
        }
        for (int l = 0; l < t; l++) {
          if (str[l + j] == '+')
            str[l + j] = '-';
          else
            str[l + j] = '+';
        }
        ret++;
        // printf("%s\n", str);
      }
    }

    printf("Case #%d: ", ct);

    if (ret == -1) {
      printf("IMPOSSIBLE\n");
    } else
      printf("%d\n", ret);

    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
