#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 102;
int t, left_bound, q, dist[N], speed[N], u, v;
vector<vector<pii>> g(N);
bool vis[N];
double readData[N];

double solve(int i) {
  if (i == v) {
    return 0;
  }
  if (!((int)(g[i]).size())) {
    return 1000000000000000000ll;
  }
  if (vis[i])
    return readData[i];
  vis[i] = true;

  readData[i] = 1000000000000000000ll;
  double totalDist = g[i].back().second;
  int argv = g[i].back().first;
  for (; totalDist <= dist[i];) {
    readData[i] = min(readData[i], totalDist / speed[i] + solve(argv));
    if (argv == v)
      break;
    if (!((int)(g[argv]).size()))
      return readData[i];
    totalDist += g[argv].back().second;
    argv = g[argv].back().first;
  }
  return readData[i];
}

inline void azwkfxlgyv(int &i, int &argv) {
  int argc;
  cin >> argc;
  if (argc != -1)
    g[i].push_back(make_pair(argv, argc));
}

int main() {

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    cin >> left_bound >> q;
    for (int i = (1); i <= (int)(left_bound); ++i)
      cin >> dist[i] >> speed[i];
    for (int i = (1); i <= (int)(left_bound); ++i)
      for (int argv = (1); argv <= (int)(left_bound); ++argv)
        azwkfxlgyv(i, argv);
    for (; q--;) {
      cin >> u >> v;
      memset(vis, 0, sizeof vis);
      printf("Case #%d: %.6f\n", test, solve(u));
    }

    g.clear(), g.resize(N);
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
