#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t, d[5];

inline void tmskzbwbcz(int &newB, int &b) {
  newB = b - (b / 2) - 1;
  d[3] += d[1];
}

inline void fywzkchpcf(int &a, int &n, int &b, int &i) {
  d[2] += d[1];
  if (a != n)
    if (b != 0)
      i++;
}

void solve(int n, int i) {
  if (n == i) {
    printf("0 0\n");
    return;
  }

  int pot = 1;

  int a = n, b = 0;
  d[0] = 1;
  d[1] = 0;
  while (pot < i) {
    int newA = 0, newB = 0;
    newA = a / 2;
    d[2] = d[0];
    if (a - newA - 1 != newA && newA != 1) {
      d[3] = d[0];
      newB = a - newA - 1;
    } else {
      if (a != 2)
        d[2] += d[0];
    }

    if (b > 1) {
      if (b % 2 == 0) {
        if (b != 2)
          tmskzbwbcz(newB, b);
        d[2] += d[1];
      } else {
        d[3] += d[1] * 2;
      }
    } else
      fywzkchpcf(a, n, b, i);

    a = newA;
    b = newB;
    d[0] = d[2];
    d[1] = d[3];
    d[2] = d[3] = 0;
 
    i -= pot;
    pot *= 2;
  }
 
  if (i > d[0])
    a = b;
  printf("%d %d\n", a / 2, max(0, a - (a / 2) - 1));
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  for (int argv = (1); argv <= ((t)); ++argv) {
    int n, i;
    cin >> n >> i;
    printf("Case #%d: ", argv);
    solve(n, i);
  }
  return 0;
}
