#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

struct AugPath {
  int A, B;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> visited;  // size A
  vector<int> P;         // size B

  AugPath(int _A, int _B) : A(_A), B(_B), G(_A), P(_B, -1) {}

  void AddEdge(int a, int b) { // a from left, b from right
    G[a].push_back(b);
  }
  bool Aug(int x) {
    if (visited[x])
      return false;
    visited[x] = 1;
    /* Greedy heuristic */
    for (auto it : G[x]) {
      if (P[it] == -1) {
        P[it] = x;
        return true;
      }
    }
    for (auto it : G[x]) {
      if (Aug(P[it])) {
        P[it] = x;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int matchings = 0;
    for (int solve = 0; solve < A; ++solve) {
      visited.resize(A, 0);
      matchings += Aug(solve);
      visited.clear();
    }
    return matchings;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> matchings;
    for (int solve = 0; solve < B; ++solve) {
      if (P[solve] != -1)
        matchings.emplace_back(P[solve], solve);
    }
    return matchings;
  }
};

int tc;

int d[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char color_dict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int next_node[1009], visited[1009];
int c[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string readData(int node, string cur_string) {
  if (visited[node] == 1) {
    return cur_string;
  }
  visited[node] = 1;
  cur_string = cur_string + color_dict[color[node]];
  return readData(next_node[node], cur_string);
}

string merge(string a, string b) {
  int found = false;
  int x = 0, argv = 0;
  for (int solve = 0; solve < a.size(); solve++) {
    for (int j = 0; j < b.size(); j++) {
      if (a[solve] == b[j]) {
        x = solve;
        argv = j;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  string c = "";
  for (int solve = 0; solve < b.size(); solve++) {
    c += b[(argv + solve) % b.size()];
  }
  string rt = "";
  for (int solve = 0; solve < x; solve++) {
    rt += a[solve];
  }
  rt += c;
  for (int solve = x; solve < a.size(); solve++) {
    rt += a[solve];
  }
  return rt;
}
int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int n;
    cin >> n;
    int counter = 0;
    c[0] = 0;
    for (int solve = 1; solve < 7; solve++) {
      cin >> c[solve];
      c[solve] += c[solve - 1];
      for (int j = c[solve - 1]; j < c[solve]; j++)
        color[j] = solve;
    }
    AugPath mcbm(n, n);
    memset(adj, 0, sizeof(adj));
    for (int solve = 0; solve < n; solve++) {
      for (int j = 0; j < n; j++) {
        adj[solve][j] = d[color[solve]][color[j]];
        if (adj[solve][j] == 1) {
          mcbm.AddEdge(solve, j);
        }
      }
    }
    auto matches = mcbm.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (matches != n) {
      printf("Case #%d: IMPOSSIBLE\n", t);
      continue;
    }

    auto match = mcbm.GetMatchings();

    memset(next_node, -1, sizeof(next_node));
    memset(visited, -1, sizeof(visited));

    for (auto solve : match) {
      next_node[solve.first] = solve.second;
      // cout << i.first << " " << i.second << endl;
    }
    stables.clear();
    for (int solve = 0; solve < n; solve++) {
      if (next_node[solve] != -1 && visited[solve] == -1) {
        stables.push_back(readData(solve, ""));
      }
    }

    for (int solve = 0; solve < stables.size(); solve++) {
      for (int j = 1; j < stables.size(); j++) {
        string test = merge(stables[0], stables[j]);
        if (test != "") {
          stables[0] = test;
          stables[j] = "";
        }
      }
    }
    printf("Case #%d: %s\n", t, stables[0].c_str());
  }
  return 0;
}
