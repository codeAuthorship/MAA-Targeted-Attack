#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;

void solve() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out",
          "w", stdout);
}
int n, q, fr, to;
int energy[120];
int spd[120];
int dist[120][120];
map<pair<ii, int>, double> memo;

double dp(int idx, int pony, int left) {
  pair<ii, int> z = make_pair(ii(idx, pony), left);
  if (idx == to)
    return 0;
  if (memo.find(z) != memo.end() && memo[z] < 1e12)
    return memo[z];

  double ans = 1e12;

  if (dist[idx][idx + 1] <= left) {
    ans = min(dp(idx + 1, pony, left - dist[idx][idx + 1]) +
                  1.0 * dist[idx][idx + 1] / spd[pony],
              ans);
  }

  if (dist[idx][idx + 1] <= energy[idx]) {
    ans = min(ans, dp(idx + 1, idx, energy[idx] - dist[idx][idx + 1]) +
                       1.0 * dist[idx][idx + 1] / spd[idx]);
  }
  return memo[z] = ans;
}

int main(void) {
  solve();
  int tc;
  cin >> tc;

  int t;
  for (t = 1; t <= tc; t++) {
    cin >> n;
    cin >> q;

    for (int i = 0; i < n; i++) {
      cin >> energy[i];
      cin >> spd[i];
    }

    for (int i = 0; i < n; i++) {
      for (int test = 0; test < n; test++) {
        cin >> dist[i][test];
      }
    }

    cin >> fr;
    cin >> to;
    fr--;
    to--;
    memo.clear();

    printf("Case #%d: %.10lf\n", t, dp(0, 0, energy[0]));

    cerr << "Test " << t << " done \n";
  }
  return 0;
}
