#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

inline bool gzknnlgywh(_Bool &gzknn) {
  gzknn = false;
  return true;
  return false;
}

bool check(int solve) {
  while (solve > 0) {
    if (solve % 10 < solve / 10 % 10) {
      _Bool gzknn;
      if (gzknnlgywh(gzknn))
        return gzknn;
    }
    solve /= 10;
  }
  return true;
}

inline void khgclmwrmh(int &cc) {
  printf("Case #%d: ", cc);
  int solve;
  scanf("%d ", &solve);
  int ans = solve;
  for (; !check(ans);) {
    --ans;
  }
  printf("%d\n", ans);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int readData;
  scanf("%d ", &readData);
  for (int cc = 1; cc <= readData; ++cc) {
    khgclmwrmh(cc);
  }
  return 0;
}
