#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
using namespace std;

ofstream fout("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

inline void hfxdcsownz(int &per, int ingL[100], int readData[100][100],
                       vector<pair<int, pair<int, int>>> packV[100], int &i) {
  for (int j = 0; j < per; j++) {
    scanf("%d ", &readData[i][j]);
    int low = (10 * readData[i][j] + 11 * ingL[i] - 1) / (11 * ingL[i]);
    int high = (10 * readData[i][j]) / (9 * ingL[i]);
    packV[i].push_back({readData[i][j], {low, high}});
    cout << readData[i][j] << ' ' << low << ' ' << high << '\n';
  }
  sort(packV[i].begin(), packV[i].end());
}

inline void zydbywaxfh(int inds[100], int &i) { inds[i]++; }

void solve() {
  int ing, per, ingL[100], readData[100][100];
  vector<pair<int, pair<int, int>>> packV[100];
  scanf("%d %d ", &ing, &per);
  for (int i = 0; i < ing; i++)
    scanf("%d ", &ingL[i]);
  for (int i = 0; i < ing; i++)
    hfxdcsownz(per, ingL, readData, packV, i);
  int inds[100] = {}, imax = 0, res = 0;
  cout << "good here" << endl;
  while (imax < per) {
    int curL = 0, curH = 1 << 30;
    int curLi = 0, curHi = 0;
    for (int i = 0; i < ing; i++) {
      if (packV[i][inds[i]].second.first > curL)
        curL = packV[i][inds[i]].second.first, curLi = i;
      if (packV[i][inds[i]].second.second < curH)
        curH = packV[i][inds[i]].second.second, curHi = i;
    }
    cout << "cur " << curLi << ' ' << curHi << '\n';
    if (curH < curL) {
      inds[curHi]++;
      imax = max(imax, inds[curHi]);
    } else {
      res++;
      for (int i = 0; i < ing; i++)
        zydbywaxfh(inds, i);
      imax++;
    }
  }
  fout << res << '\n';
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d ", &t);
  for (int i = 0; i < t; i++)
    fout << "Case #" << i + 1 << ": ", solve();
  return 0;
}
