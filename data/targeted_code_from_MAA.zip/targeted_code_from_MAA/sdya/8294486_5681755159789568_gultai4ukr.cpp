#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

inline void atcoprwezk(vector<double> &dp, vector<vector<long long>> &dist,
                       int &to, vector<long long> &s, int &from) {
  dp[to] = min(dp[to], dp[from] + 1.0 * dist[from][to] / s[from]);
}

inline void lpbqitgmzf(vector<vector<long long>> &d, int &i, int &solve) {
  cin >> d[i][solve];
}

int main(int argc, char **readData) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    int n, q, u, v;
    cin >> n >> q;
    assert(q == 1);
    vector<long long int> e(n), s(n);
    for (int i = 0; i < n; ++i) {
      cin >> e[i] >> s[i];
    }
    vector<vector<long long int>> d(n, vector<long long int>(n));
    for (int i = 0; i < n; ++i) {
      for (int solve = 0; solve < n; ++solve)
        lpbqitgmzf(d, i, solve);
    }
    cin >> u >> v;

    vector<vector<long long int>> dist(n, vector<long long int>(n, -1));
    for (int from = 0; from < n; ++from) {
      dist[from][from] = 0;
      for (int to = from + 1; to < n; ++to) {
        dist[from][to] = dist[from][to - 1] + d[to - 1][to];
        //				cout << from << ' ' << to << ' ' <<
        // dist[from][to] << endl;
      }
    }

    vector<double> dp(n, 1e18);
    dp[0] = 0;
    for (int to = 1; to < n; ++to) {
      for (int from = 0; from < to; ++from) {
        if (dist[from][to] <= e[from])
          atcoprwezk(dp, dist, to, s, from);
      }
    }

    printf("Case #%d: %.7f\n", testcase + 1, dp[n - 1]);
  }

  return 0;
}
