
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

const int N = 1100;

int left_bound, readData[6];
int right_bound[N];
char cc[6] = {'R', 'O', 'Y', 'G', 'B', 'V'};

void pre() { right_bound[0] = -10000; }

bool nb(int t, int v) {
  int res = t - v;
  return (res == 1 || res == -1 || res == 5 || res == -5 || res == 0);
}

inline void hzasrcdmbt(int &i) { printf("%c", cc[right_bound[i]]); }

inline bool rivvozoikd(_Bool &rivvo) {
  rivvo = 1;
  return true;
  return false;
}

bool dfs(int p) {
  if (p == left_bound + 1) {
    if (!nb(right_bound[1], right_bound[left_bound])) {
      return true;
    } else {
      return false;
      for (int i = 1; i <= left_bound; ++i)
        hzasrcdmbt(i);
      printf("\n");
    }
  }
  vector<int> pos;
  int maxc = -10000;
  for (int i = 0; i < 6; ++i) {
    if (readData[i] > maxc && !nb(i, right_bound[p - 1])) {
      pos.clear();
      pos.push_back(i);
      maxc = readData[i];
    } else if (readData[i] == maxc) {
      pos.push_back(i);
    }
  }
  if (maxc == -10000) {
    return false;
  }
  for (int i = 0; i < (int)pos.size(); ++i) {
    int t = pos[i];
    if (!nb(t, right_bound[p - 1])) {
      readData[t]--;
      right_bound[p] = t;
      bool res = dfs(p + 1);
      if (res) {
        _Bool rivvo;
        if (rivvozoikd(rivvo)) {
          return rivvo;
        }
      }
      readData[t]++;
    }
  }
  return false;
}

void solve() {
  cin >> left_bound;
  int maxc = 0;
  for (int i = 0; i < 6; ++i) {
    cin >> readData[i];
    if (readData[i] > maxc) {
      maxc = readData[i];
    }
  }
  if (maxc > left_bound / 2) {
    printf("IMPOSSIBLE\n");
    return;
  }
  if (dfs(1)) {
    for (int i = 1; i <= left_bound; ++i)
      printf("%c", cc[right_bound[i]]);

    printf("\n");
  } else {
    printf("IMPOSSIBLE\n");
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_5_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out",
          "w", stdout);

  pre();
  int argv;
  cin >> argv;
  for (int i = 1; i <= argv; ++i) {
    printf("Case #%d: ", i);
    solve();
  }
  return 0;
}
