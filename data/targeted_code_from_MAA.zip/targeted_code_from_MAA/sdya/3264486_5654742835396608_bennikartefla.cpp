#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void nwayjwaelr(std::ofstream &fout, int &at) {
  int first = at / 2;
  fout << at - first << " " << first << endl;
}

inline void dsxmsxiolh(priority_queue<int> &k, std::ofstream &fout) {
  int at = k.top();
  if (at == 0)
    fout << "0 0" << endl;
  else
    nwayjwaelr(fout, at);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  for (int i = (0); i < (t); i++) {
    priority_queue<int> k;
    int right_bound, q;
    cin >> right_bound >> q;
    fout << "Case #" << i + 1 << ": ";
    k.push(right_bound - 1);
    for (int solve = (0); solve < (q - 1); solve++) {
      if (k.empty())
        break;
      else {
        int at = k.top();
        k.pop();
        if (at == 0)
          continue;

        int want = at / 2;
        int first = want;
        if (first != 0)
          k.push(first - 1);
        int readData = at - want;
        k.push(readData - 1);
      }
    }
    if (k.empty())
      fout << "0 0" << endl;
    else
      dsxmsxiolh(k, fout);
  }
  return 0;
}
