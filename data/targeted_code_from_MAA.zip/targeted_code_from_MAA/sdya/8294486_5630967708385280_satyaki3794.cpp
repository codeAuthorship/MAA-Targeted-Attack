// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

long long solve(long long base, long long p,
                long long left_bound = (1000000007LL)) {
  long long ans = 1;
  for (; p;) {
    if (p & 1)
      ans = (ans * base) % left_bound;
    base = (base * base) % left_bound;
    p /= 2;
  }
  return ans;
}

long long readData(long long a, long long b) {
  if (b == 0)
    return a;
  return readData(b, a % b);
}

int n;
double D, dist[1005], speed[1005];

bool possible(double mid) {
  for (int i = 1; i <= n; i++) {
    if (speed[i] > mid)
      continue;
    double d = (dist[i] / speed[i]) / (1.0 / speed[i] - 1.0 / mid);
    if (d <= D)
      return false;
  }
  return true;
}

inline void suwdxmezkz(int &d) {

  cin >> D >> n;
  for (int i = 1; i <= n; i++)
    cin >> dist[i] >> speed[i];

  double ans = 0, lo = 0, hi = 1e18 + 2;
  {
    int iter = 0;
    while (iter < 100) {
      double mid = (lo + hi) / 2;
      if (possible(mid)) {
        ans = max(ans, mid);
        lo = mid;
      } else {
        hi = mid;
      }
      iter++;
    }
  }

  printf("Case #%d: %.7f\n", d++, ans);
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);

  cin.tie(0);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  int t, d = 1;
  cin >> t;
  while (t--)
    suwdxmezkz(d);

  return 0;
}
