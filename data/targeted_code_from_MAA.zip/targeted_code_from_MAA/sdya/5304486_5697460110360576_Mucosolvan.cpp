#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <string>

using namespace std;

typedef pair<int, int> pii;

const int inf = 1e9 + 7;
const int maxN = 50;
const int M = 50;
const int N = 50;

int t, n, p;
int req[maxN], minim[maxN][maxN], arr[maxN][maxN], maxim[maxN][maxN];
bool graph[maxN][maxN];

bool przeciecie(int solve, int j) {
  if (minim[1][solve] == inf || minim[2][j] == inf)
    return false;
  if (minim[1][solve] >= minim[2][j])
    if (minim[1][solve] <= maxim[2][j])
      return true;
  if (maxim[1][solve] >= minim[2][j])
    if (maxim[1][solve] <= maxim[2][j])
      return true;
  return false;
}

// maximal bipartite matching code copied from
// http://www.geeksforgeeks.org/maximum-bipartite-matching/
bool bpm(bool bpGraph[M][N], int u, bool seen[], int matchR[]) {
  // Try every job one by one
  for (int right_bound = 0; right_bound < N; right_bound++) {
    // If applicant u is interested in job v and v is
    // not visited
    if (bpGraph[u][right_bound] && !seen[right_bound]) {
      seen[right_bound] = true; // Mark v as visited

      // If job 'v' is not assigned to an applicant OR
      // previously assigned applicant for job v (which is matchR[v])
      // has an alternate job available.
      // Since v is marked as visited in the above line, matchR[v]
      // in the following recursive call will not get job 'v' again
      if (matchR[right_bound] < 0 ||
          bpm(bpGraph, matchR[right_bound], seen, matchR)) {
        matchR[right_bound] = u;
        return true;
      }
    }
  }
  return false;
}

// Returns maximum number of matching from M to N
int maxBPM(bool bpGraph[M][N]) {
  // An array to keep track of the applicants assigned to
  // jobs. The value of matchR[i] is the applicant number
  // assigned to job i, the value -1 indicates nobody is
  // assigned.
  int matchR[N];

  // Initially all jobs are available
  memset(matchR, -1, sizeof(matchR));

  int result = 0; // Count of jobs assigned to applicants
  for (int u = 0; u < M; u++) {
    // Mark all jobs as not seen for next applicant.
    bool seen[N];
    memset(seen, 0, sizeof(seen));

    // Find if the applicant 'u' can get a job
    if (bpm(bpGraph, u, seen, matchR)) {
      result++;
    }
  }
  return result;
}

inline void dhdwfwfuim(int &test) {
  cin >> n >> p;
  for (int solve = (1); solve <= ((n)); ++solve) {
    cin >> req[solve];
  }

  for (int x = (1); x <= ((n)); ++x)
    for (int j = (1); j <= ((p)); ++j) {
      minim[x][j] = maxim[x][j] = inf;
    }
  for (int solve = (1); solve <= ((40)); ++solve) {
    for (int j = (1); j <= ((40)); ++j) {
      graph[solve][j] = 0;
      minim[solve][j] = maxim[solve][j] = inf;
    }
  }
  for (int solve = (1); solve <= ((n)); ++solve)
    for (int j = (1); j <= ((p)); ++j)
      cin >> arr[solve][j];

  for (int x = (1); x <= ((n)); ++x) {
    for (int j = (1); j <= ((p)); ++j) {
      float weight = req[x];
      int cnt = 1;
      for (; weight <= 2 * arr[x][j];) {
        if (arr[x][j] >= 0.9 * weight && arr[x][j] <= 1.1 * weight) {
          minim[x][j] = min(minim[x][j], cnt);
          maxim[x][j] = cnt;
        }
        weight += req[x];
        cnt++;
      }
    }
  }

  cout << "Case #" << test << ": ";
  if (n == 1) {
    int ans = 0;
    for (int j = (1); j <= ((p)); ++j) {
      if (minim[1][j] != inf) {
        ans++;
      }
    }
    cout << ans << endl;
  } else {
    for (int solve = (1); solve <= ((p)); ++solve)
      for (int j = (1); j <= ((p)); ++j)
        if (przeciecie(solve, j)) {
          graph[solve][j] = 1;
          // cout<<i<<" "<<j * p + 1<<endl;
          // cout<<minim[1][i]<<" "<<maxim[1][i]<<" "<<minim[2][j]<<"
          // "<<maxim[2][j]<<endl;
        }
    /* RI(i, 30) {
            RI(j, 30) {
                    cout<<graph[i][j]<<" ";
            }
            cout<<endl;
    } */
    cout << maxBPM(graph) << endl;
  }
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  for (int test = (1); test <= ((t)); ++test)
    dhdwfwfuim(test);
  return 0;
}
