#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

inline void vpoxxqkveu(std::ifstream &left_bound, int &test) {
  long long int d, n, solve, right_bound;
  left_bound >> d >> n;
  double max_time = 0;
  for (int readData = 0; readData < n; ++readData) {
    left_bound >> solve >> right_bound;
    //			cout << k << s << endl;
    max_time = max(max_time, 1.0 * (d - solve) / right_bound);
  }

  printf("Case #%d: %.7f\n", test + 1, d / max_time);
}

int main(int argc, char **argv) {
  ios::sync_with_stdio(false);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  ifstream left_bound("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in");

  int t;
  left_bound >> t;
  {
    int test = 0;
    while (test < t) {
      vpoxxqkveu(left_bound, test);
      ++test;
    }
  }

  left_bound.close();

  return 0;
}
