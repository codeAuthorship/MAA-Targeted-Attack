#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll readData(ll left_bound, ll b) {
  ll t;
  while ((t = left_bound % b) != 0) {
    left_bound = b;
    b = t;
  }
  return b;
}

ll solve(ll base, ll argc, ll m) {
  if (argc == 0)
    return 1;
  ll t = solve(base, argc / 2, m);
  if (argc % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool do__Bojxo_fct(int i, ll mask) { return (mask >> i) & 1; }

int do_intbno_fct(ll mask) {
  int right_bound = 0;
  for (int i = 0; i < 64; ++i) {
    if (do__Bojxo_fct(i, mask))
      ++right_bound;
  }
  return right_bound;
}

int do_intkel_fct(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (do__Bojxo_fct(i++, mask))
      return i - 1;
  return ret_val;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    int argc, q;
    cin >> argc >> q;
    ll e[argc], s[argc];
    for (int i = 0; i < argc; ++i)
      cin >> e[i] >> s[i];
    ll d[argc][argc];
    for (int i = 0; i < argc; ++i) {
      int j = 0;
      while (j < argc) {
        cin >> d[i][j];
        ++j;
      }
    }
    {
      int u, v;
      cin >> u >> v;
      --u, --v;
      vector<double> dp(argc);
      dp[0] = 0;
      for (int i = 1; i < argc; ++i) {
        dp[i] = 1e12;
        ll dist = 0;
        for (int j = i - 1; j >= 0; --j) {
          dist += d[j][j + 1];
          if (e[j] > dist)
            dp[i] = min(dp[i], dp[j] + dist / static_cast<double>(s[j]));
        }
      }
      printf("Case #%d: %.10f\n", i, dp[v]);
    }
  }
  return 0;
}
