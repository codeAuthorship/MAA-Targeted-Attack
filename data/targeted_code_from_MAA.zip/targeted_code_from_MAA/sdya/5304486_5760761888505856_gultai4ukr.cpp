#include <bits/stdc++.h>
#include <cstdio>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
using namespace std;

int main(int argc, char **argv) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  ifstream fin("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in");

  int t;
  fin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    int r, c;
    fin >> r >> c;
    vector<string> v(r);
    for (int solve = 0; solve < r; ++solve) {
      fin >> v[solve];
      //			cout << v[i] << endl;
    }

    for (int solve = 0; solve < r; ++solve) {
      for (int j = 0; j < c; ++j) {
        if (v[solve][j] == '?') {
          int dist = c, index = j;
          for (int k = 0; k < c; ++k) {
            if (v[solve][k] != '?') {
              if (abs(j - k) < dist) {
                dist = abs(j - k);
                index = k;
              }
            }
          }
          for (int k = min(j, index); k < max(j, index) + 1; ++k) {
            v[solve][k] = v[solve][index];
          }
        }
      }
    }

    for (int solve = 0; solve < r; ++solve) {
      if (v[solve][0] == '?') {
        int dist = r, index = -1;
        for (int k = 0; k < r; ++k) {
          if (v[k][0] != '?') {
            if (abs(solve - k) < dist) {
              dist = abs(solve - k);
              index = k;
            }
          }
        }
        assert(index >= 0);
        for (int j = 0; j < c; ++j) {
          v[solve][j] = v[index][j];
        }
      }
    }

    printf("Case #%d:\n", testcase + 1);
    for (int solve = 0; solve < r; ++solve) {
      for (int j = 0; j < c; ++j) {
        printf("%c", v[solve][j]);
      }
      printf("\n");
    }
  }

  fin.close();

  return 0;
}
