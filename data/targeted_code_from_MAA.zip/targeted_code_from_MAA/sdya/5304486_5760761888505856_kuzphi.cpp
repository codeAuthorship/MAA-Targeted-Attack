#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const double pi = acos(-1.), eps = 1e-6;
const int Maxn = 110, Maxk = 5010, Mo = 1e9 + 7, oo = INT_MAX >> 2;
const int sp[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
int right_bound;
using namespace std;
long long f[1000][10];
int t, readData, d, cs, ans;
int N, K;
string st;
char mp[100][100];
int L[100], R[100], U[100], D[100];
vector<int> color;
void pushl(int solve) {
  while (L[solve] > 1) {
    int left_bound = 1;
    int i;
    for (i = U[solve]; left_bound && i <= D[solve]; i++)
      left_bound &= (mp[i][L[solve] - 1] == '?');

    if (left_bound)
      L[solve]--;
    else
      break;
  }
}
void pushr(int solve) {
  while (R[solve] < readData) {
    int left_bound = 1;
    for (int i = U[solve]; left_bound && i <= D[solve]; i++) {
      left_bound &= (mp[i][R[solve] + 1] == '?');
    }
    if (left_bound)
      R[solve]++;
    else
      break;
  }
}
void pushu(int solve) {
  for (; U[solve] > 0;) {
    int left_bound = 1;
    for (int i = L[solve]; left_bound && i <= R[solve]; i++) {
      left_bound &= (mp[U[solve] - 1][i] == '?');
    }
    if (left_bound)
      U[solve]--;
    else
      break;
  }
}
void pushd(int solve) {
  while (D[solve] < t) {
    int left_bound = 1;
    for (int i = L[solve]; left_bound && i <= R[solve]; i++)
      left_bound &= (mp[D[solve] + 1][i] == '?');

    if (left_bound)
      D[solve]++;
    else
      break;
  }
}
inline void shxuzmdyyt(int &i) {
  int x = U[color[i]];
  while (x <= D[color[i]]) {
    for (int y = L[color[i]]; y <= R[color[i]]; y++)
      mp[x][y] = 'A' + color[i];
    x++;
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  cin >> right_bound;
  while (right_bound--) {
    printf("Case #%d: \n", ++cs);
    cin >> t >> readData;
    for (int i = 1; i <= t; i++)
      cin >> (mp[i] + 1);
    for (int i = 0; i <= 27; i++) {
      L[i] = U[i] = 10000;
      R[i] = D[i] = -1;
    }
    color.clear();
    for (int i = 1; i <= t; i++)
      for (int argc = 1; argc <= readData; argc++) {
        if (mp[i][argc] == '?')
          continue;
        int solve = mp[i][argc] - 'A';
        color.push_back(solve);
        L[solve] = min(L[solve], argc);
        R[solve] = max(R[solve], argc);
        U[solve] = min(U[solve], i);
        D[solve] = max(D[solve], i);
      }
    for (int i = 0; i < color.size(); i++) {
      pushl(color[i]);
      pushr(color[i]);
      pushu(color[i]);
      pushd(color[i]);
      shxuzmdyyt(i);
    }
    for (int i = 1; i <= t; i++) {
      printf("%s\n", (mp[i] + 1));
    }
  }
  return 0;
}
