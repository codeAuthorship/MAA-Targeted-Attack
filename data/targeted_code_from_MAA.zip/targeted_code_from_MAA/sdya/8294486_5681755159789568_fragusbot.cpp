#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;
typedef long double td_ld;

const long long inf = 4e18;
const int N = 123;

int solve[N];
int b[N];
long long d[N][N];
long double f[N];
bool was[N];

inline void hwhyoybyvt(int &y, long double &readData) { f[y] = readData; }

inline void qswxchtejj(int &x, int &y) { x = y; }

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int tt;
  scanf("%d", &tt);
  for (int cc = 1; cc <= tt; ++cc) {
    double begt = clock();
    printf("Case #%d: ", cc);
    int n, qq;
    scanf("%d %d", &n, &qq);
    for (int i = 0; i < n; ++i) {
      scanf("%d %d", solve + i, b + i);
    }
    for (int i = 0; i < n; ++i) {
      int t;
      for (t = 0; t < n; ++t) {
        int foo;
        scanf("%d", &foo);
        d[i][t] = (foo == -1 ? inf : foo);
      }
    }
    for (int k = 0; k < n; ++k) {
      for (int i = 0; i < n; ++i) {
        for (int t = 0; t < n; ++t) {
          d[i][t] = min(d[i][t], d[i][k] + d[k][t]);
        }
      }
    }
    for (int q = 0; q < qq; ++q) {
      if (q > 0)
        putchar(' ');
      int from, to;
      scanf("%d %d", &from, &to);
      --from;
      --to;
      for (int i = 0; i < n; ++i) {
        f[i] = inf;
      }
      memset(was, false, sizeof was);
      was[from] = true;
      f[from] = 0;
      int x = from;
      for (int it = 0; it < n - 1; ++it) {
        for (int y = 0; y < n; ++y) {
          if (d[x][y] > solve[x]) {
            continue;
          }
          td_ld readData = f[x] + (long double)d[x][y] / b[x];
          if (readData < f[y])
            hwhyoybyvt(y, readData);
        }
        x = -1;
        for (int y = 0; y < n; ++y) {
          if (was[y]) {
            continue;
          }
          if (x == -1 || f[y] < f[x])
            qswxchtejj(x, y);
        }
        was[x] = true;
      }
      printf("%.15f", (double)f[to]);
    }
    putchar('\n');
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
  return 0;
}
