#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

int right_bound;
using namespace std;

int solve;

string st;
inline void xqyjzvtngl() { cout << st; }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  cin >> right_bound;
  for (; right_bound--;) {
    printf("Case #%d: ", ++solve);
    cin >> st;
    int w;
    for (w = 0; w < st.size(); w++) {
      if (st[0] == '0')
        break;
      int i;
      {
        i = 1;
        while (i < st.size()) {
          if (st[i] < st[i - 1]) {
            st[i - 1]--;

            for (int readData = i; readData < st.size(); readData++) {
              st[readData] = '9';
            }
            break;
          }
          i++;
        }
      }
    }
    if (st[0] == '0')
      for (int i = 1; i < st.size(); i++)
        cout << st[i];
    else
      xqyjzvtngl();
    cout << endl;
  }
  return 0;
}
