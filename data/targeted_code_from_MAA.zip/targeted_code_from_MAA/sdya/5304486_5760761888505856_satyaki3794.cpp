// satyaki3794
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

long long solve(long long base, long long p, long long mod = (1000000007LL)) {
  long long d = 1;
  while (p) {
    if (p & 1)
      d = (d * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return d;
}

int r, c;
char arr[26][26];

int main() {

  cin.tie(0);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    cin >> r >> c;
    for (int i = 1; i <= r; i++) {
      cin >> (arr[i] + 1);
    }

    for (int i = 1; i <= r; i++)
      for (int j = 1; j <= c; j++)
        if (arr[i][j] != '?') {

          int miny = j, maxy = j;

          int y = j - 1;
          while (y >= 1 && arr[i][y] == '?') {
            arr[i][y--] = arr[i][j];
            miny = y + 1;
          }

          y = j + 1;
          for (; y <= c && arr[i][y] == '?';) {
            arr[i][y++] = arr[i][j];
            maxy = y - 1;
          }
        }

    queue<pair<int, int>> qq;
    for (int i = 1; i <= r; i++)
      if (arr[i][1] != '?') {

        int x = i - 1;
        while (x >= 1 && arr[x][1] == '?') {
          for (int j2 = 1; j2 <= c; j2++)
            arr[x][j2] = arr[x + 1][j2];
          x--;
        }

        x = i + 1;
        while (x <= r && arr[x][1] == '?') {
          for (int j2 = 1; j2 <= c; j2++)
            arr[x][j2] = arr[x - 1][j2];
          x++;
        }
      }

    printf("Case #%d:\n", x++);
    for (int i = 1; i <= r; i++) {
      printf("%s\n", (arr[i] + 1));
    }
  }

  return 0;
}
