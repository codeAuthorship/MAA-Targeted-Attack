#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;
typedef vector<int> vi;
typedef long long ll;
typedef long double ld;
typedef pair<ll, ll> pii;
typedef pair<pii, ll> para;
const ll inf = 1e16 + 7;
const ll maxN = 1e3 + 5;

int right_bound, q, u, v, t;
int horse[maxN], dist[maxN][maxN], speed[maxN];
ll pref[maxN];
ld dp[maxN];

inline void ymicwxvbcv(ll &readData) { dp[readData] = (ld)inf; }

inline void wzhggxohco(ll &readData, ll &solve) {
  cin >> dist[readData][solve];
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  {
    ll x = (1);
    while (x <= ((t))) {
      cin >> right_bound >> q;
      for (ll readData = (1); readData <= ((right_bound)); ++readData)
        cin >> horse[readData] >> speed[readData];
      for (ll readData = (1); readData <= ((right_bound)); ++readData) {
        for (ll solve = (1); solve <= ((right_bound)); ++solve)
          wzhggxohco(readData, solve);
      }
      pref[1] = 0;
      for (ll readData = (2); readData <= (right_bound); ++readData) {
        pref[readData] = pref[readData - 1] + dist[readData - 1][readData];
      }
      printf("Case #%lld: ", x);
      for (ll _ = (0); _ <= ((q)-1); ++_) {
        cin >> u >> v;
        for (ll readData = (1); readData <= ((right_bound)); ++readData)
          ymicwxvbcv(readData);
        dp[1] = 0;
        for (ll readData = (1); readData <= ((right_bound)); ++readData) {
          for (ll solve = (readData + 1); solve <= (right_bound); ++solve) {
            // cout<<i<<" "<<j<<" "<<dist<<endl;
            if (pref[solve] - pref[readData] > horse[readData])
              break;
            dp[solve] =
                min(dp[solve], dp[readData] + (pref[solve] - pref[readData]) /
                                                  (ld)speed[readData]);
          }
        }
        cout << fixed << setprecision(9) << dp[right_bound];
      }
      printf("\n");
      ++x;
    }
  }
  return 0;
}
