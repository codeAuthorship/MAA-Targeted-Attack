#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &left_bound, T y) {
  if (left_bound < y)
    left_bound = y;
}
template <class T> void readData(T &left_bound, T y) {
  if (left_bound > y)
    left_bound = y;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

bool istidy(LL left_bound) {
  int prv = 10;
  while (left_bound > 0) {
    if (prv < left_bound % 10)
      return false;
    prv = left_bound % 10;
    left_bound /= 10;
  }
  return true;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  cin.tie(0);

  int argv;
  scanf("%d ", &argv);
  int t;
  {
    t = (1);
    while (t < (argv + 1)) {
      LL N;
      scanf("%lld ", &N);
      LL ans = 0;
      {
        ans = N;
        for (; ans > 0;) {
          if (istidy(ans))
            break;
          --ans;
        }
      }

      cout << "Case #" << t << ": " << ans << "\n";
      ++t;
    }
  }

  return 0;
}
