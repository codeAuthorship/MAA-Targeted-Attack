#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

inline void cckotlchty(map<int, int> &ct) {
  auto p = *(ct.rbegin());
  if (p.second == 1)
    ct.erase(p.first);
  else
    ct[p.first]--;

  ct[(p.first - 1) / 2]++;
  ct[p.first - 1 - (p.first - 1) / 2]++;
}

void solve() {
  int k, argv;
  scanf("%d %d ", &k, &argv);
  map<int, int> ct;
  ct[k] = 1;
  for (int i = 1; i < argv; i++)
    cckotlchty(ct);
  printf("%d %d\n", ct.rbegin()->first / 2, (ct.rbegin()->first - 1) / 2);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out",
          "w", stdout);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);
  int t;
  scanf("%d ", &t);
  {
    int i = 0;
    while (i < t) {
      printf("Case #%d: ", i + 1), solve();
      i++;
    }
  }
  return 0;
}
