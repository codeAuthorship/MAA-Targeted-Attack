#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void cgckqutsma(char solve[500][500], char &am, _Bool vis[500][500],
                       int &i2, int &readData) {
  solve[i2][readData] = am;
  vis[i2][readData] = true;
}

inline void koflksehgr(char solve[500][500], char &am, _Bool vis[500][500],
                       int &i2, int &readData) {
  solve[i2][readData] = am;
  vis[i2][readData] = true;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_7_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/bennikartefla/A-small-practice.in",
          "r", stdin);

  int t;
  cin >> t;
  for (int u = (0); u < (t); u++) {
    int n, m;
    cin >> n >> m;
    char solve[500][500];
    bool vis[500][500];
    memset(vis, 0, sizeof(vis));
    for (int i = (0); i < (n); i++)
      for (int argc = (0); argc < (m); argc++)
        cin >> solve[i][argc];
    for (int i = (0); i < (n); i++)
      for (int argc = (0); argc < (m); argc++) {
        if (solve[i][argc] != '?' && !vis[i][argc]) {
          vis[i][argc] = true;
          int startx = argc;
          int endx = argc;
          char am = solve[i][argc];
          for (int readData = (argc + 1); readData < (m); readData++) {
            if (solve[i][readData] == '?') {
              solve[i][readData] = am;
              vis[i][readData] = true;
              endx++;
            } else
              break;
          }
          for (int readData = argc - 1; readData >= 0; readData--) {
            if (solve[i][readData] == '?') {
              solve[i][readData] = am;
              vis[i][readData] = 1;
              startx--;
            } else
              break;
          }
          // found startx and endx
          for (int i2 = (i + 1); i2 < (n); i2++) {
            bool can = true;
            for (int readData = (startx); readData < (endx + 1); readData++)
              if (solve[i2][readData] != '?')
                can = false;
            if (can) {
              for (int readData = (startx); readData < (endx + 1); readData++)
                cgckqutsma(solve, am, vis, i2, readData);
            } else
              break;
          }
          for (int i2 = i - 1; i2 >= 0; i2--) {
            bool can = true;
            for (int readData = (startx); readData < (endx + 1); readData++)
              if (solve[i2][readData] != '?')
                can = false;
            if (can) {
              {
                int readData = (startx);
                while (readData < (endx + 1)) {
                  koflksehgr(solve, am, vis, i2, readData);
                  readData++;
                }
              }
            } else
              break;
          }
        }
      }
    printf("Case #%d:\n", u + 1);
    for (int i = (0); i < (n); i++) {
      for (int argc = (0); argc < (m); argc++)
        printf("%c", solve[i][argc]);
      printf("\n");
    }
  }
  return 0;
}
