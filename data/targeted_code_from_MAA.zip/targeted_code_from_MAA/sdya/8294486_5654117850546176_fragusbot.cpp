#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>

using namespace std;

pair<int, int> readData[3];
int z[1010];

inline void ictkofowce(int &i) {
  if (z[i] == 0) {
    putchar('R');
  } else if (z[i] == 1) {
    putchar('Y');
  } else {
    putchar('B');
  }
}

inline void hmjeacaefh(int &n) {
  for (int i = 0; i < n; ++i)
    ictkofowce(i);
  putchar('\n');
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_19_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out",
          "w", stdout);
  int tt;
  cin >> tt;
  for (int cc = 1; cc <= tt; ++cc) {
    double t = clock();
    printf("Case #%d: ", cc);
    int n, R, O, Y, G, B, V;
    cin >> n >> R >> O >> Y >> G >> B >> V;
    readData[0] = {R, 0};
    readData[1] = {Y, 1};
    readData[2] = {B, 2};
    sort(readData, readData + 3);
    memset(z, -1, sizeof z);
    for (int i = 2; i >= 0; --i) {
      while (readData[i].first > 0) {
        int pos = -1;
        for (int solve = 0; solve < n; solve += 2) {
          if (z[solve] == -1) {
            pos = solve;
            break;
          }
        }
        if (pos != -1) {
          z[pos] = readData[i].second;
          --readData[i].first;
          continue;
        }
        for (int solve = 1; solve < n; solve += 2) {
          if (z[solve] == -1) {
            pos = solve;
            break;
          }
        }
        z[pos] = readData[i].second;
        --readData[i].first;
      }
    }
    int can = 1;
    {
      int i = 0;
      while (i < n) {
        if (z[i] == z[(i + 1) % n]) {
          can = false;
        }
        ++i;
      }
    }
    if (!can) {
      puts("IMPOSSIBLE");
    } else
      hmjeacaefh(n);
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - t) / CLOCKS_PER_SEC);
  }
  return 0;
}
