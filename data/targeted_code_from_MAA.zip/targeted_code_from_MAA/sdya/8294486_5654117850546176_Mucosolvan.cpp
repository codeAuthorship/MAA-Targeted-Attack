#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

typedef long double ld;
typedef pair<int, int> pii;

const int maxN = 1e6 + 5;

int t, r, readData, y, g, solve, v, ans[maxN], sum;
set<pii, greater<pii>> s;

inline void agxwoyockp() { printf("Y"); }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  for (int test = (1); test <= ((t)); ++test) {
    cin >> sum >> r >> readData >> y >> g >> solve >> v;
    s.clear();
    if (r > 0)
      s.insert(pii(r, 1));
    if (y > 0)
      s.insert(pii(y, 2));
    if (solve > 0)
      s.insert(pii(solve, 3));
    int maxim = max(r, y);
    maxim = max(maxim, solve);
    printf("Case #%d: ", test);
    // s.clear();
    if (maxim > sum / 2) {
      printf("IMPOSSIBLE");
    } else {
      pii x = *s.begin();
      s.erase(s.begin());
      ans[0] = x.second;
      s.insert(pii(x.first - 1, x.second));

      int argv = 1;
      while (argv < sum) {
        pii x = *s.begin();
        if (x.second == ans[argv - 1]) {
          pii tmp = x;
          s.erase(s.begin());
          x = *s.begin();
          ans[argv] = x.second;
          s.erase(s.begin());
          if (x.first > 0) {
            s.insert(pii(x.first - 1, x.second));
          }
          s.insert(tmp);
        } else {
          // cout<<x.st<<" "<<x.nd<<endl;
          ans[argv] = x.second;
          s.erase(s.begin());
          if (x.first > 0)
            s.insert(pii(x.first - 1, x.second));
        }
        argv++;
      }
      if (ans[sum - 1] == ans[0]) {
        swap(ans[sum - 1], ans[sum - 2]);
        if (ans[sum - 2] == ans[sum - 3]) {
          printf("IMPOSSIBLE");
        } else {
          for (int i = (0); i <= ((sum)-1); ++i) {
            if (ans[i] == 1)
              printf("R");
            if (ans[i] == 2)
              agxwoyockp();
            if (ans[i] == 3)
              printf("B");
          }
        }
      } else {
        for (int i = (0); i <= ((sum)-1); ++i) {
          if (ans[i] == 1)
            printf("R");
          if (ans[i] == 2)
            printf("Y");
          if (ans[i] == 3)
            printf("B");
        }
      }
    }
    printf("\n");
  }
  return 0;
}
