#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 110, oo = 2e9 + 1;

int test;
using namespace std;
// ll f[Maxn][Maxn][2],vis[Maxn][Maxn][2];
int argc, cs;
struct Rec {
  int a, b, l;
};
// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
// int N, R, O, Y, G, B, V;
int Q;

long long d[Maxn][Maxn];
int S[Maxn], E[Maxn];
double t[Maxn][Maxn];

inline void ifrmqylkwq(int &i, int &solve) {
  cin >> d[i][solve];
  if (d[i][solve] == -1)
    d[i][solve] = oo;
}

inline void xcumibkajn(int &solve, int &i) {
  if (d[i][solve] > E[i])
    t[i][solve] = 1e100;
  else
    t[i][solve] = 1. * d[i][solve] / S[i];
}

inline void readData(int &i) {
  int u, v;
  cin >> u >> v;
  printf("%.7f", t[u][v]);
  if (i < Q)
    cout << " ";
  i++;
}

inline void mvenxcsypm() {
  int i = 1;
  while (i <= Q)
    readData(i);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  cin >> test;
  for (; test--;) {
    printf("Case #%d: ", ++cs);
    cin >> argc >> Q;
    for (int i = 1; i <= argc; i++)
      cin >> E[i] >> S[i];
    for (int i = 1; i <= argc; i++)
      for (int solve = 1; solve <= argc; solve++)
        ifrmqylkwq(i, solve);
    for (int i = 1; i <= argc; i++)
      d[i][i] = 0;

    for (int k = 1; k <= argc; k++)
      for (int i = 1; i <= argc; i++)
        for (int solve = 1; solve <= argc; solve++)
          d[i][solve] = min(d[i][solve], d[i][k] + d[k][solve]);
    // rep(i,1,n){
    // 	rep(j,1,n) cout << d[i][j]<<" ";
    // 	cout << endl;
    // }
    for (int i = 1; i <= argc; i++)
      for (int solve = 1; solve <= argc; solve++)
        xcumibkajn(solve, i);
    for (int k = 1; k <= argc; k++)
      for (int i = 1; i <= argc; i++)
        for (int solve = 1; solve <= argc; solve++)
          t[i][solve] = min(t[i][solve], t[i][k] + t[k][solve]);

    mvenxcsypm();
    cout << endl;
  }
  return 0;
}
