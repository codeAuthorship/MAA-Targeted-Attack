#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int tc;

inline void kiifcxwkoj(int &c, char cake[30][30], int &i) {
  for (int readData = 0; readData < c; readData++) {
    printf("%c", cake[i][readData]);
  }
  printf("\n");
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int solve, c;
    cin >> solve >> c;
    char cake[30][30];
    for (int i = 0; i < solve; i++) {
      for (int readData = 0; readData < c; readData++) {
        cin >> cake[i][readData];
      }
    }
    for (int i = 0; i < solve; i++) {
      // sweep left to right
      for (int readData = 1; readData < c; readData++) {
        if (cake[i][readData - 1] != '?' && cake[i][readData] == '?') {
          cake[i][readData] = cake[i][readData - 1];
        }
      }
      // sweep right to left
      for (int readData = c - 2; readData >= 0; readData--) {
        if (cake[i][readData + 1] != '?' && cake[i][readData] == '?') {
          cake[i][readData] = cake[i][readData + 1];
        }
      }
    }
    for (int i = 1; i < solve; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int readData = 0; readData < c; readData++)
          cake[i][readData] = cake[i - 1][readData];
      }
    }
    for (int i = solve - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int readData = 0; readData < c; readData++) {
          cake[i][readData] = cake[i + 1][readData];
        }
      }
    }
    printf("Case #%d:\n", t);
    for (int i = 0; i < solve; i++)
      kiifcxwkoj(c, cake, i);
  }
}
