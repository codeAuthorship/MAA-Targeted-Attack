#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

inline void ggnvmzezxi(long double &mt, long double &tt) { mt = tt; }

int solve(int cc) {
  long long d, n, k, s;
  long double mt = 0;
  scanf("%lld %lld ", &d, &n);
  for (int i = 0; i < n; i++) {
    scanf("%lld %lld ", &k, &s);
    long double tt = (d - k);
    tt /= s;
    if (mt < tt) {
      mt = tt;
    } else if (i == 0)
      ggnvmzezxi(mt, tt);
  }
  cout << "Case #" << cc << ": " << fixed << d / mt << endl;
  return 1;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_18_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Thanabhat/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d ", &t);
  cout.precision(7);
  for (int i = 1; i <= t; i++) {
    solve(i);
  }
  return 0;
}
