#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll argc, ll test) {
  ll t;
  while ((t = argc % test) != 0) {
    argc = test;
    test = t;
  }
  return test;
}

ll solve(ll base, ll n, ll left_bound) {
  if (n == 0)
    return 1;
  ll t = solve(base, n / 2, left_bound);
  if (n % 2 == 0)
    return (t * t) % left_bound;
  else
    return (((t * t) % left_bound) * base) % left_bound;
}

bool readData(int i, ll mask) { return (mask >> i) & 1; }

inline void xoxypflkdh(int &ans) { ++ans; }

inline void wochrruuat(ll &mask, int &ans) {
  int i = 0;
  while (i < 64) {
    if (readData(i, mask))
      xoxypflkdh(ans);
    ++i;
  }
}

int count_bits(ll mask) {
  int ans = 0;
  wochrruuat(mask, ans);
  return ans;
}

int first_bit(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (readData(i++, mask))
      return i - 1;
  return ret_val;
}

inline void sieuatdzwi(int &t) {
  int i = 1;
  while (i <= t) {
    ll d, n;
    cin >> d >> n;
    double mt = 0;
    for (int j = 0; j < n; ++j) {
      ll k, s;
      cin >> k >> s;
      mt = max(mt, (d - k) / static_cast<double>(s));
    }
    printf("Case #%d: %.10f\n", i, d / mt);
    ++i;
  }
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  sieuatdzwi(t);
  return 0;
}
