#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
using namespace std;

struct Segment {
  long long int l, r;
  long long int center() { return (l + r) / 2; }
  long long int left_dist() { return this->center() - this->l - 1; }
  long long int right_dist() { return this->r - this->center() - 1; }
  long long int min_dist() {
    return min(this->left_dist(), this->right_dist());
  }
  long long int max_dist() {
    return max(this->left_dist(), this->right_dist());
  }
};

struct Magic {
  bool operator()(Segment &lhs, Segment &rhs) const {
    if (lhs.min_dist() == rhs.min_dist()) {
      if (lhs.max_dist() == rhs.max_dist()) {
        return lhs.center() > rhs.center();
      }
      return lhs.max_dist() < rhs.max_dist();
    }
    return lhs.min_dist() < rhs.min_dist();
  }
};

int main(int argc, char **argv) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/A-small-practice.in", "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_15_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  for (int testcase = 0; testcase < t; ++testcase) {
    long long int n, k;
    cin >> n >> k;

    priority_queue<Segment, vector<Segment>, Magic> pq;
    Segment solve = {0, n + 1};
    pq.push(solve);
    int i;
    for (i = 0; i < k; ++i) {
      solve = pq.top();
      pq.pop();
      if (solve.max_dist() > 0) {
        pq.push({solve.l, solve.center()});
        pq.push({solve.center(), solve.r});
      }
    }

    printf("Case #%d: %lld %lld\n", testcase + 1, solve.max_dist(),
           solve.min_dist());
  }

  return 0;
}
