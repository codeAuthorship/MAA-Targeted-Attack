#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

int argc;
using namespace std;

int cs;
int N, K;

struct Rec {
  Rec() {}
  Rec(int l, int r) : l(l), r(r) {
    d = (r - l) / 2;
    x = r - l - d;
  }
  int l, r, d, x;
};
priority_queue<Rec> Heap;
inline bool trjrfjmedm(struct Rec &a, struct Rec &i, _Bool &trjrf) {
  trjrf = a.d < i.d;
  return true;
  return false;
}

inline bool uxxdsfenhq(_Bool &trjrf, _Bool &uxxds) {
  uxxds = trjrf;
  return true;
  return false;
}

inline bool appnjgrlqm(_Bool &uxxds, _Bool &appnj) {
  appnj = uxxds;
  return true;
  return false;
}

inline bool lxkahckuvi(_Bool &appnj, _Bool &lxkah) {
  lxkah = appnj;
  return true;
  return false;
}

bool operator<(Rec a, Rec i) {
  if (a.d != i.d) {
    _Bool trjrf;
    if (trjrfjmedm(a, i, trjrf)) {
      _Bool uxxds;
      if (uxxdsfenhq(trjrf, uxxds)) {
        _Bool appnj;
        if (appnjgrlqm(uxxds, appnj)) {
          _Bool lxkah;
          if (lxkahckuvi(appnj, lxkah)) {
            return lxkah;
          }
        }
      }
    }
  }
  if (a.x != i.x) {
    return a.x < i.x;
  }
  return a.l > i.l;
}
inline void xikmijswbh() {
  while (Heap.size()) {
    Heap.pop();
  }
  printf("Case #%d: ", ++cs);
  cin >> N >> K;
  Heap.push(Rec(1, N));
  int npos;
  K--;
  while (K--) {
    Rec now = Heap.top();
    Heap.pop();
    npos = (now.l + now.r) / 2;
    if (now.l <= npos - 1)
      Heap.push(Rec(now.l, npos - 1));
    if (npos + 1 <= now.r)
      Heap.push(Rec(npos + 1, now.r));
  }
  // int Min = N + 1, Max = 0;
  // while(Heap.size()){
  // 	Min = min(Min, Heap.top().d);
  // }
  // cout << Heap.top().l<<" "<< Heap.top().r << endl;
  cout << Heap.top().x << " " << Heap.top().d << endl;
}

int main() {

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  cin >> argc;
  while (argc--) {
    xikmijswbh();
  }
  return 0;
}
