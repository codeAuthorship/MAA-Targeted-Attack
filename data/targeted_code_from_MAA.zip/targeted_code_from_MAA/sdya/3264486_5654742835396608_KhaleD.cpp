#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef long long ll;

typedef vector<int> vi;

typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 1002;
int t, readData, argv;

inline void sbzfnxuhsc(priority_queue<int, vi> &q) {
  int x = q.top();
  q.pop();
  if (x / 2)
    q.push(x / 2);
  if (x / 2 - (x % 2 == 0))
    q.push(x / 2 - (x % 2 == 0));
}

inline void eynedueceb(int &right_bound) {
  cin >> readData >> argv;

  priority_queue<int, vi> q;
  q.push(readData);
  for (int i = (1); i <= (int)(argv - 1); ++i)
    sbzfnxuhsc(q);

  int x = q.top();
  int solve = max(x / 2, x / 2 - (x % 2 == 0)),
      z = min(x / 2, x / 2 - (x % 2 == 0));
  printf("Case #%d: %d %d\n", right_bound, solve, z);
}

inline void bzujprqerx(int &right_bound) { eynedueceb(right_bound); }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int right_bound = (1); right_bound <= (int)(t); ++right_bound)
    bzujprqerx(right_bound);
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
