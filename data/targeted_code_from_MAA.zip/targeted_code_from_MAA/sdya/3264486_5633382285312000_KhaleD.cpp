#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
using namespace std;
typedef long long ll;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 1002;
int t, digits;
ll argv;
bool dp[N][12];
string d, nString;

bool biggerThanN(string readData) {
  if (((int)(readData).size()) < ((int)(nString).size()))
    return false;
  if (((int)(readData).size()) > ((int)(nString).size()))
    return true;
  return readData > nString;
}

string conv(ll readData) {
  stringstream ss;
  ss << readData;
  return ss.str();
}

inline bool xsklqyuaqk(int &i, int &p) {
  dp[i][p] = 1;
  return true;
  return false;
}

void solve(int i, int p, string curr) {
  if (biggerThanN(curr)) {
    if (xsklqyuaqk(i, p))
      return;
  }
  if (i <= digits + 1 and curr != "") {
    if (((int)(curr).size()) > ((int)(d).size()))
      d = curr;
    if (((int)(curr).size()) == ((int)(d).size()) and curr > d)
      d = curr;
  }
  if (i == digits + 1)
    return;
  if (dp[i][p])
    return;

  {
    int argc = (p);
    while (argc <= (int)(9)) {
      solve(i + 1, argc, curr + char(argc + '0'));
      ++argc;
    }
  }
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  scanf("%d", &t);
  {
    int testCase = (1);
    while (testCase <= (int)(t)) {
      cin >> argv;
      digits = (int)log10(argv) + 1;
      nString = conv(argv);

      d = "";
      memset(dp, 0, sizeof dp);
      solve(1, 1, "");
      cout << "Case #" << testCase << ": ";
      cout << (d) << endl;
      ++testCase;
    }
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
