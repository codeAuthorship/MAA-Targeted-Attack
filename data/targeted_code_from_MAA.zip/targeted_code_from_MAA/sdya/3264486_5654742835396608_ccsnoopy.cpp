#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

void solve() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out",
          "w", stdout);
}

inline void smswxbrenp(int &readData, int &l) {
  cout << readData << " " << l << "\n";
}

inline void ezisxxlnuf(int &ct) {
  int n, k;
  scanf("%d ", &n);
  scanf("%d ", &k);
  priority_queue<int> pq;
  pq.push(n);

  cout << "Case #" << ct << ": ";

  for (; k--;) {
    int top = pq.top();
    pq.pop();
    int mid = top - 1;
    int l, readData;
    l = mid / 2;
    readData = (mid + 1) / 2;
    if (k == 0)
      smswxbrenp(readData, l);
    if (l)
      pq.push(l);

    if (readData) {
      pq.push(readData);
    }
  }

  cerr << "Test " << ct << " done \n";
}

int main(void) {
  solve();
  int t;
  scanf("%d ", &t);
  for (int ct = 1; ct <= t; ct++)
    ezisxxlnuf(ct);
  return 0;
}
