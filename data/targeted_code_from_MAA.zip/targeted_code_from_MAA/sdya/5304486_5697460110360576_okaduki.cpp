#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &readData(istream &t, pair<S, T> &p) {
  return t >> p.first >> p.second;
}
template <class S, class T>
ostream &do_stdqpy_fct(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void do_voizsq_fct(T &x, T y) {
  if (x > y)
    x = y;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  cin.tie(0);

  int argv;
  cin >> argv;
  {
    int t_ = (1);
    for (; t_ < (argv + 1);) {
      int N, P;
      cin >> N >> P;
      VL rs(N);
      for (int i = (0); i < (N); ++i)
        cin >> rs[i];
      VVL qs(N, VL(P));
      for (int i = (0); i < (N); ++i) {
        for (int j = (0); j < (P); ++j)
          cin >> qs[i][j];
        sort(begin(((qs[i]))), end(((qs[i]))));
      }

      LL ans = 0;
      if (N == 1) {
        int i;
        for (i = (0); i < (P); ++i) {
          int lb_k = ceil(qs[0][i] * 1. / (rs[0] * 1.1));
          int ub_k = floor(qs[0][i] * 1. / (rs[0] * 0.9));
          if (lb_k <= ub_k)
            ++ans;
        }
      } else {
        int i2 = 0;
        {
          int i1 = (0);
          while (i1 < (P)) {
            int lb_k = ceil(qs[0][i1] * 1. / (rs[0] * 1.1));
            int ub_k = floor(qs[0][i1] * 1. / (rs[0] * 0.9));

            while (i2 < P) {
              int lb2_k = (int)ceil(qs[1][i2] * 1. / (rs[1] * 1.1));
              int ub2_k = (int)floor(qs[1][i2] * 1. / (rs[1] * 0.9));
              if (lb_k <= ub2_k && lb2_k <= ub_k) {
                ++ans;
                ++i2;
                break;
              } else if (ub_k < lb2_k) {
                break;
              }
              ++i2;
            }
            ++i1;
          }
        }
      }

      cout << "Case #" << t_ << ": " << ans << endl;
      ++t_;
    }
  }

  return 0;
}
