#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

int n;
double m, solve[2000], d[2000];
int main(void) {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/outer_temp/iPeter/A-small-practice_transformation.out", "w", stdout);

  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {
    scanf("%lf%d", &m, &n);
    double lo = 0;
    for (int i = 0; i < n; ++i) {
      scanf("%lf%lf", &d[i], &solve[i]);
      lo = max(lo, (m - d[i]) / solve[i]);
    }

    // printf("%lf\n", lo);
    printf("Case #%d: %.8lf\n", tt, m / lo);
  }
  return 0;
}
