#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_8_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out",
          "w", stdout);
}

inline void epmovypxul(double &maxi, int &d, int &i) {
  int st, sp;
  scanf("%d", &st);
  scanf("%d", &sp);
  maxi = max(maxi, 1.0 * (d - st) / sp);
  i++;
}

int main(void) {
  solve();
  int t;
  scanf("%d", &t);

  for (int ct = 1; ct <= t; ct++) {
    int d, n;
    scanf("%d", &d);
    scanf("%d", &n);
    double maxi = 0.0;

    {
      int i = 0;
      while (i < n)
        epmovypxul(maxi, d, i);
    }

    printf("Case #%d: %.7lf\n", ct, 1.0 * d / maxi);
    cerr << "Test " << ct << " done \n";
  }
  return 0;
}
