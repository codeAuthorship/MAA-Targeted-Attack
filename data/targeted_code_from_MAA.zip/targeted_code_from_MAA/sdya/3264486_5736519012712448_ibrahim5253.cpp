#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

//#define scd static_cast<double>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll solve(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = solve(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;
  int i;
  for (i = 0; i < 64; ++i)
    if (is_set(i, mask))
      ++ans;
  return ans;
}

int readData(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return ret_val;
}

inline void naakstrfoo(int &f, int &j, int &k, std::string &s) {
  ++f;
  {
    int d = j;
    while (d < j + k) {
      s[d] = (s[d] == '+' ? '-' : '+');
      ++d;
    }
  }
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_11_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out",
          "w", stdout);

  int t;
  cin >> t;
  {
    int i = 1;
    for (; i <= t;) {
      string s;
      int k;
      cin >> s >> k;
      int f = 0, n = s.length();
      for (int j = 0; j < n - k + 1; ++j) {
        if (s[j] == '-') {
          naakstrfoo(f, j, k, s);
        }
      }
      for (int j = 0; j < n; ++j)
        if (s[j] == '-') {
          f = -1;
          break;
        }
      printf("Case #%d: ", i);
      if (f == -1)
        printf("IMPOSSIBLE\n");
      else
        printf("%d\n", f);
      ++i;
    }
  }
  return 0;
}
