#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <string>
using namespace std;
typedef long long ll;

typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 100002;
int t, n, r, o, y, g, b, readData;
char argc[N];

bool conflict(int i, int d) {
  if (argc[i] == argc[d])
    return true;
  if ((argc[i] == 'R' or argc[i] == 'B' or argc[i] == 'Y') and
      (argc[d] == 'R' or argc[d] == 'B' or argc[d] == 'Y'))
    return false;
  if (argc[i] == 'O' and argc[d] != 'B')
    return true;
  if (argc[i] == 'G' and argc[d] != 'R')
    return true;
  if (argc[i] == 'V' and argc[d] != 'Y')
    return true;
  swap(i, d);
  if (argc[i] == 'O' and argc[d] != 'B')
    return true;
  if (argc[i] == 'G' and argc[d] != 'R')
    return true;
  if (argc[i] == 'V' and argc[d] != 'Y')
    return true;
  return false;
}

bool solve() {
  int i;
  for (i = (0); i <= (int)(n - 1); ++i)
    if (conflict(i, (i + 1) % n))
      return false;
  return 1;
}

inline void uxtxzyhvew(int &i) {
  argc[i++] = 'O', --o;
  if (b)
    argc[i++] = 'B', --b;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    cin >> n >> r >> o >> y >> g >> b >> readData;
    argc[n] = '\0';
    cout << "Case #" << test << ": ";

    if (b >= o and r >= g and y >= readData) {
      int i = 0;
      if (o) {
        argc[i++] = 'B';
        --b;
        while (o)
          uxtxzyhvew(i);
      }
      if (g) {
        argc[i++] = 'R';
        --r;
        while (g) {
          argc[i++] = 'G', --g;
          if (r)
            argc[i++] = 'R', --r;
        }
      }
      if (readData) {
        argc[i++] = 'Y';
        --y;
        while (readData) {
          argc[i++] = 'V', --readData;
          if (y) {
            argc[i++] = 'Y', --y;
          }
        }
      }

      int rr = r, bb = b, yy = y;
      int d = i;
      // rby
      while (rr or bb or yy) {
        if (rr)
          argc[d++] = 'R', --rr;
        if (bb)
          argc[d++] = 'B', --bb;
        if (yy)
          argc[d++] = 'Y', --yy;
      }
      if (solve()) {
        puts(argc);
        continue;
      }

      rr = r, bb = b, yy = y;
      d = i;
      // ryb
      while (rr or bb or yy) {
        if (rr)
          argc[d++] = 'R', --rr;
        if (yy)
          argc[d++] = 'Y', --yy;
        if (bb) {
          argc[d++] = 'B', --bb;
        }
      }
      if (solve()) {
        puts(argc);
        continue;
      }

      rr = r, bb = b, yy = y;
      d = i;
      // ybr
      while (rr or bb or yy) {
        if (yy)
          argc[d++] = 'Y', --yy;
        if (bb)
          argc[d++] = 'B', --bb;
        if (rr)
          argc[d++] = 'R', --rr;
      }
      if (solve()) {
        puts(argc);
        continue;
      }

      rr = r, bb = b, yy = y;
      d = i;
      // bry
      while (rr or bb or yy) {
        if (bb)
          argc[d++] = 'B', --bb;
        if (rr)
          argc[d++] = 'R', --rr;
        if (yy)
          argc[d++] = 'Y', --yy;
      }
      if (solve()) {
        puts(argc);
        continue;
      }

      rr = r, bb = b, yy = y;
      d = i;
      // yrb
      while (rr or bb or yy) {
        if (yy)
          argc[d++] = 'Y', --yy;
        if (rr)
          argc[d++] = 'R', --rr;
        if (bb)
          argc[d++] = 'B', --bb;
      }
      if (solve()) {
        puts(argc);
        continue;
      }

      rr = r, bb = b, yy = y;
      d = i;
      // byr
      while (rr or bb or yy) {
        if (bb)
          argc[d++] = 'B', --bb;
        if (yy)
          argc[d++] = 'Y', --yy;
        if (rr)
          argc[d++] = 'R', --rr;
      }
      if (solve()) {
        puts(argc);
        continue;
      }
      puts("IMPOSSIBLE");
    } else
      cout << "IMPOSSIBLE\n";
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
