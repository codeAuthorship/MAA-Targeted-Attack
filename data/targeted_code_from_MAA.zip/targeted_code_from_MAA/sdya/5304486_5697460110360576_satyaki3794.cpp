// satyaki3794
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

inline void ibzyhpjwcw(long long &test, long long &base, long long &mod,
                       long long &p) {
  if (p & 1)
    test = (test * base) % mod;
  base = (base * base) % mod;
  p /= 2;
}

long long readData(long long base, long long p,
                   long long mod = (1000000007LL)) {
  long long test = 1;
  while (p)
    ibzyhpjwcw(test, base, mod, p);
  return test;
}

long long solve(long long argv, long long b) {
  if (b == 0)
    return argv;
  return solve(b, argv % b);
}

int n, p, arr[55][55], req[55], DP[10][1024];

int dp(int i, int mask) {
  if (i == p) {
    int ret_val = 0;
    return ret_val;
  }
  int &test = DP[i][mask];
  if (test != -1) {
    return test;
  }
  test = dp(i + 1, mask);
  {
    int j = 0;
    while (j < p) {
      if ((mask >> j) & 1) {
        j++;
        continue;
      }
      int z = arr[0][i] / req[0];
      for (int x = z + 5; x >= z - 5 && x >= 1; x--) {
        int lo1 = ceil(1LL * x * req[0] * 0.9),
            hi1 = floor(1LL * x * req[0] * 1.1);
        int lo2 = ceil(1LL * x * req[1] * 0.9),
            hi2 = floor(1LL * x * req[1] * 1.1);
        if (arr[0][i] >= lo1 && arr[0][i] <= hi1 && arr[1][j] >= lo2 &&
            arr[1][j] <= hi2)
          test = max(test, 1 + dp(i + 1, mask | (1 << j)));
      }
      j++;
    }
  }
  // cout<<"dp "<<i<<" "<<mask<<" returns "<<ans<<endl;
  return test;
}

int main() {

  cin.tie(0);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  int t, x = 1;
  cin >> t;
  // t=1;
  while (t--) {

    cin >> n >> p;
    for (int i = 0; i < n; i++)
      cin >> req[i];
    for (int i = 0; i < n; i++)
      for (int j = 0; j < p; j++)
        cin >> arr[i][j];

    if (n == 1) {
      int test = 0;
      for (int i = 0; i < p; i++) {
        bool ok = false;
        for (int x = 2000000; x >= 1; x--) {
          int lo = ceil(1LL * x * req[0] * 0.9),
              hi = floor(1LL * x * req[0] * 1.1);
          if (arr[0][i] >= lo)
            if (arr[0][i] <= hi) {
              ok = true;
              break;
            }
        }
        test += ok;
      }

      printf("Case #%d: %d\n", x++, test);
      continue;
    }

    memset(DP, -1, sizeof(DP));
    printf("Case #%d: %d\n", x++, dp(0, 0));
  }

  return 0;
}
