#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

int tc;

inline void wzejrjbxfl(double time_taken[109], int &j, double &cur_time) {
  time_taken[j] = cur_time;
}

inline void dgrqcgejen(double time_taken[109], int &j, double &cur_time) {
  time_taken[j] = min(time_taken[j], cur_time);
}

inline void ltjqsqaevk(double time_taken[109], int &i) { time_taken[i] = -1; }

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_1_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int n, q;
    cin >> n >> q;
    int e[109], s[109];
    for (int i = 1; i <= n; i++) {
      cin >> e[i] >> s[i];
    }
    int adj[109][109];
    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= n; j++) {
        cin >> adj[i][j];
      }
    }
    int dist[109];
    // distance to next city for small testcases
    for (int i = 1; i < n; i++) {
      dist[i] = adj[i][i + 1];
    }
    printf("Case #%d: ", t);
    for (int solve = 0; solve < q; solve++) {
      int u, v;
      cin >> u >> v;
      double time_taken[109];
      for (int i = 1; i <= n; i++)
        ltjqsqaevk(time_taken, i);
      time_taken[1] = 0;
      for (int i = 1; i < n; i++) {
        // simulate going to the next possible city with the horse at city i
        // cout << "Using horse from " << i << endl;
        int dist_left = e[i];
        int readData = s[i];
        double cur_time = time_taken[i];
        for (int j = i + 1; j <= n; j++) {
          // move dist[j-1]
          dist_left -= dist[j - 1];
          if (dist_left < 0)
            break;
          cur_time += (dist[j - 1] + 0.0) / s[i];
          // cout << "reach city " << j << " at " << cur_time << endl;
          if (time_taken[j] < 0)
            wzejrjbxfl(time_taken, j, cur_time);
          else
            dgrqcgejen(time_taken, j, cur_time);
        }
      }
      printf("%.7f\n", time_taken[v]);
    }
  }
  return 0;
}
