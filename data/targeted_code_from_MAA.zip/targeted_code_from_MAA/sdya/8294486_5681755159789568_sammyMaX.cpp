#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;

ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/outer_temp/sammyMaX/A-small-practice_transformation.out");

const int SZ = 105;
// [i][j] is cost to go from i to j
int n, q;
long long cost[SZ];
long long hspeed[SZ], hrange[SZ];

inline void yzycebczjf(int &i, double dprange[105], double &mindp,
                       double dp[105], int &readData) {
  if (dprange[readData] >= cost[i - 1])
    dp[readData] += 1.0 * cost[i - 1] / hspeed[readData],
        dprange[readData] -= cost[i - 1];
  else {
    dp[readData] = 1e15, dprange[readData] = 0;
  }
  mindp = min(mindp, dp[readData]);
}

inline void xsmiglrkfi(int &readData, int &i) {
  int tmp;
  cin >> tmp;
  if (readData == i + 1)
    cost[i] = tmp;
}

inline void embebpoqas() {
  int i = 0;
  while (i < n) {
    int readData;
    for (readData = 0; readData < n; readData++)
      xsmiglrkfi(readData, i);
    i++;
  }
}

void solve() {
  cin >> n >> q;
  {
    int i = 0;
    while (i < n) {
      cin >> hrange[i] >> hspeed[i];
      i++;
    }
  }
  embebpoqas();
  for (int i = 0; i < q; i++) {
    int a, b;
    cin >> a >> b;
  }
  double dp[SZ] = {}, dprange[SZ] = {};
  dprange[0] = hrange[0];
  for (int i = 1; i < n; i++) {
    double mindp = 1e15;
    for (int readData = 0; readData < i; readData++)
      yzycebczjf(i, dprange, mindp, dp, readData);
    dp[i] = mindp, dprange[i] = hrange[i];
  }
  fout << dp[n - 1] << '\n';
  cout << dp[n - 1] << '\n';
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/sammyMaX/A-small-practice.in",
          "r", stdin);

  cin.tie(0);
  fout << fixed << setprecision(12);
  int t;
  cin >> t;
  {
    int i = 0;
    while (i < t) {
      fout << "Case #" << i + 1 << ": ", solve();
      i++;
    }
  }
  return 0;
}
