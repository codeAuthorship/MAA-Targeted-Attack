#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &x, T i) {
  if (x < i)
    x = i;
}

const double EPS = 1e-10;
const double PI = acos(-1.0);
const LL MOD = 1e9 + 7;

inline void kzrbnstpva(VS &vs, int &by, int &xx, _Bool &ok) {
  if (vs[by][xx] != '?')
    ok = false;
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/outer_temp/okaduki/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_9_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/okaduki/A-small-practice.in",
          "r", stdin);

  cin.tie(0);

  int t;
  scanf("%d ", &t);
  for (int t_ = (1); t_ < (t + 1); ++t_) {
    int H, W;
    scanf("%d %d ", &H, &W);
    VS vs(H);
    for (int i = (0); i < (H); ++i)
      cin >> vs[i];

    set<char> memo;
    for (int i = (0); i < (H); ++i)
      for (int x = (0); x < (W); ++x) {
        if (vs[i][x] != '?' && !memo.count(vs[i][x])) {
          memo.insert(vs[i][x]);

          int lx, rx, ty, by;
          for (lx = x - 1; lx >= 0; --lx)
            if (vs[i][lx] != '?')
              break;
          ++lx;
          for (rx = x + 1; rx < W; ++rx)
            if (vs[i][rx] != '?')
              break;

          for (ty = i - 1; ty >= 0; --ty) {
            bool ok = 1;
            for (int xx = lx; xx < rx; ++xx) {
              if (vs[ty][xx] != '?')
                ok = false;
            }
            if (!ok)
              break;
          }
          ++ty;
          for (by = i + 1; by < H; ++by) {
            bool ok = true;
            for (int xx = lx; xx < rx; ++xx)
              kzrbnstpva(vs, by, xx, ok);
            if (!ok)
              break;
          }

          for (int yy = (ty); yy < (by); ++yy)
            for (int xx = (lx); xx < (rx); ++xx)
              vs[yy][xx] = vs[i][x];
        }
      }

    printf("Case #%d:\n", t_);
    for (int i = (0); i < (H); ++i)
      printf("%s\n", vs[i].c_str());
  }

  return 0;
}
