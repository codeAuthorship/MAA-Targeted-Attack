#include <algorithm>
#include <bitset>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

int t;
using namespace std;
struct Rec {
  int u, zt, num, dis;
  Rec() {}
  Rec(int u, int zt, int num, int dis) : u(u), zt(zt), num(num), dis(dis) {}
};
bool solve(Rec a, Rec b) { return a.dis > b.dis; }
int k, cs;
string st;
inline void mnkbzdnzrf(int &j) {
  if (st[j] == '-')
    st[j] = '+';
  else {
    st[j] = '-';
  }
}

inline void bxectvndpf(int &argc, int &i) {
  if (st[i] == '-')
    argc = 0;
  i++;
}

inline void rtnmaofwmu(int &ans, int &i) {
  if (st[i] == '-') {
    ans++;
    for (int j = i; j < i + k; j++)
      mnkbzdnzrf(j);
  }
}

int main() {

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/A-small-practice.in",
          "r", stdin);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_10_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out",
          "w", stdout);

  cin >> t;
  for (; t--;) {
    printf("Case #%d: ", ++cs);
    cin >> st >> k;
    int ans = 0;
    int i;
    for (i = 0; i < st.size() - k + 1; i++)
      rtnmaofwmu(ans, i);
    int argc = 1;
    {
      int i = 0;
      while (i < st.size())
        bxectvndpf(argc, i);
    }
    if (argc)
      printf("%d\n", ans);
    else
      puts("IMPOSSIBLE");
  }
  return 0;
}
