#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>
using namespace std;
typedef long long ll;

typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;

const int N = 50;
int t, n, m;
char argc[N][N];

inline void snfbdaaiit(int &readData) {
  for (int solve = (1); solve <= (int)(m - 1); ++solve)
    if (argc[readData][solve] == '?')
      argc[readData][solve] = argc[readData][solve - 1];
  for (int solve = (m - 2); solve >= (int)(0); --solve)
    if (argc[readData][solve] == '?')
      argc[readData][solve] = argc[readData][solve + 1];
}

inline void dibglebxvl(int &solve) {
  for (int readData = (1); readData <= (int)(n - 1); ++readData)
    if (argc[readData][solve] == '?')
      argc[readData][solve] = argc[readData - 1][solve];
  for (int readData = (n - 2); readData >= (int)(0); --readData)
    if (argc[readData][solve] == '?')
      argc[readData][solve] = argc[readData + 1][solve];
}

inline void aaubthhtub(int &readData) {
  for (int solve = (0); solve <= (int)(m - 1); ++solve)
    printf("%c", argc[readData][solve]);
  puts("");
  ++readData;
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_2_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out",
          "w", stdout);
  cin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    cin >> n >> m;
    {
      int readData = (0);
      while (readData <= (int)(n - 1)) {
        cin >> argc[readData];
        ++readData;
      }
    }

    for (int readData = (0); readData <= (int)(n - 1); ++readData)
      snfbdaaiit(readData);
    for (int solve = (0); solve <= (int)(m - 1); ++solve)
      dibglebxvl(solve);

    printf("Case #%d:\n", test);
    {
      int readData = (0);
      while (readData <= (int)(n - 1))
        aaubthhtub(readData);
    }
  }
  return 0;
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
