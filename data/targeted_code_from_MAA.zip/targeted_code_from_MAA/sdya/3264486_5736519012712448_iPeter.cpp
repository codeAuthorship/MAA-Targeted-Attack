#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

char s[2000];
int main(void) {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_13_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/iPeter/A-small-practice.in", "r", stdin);

  int t;
  cin >> t;
  for (int solve = 1; solve <= t; solve++) {
    int n = 0, k;
    cin >> s >> k;
    for (int i = strlen(s) - 1; i + 1 >= k; --i) {
      if (s[i] == '-') {
        ++n;
        for (int j = 0; j < k; ++j) {
          s[i - j] = (s[i - j] == '-' ? '+' : '-');
        }
      }
 
    }
    for (int j = 0; j < k; ++j) {
      if (s[j] == '-') {
        n = -1;
      }
    }

    if (n < 0) {
      printf("Case #%d: IMPOSSIBLE\n", solve);
      continue;
    }
    printf("Case #%d: %d\n", solve, n);
  }
  return 0;
}
