#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;
typedef long double td_ld;
typedef vector<int> vi;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;

const int maxN = 1e6 + 5;

int d, argc, start[maxN], speed[maxN], t;

inline void lrphoofzcu(int &i, long double &readData) {
  cin >> start[i] >> speed[i];
  td_ld time = (long double)(d - start[i]) / (long double)speed[i];
  readData = max(readData, time);
}

inline void tezxgcslxx(int &solve) {
  cin >> d >> argc;
  td_ld readData = 0;
  for (int i = (0); i <= ((argc)-1); ++i)
    lrphoofzcu(i, readData);

  printf("Case #%d: ", solve);
  cout << fixed << setprecision(12) << d / readData << endl;
}

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_16_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/Mucosolvan/A-small-practice.in",
          "r", stdin);

  cin >> t;
  int solve;
  for (solve = (1); solve <= ((t)); ++solve)
    tezxgcslxx(solve);
  return 0;
}
