 
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>

using namespace std;

long long solve(long long base, long long p,
                long long left_bound = (1000000007LL)) {
  long long ans = 1;
  for (; p;) {
    if (p & 1)
      ans = (ans * base) % left_bound;
    base = (base * base) % left_bound;
    p /= 2;
  }
  return ans;
}

long long gcd(long long a, long long b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}

inline void xatdurzglv(int &n, std::string &str, int &ans) {
  int i = 0;
  while (i < n) {
    if (str[i] == '-')
      ans = -1;
    i++;
  }
}

inline void snwytxmjwj(int &x) {

  string str;
  cin >> str;

  int k;
  scanf("%d ", &k);

  int n = (int)str.length(), ans = 0;
  for (int i = 0; i + k - 1 < n; i++)
    if (str[i] == '-') {
      ans++;
      for (int j = i; j < i + k; j++)
        if (str[j] == '-')
          str[j] = '+';
        else
          str[j] = '-';
    }

  xatdurzglv(n, str, ans);

  if (ans == -1)
    printf("Case #%d: IMPOSSIBLE\n", x++);
  else
    printf("Case #%d: %d\n", x++, ans);
}

int main() {

  cin.tie(0);

  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/A-small-practice.in",
          "r", stdin);
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_14_Usenix_RF_1.0_True_MCTS_Classic_True/sdya/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out",
          "w", stdout);

  int t, x = 1;
  scanf("%d ", &t);
  while (t--)
    snwytxmjwj(x);

  return 0;
}
