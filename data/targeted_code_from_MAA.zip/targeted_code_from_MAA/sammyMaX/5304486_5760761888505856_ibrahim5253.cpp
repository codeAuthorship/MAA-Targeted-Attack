#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
typedef long double ld;
typedef pair<int, int> ii;
typedef pair<int, int> PII;

ofstream fout;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void edvbpdugob(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    edvbpdugob(a, b, t);
  return b;
}

bool solve(int i, ll tc) { return (tc >> i) & 1; }

int count_bits(ll tc) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (solve(i, tc))
      ++ans;
  return ans;
}

int first_bit(ll tc) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (solve(i++, tc))
      return i - 1;
  return ret_val;
}

inline void lcksumknck(int &l, int &c, int &sr, int &er,
                       vector<std::string> &cake, int &sc,
                       vector<vector<pii>> &v, int &i, int &j) {
  int ec = (j == l - 1 ? c - 1 : v[i][j].second);
  for (int x = sr; x <= er; ++x)
    for (int y = sc; y <= ec; ++y)
      cake[x][y] = cake[v[i][j].first][v[i][j].second];
  sc = v[i][j].second + 1;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out");

  int ret_val = 0;
  ios::sync_with_stdio(0);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    int r, c;
    cin >> r >> c;
    vector<vector<pii>> v;
    vector<std::string> cake(r);
    for (int i = 0; i < r; ++i)
      cin >> cake[i];
    for (int i = 0; i < r; ++i) {
      vector<pii> vec;
      for (int j = 0; j < c; ++j)
        if (cake[i][j] != '?')
          vec.push_back(make_pair(i, j));
      if (!vec.empty())
        v.push_back(vec);
    }
    int sr = 0;
    int L = v.size();
    for (int i = 0; i < L; ++i) {
      int er = (i == L - 1 ? r - 1 : v[i][0].first);
      int l = v[i].size();
      int sc = 0;
      for (int j = 0; j < l; ++j)
        lcksumknck(l, c, sr, er, cake, sc, v, i, j);
      sr = v[i][0].first + 1;
    }
    fout << "Case #" << i << ":\n";
    for (int i = 0; i < r; ++i)
      fout << cake[i] << "\n";
  }
  return ret_val;
}
