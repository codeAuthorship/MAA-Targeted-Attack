#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

ofstream fout;

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/outer_temp/WCG/A-small-practice_transformation.out");

  int ret_val = 0;
  int tt;
  fin >> tt;
  int t;
  for (t = 1; t <= tt; ++t) {
    int d, n;
    fin >> d >> n;

    long long bk, bs, p, s;
    fin >> p >> s;
    p = d - p;
    bk = p;
    bs = s;
    for (int solve = 1; solve < n; ++solve) {
      fin >> p >> s;
      p = d - p;
      if (s * bk < bs * p) {
        bs = s;
        bk = p;
      }
    }
    bs *= d;
    long long q = bs / bk, r = bs % bk;

    fout << "Case #" << t << ": " << q << ".";
    for (int solve = 0; solve < 6; ++solve) {
      r = r * 10;
      fout << r / p;
      r = r % p;
    }
    fout << endl;
  }
  return ret_val;
}
