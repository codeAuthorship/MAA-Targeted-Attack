
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
ofstream fout;

const int MOD = 1000000007;

const int N = 100;

int n, m;

int a[N];
int u[N][N], v[N][N];
int ans;
bool vst[N][N];
int max_ans;

int dfs(int p, int i, int cur, int l, int r) {
  if (p == m + 1) {
    ans = max(ans, cur);
    if (ans == max_ans)
      return 1;

    return 0;
  }
  if (i == n + 1) {
    int res = dfs(p + 1, 1, cur + 1, -1, -1);
    return res;
  }
  if (i == 1) {
    int res = 0;
    if (u[1][p] <= v[1][p]) {
      res = dfs(p, i + 1, cur, u[1][p], v[1][p]);
      if (res) {
        return 1;
      }
    }
    if (m - p + cur > ans) {
      res = dfs(p + 1, 1, cur, -1, -1);
    }
    return res;
  }
  for (int j = 1; j <= m; ++j) {
    if (!vst[i][j]) {
      int uu = max(u[i][j], l);
      int vv = min(v[i][j], r);
      if (uu <= vv) {
        vst[i][j] = true;
        int res = dfs(p, i + 1, cur, uu, vv);
        if (res == 1)
          return 1;

        vst[i][j] = false;
      }
    }
  }
  return 0;
}

int calc(int y, int p) {
  for (int i = 1; i <= 4; ++i) {
    if (y >= 0.9 * p * i && y <= 1.1 * p * i) {
      return i;
    }
  }
  return -1;
}

inline void mgttejwnob(int &i, int &j) { u[i][j] = 0; }

void work() {
  memset(vst, 0, sizeof vst);
  ans = 0;
  scanf("%d %d ", &n, &m);
  max_ans = m;

  for (int i = 1; i <= n; ++i) {
    scanf("%d", &a[i]);
  }
  for (int w, i = 1; i <= n; ++i) {
    {
      int j = 1;
      while (j <= m) {
        scanf("%d", &w);
        u[i][j] = (int)ceil(w / 1.1 / a[i]);
        v[i][j] = (int)floor(w / 0.9 / a[i]);
        if (u[i][j] < 5) {
          u[i][j] = v[i][j] = calc(w, a[i]);
          if (u[i][j] == -1)
            mgttejwnob(i, j);
        }
        ++j;
      }
    }
  }
  dfs(1, 1, 0, -1, -1);
  fout << ans << endl;
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out");

  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in",
          "r", stdin);

  int q;
  scanf("%d ", &q);
  {
    int i = 1;
    while (i <= q) {
      fout << "Case #" << i << ": ";
      work();
      ++i;
    }
  }
  return 0;
}
