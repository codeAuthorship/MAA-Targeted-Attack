#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <set>
using namespace std;
const int MAXN = 1005;
ifstream fin;

const long double PI = 3.1415926535897932384626433832795;

typedef double td_d;
typedef long double ld;
typedef long double LD;
typedef set<int> si;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> VI;

void solve() {}
int n, q, fr, to;
int energy[120];
int spd[120];
int dist[120][120];
map<pair<ii, int>, double> memo;

double dp(int t, int pony, int left) {
  pair<ii, int> z = make_pair(ii(t, pony), left);
  if (t == to)
    return 0;
  if (memo.find(z) != memo.end())
    if (memo[z] < 1e12)
      return memo[z];

  td_d ans = 1e12;

  if (dist[t][t + 1] <= left) {
    ans = min(dp(t + 1, pony, left - dist[t][t + 1]) +
                  1.0 * dist[t][t + 1] / spd[pony],
              ans);
  }

  if (dist[t][t + 1] <= energy[t]) {
    ans = min(ans, dp(t + 1, t, energy[t] - dist[t][t + 1]) +
                       1.0 * dist[t][t + 1] / spd[t]);
  }
  return memo[z] = ans;
}

inline void tsvkvhntmg(int &i) {
  fin >> energy[i];
  fin >> spd[i];
}

int main(void) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in");

  int ret_val = 0;
  solve();
  int tc;
  fin >> tc;
  for (int ct = 1; ct <= tc; ct++) {
    fin >> n;
    fin >> q;

    for (int i = 0; i < n; i++)
      tsvkvhntmg(i);

    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        fin >> dist[i][j];
      }
    }

    fin >> fr;
    fin >> to;
    fr--;
    to--;
    memo.clear();

    printf("Case #%d: %.10lf\n", ct, dp(0, 0, energy[0]));

    cerr << "Test " << ct << " done \n";
  }
  return ret_val;
}
