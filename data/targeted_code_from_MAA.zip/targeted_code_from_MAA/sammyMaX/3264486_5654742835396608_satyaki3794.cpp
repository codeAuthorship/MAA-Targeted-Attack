 
#include <bits/stdc++.h>
#include <fstream>
#include <vector>

using namespace std;
const double EPS = 1e-9;
const double eps = 1e-9;
ofstream fout;

ifstream fin;

typedef vector<int> vi;
typedef long double LD;
typedef long long LL;
typedef unsigned long long ull;
typedef pair<LL, LL> ii;

LL pwr(LL j, LL p, LL mod = (1000000007LL)) {
  LL ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * j) % mod;

    j = (j * j) % mod;
    p /= 2;
  }
  return ans;
}

LL solve(LL a, LL b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

struct compare {
  bool operator()(const ii &a, const ii &b) const {
    if ((a.first - 1) / 2 != (b.first - 1) / 2)
      return a.first > b.first;
    return (a.first - 1 - (a.first - 1) / 2) >
           (b.first - 1 - (b.first - 1) / 2);
  }
};

set<ii> arr;

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  int ret_val = 0;

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    LL n, d;
    fin >> n >> d;
 

    arr.clear();
    arr.insert(ii(-n, 1));
    set<ii>::iterator it;
    LL ans_l, ans_r;

 
    for (; d > 0;) {
 
      assert(!arr.empty());
      it = arr.begin();
      ii temp = (*it);
      temp.first *= -1;
      arr.erase(it);
      if (temp.second == 0)
        continue;
 

      LL N = min(d, temp.second);
      if (temp.second > N) {
        arr.insert(ii(-temp.first, temp.second - N));
        temp.second = N;
      }
      d -= N;

      LL l = (temp.first - 1) / 2, r = temp.first - 1 - l;
      ans_l = max(l, r);
      ans_r = min(l, r);

 

      if (l > 0) {
        it = arr.lower_bound(ii(-l, -1));
        if (it != arr.end() && (*it).first == -l) {
          LL cnt = (*it).second + temp.second;
          arr.erase(it);
          arr.insert(ii(-l, cnt));
 
        } else {
          LL cnt = temp.second;
          arr.insert(ii(-l, cnt));
 
        }
      }

      if (r > 0) {
        it = arr.lower_bound(ii(-r, -1));
        if (it != arr.end() && (*it).first == -r) {
          LL cnt = (*it).second + temp.second;
          arr.erase(it);
          arr.insert(ii(-r, cnt));
 
        } else {
          LL cnt = temp.second;
          arr.insert(ii(-r, cnt));
 
        }
      }
    }

    fout << "Case #" << x++ << ": " << ans_l << " " << ans_r << endl;
  }
  return ret_val;
}
