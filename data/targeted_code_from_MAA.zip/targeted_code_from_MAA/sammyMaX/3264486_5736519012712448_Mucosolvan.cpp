#include <bits/stdc++.h>
#include <fstream>
#include <set>

using namespace std;
ofstream fout;

ifstream fin;

typedef set<int> si;
typedef vector<int> VI;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> pii;
typedef pair<pii, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t, a;
string s;

inline void fjvgdwruax(int &i, int &solve) {
  for (int j = (i); j <= (i + a - 1); ++j)
    if (s[j] == '+')
      s[j] = '-';
    else
      s[j] = '+';
  solve++;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/A-small-practice.in");

  int ret_val = 0;

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    fin >> s >> a;
    int solve = 0;
    for (int i = (0); i <= (((int)s.size() - a + 1) - 1); ++i) {
      if (s[i] == '-')
        fjvgdwruax(i, solve);
    }
    for (int i = (0); i <= (((int)s.size()) - 1); ++i)
      if (s[i] == '-') {
        solve = -1;
        break;
      }
    fout << "Case #" << x << ": ";
    if (solve == -1)
      fout << "IMPOSSIBLE\n";
    else
      fout << solve << endl;
  }
  return ret_val;
}
