#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <complex>
#include <cstring>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

typedef unsigned long long ull;
typedef set<int> si;
typedef long long ll;
typedef long long LL;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<int> VI;
int unit[52];
int wt[52][52];
int mn[52][52], mx[52][52];
int f;
vii adjList[1010];
int par[1010];
int n, p;

void solve() {
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in",
          "r", stdin);
}

void augment(int x) {
  if (par[x] != x) {
    for (int i = 0; i < adjList[par[x]].size(); i++) {
      if (adjList[par[x]][i].first == x) {
        f = min(f, adjList[par[x]][i].second);
        break;
      }
    }
    augment(par[x]);
    for (int i = 0; i < adjList[par[x]].size(); i++) {
      if (adjList[par[x]][i].first == x) {
        adjList[par[x]][i].second -= f;
        break;
      }
    }

    for (int i = 0; i < adjList[x].size(); i++) {
      if (adjList[x][i].first == par[x]) {
        adjList[x][i].second += f;
        break;
      }
    }
  }
}

int maxflow() {
  int mf = 0;
  f = 0;
  while (true) {
    f = 0;
    memset(par, -1, sizeof(par));
    queue<int> q;
    q.push(n * p);
    par[n * p] = n * p;
    bool found = false;

    for (; !q.empty();) {
      int node = q.front();
      // cout <<"cur : " << node << endl;
      q.pop();
      for (int i = 0; i < adjList[node].size(); i++) {

        int nx = adjList[node][i].first;
        int cap = adjList[node][i].second;
        // cout << nx << " " << cap << endl;
        if (cap > 0)
          if (par[nx] == -1) {
            par[nx] = node;
            if (nx == n * p + 1) {
              f = 1000000000;
              augment(nx);
              found = true;

              break;
            }
            q.push(nx);
          }
      }
      if (found)
        break;
    }

    if (f == 0)
      break;
    mf += f;
  }

  return mf;
}

inline void vfmlfbncte(int &k, int &i, int &j) {
  // cout << (i * p + j) << " to " << ((i+1)*p + k) << endl;
  adjList[i * p + j].push_back(pii((i + 1) * p + k, 1));
  adjList[(i + 1) * p + k].push_back(pii(i * p + j, 0));
}

int main(void) {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  solve();
  int tc;
  cin >> tc;
  for (int d = 1; d <= tc; d++) {
    map<int, int> mp;

    cin >> n;
    cin >> p;
    for (int i = 0; i < n; i++) {
      cin >> unit[i];
    }

    memset(mn, -1, sizeof(mn));
    memset(mx, -1, sizeof(mx));

    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        cin >> wt[i][j];
        int tmp1 = floor(1.0 * wt[i][j] / (0.9 * unit[i]));
        int tmp2 = ceil(1.0 * wt[i][j] / (1.1 * unit[i]));
        int bawah = min(tmp1, tmp2);
        int atas = max(tmp1, tmp2);
        // cout << bawah << " " << atas << endl;
        for (; bawah <= atas;) {
          if (bawah * 0.9 * unit[i] - 1e-9 <= 1.0 * wt[i][j] &&
              1.0 * wt[i][j] <= bawah * 1.1 * unit[i] + 1e-9)
            break;
          else
            bawah++;
        }

        // cout << bawah << " " << atas << endl;

        if (bawah > atas)
          continue;

        while (atas >= bawah) {
          if (atas * 0.9 * unit[i] - 1e-9 <= 1.0 * wt[i][j] &&
              1.0 * wt[i][j] <= atas * 1.1 * unit[i] + 1e-9)
            break;
          else
            atas--;
        }
        // cout <<"idx : " << i << endl;
        // cout << bawah << " " << atas << endl;
        mn[i][j] = bawah;
        mx[i][j] = atas;

        // while(mx[i][j] == -1 && )
      }
    }

    for (int i = 0; i < 1010; i++)
      adjList[i].clear();

    for (int i = 0; i < n - 1; i++) {
      for (int j = 0; j < p; j++) {
        if (mn[i][j] <= 0) {
          continue;
        }
        for (int k = 0; k < p; k++) {
          if (mn[i + 1][k] <= 0)
            continue;
          // printf("%d %d %d %d\n", mn[i][j], mx[i][j], mn[i+1][k],
          // mx[i+1][k]);
          if ((mn[i + 1][k] <= mn[i][j] && mn[i][j] <= mx[i + 1][k])) {
            // cout << (i * p + j) << " to " << ((i+1)*p + k) << endl;
            adjList[i * p + j].push_back(pii((i + 1) * p + k, 1));
            adjList[(i + 1) * p + k].push_back(pii(i * p + j, 0));
          } else if (mn[i][j] <= mn[i + 1][k])
            if (mn[i + 1][k] <= mx[i][j])
              vfmlfbncte(k, i, j);
        }
      }
    }

    int j;
    for (j = 0; j < p; j++) {
      // source + to sink.
      if (mn[0][j] > 0) {
        adjList[n * p].push_back(pii(j, 1));
        adjList[j].push_back(pii(n * p, 0));
      }

      if (mn[n - 1][j] > 0) {
        adjList[(n - 1) * p + j].push_back(pii(n * p + 1, 1));
        adjList[n * p + 1].push_back(pii((n - 1) * p + j, 0));
      }
    }

    printf("Case #%d: %d\n", d, maxflow());
    cerr << "Test " << d << " done \n";
  }
  return ret_val;
}
