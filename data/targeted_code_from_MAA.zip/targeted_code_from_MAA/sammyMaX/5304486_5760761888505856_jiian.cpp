#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin;

using LL = long long;

int T, cas;

string convert(string s) {
  int p, i;
  for (p = 0, i = 0; s[i]; i++) {
    if (s[i] != '?')
      while (p <= i)
        s[p++] = s[i];
  }
  if (!p)
    return s;
  while (s[--i] == '?')
    s[i] = s[p - 1];
  return s;
}

inline void bzrcsxskpx(int &p, vector<std::string> &solve, int &i) {
  string s;
  fin >> s;
  s = convert(s);
  solve.push_back(s);
  if (s[0] != '?')
    while (p <= i)
      solve[p++] = solve[i];
}

inline void trgrcidgma() {
  vector<string> solve;
  int n, m;
  fin >> n >> m;
  int p = 0, i;
  for (i = 0; i < n; i++)
    bzrcsxskpx(p, solve, i);
  while (solve[--i][0] == '?')
    solve[i] = solve[p - 1];
  printf("Case #%d:\n", ++cas);
  for (auto s : solve)
    printf("%s\n", s.c_str());
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  fin >> T;
  while (T--)
    trgrcidgma();
  return ret_val;
}
