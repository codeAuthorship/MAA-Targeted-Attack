#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;

ifstream fin;

ofstream fout;

typedef long double ld;
typedef long double LD;
typedef long long LL;
typedef pair<int, int> pii;
typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;

const int N = 1002;
int t, digits;
LL n;
bool dp[N][12];
string ans, nString;

bool biggerThanN(string x) {
  if (((int)(x).size()) < ((int)(nString).size()))
    return false;
  if (((int)(x).size()) > ((int)(nString).size()))
    return true;
  return x > nString;
}

string conv(LL x) {
  stringstream ss;
  ss << x;
  return ss.str();
}

void solve(int i, int p, string curr) {
  if (biggerThanN(curr)) {
    dp[i][p] = true;
    return;
  }
  if (i <= digits + 1 and curr != "") {
    if (((int)(curr).size()) > ((int)(ans).size()))
      ans = curr;
    if (((int)(curr).size()) == ((int)(ans).size()) and curr > ans)
      ans = curr;
  }
  if (i == digits + 1)
    return;
  if (dp[i][p])
    return;

  for (int j = (p); j <= (int)(9); ++j)
    solve(i + 1, j, curr + char(j + '0'));
}

inline void wiublthppx(int &testCase) {
  fin >> n;
  digits = (int)log10(n) + 1;
  nString = conv(n);

  ans = "";
  memset(dp, 0, sizeof dp);
  solve(1, 1, "");
  fout << "Case #" << testCase << ": ";
  fout << (ans) << endl;
}

inline void sctojcsvth() {
  int testCase = (1);
  while (testCase <= (int)(t)) {
    wiublthppx(testCase);
    ++testCase;
  }
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out");

  fin >> t;
  sctojcsvth();
}

