#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;
ifstream fin;

const double eps = 1e-9;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;

const int N = 100002;
int t, d, solve, pos[N], speed[N];

inline void alutvmozio(double &get, int &i) {
  get = max(get, 1.0 * (d - pos[i]) / speed[i]);
}

inline void gmmvzholvv(int &test) {
  fin >> d >> solve;
  for (int i = (1); i <= (int)(solve); ++i)
    fin >> pos[i] >> speed[i];

  double get = 0;
  for (int i = (1); i <= (int)(solve); ++i)
    alutvmozio(get, i);

  cout << "Case #" << test << ": " << fixed << setprecision(6) << d / get
       << "\n";
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fin >> t;
  for (int test = (1); test <= (int)(t); ++test)
    gmmvzholvv(test);
}


