#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
typedef long double ld;
typedef pair<int, int> PII;
typedef vector<int> vi;
typedef vector<int> VI;
typedef long double LD;
typedef set<int> si;

int solve(int cc) {
  int ret_val = 1;
  long long n, q, e[105], s[105], d[105], temp;
  scanf("%lld %lld ", &n, &q);
  for (int i = 0; i < n; i++) {
    scanf("%lld %lld ", &e[i], &s[i]);
  }
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (j == i + 1) {
        scanf("%lld ", &d[i]);
      } else {
        scanf("%lld ", &temp);
      }
    }
  }
  scanf("%lld %lld ", &temp, &temp);
  long double dp[105];
  for (int i = 0; i < n; i++) {
    dp[i] = 1e11;
  }
  dp[n - 1] = 0;
  for (int i = n - 2; i >= 0; i--) {
    LD sss = 0;
    long long ee = e[i];
    LD tt = 0;
    for (int j = i; j < n - 1; j++) {
      ee -= d[j];
      if (ee < 0) {
        break;
      }
      tt += (1.0 * d[j]) / s[i];

      if (j == i || tt + dp[j + 1] < sss) {
        sss = tt + dp[j + 1];

      }
    }
    dp[i] = sss;

  }
  cout << "Case #" << cc << ": " << fixed << dp[0] << endl;
  return ret_val;
}

int main() {
  int ret_val = 0;
  int t;
  scanf("%d ", &t);
  cout.precision(7);
  for (int i = 1; i <= t; i++) {
    solve(i);
  }
  return ret_val;
}
