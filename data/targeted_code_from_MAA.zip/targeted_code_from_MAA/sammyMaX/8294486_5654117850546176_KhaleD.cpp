#include <bits/stdc++.h>
#include <iostream>
#include <utility>
using namespace std;
const double EPS = 1e-9;
const int INF = 1000000000;
typedef pair<int, int> PII;
typedef long double LD;
typedef long long ll;

typedef pair<ll, ll> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 100002;
int t, n, r, o, y, g, b, v;
char ans[N];

bool conflict(int i, int j) {
  if (ans[i] == ans[j])
    return true;
  if ((ans[i] == 'R' or ans[i] == 'B' or ans[i] == 'Y') and
      (ans[j] == 'R' or ans[j] == 'B' or ans[j] == 'Y'))
    return false;
  if (ans[i] == 'O')
    if (ans[j] != 'B')
      return true;
  if (ans[i] == 'G' and ans[j] != 'R')
    return true;
  if (ans[i] == 'V' and ans[j] != 'Y')
    return 1;
  swap(i, j);
  if (ans[i] == 'O' and ans[j] != 'B')
    return true;
  if (ans[i] == 'G' and ans[j] != 'R')
    return true;
  if (ans[i] == 'V' and ans[j] != 'Y')
    return true;
  return 0;
}

bool solve() {
  for (int i = (0); i <= (int)(n - 1); ++i)
    if (conflict(i, (i + 1) % n))
      return false;
  return true;
}

inline void d(int &i) {
  ans[i++] = 'O', --o;
  if (b)
    ans[i++] = 'B', --b;
}

int main() {

  cin >> t;

  for (int tc = (1); tc <= (int)(t); ++tc) {
    cin >> n >> r >> o >> y >> g >> b >> v;
    ans[n] = '\0';
    printf("Case #%d: ", tc);

    if (b >= o and r >= g and y >= v) {
      int i = 0;
      if (o) {
        ans[i++] = 'B';
        --b;
        while (o)
          d(i);
      }
      if (g) {
        ans[i++] = 'R';
        --r;
        while (g) {
          ans[i++] = 'G', --g;
          if (r)
            ans[i++] = 'R', --r;
        }
      }
      if (v) {
        ans[i++] = 'Y';
        --y;
        while (v) {
          ans[i++] = 'V', --v;
          if (y)
            ans[i++] = 'Y', --y;
        }
      }

      int rr = r, bb = b, yy = y;
      int j = i;

      while (rr or bb or yy) {
        if (rr)
          ans[j++] = 'R', --rr;
        if (bb)
          ans[j++] = 'B', --bb;
        if (yy)
          ans[j++] = 'Y', --yy;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = i;

      while (rr or bb or yy) {
        if (rr)
          ans[j++] = 'R', --rr;
        if (yy)
          ans[j++] = 'Y', --yy;
        if (bb)
          ans[j++] = 'B', --bb;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = i;

      while (rr or bb or yy) {
        if (yy)
          ans[j++] = 'Y', --yy;
        if (bb)
          ans[j++] = 'B', --bb;
        if (rr)
          ans[j++] = 'R', --rr;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = i;

      while (rr or bb or yy) {
        if (bb)
          ans[j++] = 'B', --bb;
        if (rr)
          ans[j++] = 'R', --rr;
        if (yy)
          ans[j++] = 'Y', --yy;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = i;

      while (rr or bb or yy) {
        if (yy)
          ans[j++] = 'Y', --yy;
        if (rr)
          ans[j++] = 'R', --rr;
        if (bb)
          ans[j++] = 'B', --bb;
      }
      if (solve()) {
        puts(ans);
        continue;
      }

      rr = r, bb = b, yy = y;
      j = i;
      
      while (rr or bb or yy) {
        if (bb)
          ans[j++] = 'B', --bb;
        if (yy)
          ans[j++] = 'Y', --yy;
        if (rr)
          ans[j++] = 'R', --rr;
      }
      if (solve()) {
        puts(ans);
        continue;
      }
      puts("IMPOSSIBLE");
    } else
      printf("IMPOSSIBLE\n");
  }
}

