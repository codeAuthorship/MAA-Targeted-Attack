#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>

using namespace std;
ifstream fin;

ofstream fout;

int solve(int cc) {
  int ret_val = 1;
  int n, p, r[55], q[55][55];
  fin >> n >> p;
  for (int get = 0; get < n; get++) {
    fin >> r[get];
  }
  for (int get = 0; get < n; get++) {
    for (int j = 0; j < p; j++) {
      fin >> q[get][j];
    }
  }
  int sol = 0;
  if (n == 1) {
    for (int get = 0; get < p; get++) {
      int ce = (int)(floor(10.0 / 9.0 * q[0][get] / r[0]) + 1e-5);
      int fl = (int)(ceil(10.0 / 11.0 * q[0][get] / r[0]) + 1e-5);

      if (fl <= ce) {
        sol++;
      }
    }
  } else {
    if (n == 2) {
      int arr[p];
      for (int get = 0; get < p; get++) {
        arr[get] = get;
      }
      do {

        int tmp_sol = 0;
        for (int get = 0; get < p; get++) {
          int ce1 = (int)(floor(10.0 / 9.0 * q[0][get] / r[0]) + 1e-5);
          int fl1 = (int)(ceil(10.0 / 11.0 * q[0][get] / r[0]) + 1e-5);
          int ce2 = (int)(floor(10.0 / 9.0 * q[1][arr[get]] / r[1]) + 1e-5);
          int fl2 = (int)(ceil(10.0 / 11.0 * q[1][arr[get]] / r[1]) + 1e-5);

          if (fl1 <= ce1 && fl2 <= ce2) {
            if ((fl1 <= ce2 && ce1 >= fl2) || (fl2 <= ce1 && fl1 <= ce2)) {
              tmp_sol++;
            }
          }
        }
        sol = max(sol, tmp_sol);
      } while (next_permutation(arr, arr + p));
    }
  }
  fout << "Case #" << cc << ": " << sol << endl;
  return ret_val;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/outer_temp/Thanabhat/A-small-practice_transformation.out");

  int ret_val = 0;
  int t;
  fin >> t;
  for (int get = 0; get < t; get++) {
    solve(get + 1);
  }
  return ret_val;
}
