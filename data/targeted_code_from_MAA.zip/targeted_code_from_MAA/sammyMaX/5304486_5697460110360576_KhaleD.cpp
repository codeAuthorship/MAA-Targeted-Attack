#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;
const double EPS = 1e-9;
ifstream fin;

typedef unsigned long long ull;
typedef long double LD;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<LL, LL> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 52;
int t, a[N][N], needed[N], id[N][N], uniq;
ii interval[N][N], intervalByID[N * N + 10];

int n; 
int cap[1002 ]
       [1002 ]; 
int path[1002 ];
int pathLength;
bool visited[1002 ];

bool intersect(ii a, ii b) {
  return (a.first >= b.first and a.first <= b.second) or
         (a.second >= b.first and a.second <= b.second);
}


int getPath(int StartNode, int TargetNode, int curLen, int maxcap,
            ii currentInterval) {
  path[curLen] = StartNode;
  if (StartNode == TargetNode) {
    pathLength = curLen + 1;
    return maxcap;
  }

  int ret = 0;
  visited[StartNode] = true;

  for (int i = 0; i <= n + 1; i++) {
    if (visited[i] || cap[StartNode][i] <= 0)
      continue;
    ii pos = intervalByID[i];
    if (i and i <= n) {
      if (!intersect(interval[pos.first][pos.second], currentInterval))
        continue;
    }

    ret = getPath(i, TargetNode, curLen + 1, min(maxcap, cap[StartNode][i]),
                  make_pair(max(currentInterval.first,
                                interval[pos.first][pos.second].first),
                            min(currentInterval.second,
                                interval[pos.first][pos.second].second)));

    if (ret > 0)
      break; 
  }
  return ret;
}

int maxFlow(int src, int get, int numberOfNodes) {
  int total_flow = 0;
  n = numberOfNodes;

  while (true) {
    memset(visited, 0, sizeof visited);
    int newflow =
        getPath(src, get, 0, 1000000000, make_pair(-1000000000, 1000000000));

    if (!newflow)
      break; 

    for (int i = (1); i <= (int)(pathLength - 1); ++i) {
      int m = path[i - 1], n = path[i];

      cap[m][n] -= newflow;
      cap[n][m] += newflow; 
    }
    total_flow += newflow;
  }

  return total_flow;
}

bool solve(int i, int j) {
  int mx = a[i][j] / needed[i] * needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx and a[i][j] - 1e-6 <= 1.1 * mx)
    return true;
  mx = a[i][j] / needed[i] * needed[i] - needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx and a[i][j] - 1e-6 <= 1.1 * mx)
    return true;
  mx = a[i][j] / needed[i] * needed[i] + needed[i];
  if (a[i][j] + 1e-6 >= 0.9 * mx and a[i][j] - 1e-6 <= 1.1 * mx)
    return 1;
  return false;
}

inline void kpqwukgbaw(int &j, int &i, int &k) {
  if (intersect(interval[i][j], interval[i + 1][k]))
    cap[id[i][j]][id[i + 1][k]] = 1;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    int n, m;
    fin >> n >> m;
    for (int i = (1); i <= (int)(n); ++i)
      fin >> needed[i];
    for (int i = (1); i <= (int)(n); ++i)
      for (int j = (1); j <= (int)(m); ++j) {
        fin >> a[i][j];
        interval[i][j] = make_pair(ceil(a[i][j] / 1.1 / needed[i]),
                                   a[i][j] / 0.9 / needed[i]);
        id[i][j] = ++uniq;
        intervalByID[id[i][j]] = make_pair(i, j);
      }
    intervalByID[0] = make_pair(-1000000000, 1000000000);

    for (int i = (1); i <= (int)(n - 1); ++i)
      for (int j = (1); j <= (int)(m); ++j)
        if (solve(i, j))
          for (int k = (1); k <= (int)(m); ++k)
            if (solve(i + 1, k))
              kpqwukgbaw(j, i, k);

    for (int j = (1); j <= (int)(m); ++j) {
      if (solve(1, j))
        cap[0][id[1][j]] = 1;
      if (solve(n, j))
        cap[id[n][j]][n * m + 1] = 1;
    }
    printf("Case #%d: %d\n", test, maxFlow(0, n * m + 1, n * m));

    uniq = 0;
    memset(cap, 0, sizeof cap);
  }
}


