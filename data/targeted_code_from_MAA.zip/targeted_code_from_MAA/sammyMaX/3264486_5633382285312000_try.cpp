#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double EPS = 1e-9;
ifstream fin;

char s[64];
int n, l;

inline void lwbgwzoctz(int &i) {
  for (; (i >= 1) && (s[i - 1] == '0');) {
    i--;
  }
  s[i - 1]--;
  memset(s + i, '9', (l - i) * sizeof(char));
}

int main() {
  ios::sync_with_stdio(0);

  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  int ret_val = 0;

  int t, i, f;
  fin >> t;
  for (int solve = 0; solve < t; solve++) {
    fin >> s;
    l = strlen(s);
    for (i = l - 1; i >= 1; i--) {
      if (s[i] < s[i - 1]) {
        lwbgwzoctz(i);
      }
    }
    printf("Case #%d: %I64d\n", solve + 1, atoll(s));
  }
  return ret_val;
}
