#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double pi = acos(-1.), eps = 1e-6;
const int Maxn = 110, Maxk = 5010, Mo = 1e9 + 7, oo = INT_MAX >> 2;
const int sp[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
int T;
using namespace std;
ifstream fin;

typedef unsigned long long ull;
typedef vector<int> vi;

long long q[1000][10];
int n, m, k, p, ans;
int N, i;
string t;
struct Rec {
  Rec() {}
  Rec(int l, int r) : l(l), r(r) {
    d = (r - l) / 2;
    x = r - l - d;
  }
  int l, r, d, x;
};
priority_queue<Rec> Heap;
bool operator<(Rec a, Rec b) {
  if (a.d != b.d)
    return a.d < b.d;
  if (a.x != b.x)
    return a.x < b.x;
  return a.l > b.l;
}
inline void mmoieccqiq() {
  while (Heap.size())
    Heap.pop();
  printf("Case #%d: ", ++p);
  fin >> N >> i;
  Heap.push(Rec(1, N));
  int npos;
  i--;
  while (i--) {
    Rec now = Heap.top();
    Heap.pop();
    npos = (now.l + now.r) / 2;
    if (now.l <= npos - 1)
      Heap.push(Rec(now.l, npos - 1));
    if (npos + 1 <= now.r)
      Heap.push(Rec(npos + 1, now.r));
  }
  // int Min = N + 1, Max = 0;
  // while(Heap.size()){
  // 	Min = min(Min, Heap.top().d);
  // }
  // cout << Heap.top().l<<" "<< Heap.top().r << endl;
  cout << Heap.top().x << " " << Heap.top().d << endl;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");

  int ret_val = 0;
  fin >> T;
  while (T--)
    mmoieccqiq();
  return ret_val;
}
