#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
ifstream fin;

ofstream fout;

typedef long long td_ll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;          
typedef unsigned long long ULL; 



struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void get(int *arr, int n) {
  fout << "[";
  for (int i = 0; i < n; i++)
    fout << arr[i] << " ";
  fout << "]" << endl;
}

inline void fcqlqxldzi(td_ll &x, td_ll &y) { x = (x * y); }

long long pow2(int a, long long int b) {
  td_ll x = 1, y = a;
  while (b > 0) {
    if (b % 2 == 1)
      fcqlqxldzi(x, y);
    y = (y * y);
    b /= 2;
  }
  return x;
}
LL dist[2];
inline void xdlxqhayug(LL &x, LL &tempx, LL &x1, LL &tempx1, LL tempdist[2]) {
  tempdist[0] = 0;
  tempdist[1] = 0;
  if (x & 1) {
    tempx = x / 2;
    tempx1 = tempx;
    tempdist[0] = 2 * dist[0];
  } else {
    tempx = (x - 1) / 2;
    tempx1 = tempx + 1;
    tempdist[0] = dist[0];
    tempdist[1] = dist[0];
  }

  if (dist[1] > 0) {
    if (!(x1 & 1)) {
      tempx = (x1 - 1) / 2;
      tempx1 = x1 / 2;
      tempdist[0] += dist[1];
      tempdist[1] += dist[1];
    } else {
      tempx1 = x1 / 2;
      tempdist[1] += 2 * dist[1];
    }
  }
  x = tempx;
  x1 = tempx1;
  dist[0] = tempdist[0];
  dist[1] = tempdist[1];
}

inline void ktjwsgqttf(int &c, LL &used) {
  fout << "Case #" << c++ << ": " << used / 2 << " " << used / 2 << endl;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out");

 
  int j, l, m, t, s = 0, d;
  LL n, k, x, x1, level, used, prevLevel, rem;
  fin >> t;
  ;
  int c = 1;
  while (t--) {
    fin >> n;
    fin >> k;
    x = n;
    x1 = n;
    level = log2(k);
    dist[0] = 1;
    dist[1] = 0;
    LL tempx, tempx1;
    LL tempdist[2];
    for (int i = 1; i <= level; i++)
      xdlxqhayug(x, tempx, x1, tempx1, tempdist);
    prevLevel = pow2(2, level) - 1;
    rem = k - prevLevel;
 
    if (rem > dist[1])
      used = x;
    else
      used = x1;

   
    if (used & 1)
      ktjwsgqttf(c, used);
    else {
      fout << "Case #" << c++ << ": " << used / 2 << " " << (used - 1) / 2
           << endl;
    }
  }
  return (0);
}
