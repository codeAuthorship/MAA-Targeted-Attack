#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <complex>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>

using namespace std;

inline void xenvvyncvt(int &res, int &i, int &k, std::string &s) {
  ++res;
  for (int j = i; j < i + k; ++j) {
    s[j] = (s[j] == '+' ? '-' : '+');
  }
}

void solve(int test) {
  string s;
  cin >> s;
  int k;
  cin >> k;

  int n = s.size();

  int res = 0;
  for (int i = 0; i + k - 1 < n; ++i) {
    if (s[i] == '-')
      xenvvyncvt(res, i, k, s);
  }

  if (count(s.begin(), s.end(), '+') != n) {
    printf("Case #%d: IMPOSSIBLE\n", test);
  } else
    printf("Case #%d: %d\n", test, res);
}

int main() {
  int ret_val = 0;

  int t;
  scanf("%d", &t);
  for (int i = 0; i < t; ++i) {
    solve(i + 1);
    cerr << i + 1 << ": " << clock() << endl;
  }
  return ret_val;
}
