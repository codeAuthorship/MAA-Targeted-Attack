#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;
ofstream fout;

ifstream fin;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {}

int main(void) {
  ios::sync_with_stdio(false);

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in");

  int get = 0;
  solve();
  int tc;
  fin >> tc;
  char str[1010];
  int t;
  {
    int ct = 1;
    for (; ct <= tc;) {
      fin >> str;
      fin >> t;
      int ret = 0;
      int len = strlen(str);

      int j;
      for (j = 0; j < len; j++) {
        if (str[j] == '-') {
          if (j + t > len) {
            ret = -1;
            break;
          }
          for (int l = 0; l < t; l++) {
            if (str[l + j] == '+')
              str[l + j] = '-';
            else {
              str[l + j] = '+';
            }
          }
          ret++;
          // printf("%s\n", str);
        }
      }

      fout << "Case #" << ct << ": ";

      if (ret == -1) {
        fout << "IMPOSSIBLE\n";
      } else {
        fout << ret << "\n";
      }
      cerr << "Test " << ct << " done \n";
      ct++;
    }
  }
  return get;
}
