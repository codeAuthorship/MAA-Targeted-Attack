#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <utility>
#include <vector>
using namespace std;

int N, Q, U, V;
int e[200];
double s[200];
int d[200][200];
int go[200];

double ans[200];
int main(void) {
  int ret_val = 0;
  int t;
  scanf("%d", &t);
  for (int solve = 1; solve <= t; solve++) {
    scanf("%d%d", &N, &Q);
    for (int i = 0; i < N; ++i)
      scanf("%d%lf", &e[i], &s[i]);
    for (int i = 0; i < N; ++i)
      for (int j = 0; j < N; ++j)
        scanf("%d", &d[i][j]);

    for (int k = 0; k < N; ++k)
      for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j) {
          if (i == j || d[i][k] < 0 || d[k][j] < 0)
            continue;
          if (d[i][j] >= d[i][k] + d[k][j]) {
            d[i][j] = d[i][k] + d[k][j];
          } else if (d[i][j] < 0) {
            d[i][j] = d[i][k] + d[k][j];
          }
        }

    printf("Case #%d:", solve);

    for (; Q--;) {
      scanf("%d%d", &U, &V);
      --U, --V;
      for (int i = 0; i < N; ++i) {
        ans[i] = -1;
        go[i] = false;
      }
      ans[U] = 0;
 

      int cur = U;
      while (1) {
        go[cur] = true;
        for (int i = 0; i < N; ++i) {
          if (d[cur][i] > e[cur] || d[cur][i] < 0)
            continue;
          if (ans[i] < 0 || ans[i] > ans[cur] + d[cur][i] / s[cur])
            ans[i] = ans[cur] + d[cur][i] / s[cur];
        }

        double mind = -1;
        for (int i = 0; i < N; ++i) {
          if (go[i] || ans[i] < 0)
            continue;
          if (mind < 0 || mind > ans[i]) {
            cur = i;
            mind = ans[i];
          }
        }

        if (mind < 0)
          break;
      }

      printf(" %lf", ans[V]);
    }

    puts("");
  }
  return ret_val;
}
