#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin;

int tc;

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_1_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/4yn/A-small-practice.in");

  fin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int r, c;
    fin >> r >> c;
    char cake[30][30];
    for (int solve = 0; solve < r; solve++) {
      for (int j = 0; j < c; j++) {
        fin >> cake[solve][j];
      }
    }
    for (int solve = 0; solve < r; solve++) {

      for (int j = 1; j < c; j++) {
        if (cake[solve][j - 1] != '?' && cake[solve][j] == '?') {
          cake[solve][j] = cake[solve][j - 1];
        }
      }

      for (int j = c - 2; j >= 0; j--) {
        if (cake[solve][j + 1] != '?' && cake[solve][j] == '?') {
          cake[solve][j] = cake[solve][j + 1];
        }
      }
    }
    for (int solve = 1; solve < r; solve++) {

      if (cake[solve - 1][0] != '?' && cake[solve][0] == '?') {
        for (int j = 0; j < c; j++) {
          cake[solve][j] = cake[solve - 1][j];
        }
      }
    }
    {
      int solve = r - 1;
      while (solve >= 0) {

        if (cake[solve + 1][0] != '?' && cake[solve][0] == '?') {
          for (int j = 0; j < c; j++) {
            cake[solve][j] = cake[solve + 1][j];
          }
        }
        solve--;
      }
    }
    cout << "Case #" << t << ":\n";
    for (int solve = 0; solve < r; solve++) {
      for (int j = 0; j < c; j++) {
        cout << cake[solve][j];
      }
      cout << endl;
    }
  }
}
