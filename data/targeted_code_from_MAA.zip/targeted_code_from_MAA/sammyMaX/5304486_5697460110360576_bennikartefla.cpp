#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin;

const int MAXN = 1005;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

struct BpGraph {
  vvi adj;
  vi owner;
  vector<bool> done;

  BpGraph(int n, int m) {
    adj = vvi(n);
    done = vector<bool>(n);
    owner = vi(m, -1);
  }
  void addEdge(int a, int b) { adj[a].push_back(b); }
  int alternating_path(int left) {
    int ret_val = 0;
    if (done[left]) {
      int ret_val = 0;
      return ret_val;
    }
    done[left] = true;
    for (int i = (0); i < (adj[left].size()); i++) {
      int right = adj[left][i];
      if (owner[right] == -1 || alternating_path(owner[right])) {
        int ret_val = 1;
        owner[right] = left;
        return ret_val;
      }
    }
    return ret_val;
  }
  int maximum_matching(int n, int m) {
    int res = 0;
    for (int i = (0); i < (n); i++) {
      for (int a = (0); a < (n); a++)
        done[a] = 0;
      res += alternating_path(i);
    }
    return res;
  }
};

bool binary(double num, double need) {
  int lo = 1, hi = 100000000;
  while (lo <= hi) {
    int mid = (lo + hi) / 2;
    double ok = mid * num;
    double res = need / ok;
    if (res >= 0.90 && res <= 1.1) {
      return true;
    }
    if (res > 1.1) {
      lo = mid + 1;
    } else
      hi = mid - 1;
  }
  return 0;
}

inline void bkduwmnoix(struct BpGraph &solve, int &i, int &a) {
  solve.addEdge(i, a);
}

inline void lgvqozpdrr(double &duds, int &count) {
  double hold;
  fin >> hold;
  if (binary(duds, hold))
    count++;
}

inline void xlcxwdgsoy(vector<double> &duds, int &i) { fin >> duds[i]; }

int main() {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/A-small-practice.in");
  ofstream fout("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int u = (0); u < (t); u++) {
    int n, p;
    fin >> n >> p;
    int x = 0;
    if (n == 1) {
      int count = 0;
      double duds = 0;
      fin >> duds;
      for (int i = (0); i < (p); i++)
        lgvqozpdrr(duds, count);
      x = count;
    } else {
      BpGraph solve(p, p);
      int count = 0;
      vector<double> duds(n);
      for (int i = (0); i < (n); i++)
        xlcxwdgsoy(duds, i);
      vector<double> first(p);
      vector<double> second(p);
      for (int i = (0); i < (p); i++)
        fin >> first[i];
      for (int i = (0); i < (p); i++)
        fin >> second[i];
      for (int i = (0); i < (p); i++) {
        for (int a = (0); a < (p); a++) {
          bool can = 0;
          for (int z = (1); z < (1000001); z++) {
            double ok = duds[0] * z;
            double otherok = duds[1] * z;
            double fin1 = first[i] / ok;
            double fin2 = second[a] / otherok;
            if (fin1 >= 0.9 && fin1 <= 1.1 && fin2 >= 0.9 && fin2 <= 1.1) {
              can = true;
              break;
            }
          }
          if (can)
            bkduwmnoix(solve, i, a);
        }
      }
      x = solve.maximum_matching(p, p);
    }
    fout << "Case #" << u + 1 << ": " << x << endl;
  }
  return ret_val;
}
