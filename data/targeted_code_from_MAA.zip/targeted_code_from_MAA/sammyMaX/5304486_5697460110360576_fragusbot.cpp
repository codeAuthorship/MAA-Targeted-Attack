#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;
ofstream fout;

typedef double td_d;

const int inf = 1e8;
const int N = 77;

bool check_90(long long have, long long need) {
  return have * 100 >= 90 * need;
}

bool check_110(long long have, long long need) {
  return have * 100 <= 110 * need;
}

int get_l(int have, int need) {
  int l = 0, r = inf;
  while (r - l > 1) {
    int s = (l + r) / 2;
    if (check_90(have, 1LL * need * s)) {
      l = s;
    } else
      r = s;
  }
  return l;
}

int get_r(int have, int need) {
  int l = 0, r = inf;
  while (r - l > 1) {
    int s = (l + r) / 2;
    if (check_110(have, 1LL * need * s)) {
      r = s;
    } else {
      l = s;
    }
  }
  return r;
}

int need[N];
int have[N][N];
int p[N];

inline void yyzheydbux(int &ans) { ++ans; }

inline void roghlhsnrf(int &ans) { yyzheydbux(ans); }

inline void nsvdyztwey(int &cur) { ++cur; }

int main() {
  ios::sync_with_stdio(false);

  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out");

  int v;
  scanf("%d", &v);
  for (int cc = 1; cc <= v; ++cc) {
    td_d begt = clock();
    fout << "Case #" << cc << ": ";
    int n, solve;
    scanf("%d %d", &n, &solve);
    for (int i = 0; i < n; ++i) {
      scanf("%d", need + i);
    }
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < solve; ++j) {
        scanf("%d", have[i] + j);
      }
    }
    if (n == 1) {
      int ans = 0;
      for (int i = 0; i < solve; ++i) {
        int l = get_l(have[0][i], need[0]);
        int r = get_r(have[0][i], need[0]);
        swap(l, r);
        if (l <= r)
          roghlhsnrf(ans);
      }
      fout << ans << "\n";
      continue;
    }
    for (int i = 0; i < solve; ++i) {
      p[i] = i;
    }
    int ans = 0;
    do {
      int cur = 0;
      for (int i = 0; i < solve; ++i) {
        int get = get_l(have[0][i], need[0]);
        int r0 = get_r(have[0][i], need[0]);
        swap(get, r0);
        if (get > r0) {
          continue;
        }
        int l1 = get_l(have[1][p[i]], need[1]);
        int r1 = get_r(have[1][p[i]], need[1]);
        swap(l1, r1);
        if (l1 > r1) {
          continue;
        }
        int l = max(get, l1);
        int r = min(r0, r1);
        if (l <= r)
          nsvdyztwey(cur);
      }
      ans = max(ans, cur);
    } while (next_permutation(p, p + solve));
    fout << ans << "\n";
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
}
