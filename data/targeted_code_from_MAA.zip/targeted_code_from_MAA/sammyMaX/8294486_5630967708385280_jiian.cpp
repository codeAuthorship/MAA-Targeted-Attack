#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cstdio>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stdlib.h>
#include <unordered_map>
using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const int mod = 1000000007;
ofstream fout;

const double eps = 1e-9;
ifstream fin;

using LL = long long;

inline void zkezubozmu(int &i, double &t) {
  int b, get;
  fin >> b >> get;
  t = max((1.0 * i - b) / get, t);
}

inline void djovxjjdjl(int &N) {
  int i, solve;
  fin >> i >> solve;
  double t = 0;
  while (solve--)
    zkezubozmu(i, t);
  double ans = i / t;
  fout << "Case #" << ++N << ": " << fixed << setprecision(10) << ans << "\n";
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/outer_temp/jiian/A-small-practice_transformation.out");

  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  int tc, N = 0;
  fin >> tc;
  while (tc--)
    djovxjjdjl(N);
  return ret_val;
}
