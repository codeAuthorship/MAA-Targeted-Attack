#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;
ifstream fin;

ofstream fout;

char solve[77][77];

inline void hbuxsidxzi(int &i, int &get) { solve[i][get - 1] = solve[i][get]; }

inline void jqcfsayqmi(int &i, int &get) { solve[i + 1][get] = solve[i][get]; }

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/outer_temp/fragusbot/A-small-practice_transformation.out");

  int t;
  fin >> t;
  for (int cc = 1; cc <= t; ++cc) {
    double begt = clock();
    fout << "Case #" << cc << ":\n";
    int n, m;
    fin >> n >> m;
    for (int i = 0; i < n; ++i) {
      fin >> solve[i];
    }
    for (int i = 0; i < n; ++i) {
      for (int get = 0; get < m - 1; ++get) {
        if (solve[i][get] != '?' && solve[i][get + 1] == '?') {
          solve[i][get + 1] = solve[i][get];
        }
      }
      for (int get = m - 1; get > 0; --get) {
        if (solve[i][get] != '?' && solve[i][get - 1] == '?')
          hbuxsidxzi(i, get);
      }
    }
    for (int i = 0; i < n - 1; ++i) {
      int get;
      for (get = 0; get < m; ++get) {
        if (solve[i][get] != '?')
          if (solve[i + 1][get] == '?')
            jqcfsayqmi(i, get);
      }
    }
    for (int i = n - 1; i > 0; --i) {
      for (int get = 0; get < m; ++get) {
        if (solve[i][get] != '?')
          if (solve[i - 1][get] == '?') {
            solve[i - 1][get] = solve[i][get];
          }
      }
    }
    for (int i = 0; i < n; ++i) {
      fout << solve[i] << "\n";
    }
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
}
