#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>


using namespace std;

const int MAXN = 1005;
ifstream fin;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void jjmvaithol(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll do_lldqd_fct(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    jjmvaithol(a, b, t);
  return b;
}

ll get(ll base, ll n, ll tc) {
  if (n == 0) {
    return 1;
  }
  ll t = get(base, n / 2, tc);
  if (n % 2 == 0)
    return (t * t) % tc;
  else
    return (((t * t) % tc) * base) % tc;
}

bool do__Bocbu_fct(int i, ll mask) { return (mask >> i) & 1; }

int solve(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (do__Bocbu_fct(i, mask))
      ++ans;
  return ans;
}

inline void qqqnioxcqd(double &mt, ll &d) {
  ll k, s;
  fin >> k >> s;
  mt = max(mt, (d - k) / static_cast<double>(s));
}

int main() {
  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/A-small-practice.in");
  int t;
  fin >> t;
  for (int i = 1; i <= t; ++i) {
    ll d, n;
    fin >> d >> n;
    double mt = 0;
    for (int j = 0; j < n; ++j)
      qqqnioxcqd(mt, d);
    cout << "Case #" << i << ": " << fixed << setprecision(10) << d / mt
         << "\n";
  }
  return ret_val;
}
