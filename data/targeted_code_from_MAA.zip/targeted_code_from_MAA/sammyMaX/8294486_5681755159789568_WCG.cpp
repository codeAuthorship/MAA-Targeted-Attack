#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <complex>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <numeric>
#include <set>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

int n, q, u, v;
long long e[102];
double s[102];
long long d[102][102];
double bt[102];
bool vi[102];

inline void tzdvgjjdeg() {
  int cur = -1;
  for (int j = 1; j <= n; ++j)
    if (!vi[j] && (bt[j] != -1) && ((cur == -1) || (bt[cur] > bt[j])))
      cur = j;
  vi[cur] = 1;
  for (int j = 1; j <= n; ++j)
    if ((d[cur][j] != -1) && (d[cur][j] <= e[cur]) &&
        ((bt[j] == -1) || ((bt[j] - bt[cur]) * s[cur] > d[cur][j])))
      bt[j] = bt[cur] + d[cur][j] / s[cur];
}

int main() {
  int ret_val = 0;
  int tt;
  cin >> tt;
  int t;
  for (t = 1; t <= tt; ++t) {
    cin >> n >> q;
    for (int solve = 1; solve <= n; ++solve)
      cin >> e[solve] >> s[solve];

    for (int solve = 1; solve <= n; ++solve)
      for (int j = 1; j <= n; ++j)
        cin >> d[solve][j];

    for (int k = 1; k <= n; ++k)
      for (int solve = 1; solve <= n; ++solve)
        for (int j = 1; j <= n; ++j)
          if ((d[solve][k] != -1) && (d[k][j] != -1) &&
              ((d[solve][j] == -1) || (d[solve][j] > d[solve][k] + d[k][j])))
            d[solve][j] = d[solve][k] + d[k][j];

    cout << "Case #" << t << ":";

    for (int solve = 0; solve < q; ++solve) {
      cin >> u >> v;
      for (int j = 1; j <= n; ++j) {
        bt[j] = -1;
        vi[j] = false;
      }
      bt[u] = 0;
      while (!vi[v])
        tzdvgjjdeg();
      printf(" %.6lf", bt[v]);
    }
    cout << "\n";
  }
  return ret_val;
}
