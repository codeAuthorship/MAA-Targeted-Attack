#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
#include <set>
#include <stdio.h>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
const int mod = 1000000007;

typedef set<int> si;
typedef vector<vector<int>> vvi;
typedef vector<int> VI;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> pii;
typedef pair<pii, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t, p[5];

void solve(int n, int c) {
  if (n == c) {
    cout << "0 0\n";
    return;
  }

  int pot = 1;

  int a = n, b = 0;
  p[0] = 1;
  p[1] = 0;
  for (; pot < c;) {
    int newA = 0, newB = 0;
    newA = a / 2;
    p[2] = p[0];
    if (a - newA - 1 != newA && newA != 1) {
      p[3] = p[0];
      newB = a - newA - 1;
    } else {
      if (a != 2)
        p[2] += p[0];
    }

    if (b > 1) {
      if (b % 2 == 0) {
        if (b != 2) {
          newB = b - (b / 2) - 1;
          p[3] += p[1];
        }
        p[2] += p[1];
      } else {
        p[3] += p[1] * 2;
      }

    } else {
      p[2] += p[1];
      if (a != n)
        if (b != 0)
          c++;
    }

    a = newA;
    b = newB;
    p[0] = p[2];
    p[1] = p[3];
    p[2] = p[3] = 0;
   
    c -= pot;
    pot *= 2;
  }
 
  if (c > p[0])
    a = b;
  cout << a / 2 << " " << max(0, a - (a / 2) - 1) << "\n";
}

int main() {
  int ret_val = 0;

  cin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    int n, c;
    cin >> n >> c;
    cout << "Case #" << x << ": ";
    solve(n, c);
  }
  return ret_val;
}
