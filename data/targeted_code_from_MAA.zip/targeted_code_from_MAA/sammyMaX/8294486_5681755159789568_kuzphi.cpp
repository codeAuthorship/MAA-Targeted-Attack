#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

const int Maxn = 110, oo = 2e9 + 1;

int T;
using namespace std;
ofstream fout;

const int INF = 1000000000;
ifstream fin;

// ll f[Maxn][Maxn][2],vis[Maxn][Maxn][2];
int n, cs;
struct Rec {
  int a, b, l;
};
// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
// int N, R, O, Y, G, B, V;
int Q;

long long d[Maxn][Maxn];
int S[Maxn], E[Maxn];
double t[Maxn][Maxn];

inline void sqypbudvyy() {
  int i = 1;
  while (i <= n) {
    fin >> E[i] >> S[i];
    i++;
  }
}

inline void dezavvwylo() {
  int i = 1;
  while (i <= n) {
    d[i][i] = 0;
    i++;
  }
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out");

  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");
  fin >> T;
  for (; T--;) {
    fout << "Case #" << ++cs << ": ";
    fin >> n >> Q;
    sqypbudvyy();
    int i;
    for (i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++) {
        fin >> d[i][j];
        if (d[i][j] == -1)
          d[i][j] = oo;
      }
    dezavvwylo();

    int solve;
    for (solve = 1; solve <= n; solve++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          d[i][j] = min(d[i][j], d[i][solve] + d[solve][j]);
    // rep(i,1,n){
    // 	rep(j,1,n) cout << d[i][j]<<" ";
    // 	cout << endl;
    // }
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++) {
        if (d[i][j] > E[i])
          t[i][j] = 1e100;
        else
          t[i][j] = 1. * d[i][j] / S[i];
      }
    for (int solve = 1; solve <= n; solve++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) {
          t[i][j] = min(t[i][j], t[i][solve] + t[solve][j]);
        }
    for (int i = 1; i <= Q; i++) {
      int u, v;
      fin >> u >> v;
      fout << fixed << setprecision(7) << t[u][v];
      if (i < Q)
        fout << " ";
    }
    fout << endl;
  }
  return ret_val;
}
