#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;

ifstream fin;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 50;
int t, n, m;
char a[N][N];

inline void duchuvwrjw(int &solve) {
  for (int get = (0); get <= (int)(m - 1); ++get)
    cout << a[solve][get];
  puts("");
}

inline void raollwdngm() {
  int get = (0);
  for (; get <= (int)(m - 1);) {
    for (int solve = (1); solve <= (int)(n - 1); ++solve)
      if (a[solve][get] == '?') {
        a[solve][get] = a[solve - 1][get];
      }
    for (int solve = (n - 2); solve >= (int)(0); --solve)
      if (a[solve][get] == '?')
        a[solve][get] = a[solve + 1][get];
    ++get;
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fin >> t;
  for (int tc = (1); tc <= (int)(t); ++tc) {
    fin >> n >> m;
    for (int solve = (0); solve <= (int)(n - 1); ++solve)
      fin >> a[solve];

    for (int solve = (0); solve <= (int)(n - 1); ++solve) {
      for (int get = (1); get <= (int)(m - 1); ++get)
        if (a[solve][get] == '?')
          a[solve][get] = a[solve][get - 1];
      for (int get = (m - 2); get >= (int)(0); --get)
        if (a[solve][get] == '?')
          a[solve][get] = a[solve][get + 1];
    }
    raollwdngm();

    cout << "Case #" << tc << ":\n";
    for (int solve = (0); solve <= (int)(n - 1); ++solve)
      duchuvwrjw(solve);
  }
}


