#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;

ifstream fin;

ofstream fout;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T> ostream &solve(ostream &ans, const pair<S, T> &p) {
  return ans << p.first << " " << p.second;
}
template <class T> void get(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

inline void yfdhvarnpe(VS &vs, int &by, int &xx, _Bool &ok) {
  if (vs[by][xx] != '?')
    ok = 0;
}

inline void zwgkutuwye(VS &vs, int &ty, int &xx, _Bool &ok) {
  if (vs[ty][xx] != '?')
    ok = false;
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/outer_temp/okaduki/A-small-practice_transformation.out");

  int ret_val = 0;
  cin.tie(0);

  int T;
  fin >> T;
  for (int a = (1); a < (T + 1); ++a) {
    int H, W;
    fin >> H >> W;
    VS vs(H);
    for (int y = (0); y < (H); ++y)
      fin >> vs[y];

    set<char> memo;
    for (int y = (0); y < (H); ++y)
      for (int x = (0); x < (W); ++x) {
        if (vs[y][x] != '?')
          if (!memo.count(vs[y][x])) {
            memo.insert(vs[y][x]);

            int lx, rx, ty, by;
            for (lx = x - 1; lx >= 0; --lx)
              if (vs[y][lx] != '?')
                break;
            ++lx;
            for (rx = x + 1; rx < W; ++rx)
              if (vs[y][rx] != '?')
                break;

            for (ty = y - 1; ty >= 0; --ty) {
              bool ok = true;
              for (int xx = lx; xx < rx; ++xx)
                zwgkutuwye(vs, ty, xx, ok);
              if (!ok)
                break;
            }
            ++ty;
            for (by = y + 1; by < H; ++by) {
              bool ok = true;
              for (int xx = lx; xx < rx; ++xx)
                yfdhvarnpe(vs, by, xx, ok);
              if (!ok)
                break;
            }

            for (int yy = (ty); yy < (by); ++yy)
              for (int xx = (lx); xx < (rx); ++xx)
                vs[yy][xx] = vs[y][x];
          }
      }

    fout << "Case #" << a << ":" << endl;

    for (int y = (0); y < (H); ++y)
      fout << vs[y] << endl;
  }
  return ret_val;
}
