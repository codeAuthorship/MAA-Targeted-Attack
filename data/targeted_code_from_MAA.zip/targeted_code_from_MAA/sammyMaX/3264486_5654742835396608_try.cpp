#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
using namespace std;
const int mod = 1000000007;
ofstream fout;

ifstream fin;

priority_queue<int> Q, E;
int n, k;

inline void xrqrczpyut(int &solve, int &y, int &z, int &get) {
  solve = Q.top();
  Q.pop();
  y = solve / 2;
  z = (solve - 1) / 2;
  Q.push(y);
  Q.push(z);
  get++;
}

inline void oiqpcmqkda(int &get, int &solve, int &c, int &y, int &z) {
  fin >> n >> k;
  Q = E;
  Q.push(n);
  {
    get = 0;
    while (get < k)
      xrqrczpyut(solve, y, z, get);
  }
  fout << "Case #" << c + 1 << ": " << y << " " << z << "\n";
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/outer_temp/try/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  int ret_val = 0;

  int t, get, solve, y, z;
  fin >> t;
  for (int c = 0; c < t; c++) {
    oiqpcmqkda(get, solve, c, y, z);
  }
  return ret_val;
}
