#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

int main() {
  int ret_val = 0;
  cin.sync_with_stdio(false);
  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  cin >> t;
  string nice = "ROYGBVXXX";
  for (int u = (0); u < (t); u++) {
    int arr[8];
    memset(arr, 0, sizeof(arr));
    int n;
    cin >> n;
    for (int i = (0); i < (6); i++)
      cin >> arr[i];
    string s = "";
    int last = 7;
    int og = n;
    int solve = true;
    while (n != 0) {
      int bst = 0;
      int index = 0;
      for (int i = (0); i < (6); i++)
        if (arr[i] >= bst && nice[i] != nice[last] && arr[i] != 0) {
          if (arr[i] == bst && arr[i] != 0) {
            if (n != og) {
              if (s[0] == nice[i]) {
                bst = arr[i];
                index = i;
              }
            }
          } else if (arr[i] > bst) {
            bst = arr[i];
            index = i;
          }
        }
      arr[index]--;
      if (bst == -1) {
        solve = false;
        break;
      }
      s += nice[index];
      last = index;
      n--;
    }
    if (s.size() != og)
      solve = false;
    for (int i = (0); i < (s.size() - 1); i++)
      if (s[i] == s[i + 1])
        solve = false;
    for (int i = (1); i < (s.size()); i++)
      if (s[i] == s[i - 1])
        solve = false;
    fout << "Case #" << u + 1 << ": ";
    if (s[0] == s[s.size() - 1] || !solve)
      fout << "IMPOSSIBLE" << endl;
    else
      fout << s << endl;
  }
  return ret_val;
}
