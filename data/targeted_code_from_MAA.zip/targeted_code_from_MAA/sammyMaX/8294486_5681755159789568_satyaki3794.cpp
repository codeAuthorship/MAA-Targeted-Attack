#include <bits/stdc++.h>
#include <fstream>
#include <vector>

using namespace std;

typedef unsigned long long ull;
typedef vector<int> VI;
typedef long double LD;
typedef vector<vector<int>> vvi;

ifstream fin;

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

const int N = 102;
int n, q;
double endurance[N], speed[N], adj[N][N], dist[N][N];

inline void nhsbdbujcf(int &src, priority_queue<pair<double, int>> &pq,
                       double &dd, int &vv) {
  dist[src][vv] = dd;
  pq.push(pair<double, int>(-dd, vv));
}

void dijkstra(int src) {
  for (int i = 1; i <= n; i++)
    dist[src][i] = 1e15;
  priority_queue<pair<double, int>> pq;
  dist[src][src] = 0;
  pq.push(pair<double, int>(0, src));
  while (!pq.empty()) {

    int v = pq.top().second;
    double d = -pq.top().first;
    pq.pop();
    if (d > dist[src][v])
      continue;

    for (int vv = 1; vv <= n; vv++) {
      if (adj[v][vv] > endurance[v])
        continue;
      double dd = d + adj[v][vv] / speed[v];
      if (dd < dist[src][vv])
        nhsbdbujcf(src, pq, dd, vv);
    }
  }
}

inline void jvubjeotno() {
  int a, b;
  fin >> a >> b;
  cout << fixed << setprecision(7) << " " << dist[a][b];
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  int ret_val = 0;

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    fin >> n >> q;
    for (int i = 1; i <= n; i++)
      fin >> endurance[i] >> speed[i];

    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= n; j++) {
        fin >> adj[i][j];
        if (adj[i][j] == -1)
          adj[i][j] = 1e15;
      }
    }

    for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
          adj[i][j] = min(adj[i][j], adj[i][k] + adj[k][j]);

    for (int i = 1; i <= n; i++)
      dijkstra(i);

    cout << "Case #" << x++ << ":";
    while (q--)
      jvubjeotno();
    cout << endl;
  }
  return ret_val;
}
