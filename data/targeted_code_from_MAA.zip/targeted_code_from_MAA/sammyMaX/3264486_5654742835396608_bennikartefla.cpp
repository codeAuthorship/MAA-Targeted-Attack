#include <bits/stdc++.h>
#include <fstream>
using namespace std;
const int MOD = 1000000007;
const double EPS = 1e-9;
const int mod = 1000000007;
ifstream fin;

inline void hlsxchszmp(std::ofstream &fout, int &j) {
  int first = j / 2;
  fout << j - first << " " << first << endl;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/A-small-practice.in");

  int ret_val = 0;

  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int n;
  fin >> n;
  for (int i = (0); i < (n); i++) {
    priority_queue<int> k;
    int s, q;
    fin >> s >> q;
    fout << "Case #" << i + 1 << ": ";
    k.push(s - 1);
    {
      int a = (0);
      while (a < (q - 1)) {
        if (k.empty()) {
          break;
        } else {
          int j = k.top();
          k.pop();
          if (j == 0) {
            a++;
            continue;
          }
          int want = j / 2;
          int first = want;
          if (first != 0)
            k.push(first - 1);
          int solve = j - want;
          k.push(solve - 1);
        }
        a++;
      }
    }
    if (k.empty())
      fout << "0 0" << endl;
    else {
      int j = k.top();
      if (j == 0)
        fout << "0 0" << endl;
      else
        hlsxchszmp(fout, j);
    }
  }
  return ret_val;
}
