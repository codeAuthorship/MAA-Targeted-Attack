
#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

typedef long double ld;
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef set<int> si;
typedef vector<vector<int>> vvi;

void solve() {
  string s;
  int t;
  fin >> s >> t;
  int len = (int)s.size();
  int ans = 0;
  for (int i = 0; i <= len - t; ++i) {
    if (s[i] == '-') {
      ans++;
      {
        int j = i;
        for (; j < i + t;) {
          s[j] = (s[j] == '-' ? '+' : '-');
          ++j;
        }
      }
    }
  }
  for (int i = len - t + 1; i < len; ++i) {
    if (s[i] == '-') {
      printf("IMPOSSIBLE\n");
      return;
    }
  }
  printf("%d\n", ans);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in");

  int ret_val = 0;

  int q;
  fin >> q;
  for (int i = 1; i <= q; ++i) {
    printf("Case #%d: ", i);
    solve();
  }
  return ret_val;
}
