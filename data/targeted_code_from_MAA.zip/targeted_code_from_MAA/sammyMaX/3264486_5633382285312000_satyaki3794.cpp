// satyaki3794
#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream fin;

ofstream fout;

inline void fddeesmhfs(long long &ans, long long &v, long long &mod,
                       long long &p) {
  if (p & 1)
    ans = (ans * v) % mod;
  v = (v * v) % mod;
  p /= 2;
}

long long solve(long long v, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p)
    fddeesmhfs(ans, v, mod, p);
  return ans;
}

long long get(long long a, long long b) {
  if (b == 0)
    return a;
  return get(b, a % b);
}

vector<int> arr;

inline void edbusitxzn(long long &val) {
  arr.push_back(val % 10);
  val /= 10;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");

  int ret_val = 0;
  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    long long val;
    fin >> val;

    long long z = val;
    arr.clear();
    while (val)
      edbusitxzn(val);
    reverse(arr.begin(), arr.end());

    int ok = true;
    for (int i = 1; i < (int)arr.size(); i++)
      if (arr[i] < arr[i - 1])
        ok = false;
    if (ok) {
      fout << "Case #" << x++ << ": " << z << endl;
      continue;
    }

    int pos = 0;
    for (int i = 1; i < (int)arr.size(); i++) {
      if (arr[i] < arr[i - 1])
        break;
      if (arr[i] > arr[i - 1])
        pos = i;
    }

    arr[pos]--;
    for (int i = pos + 1; i < (int)arr.size(); i++)
      arr[i] = 9;
    long long ans = 0;
    for (auto it : arr)
      ans = ans * 10 + it;
    fout << "Case #" << x++ << ": " << ans << endl;
  }
  return ret_val;
}
