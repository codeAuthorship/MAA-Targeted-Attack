#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

int main() {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  int tt;
  cin >> tt;
  int t;
  for (t = 1; t <= tt; ++t) {
    string s;
    int k, res = 0;
    cin >> s >> k;
    for (int solve = 0; solve + k <= s.size(); ++solve) {
      if (s[solve] == '-') {
        for (int j = 0; j < k; ++j)
          s[solve + j] = (s[solve + j] == '-') ? '+' : '-';
        res++;
      }
    }
    for (int solve = 0; solve < s.size(); ++solve)
      if (s[solve] == '-')
        res = -1;

    cout << "Case #" << t << ": ";
    if (res == -1)
      cout << "IMPOSSIBLE" << endl;
    else {
      cout << res << endl;
    }
  }
  return ret_val;
}
