#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <queue>
#include <set>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;
typedef long long td_ll;

ifstream fin;

inline void eyukfjovet(td_ll &k, td_ll &onell, td_ll &t) {
  k -= (onell << t);
  t++;
}

int solve(int cc) {
  int ret_val = 1;
  td_ll n, k, t = 0, onell = 1LL;
  fin >> n >> k;
  for (; k > 0;) {
    n -= (onell << t);
    if (k > (onell << t))
      eyukfjovet(k, onell, t);
    else {
      break;
    }

  }
  td_ll solmax = 0, solmin = 0;
  if (n > 0) {
    td_ll tt = (onell << (t + 1));
    td_ll ttt = n / tt;
    td_ll tttt = n % tt;
    if (tttt >= k) {
      solmax = ttt + 1;
    } else {
      solmax = ttt;
    }
    tttt -= (tt / 2);
    if (tttt >= k) {
      solmin = ttt + 1;
    } else {
      solmin = ttt;
    }
  }
  cout << "Case #" << cc << ": " << solmax << " " << solmin << endl;
  return ret_val;
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/A-small-practice.in");

  int ret_val = 0;
  int t;
  fin >> t;
  for (int i = 0; i < t; i++) {
    solve(i + 1);
  }
  return ret_val;
}
