#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <complex>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>

using namespace std;

const long long inf = 1000000000000000000LL;

vector<long long> res;

void rec(long long value, long long d) {
  if (value >= inf) {
    return;
  }
  res.push_back(value);
  for (long long i = d; i <= 9; ++i) {
    if (value < inf / 10LL) {
      rec(value * 10LL + i, i);
    }
  }
}

void solve(int test) {
  long long n;
  cin >> n;

  int index = upper_bound(res.begin(), res.end(), n) - res.begin() - 1;
  printf("Case #%d: %lld\n", test, res[index]);
}

int main() {
  int ret_val = 0;
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in",
          "r", stdin);
  for (int i = 1; i <= 9; ++i) {
    rec(i, i);
  }
  sort(res.begin(), res.end());
  cerr << "Res size: " << res.size() << endl;
  int t;
  cin >> t;
  for (int i = 0; i < t; ++i) {
    solve(i + 1);
    cerr << i + 1 << ": " << clock() << endl;
  }
  return ret_val;
}
