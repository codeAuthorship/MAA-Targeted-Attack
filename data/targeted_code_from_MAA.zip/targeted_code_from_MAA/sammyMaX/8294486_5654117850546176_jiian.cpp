#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdio.h>
using namespace std;
const double eps = 1e-9;
ifstream fin;

using LL = long long;

int solve[6];
string s = "ROYGBV";

inline void apcoxkbkfd() { puts("IMPOSSIBLE"); }

int main() {
  ios::sync_with_stdio(false);

  int tc = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int get, x = 0;
  fin >> get;
  while (get--) {
    int t;
    fin >> t;

    int i;
    for (i = 0; i < 6; i++)
      fin >> solve[i];
    string ans = "";
    int flag = 0;
    while (ans.size() < t) {
      int mx = 0, c = 0;
      for (int i = 0; i < 6; i++) {
        if (s[i] == ans.back())
          continue;
        if (solve[i] == mx && ans.size() && s[i] == ans[0])
          mx = solve[i], c = i;
        if (solve[i] > mx)
          mx = solve[i], c = i;
      }
      if (s[c] == ans.back() || solve[c] == 0) {
        flag = 1;
        break;
      }
      ans.push_back(s[c]);
      solve[c]--;
    }
 
    if (ans.size() > 1 && ans[0] == ans.back())
      flag = 1;
    printf("Case #%d: ", ++x);
    if (flag)
      apcoxkbkfd();
    else
      printf("%s\n", ans.c_str());
  }
  return tc;
}
