 
#include <bits/stdc++.h>
#include <fstream>
#include <iostream>

using namespace std;
ifstream fin;

const double eps = 1e-9;
ofstream fout;

typedef pair<int, int> ii;

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

int r, c;
char s[26][26];

inline void jtnthhquxy(int &i, int &j, int &maxy, int &y) {
  s[i][y++] = s[i][j];
  maxy = y - 1;
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");

  int ret_val = 0;
  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    fin >> r >> c;
    for (int i = 1; i <= r; i++)
      fin >> (s[i] + 1);

    for (int i = 1; i <= r; i++)
      for (int j = 1; j <= c; j++)
        if (s[i][j] != '?') {

          int miny = j, maxy = j;

          int y = j - 1;
          while (y >= 1 && s[i][y] == '?') {
            s[i][y--] = s[i][j];
            miny = y + 1;
          }

          y = j + 1;
          while (y <= c && s[i][y] == '?')
            jtnthhquxy(i, j, maxy, y);
        }

    queue<ii> qq;
    for (int i = 1; i <= r; i++)
      if (s[i][1] != '?') {

        int x = i - 1;
        for (; x >= 1 && s[x][1] == '?';) {
          for (int j2 = 1; j2 <= c; j2++)
            s[x][j2] = s[x + 1][j2];
          x--;
        }

        x = i + 1;
        for (; x <= r && s[x][1] == '?';) {
          for (int j2 = 1; j2 <= c; j2++)
            s[x][j2] = s[x - 1][j2];
          x++;
        }
      }

    fout << "Case #" << x++ << ":" << endl;
    for (int i = 1; i <= r; i++)
      fout << (s[i] + 1) << endl;
  }
  return ret_val;
}
