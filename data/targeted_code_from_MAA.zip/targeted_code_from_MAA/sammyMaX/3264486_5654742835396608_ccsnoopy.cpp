#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {}

int main(void) {
  int ret_val = 0;
  solve();
  int tc;
  scanf("%d", &tc);
  int t;
  for (t = 1; t <= tc; t++) {
    int n, k;
    scanf("%d", &n);
    scanf("%d", &k);
    priority_queue<int> pq;
    pq.push(n);

    printf("Case #%d: ", t);

    for (; k--;) {
      int top = pq.top();
      pq.pop();
      int mid = top - 1;
      int get, r;
      get = mid / 2;
      r = (mid + 1) / 2;
      if (k == 0) {
        printf("%d %d\n", r, get);
      }
      if (get) {
        pq.push(get);
      }

      if (r) {
        pq.push(r);
      }
    }

    cerr << "Test " << t << " done \n";
  }
  return ret_val;
}
