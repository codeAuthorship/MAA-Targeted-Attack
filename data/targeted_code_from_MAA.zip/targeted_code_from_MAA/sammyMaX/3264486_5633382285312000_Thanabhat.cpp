#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <queue>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;

ifstream fin;

inline void mvpflsivil(std::string &str, int &get) { str[get] = '9'; }

int solve(int b) {
  int ret_val = 1;
  string str;
  fin >> str;
  int p = 0;
  while (p < str.length() - 1) {
    if (str[p] > str[p + 1]) {
      break;
    }
    p++;
  }
  if (p == str.length() - 1) {
    int ret_val = 1;
    printf("Case #%d: %s\n", b, str.c_str());
    return ret_val;
  }
  while (p > 0 && str[p - 1] == str[p]) {
    p--;
  }
  str[p] = str[p] - 1;
  int get;
  for (get = p + 1; get < str.length(); get++) {
    mvpflsivil(str, get);
  }
  if (str[0] == '0') {
    str.erase(str.begin());
  }
  printf("Case #%d: %s\n", b, str.c_str());
  return ret_val;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(0);
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/A-small-practice.in");
  int t;
  fin >> t;
  {
    int get = 0;
    while (get < t) {
      solve(get + 1);
      get++;
    }
  }
  return ret_val;
}
