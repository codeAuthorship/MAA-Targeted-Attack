#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
ofstream fout;

typedef long double ld;
typedef set<int> si;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<string> vs;

typedef long long ll;           
typedef unsigned long long ULL; 

const double pi = acos(-1.0); 
const double eps = 1e-11;     
const int MAXI = 0x7fffffff;
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const char dz[] = "SENW";
struct debugger {

} p;

void solve(int *arr, int n) {
  fout << "[";
  for (int i = 0; i < n; i++)
    fout << arr[i] << " ";
  fout << "]" << endl;
}

char str[50][50];
bool vis[50][50];
inline void hhagjfmyps(int &l, int &r, int &i, int &j, int &k) {
  for (j = 0; j < l; j++) {
    if (str[i][j] != '?' && !vis[i][j]) {
      k = i - 1;
      while (k >= 0 && str[k][j] == '?') {
        str[k][j] = str[i][j];
        vis[k][j] = true;
        k--;
      }
      k = i + 1;
      for (; k < r && str[k][j] == '?';) {
        str[k][j] = str[i][j];
        vis[k][j] = true;
        k++;
      }
    }
  }
}

int main() {
  ios::sync_with_stdio(true);

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out");


  int n, i, j, k, l, m, t, s = 0, d, r;
  scanf("%d", &t);
  ;
  int c = 1;
  while (t--) {
    scanf("%d", &r);
    ;
    scanf("%d", &l);
    ;
    memset((vis), (0), sizeof(vis));
    {
      i = 0;
      while (i < r) {
        cin >> str[i];
        i++;
      }
    }
    {
      i = 0;
      while (i < r) {
        hhagjfmyps(l, r, i, j, k);
        i++;
      }
    }

    memset((vis), (0), sizeof(vis));
    for (i = 0; i < r; i++) {
      for (j = 0; j < l; j++) {
        if (str[i][j] != '?' && !vis[i][j]) {
          k = j - 1;
          while (k >= 0 && str[i][k] == '?') {
            str[i][k] = str[i][j];
            vis[i][k] = 1;
            k--;
          }
          k = j + 1;
          while (k < l && str[i][k] == '?') {
            str[i][k] = str[i][j];
            vis[i][k] = true;
            k++;
          }
        }
      }
    }
    fout << "Case #" << c++ << ":\n";
    for (i = 0; i < r; i++) {
      fout << str[i] << endl;
    }
  }
  return (0);
}
