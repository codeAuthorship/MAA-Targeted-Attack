#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream fin;

typedef long double ld;
typedef pair<int, int> pii;
typedef pair<pii, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int d, n, start[maxN], speed[maxN], t;

inline void pbrjzkrdik(int &solve, long double &maxim) {
  fin >> start[solve] >> speed[solve];
  long double time =
      (long double)(d - start[solve]) / (long double)speed[solve];
  maxim = max(maxim, time);
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/A-small-practice.in");

  int ret_val = 0;

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    fin >> d >> n;
    long double maxim = 0;
    for (int solve = (0); solve <= ((n)-1); ++solve)
      pbrjzkrdik(solve, maxim);

    cout << "Case #" << x << ": ";
    cout << fixed << setprecision(12) << d / maxim << endl;
  }
  return ret_val;
}
