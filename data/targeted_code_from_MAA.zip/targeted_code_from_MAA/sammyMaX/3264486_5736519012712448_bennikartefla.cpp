#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

inline void yqhagsgfvz() {}

int doit(string s, int len) {
  int howmany = 0;
  for (; true;) {
    if (s.size() == len) {
      int f1 = 0;
      int f2 = 0;
      for (int i = (0); i < (len); i++) {
        if (s[i] == '+')
          f1++;
        else
          f2++;
      }
      if (f1 == len)
        yqhagsgfvz();
      else if (f2 == len) {
        howmany++;
      } else {
        howmany += 1000000;
      }

      break;
    } else {
      if (s[0] == '+') {
        s.erase(s.begin());
      } else {
        for (int i = (0); i < (len); i++) {
          if (s[i] == '+')
            s[i] = '-';
          else
            s[i] = '+';
        }
        howmany++;
      }
    }
  }
  return howmany;
}

int main() {
  int solve = 0;
  cin.sync_with_stdio(false);
  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int n;
  cin >> n;
  for (int i = (0); i < (n); i++) {
    string s;
    cin >> s;
    int t;
    cin >> t;
    int ans = INF;
    ans = min(doit(s, t), ans);
    reverse(s.begin(), s.end());
    ans = min(doit(s, t), ans);
    fout << "Case #" << i + 1 << ": ";
    if (ans > 10000)
      fout << "IMPOSSIBLE" << endl;
    else
      fout << ans << endl;
  }
  return solve;
}
