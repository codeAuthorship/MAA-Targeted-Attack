#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
const double eps = 1e-9;
ofstream fout;

ifstream fin;

typedef vector<int> vi;

typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ULL; 
typedef unsigned uint;



struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void debugarr(int *arr, int n) {
  fout << "[";
  for (int i = 0; i < n; i++)
    fout << arr[i] << " ";
  fout << "]" << endl;
}

char str[50];

bool containszero(int l) {
  int i = 0;
  for (; str[i] == '0';) {
    i++;
  }
  for (; i < l;) {
    if (str[i] == '0')
      return true;
    i++;
  }
  return false;
}
int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/A-small-practice.in");

  ios::sync_with_stdio(true);


  int n, i, x, l, m, t, s = 0, d;
  fin >> t;
  ;
  int c = 1;
  for (; t--;) {
    fin >> str;
    fin >> x;
    int ans = 0;
    l = strlen(str);
    for (i = 0; i + x - 1 < l; i++) {
      if (str[i] == '+')
        continue;
      s = 0;
      for (int j = i; s < x; s++, j++) {
        if (str[j] == '-')
          str[j] = '+';
        else
          str[j] = '-';
      }
      ans++;
    }
    for (i = 0; i < l; i++) {
      if (str[i] == '-')
        break;
    }
    if (i < l) {
      fout << "Case #" << c++ << ": IMPOSSIBLE\n";
    } else {
      fout << "Case #" << c++ << ": " << ans << "\n";
    }
  }
  return (0);
}
