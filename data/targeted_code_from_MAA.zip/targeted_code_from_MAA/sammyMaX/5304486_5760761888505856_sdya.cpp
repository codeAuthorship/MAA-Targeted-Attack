#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const int MOD = 1000000007;
ifstream fin;

void get() {}

const int maxN = 50;
string s[maxN];
int n, m;

void solve(int test) {
  fin >> n >> m;
  for (int i = 0; i < n; ++i) {
    fin >> s[i];
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 1; j < m; ++j) {
      if (s[i][j] == '?')
        s[i][j] = s[i][j - 1];
    }
    for (int j = m - 2; j >= 0; --j) {
      if (s[i][j] == '?') {
        s[i][j] = s[i][j + 1];
      }
    }
  }

  for (int j = 0; j < m; ++j) {
    for (int i = 1; i < n; ++i) {
      if (s[i][j] == '?') {
        s[i][j] = s[i - 1][j];
      }
    }
    for (int i = n - 2; i >= 0; --i) {
      if (s[i][j] == '?') {
        s[i][j] = s[i + 1][j];
      }
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      if (s[i][j] == '?') {
        cerr << "BAD" << endl;
      }
    }
  }

  cout << "Case #" << test << ":\n";
  for (int i = 0; i < n; ++i) {
    cout << s[i] << "\n";
  }
}

int main(int y, char *argv[]) {

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in");

  int ret_val = 0;

  int c, b;
  int t;
  fin >> t;
  c = 1, b = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= c && i <= b) {
      solve(i);
    } else
      get();

    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
