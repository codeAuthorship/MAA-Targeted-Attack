#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <vector>
using namespace std;

char solve[2000];
int main(void) {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  int t;
  cin >> t;
  {
    int tt = 1;
    for (; tt <= t;) {
      int get = 0, k;
      cin >> solve >> k;
      for (int i = strlen(solve) - 1; i + 1 >= k; --i) {
        if (solve[i] == '-') {
          ++get;
          for (int j = 0; j < k; ++j) {
            solve[i - j] = (solve[i - j] == '-' ? '+' : '-');
          }
        }
 
      }
      for (int j = 0; j < k; ++j) {
        if (solve[j] == '-') {
          get = -1;
        }
      }

      if (get < 0) {
        printf("Case #%d: IMPOSSIBLE\n", tt);
        tt++;
        continue;
      }
      printf("Case #%d: %d\n", tt, get);
      tt++;
    }
  }
  return ret_val;
}
