#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;
const int INF = 1000000000;
ofstream fout;

ifstream fin;

const double EPS = 1e-9;
typedef double td_d;
typedef long double ld;
typedef long long LL;
typedef pair<int, int> PII;
typedef pair<LL, LL> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 102;
int t, n, q, dist[N], speed[N], u, v;
vector<vector<PII>> g(N);
bool vis[N];
double dp[N];

double solve(int i) {
  if (i == v)
    return 0;
  if (!((int)(g[i]).size()))
    return 1000000000000000000ll;
  if (vis[i])
    return dp[i];
  vis[i] = true;

  dp[i] = 1000000000000000000ll;
  td_d totalDist = g[i].back().second;
  int j = g[i].back().first;
  while (totalDist <= dist[i]) {
    dp[i] = min(dp[i], totalDist / speed[i] + solve(j));
    if (j == v) {
      break;
    }
    if (!((int)(g[j]).size()))
      return dp[i];
    totalDist += g[j].back().second;
    j = g[j].back().first;
  }
  return dp[i];
}

inline void dpoeljwkfp(int &i, int &j) {
  int a;
  fin >> a;
  if (a != -1)
    g[i].push_back(make_pair(j, a));
}

inline void xtrvjrueur() {
  int i = (1);
  while (i <= (int)(n)) {
    for (int j = (1); j <= (int)(n); ++j)
      dpoeljwkfp(i, j);
    ++i;
  }
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fin >> t;
  for (int test = (1); test <= (int)(t); ++test) {
    fin >> n >> q;
    for (int i = (1); i <= (int)(n); ++i)
      fin >> dist[i] >> speed[i];
    xtrvjrueur();
    for (; q--;) {
      fin >> u >> v;
      memset(vis, 0, sizeof vis);
      fout << "Case #" << test << ": " << fixed << setprecision(6) << solve(u)
           << "\n";
    }

    g.clear(), g.resize(N);
  }
}


