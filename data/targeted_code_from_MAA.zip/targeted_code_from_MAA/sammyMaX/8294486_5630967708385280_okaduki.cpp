#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
using namespace std;
const int mod = 1000000007;
typedef double td_d;

ifstream fin;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &b, pair<S, T> &p) {
  return b >> p.first >> p.second;
}
template <class S, class T> ostream &solve(ostream &d, const pair<S, T> &p) {
  return d << p.first << " " << p.second;
}
template <class T> void maxi(T &x, T y) {
  if (x < y)
    x = y;
}

inline void zmxemhbwng(int &t) {
  LL D, N;
  fin >> D >> N;
  td_d mn = 0;
  vector<PLL> j(N);
  for (int i = (0); i < (N); ++i)
    fin >> j[i];
  int i;
  for (i = (0); i < (N); ++i)
    mn = max(mn, (D - j[i].first) * 1. / j[i].second);
  td_d ans = D / mn;
  printf("Case #%d: %.9f\n", t, ans);
}

int main() {
  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/A-small-practice.in");
  cin.tie(0);
  int n;
  fin >> n;
  int t;
  for (t = (1); t < (n + 1); ++t)
    zmxemhbwng(t);
  return ret_val;
}
