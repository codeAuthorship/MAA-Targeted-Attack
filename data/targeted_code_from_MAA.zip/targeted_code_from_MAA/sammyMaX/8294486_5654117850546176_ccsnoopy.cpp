#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
void solve() {}

void pr(int N) {
  switch (N) {
  case 0:
    cout << "R";
    break;
  case 1:
    cout << "O";
    break;
  case 2:
    cout << "Y";
    break;
  case 3:
    cout << "G";
    break;
  case 4:
    cout << "B";
    break;
  case 5:
    cout << "V";
    break;
  }
}

int main(void) {
  ios::sync_with_stdio(false);

  int get = 0;
  solve();
  int tc;
  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int n;
    cin >> n;
    int arr[10];
    cout << "Case #" << t << ": ";
    for (int i = 0; i < 6; i++) {
      cin >> arr[i];
    }
    bool imp = false;
    for (int i = 0; i < 6; i++) {
      if (arr[i] * 2 > n) {
        imp = 1;
        cout << "IMPOSSIBLE\n";
        break;
      }
    }

    if (imp)
      continue;

    int maxidx = 0;
    for (int i = 0; i < 6; i++) {
      if (arr[maxidx] < arr[i])
        maxidx = i;
    }
    bool palinggede = true;
    int last = maxidx;
    pr(maxidx);
    arr[maxidx]--;
    int first = last;

    while (true) {
      bool ada = false;
      for (int i = 0; i < 6; i++) {
        if (arr[i] > 0)
          ada = true;
      }

      if (!ada)
        break;

      if (last == 0) {
        if (arr[2] > arr[4])
          last = 2;
        else if (arr[2] < arr[4]) {
          last = 4;
        } else {
          if (first == 2) {
            last = 2;
          } else
            last = 4;
        }
      } else if (last == 2) {
        if (arr[0] > arr[4]) {
          last = 0;
        } else if (arr[0] < arr[4]) {
          last = 4;
        } else {
          if (first == 0) {
            last = 0;
          } else
            last = 4;
        }
      } else {
        if (arr[0] > arr[2]) {
          last = 0;
        } else if (arr[0] < arr[2]) {
          last = 2;
        } else {
          if (first == 0) {
            last = 0;
          } else
            last = 2;
        }
      }
      pr(last);
      arr[last]--;
    }
    cout << "\n";

    cerr << "Test " << t << " done \n";
    if (first == last) {
      cerr << "last equals first\n";
    }
  }
  return get;
}
