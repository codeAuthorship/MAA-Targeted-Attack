#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <stack>
#include <unordered_map>
#include <vector>
using namespace std;
ofstream fout;

ifstream fin;

using LL = long long;

double e[123], v[123], s[123], a[123][123], dp[123];

inline void vuxuenfynp(int &solve, int &j) { fin >> a[solve][j]; }

inline void zsuzvvvlqc(int &cas) {
  int n, q;
  fin >> n >> q;
  for (int solve = 1; solve <= n; solve++)
    fin >> e[solve] >> v[solve];
  for (int solve = 1; solve <= n; solve++)
    for (int j = 1; j <= n; j++)
      vuxuenfynp(solve, j);
  for (int solve = 2; solve <= n; solve++)
    s[solve] = s[solve - 1] + a[solve - 1][solve];
  dp[1] = 0;
  for (int solve = 2; solve <= n; solve++)
    dp[solve] = 1e17;
  for (int solve = 0; solve < n; solve++) {
    for (int j = solve + 1; j <= n; j++)
      if (s[j] - s[solve] <= e[solve])
        dp[j] = min(dp[j], dp[solve] + (s[j] - s[solve]) / v[solve]);
  }
  int qu, qv;
  fin >> qu >> qv;
  fout << "Case #" << ++cas << ": " << fixed << setprecision(10) << dp[n]
       << "\n";
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/outer_temp/jiian/A-small-practice_transformation.out");

  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int get, cas = 0;
  fin >> get;
  for (; get--;) {
    zsuzvvvlqc(cas);
  }
  return ret_val;
}
