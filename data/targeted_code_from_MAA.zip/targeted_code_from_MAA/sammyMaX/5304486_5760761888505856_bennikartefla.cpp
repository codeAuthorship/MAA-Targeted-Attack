#include <bits/stdc++.h>
#include <fstream>
#include <set>
using namespace std;
ifstream fin;

typedef long double ld;
typedef set<int> si;
typedef pair<int, int> pii;
typedef vector<int> VI;
typedef vector<pii> vii;

const int INF = ~(1 << 31);
const double pi = acos(-1);

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/A-small-practice.in");

  int ret_val = 0;

  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int u = (0); u < (t); u++) {
    int n, m;
    fin >> n >> m;
    char at[500][500];
    bool vis[500][500];
    memset(vis, 0, sizeof(vis));
    for (int i = (0); i < (n); i++)
      for (int solve = (0); solve < (m); solve++)
        fin >> at[i][solve];
    for (int i = (0); i < (n); i++)
      for (int solve = (0); solve < (m); solve++) {
        if (at[i][solve] != '?' && !vis[i][solve]) {
          vis[i][solve] = true;
          int startx = solve;
          int endx = solve;
          char am = at[i][solve];
          for (int a2 = (solve + 1); a2 < (m); a2++) {
            if (at[i][a2] == '?') {
              at[i][a2] = am;
              vis[i][a2] = true;
              endx++;
            } else
              break;
          }
          {
            int a2 = solve - 1;
            while (a2 >= 0) {
              if (at[i][a2] == '?') {
                at[i][a2] = am;
                vis[i][a2] = true;
                startx--;
              } else
                break;
              a2--;
            }
          }
          // found startx and endx
          for (int i2 = (i + 1); i2 < (n); i2++) {
            bool can = true;
            for (int a2 = (startx); a2 < (endx + 1); a2++)
              if (at[i2][a2] != '?')
                can = false;
            if (can) {
              for (int a2 = (startx); a2 < (endx + 1); a2++) {
                at[i2][a2] = am;
                vis[i2][a2] = true;
              }
            } else
              break;
          }
          for (int i2 = i - 1; i2 >= 0; i2--) {
            bool can = true;
            for (int a2 = (startx); a2 < (endx + 1); a2++)
              if (at[i2][a2] != '?')
                can = false;
            if (can) {
              for (int a2 = (startx); a2 < (endx + 1); a2++) {
                at[i2][a2] = am;
                vis[i2][a2] = true;
              }
            } else
              break;
          }
        }
      }
    fout << "Case #" << u + 1 << ":" << endl;
    for (int i = (0); i < (n); i++) {
      for (int solve = (0); solve < (m); solve++)
        fout << at[i][solve];
      fout << endl;
    }
  }
  return ret_val;
}
