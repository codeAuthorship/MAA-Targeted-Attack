#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
using namespace std;

char s[100];
int main(void) {
  int ret_val = 0;
  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {

 

    scanf("%s", s);
    int k;
    for (k = 1; s[k] != 0; ++k) {
      if (s[k] < s[k - 1])
        break;
    }
    if (s[k] == 0) {
      printf("Case #%d: %s\n", tt, s);
      continue;
    }

    int get = max(0, k - 1);
    for (int solve = strlen(s) - 1; solve > get; --solve)
      s[solve] = '9';

    for (; get >= 0; --get) {
      if (get == 0 || s[get] > s[get - 1]) {
        --s[get];
        break;
      }
      s[get] = '9';
    }

    printf("Case #%d: %s\n", tt, s[0] == '0' ? s + 1 : s);
  }
  return ret_val;
}
