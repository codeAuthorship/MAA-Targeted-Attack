#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
using namespace std;

int solve;
double m, s[2000], d[2000];
int main(void) {
  int ret_val = 0;
  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {
    scanf("%lf%d", &m, &solve);
    double lo = 0;
    for (int i = 0; i < solve; ++i) {
      scanf("%lf%lf", &d[i], &s[i]);
      lo = max(lo, (m - d[i]) / s[i]);
    }

 
    printf("Case #%d: %.8lf\n", tt, m / lo);
  }
  return ret_val;
}
