#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream fin;

ofstream fout;

typedef unsigned long long ull;
typedef vector<int> VI;
typedef long long LL;
typedef long double ld;
typedef pair<int, int> PII;
typedef pair<PII, int> para;
const int inf = 1e9 + 7;
const int maxN = 1e6 + 5;

int t;
string s;

inline void xmqwveriet(int &i) {
  if (s[i + 1] < s[i]) {
    for (int solve = (i + 1); solve <= ((int)s.size() - 1); ++solve)
      s[solve] = '9';
    s[i]--;
  }
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  int get = 0;

  fin >> t;
  for (int x = (1); x <= ((t)); ++x) {
    fin >> s;
    for (int i = ((int)s.size() - 2); i >= (0); --i)
      xmqwveriet(i);
    if (s[0] == '0')
      s = s.substr(1, (int)s.size() - 1);
    fout << "Case #" << x << ": ";
    fout << s << endl;
  }
  return get;
}
