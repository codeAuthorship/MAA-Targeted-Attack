#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
ifstream fin;

void readData() {}

int n, r, o, y, g, b, v;

string solve(int r, int y, int b) {
  int a[3] = {r, y, b};
  string t = "RYB";

  for (int i = 0; i < 3; ++i) {
    for (int j = i + 1; j < 3; ++j) {
      if (a[j] > a[i]) {
        swap(a[j], a[i]);
        swap(t[j], t[i]);
      }
    }
  }

  string ans(n, ' ');
  for (int i = 0; i < n; i += 2) {
    for (int j = 0; j < 3; ++j) {
      if (a[j] > 0) {
        ans[i] = t[j];
        --a[j];
        break;
      }
    }
  }
  for (int i = 1; i < n; i += 2) {
    for (int j = 0; j < 3; ++j) {
      if (a[j] > 0) {
        ans[i] = t[j];
        --a[j];
        break;
      }
    }
  }

  int ok = true;
  int i;
  for (i = 1; i < n; ++i) {
    if ((n > 1 && ans[0] == ans[n - 1])) {
      ok = 0;
    } else if (ans[i] == ans[i - 1]) {
      ok = 0;
    }
  }

  if (!ok)
    cerr << "BAD" << endl;

  return ans;
}

void solve(int test) {
  fin >> n >> r >> o >> y >> g >> b >> v;
  if (2 * r > n || 2 * y > n || 2 * b > n) {
    cout << "Case #" << test << ": IMPOSSIBLE\n";
    return;
  }
  if (r + y + b != n) {
    cout << "Case #" << test << ": IMPOSSIBLE\n";
    return;
  }

  cout << "Case #" << test << ": " << solve(r, y, b) << "\n";
}

int main(int argc, char *argv[]) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in");

  int ret_val = 0;

  int p, right_bound;
  int t;
  fin >> t;
  p = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= p && i <= right_bound) {
      solve(i);
    } else {
      readData();
    }
    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
