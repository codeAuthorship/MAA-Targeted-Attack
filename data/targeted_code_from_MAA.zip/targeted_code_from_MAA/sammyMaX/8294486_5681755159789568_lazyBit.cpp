#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;          
typedef unsigned long long ULL; 



struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void get(int *tc, int n) {
  cout << "[";
  for (int i = 0; i < n; i++)
    cout << tc[i] << " ";
  cout << "]" << endl;
}

double besttime[1010];
LL c[110], d[110], dist[110][110], a[110], b[110], dd[110];
long double best[110][110];
inline void tvetyxhxvx(int &i, int &j) {
  best[i][j] = besttime[j] + ((dd[i] - dd[j]) * 1.0) / d[j];
}

inline void uozliuexag(int &i, int &j) { best[i][j] = 1e18; }

inline void purjvenbrb(int &i, int &j) {
  scanf("%lld", &dist[i][j]);
  ;
}

int main() {

  ;
  

  long long n, k, l, m, t, s = 0, p, q;
  int i, j;
  scanf("%lld ", &t);
  int ct = 1;
  for (; t--;) {
    scanf("%lld", &n);
    ;
    scanf("%lld", &q);
    ;
    for (i = 0; i < n; i++) {
      scanf("%lld", &c[i]);
      ;
      scanf("%lld", &d[i]);
      ;
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++)
        purjvenbrb(i, j);
    }
    for (i = 0; i < q; i++) {
      scanf("%lld", &a[i]);
      ;
      scanf("%lld", &b[i]);
      ;
    }
    dd[0] = 0;
    for (i = 1; i < n; i++) {
      dd[i] = dd[i - 1] + dist[i - 1][i];
    }
    besttime[0] = 0.0;
    long double r;
    for (i = 1; i < n; i++) {
      r = 1e18;
      for (j = 0; j < i; j++) {
        if (dd[i] - dd[j] <= c[j])
          tvetyxhxvx(i, j);
        else
          uozliuexag(i, j);
        r = min(r, best[i][j]);
      }
      besttime[i] = r;
    }

    printf("Case #%d: %0.6lf\n", ct++, besttime[n - 1]);
  }
  return (0);
}
