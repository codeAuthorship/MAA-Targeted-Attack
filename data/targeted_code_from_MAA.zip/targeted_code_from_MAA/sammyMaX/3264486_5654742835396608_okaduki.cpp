#include <bits/stdc++.h>
#include <fstream>
#include <set>
#include <utility>
#include <vector>
using namespace std;
const int MAXN = 1005;
typedef vector<int> vi;
typedef long double LD;
typedef long long ll;
typedef pair<int, int> pii;

ofstream fout;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &q, pair<S, T> &p) {
  return q >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void get(T &x, T y) {
  if (x < y)
    x = y;
}

int main() {
  int ret_val = 0;
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/outer_temp/okaduki/A-small-practice_transformation.out");
  cin.tie(0);
  ios_base::sync_with_stdio(false);
  int T;
  cin >> T;
  for (int t_ = (1); t_ < (T + 1); ++t_) {
    LL N, K;
    cin >> N >> K;

    vector<bool> n(N + 2);
    n[0] = n[N + 1] = true;
    tuple<LL, LL, LL> ans;
    for (int k = (0); k < (K); ++k) {
      tuple<LL, LL, LL> mx(-1, -1, -1);

      for (int i = (0); i < (N + 2); ++i) {
        if (n[i])
          continue;
        LL l, r;
        for (l = i - 1; !n[l]; --l) {
          ;
        }
        for (r = i + 1; !n[r]; ++r)
          ;
        l = i - l - 1;
        r = r - i - 1;
        tuple<LL, LL, LL> t(min(l, r), max(l, r), -i);
        get(mx, t);
      }
      n[-get<2>(mx)] = true;
      ans = mx;
    }
    fout << "Case #" << t_ << ": " << get<1>(ans) << " " << get<0>(ans) << endl;
  }
  return ret_val;
}
