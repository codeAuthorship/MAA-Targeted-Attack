#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int MAXN = 1005;

char ans[1000 + 1];
int ord[1000 + 1];
int n, m, r, o, y, g, b, v;

inline void jwnaopdbak() { ans[ord[m++]] = 'B'; }

inline void xdsvfqhvab() { ans[ord[m++]] = 'R'; }

int main() {
  int ret_val = 0;

  int solve, t, i;
  cin >> t;
  {
    solve = 0;
    while (solve < t) {
      cin >> n >> r >> o >> y >> g >> b >> v;
      cout << "Case #" << solve + 1 << ": ";
      if ((b * 2 > n)) {
        cout << "IMPOSSIBLE\n";
        solve++;
        continue;
      } else if ((r * 2 > n) || (y * 2 > n)) {
        cout << "IMPOSSIBLE\n";
        solve++;
        continue;
      }
      m = 0;
      for (i = 0; i < n; i = i + 2) {
        ord[m++] = i;
      }
      {
        i = 1;
        while (i < n) {
          ord[m++] = i;
          i = i + 2;
        }
      }
      m = 0;
      if ((r >= y) && (y >= b)) {
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
      } else if ((r >= b) && (b >= y)) {
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
      } else if ((y >= b) && (b >= r)) {
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
      } else if ((y >= r) && (r >= b)) {
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
      } else if ((b >= r) && (r >= y)) {
        while (--b >= 0)
          jwnaopdbak();
        while (--r >= 0)
          xdsvfqhvab();
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
      } else {
        while (--b >= 0) {
          ans[ord[m++]] = 'B';
        }
        while (--y >= 0) {
          ans[ord[m++]] = 'Y';
        }
        while (--r >= 0) {
          ans[ord[m++]] = 'R';
        }
      }
      ans[m] = '\0';
      cout << ans << "\n";
      solve++;
    }
  }
  return ret_val;
}
