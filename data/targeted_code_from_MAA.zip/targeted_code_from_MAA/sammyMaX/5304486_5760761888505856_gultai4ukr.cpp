#include <bits/stdc++.h>
using namespace std;
const int MOD = 1000000007;
const double EPS = 1e-9;

inline void rtacnokfxl(int &get, int &j, int &index, int &p) {
  get = abs(j - p);
  index = p;
}

inline void klbdonhsde(int &r, int &c, vector<std::string> &v) {
  int solve = 0;
  for (; solve < r;) {
    {
      int j = 0;
      while (j < c) {
        if (v[solve][j] == '?') {
          int get = c, index = j;
          for (int p = 0; p < c; ++p) {
            if (v[solve][p] != '?') {
              if (abs(j - p) < get)
                rtacnokfxl(get, j, index, p);
            }
          }
          {
            int p = min(j, index);
            while (p < max(j, index) + 1) {
              v[solve][p] = v[solve][index];
              ++p;
            }
          }
        }
        ++j;
      }
    }
    ++solve;
  }
}

int main(int argc, char **argv) {
  int ret_val = 0;
  ifstream fin("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int x = 0; x < t; ++x) {
    int r, c;
    fin >> r >> c;
    vector<string> v(r);
    for (int solve = 0; solve < r; ++solve) {
      fin >> v[solve];
      //			cout << v[i] << endl;
    }

    klbdonhsde(r, c, v);

    for (int solve = 0; solve < r; ++solve) {
      if (v[solve][0] == '?') {
        int get = r, index = -1;
        for (int p = 0; p < r; ++p) {
          if (v[p][0] != '?') {
            if (abs(solve - p) < get) {
              get = abs(solve - p);
              index = p;
            }
          }
        }
        assert(index >= 0);
        for (int j = 0; j < c; ++j) {
          v[solve][j] = v[index][j];
        }
      }
    }

    fout << "Case #" << x + 1 << ":" << endl;
    {
      int solve = 0;
      while (solve < r) {
        for (int j = 0; j < c; ++j)
          fout << v[solve][j];

        fout << endl;
        ++solve;
      }
    }
  }
  fin.close();
  fout.close();
  return ret_val;
}
