#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
using namespace std;
ifstream fin;

int N, P;
int s[200];
int r[200][200];
int b[200];
int tb[200];

int ll[200][200];
int mm[200][200];

bool dfs(int cur, int less, int solve) { return false; }

inline void sxoiybvkrl(int &i, int &j) { fin >> r[i][j]; }

int main(void) {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_12_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/iPeter/A-small-practice.in");

  int ret_val = 0;
  int t;
  fin >> t;
  for (int tt = 1; tt <= t; tt++) {
    fin >> N >> P;
    for (int i = 0; i < N; ++i)
      fin >> s[i];
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < P; ++j)
        sxoiybvkrl(i, j);
      sort(r[i], r[i] + P);
      for (int j = 0; j < P; ++j) {
        ll[i][j] = ceil(1.0 * r[i][j] / (1.1 * s[i]));
        mm[i][j] = floor(1.0 * r[i][j] / (0.9 * s[i]));
      }
    }

 

    int ans = 0;
    memset(b, 0, sizeof(b));

 

    while (1) {
      bool stop = false;
      int i;
      for (i = 0; i < N; ++i) {
        if (b[i] >= P)
          stop = true;
      }
      if (stop)
        break;

      int cur = 0;
      for (int i = 0; i < N; ++i) {
        cur = max(cur, ll[i][b[i]]);
      }

      bool ok = true;
      for (int i = 0; i < N; ++i) {
        for (int j = b[i]; j <= P; ++j) {
          if (j == P || cur < ll[i][j]) {
            b[i] = j;
            ok = false;
            break;
          }
          if (ll[i][j] > mm[i][j]) {
            continue;
          }
          if (cur <= mm[i][j]) {
            tb[i] = j;
            break;
          }
        }
      }

 
      if (!ok)
        continue;

      ++ans;
      for (int i = 0; i < N; ++i) {
        b[i] = tb[i] + 1;
      }
    }

    printf("Case #%d: %d\n", tt, ans);
  }
  return ret_val;
}
