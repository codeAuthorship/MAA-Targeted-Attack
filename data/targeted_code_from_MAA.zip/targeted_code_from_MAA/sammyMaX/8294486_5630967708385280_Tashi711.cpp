
#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
const int mod = 1000000007;

const int N = 1100;
int x[N], s[N];

inline void fdlfrcnrhh(double &mt, int &d, int &i) {
  cin >> x[i] >> s[i];
  mt = max(mt, double(d - x[i]) / s[i]);
}

void solve() {
  int d, n;
  cin >> d >> n;
  double mt = 0;
  for (int i = 1; i <= n; ++i)
    fdlfrcnrhh(mt, d, i);
  cout << fixed << setprecision(9) << d / mt << endl;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(true);

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    cout << "Case #" << i << ": ";
    solve();
  }
  return ret_val;
}
