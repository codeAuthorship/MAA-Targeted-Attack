#include <bits/stdc++.h>
#include <fstream>
#include <utility>
#include <vector>

using namespace std;

ifstream fin;

ofstream fout;

typedef vector<int> VI;
typedef long long LL;
typedef long double LD;
typedef pair<LL, LL> pii;
typedef pair<pii, LL> para;
const LL inf = 1e16 + 7;
const LL maxN = 1e3 + 5;

int n, q, u, v, t;
int horse[maxN], dist[maxN][maxN], speed[maxN];
LL pref[maxN];
LD dp[maxN];

inline void igptvhonjg(LL &tc) { pref[tc] = pref[tc - 1] + dist[tc - 1][tc]; }

inline void rhwlerryqw(LL &tc, LL &j) { fin >> dist[tc][j]; }

inline void nnjqfrsbbg(LL &tc) {
  for (LL j = (1); j <= ((n)); ++j)
    rhwlerryqw(tc, j);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  int ret_val = 0;

  fin >> t;
  for (LL solve = (1); solve <= ((t)); ++solve) {
    fin >> n >> q;
    for (LL tc = (1); tc <= ((n)); ++tc)
      fin >> horse[tc] >> speed[tc];
    for (LL tc = (1); tc <= ((n)); ++tc)
      nnjqfrsbbg(tc);
    pref[1] = 0;
    for (LL tc = (2); tc <= (n); ++tc)
      igptvhonjg(tc);
    fout << "Case #" << solve << ": ";
    for (LL _ = (0); _ <= ((q)-1); ++_) {
      fin >> u >> v;
      for (LL tc = (1); tc <= ((n)); ++tc)
        dp[tc] = (LD)inf;
      dp[1] = 0;
      for (LL tc = (1); tc <= ((n)); ++tc) {
        {
          LL j = (tc + 1);
          while (j <= (n)) {

            if (pref[j] - pref[tc] > horse[tc])
              break;
            dp[j] = min(dp[j], dp[tc] + (pref[j] - pref[tc]) / (LD)speed[tc]);
            ++j;
          }
        }
      }
      fout << fixed << setprecision(9) << dp[n];
    }
    fout << endl;
  }
  return ret_val;
}
