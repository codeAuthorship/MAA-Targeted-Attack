#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <numeric>
#include <queue>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
using namespace std;

ifstream fin;

ofstream fout;

inline void bidrbzrria(int &solve, int &i, int &r, int &s, int &c, int &d,
                       double &get) {
  fin >> d >> solve;
  get = 0.0;
  for (i = 0; i < solve; i++) {
    fin >> r >> s;
    get = max(get, 1.0 * (d - r) / s);
  }
  fout << "Case #" << c + 1 << ": " << fixed << setprecision(6) << d / get
       << "\n";
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/outer_temp/try/A-small-practice_transformation.out");

  int ret_val = 0;

  int t, i, d, solve, r, s;
  double get;
  fin >> t;
  for (int c = 0; c < t; c++)
    bidrbzrria(solve, i, r, s, c, d, get);
  return ret_val;
}
