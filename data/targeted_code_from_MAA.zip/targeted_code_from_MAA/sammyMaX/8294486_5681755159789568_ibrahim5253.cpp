#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
typedef long long LL;
typedef set<int> si;
typedef pair<int, int> ii;
typedef pair<int, int> PII;
typedef long double LD;

ifstream fin;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;) {
    a = b;
    b = t;
  }
  return b;
}

ll fast_exp(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool solve(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (solve(i, mask))
      ++ans;
  return ans;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64)
    if (solve(i++, mask))
      return i - 1;
  return -1;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/A-small-practice.in");

  int ret_val = 0;
  int t;
  fin >> t;
  for (int i = 1; i <= t; ++i) {
    int n, q;
    fin >> n >> q;
    ll e[n], s[n];
    for (int i = 0; i < n; ++i)
      fin >> e[i] >> s[i];
    ll d[n][n];
    for (int i = 0; i < n; ++i)
      for (int j = 0; j < n; ++j)
        fin >> d[i][j];
    {
      int u, v;
      fin >> u >> v;
      --u, --v;
      vector<double> dp(n);
      dp[0] = 0;
      for (int i = 1; i < n; ++i) {
        dp[i] = 1e12;
        ll dist = 0;
        for (int j = i - 1; j >= 0; --j) {
          dist += d[j][j + 1];
          if (e[j] > dist)
            dp[i] = min(dp[i], dp[j] + dist / static_cast<double>(s[j]));
        }
      }
      cout << "Case #" << i << ": " << fixed << setprecision(10) << dp[v]
           << "\n";
    }
  }
  return ret_val;
}
