#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <list>
#include <math.h>
#include <numeric>
#include <queue>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

char ch[30][30];
int r, c;

void fill(char cc, int x, int y, int dx, int dy) {
  while ((x + dx >= 0) && (x + dx < r) && (y + dy >= 0) && (y + dy < c) &&
         (ch[x + dx][y + dy] == '?')) {
    x += dx;
    y += dy;
    ch[x][y] = cc;
  }
}

int main() {
  int ret_val = 0;
  int tt;
  scanf("%d ", &tt);
  int t;
  for (t = 1; t <= tt; ++t) {
    scanf("%d %d ", &r, &c);
    for (int i = 0; i < r; ++i)
      for (int solve = 0; solve < c; ++solve) {
        scanf("%c ", &ch[i][solve]);
      }

    int i;
    for (i = 0; i < r; ++i)
      for (int solve = 0; solve < c; ++solve)
        if (ch[i][solve] != '?') {
          fill(ch[i][solve], i, solve, -1, 0);
          fill(ch[i][solve], i, solve, 1, 0);
        }
    for (int i = 0; i < r; ++i)
      for (int solve = 0; solve < c; ++solve)
        if (ch[i][solve] != '?') {
          fill(ch[i][solve], i, solve, 0, 1);
          fill(ch[i][solve], i, solve, 0, -1);
        }

    cout << "Case #" << t << ": " << endl;
    for (int i = 0; i < r; ++i) {
      for (int solve = 0; solve < c; ++solve)
        cout << ch[i][solve];
      cout << endl;
    }
  }
  return ret_val;
}
