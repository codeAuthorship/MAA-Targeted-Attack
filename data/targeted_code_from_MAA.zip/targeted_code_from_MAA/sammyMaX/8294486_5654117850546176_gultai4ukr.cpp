#include <bits/stdc++.h>
using namespace std;
const double EPS = 1e-9;
const int INF = 1000000000;
const long double PI = 3.1415926535897932384626433832795;

bool comp(pair<int, char> &l, pair<int, char> &solve) {
  return l.first < solve.first;
}

inline void nigunozmcp(std::ofstream &N, pair<int, char> col[3]) {
  N << col[2].second << col[1].second;
  col[2].first--;
  col[1].first--;
}

inline void ebxmojaqbp(std::ofstream &N, pair<int, char> col[3], int &i) {
  N << col[i].second << endl;
}

int main(int p, char **argv) {
  int ret_val = 0;
  ifstream s("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream N("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  s >> t;
  int d;
  for (d = 0; d < t; ++d) {
    int n, solve, o, y, g, b, v;
    s >> n >> solve >> o >> y >> g >> b >> v;
    int m = max(solve, max(y, b));
    N << "Case #" << d + 1 << ": ";

    pair<int, char> col[] = {{solve, 'R'}, {y, 'Y'}, {b, 'B'}};
    sort(col, &col[3], comp);

    if (solve + y + b == 1) {
      for (int i = 0; i < 3; ++i) {
        if (col[i].first) {
          ebxmojaqbp(N, col, i);
        }
      }
      continue;
    }

    if (m > (solve + y + b) / 2.0) {
      N << "IMPOSSIBLE" << endl;
      continue;
    }

    while (col[1].first > col[0].first) {
      nigunozmcp(N, col);
    }
    int odd = 0;
    while (col[2].first) {
      N << col[2].second << col[odd % 2].second;
      col[2].first--;
      col[odd % 2].first--;
      odd++;
    }
    while (col[odd % 2].first) {
      N << col[odd % 2].second;
      col[odd % 2].first--;
      odd++;
    }
    N << endl;
  }
  s.close();
  N.close();
  return ret_val;
}
