#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
using namespace std;
const double EPS = 1e-9;
ofstream fout;

const int MAXN = 1005;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &get(istream &n, pair<S, T> &p) {
  return n >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &d, const pair<S, T> &p) {
  return d << p.first << " " << p.second;
}
template <class T> void solve(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void do_voijmh_fct(T &x, T y) {
  if (x > y)
    x = y;
}

bool a(LL x) {
  int prv = 10;
  for (; x > 0;) {
    if (prv < x % 10)
      return false;
    prv = x % 10;
    x /= 10;
  }
  return true;
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/outer_temp/okaduki/A-small-practice_transformation.out");

  int ret_val = 0;
  cin.tie(0);

  int j;
  scanf("%d ", &j);
  int t;
  for (t = (1); t < (j + 1); ++t) {
    LL N;
    scanf("%lld ", &N);
    LL ans = 0;
    for (ans = N; ans > 0; --ans)
      if (a(ans))
        break;

    fout << "Case #" << t << ": " << ans << endl;
  }
  return ret_val;
}
