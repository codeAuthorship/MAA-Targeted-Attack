#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;
ifstream fin;

const int INF = 1000000000;

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  int solve, cas = 0;
  fin >> solve;
  for (; solve--;) {
    string s;
    fin >> s;
    reverse(s.begin(), s.end());
    int n = s.size();
    for (int get = 1; get < n; get++) {
      if (s[get] <= s[get - 1])
        continue;
      for (int j = 0; j < get; j++)
        s[j] = '9';
      int j = get;
      while (s[j] == '0')
        s[j] = '9', j++;
      s[j]--;
    }
    while (s.back() == '0')
      s.pop_back();
    reverse(s.begin(), s.end());
    cout << "Case #" << ++cas << ": " << s << "\n";
  }
  return ret_val;
}
