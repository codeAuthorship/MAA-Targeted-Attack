#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
ifstream fin;

typedef long double ld;
typedef long double LD;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> PII;
typedef vector<PII> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ull; 
typedef unsigned uint;


struct debugger {};

void solve(int *b, int n) {
  cout << "[";
  int i;
  for (i = 0; i < n; i++) {
    cout << b[i] << " ";
  }
  cout << "]\n";
}

inline void fijpkktjub(int &d, int &k, int &s, double &ans, int &i) {
  fin >> k;
  ;
  fin >> s;
  ;
  double r = ((d - k) * 1.0) / s;

  ans = max(ans, r);
  i++;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/A-small-practice.in");

  ;


  int n, i, j, k, l, m, t, s = 0, d, p;
  fin >> t;
  ;
  int c = 1;
  while (t--) {
    fin >> d;
    ;
    fin >> n;
    ;
    double ans = 0.0;
    double r;

    {
      i = 0;
      while (i < n)
        fijpkktjub(d, k, s, ans, i);
    }
    printf("Case #%d: %0.6lf\n", c++, d / ans);
  }
  return (0);
}
