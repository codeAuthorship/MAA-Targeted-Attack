#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin;

int tc;

inline void whkzzfmeyp(std::string &s, int &solve) {
  if (s[solve] == '-')
    s[solve] = '+';
  else
    s[solve] = '-';
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_1_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/4yn/A-small-practice.in");

  fin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    string s;
    int k, fl = 0;
    fin >> s >> k;
    for (int i = 0; i < s.size() - k + 1; i++) {
      if (s[i] == '-') {

        fl++;
        for (int solve = i; solve < i + k; solve++)
          whkzzfmeyp(s, solve);
      }
    }
    int f = 1;
    for (int i = s.size() - k + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
