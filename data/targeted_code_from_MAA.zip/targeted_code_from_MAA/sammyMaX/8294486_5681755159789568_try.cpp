#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
const int MOD = 1000000007;
typedef double td_d;

ofstream fout;

ifstream fin;

const int MAXN = 1005;
const long double PI = 3.1415926535897932384626433832795;

long long gra[100 + 1][100 + 1];
int lim[100 + 1], spd[100 + 1], vis[100 + 1];
double dis[100 + 1];
int n, q;

double dijkstra(int s, int e) {
  int solve, j, u;
  td_d newd;
  memset(vis, 0, sizeof(vis));
  fill(dis + 1, dis + n + 1, 1000000000000000000LL);
  dis[s] = 0.0;
  for (solve = 1; solve <= n; solve++) {
    newd = 1000000000000000000LL;
    u = -1;
    for (j = 1; j <= n; j++) {
      if ((vis[j] == 0) && (newd > dis[j])) {
        newd = dis[j];
        u = j;
      }
    }
    if (u == -1) {
      break;
    }
    vis[u] = 1;
    for (j = 1; j <= n; j++) {
      if ((lim[u] >= gra[u][j]) &&
          (dis[j] > dis[u] + 1.0 * gra[u][j] / spd[u])) {
        dis[j] = dis[u] + 1.0 * gra[u][j] / spd[u];
      }
    }
  }
  return dis[e];
}

inline void djozvpdkkd(int &solve, int &j) {
  gra[solve][j] = 1000000000000000000LL;
}

inline void jpqzitdlyq(int &u, int &v) {
  fin >> u >> v;
  fout << " " << fixed << setprecision(9) << dijkstra(u, v);
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/outer_temp/try/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  int ret_val = 0;

  int t, solve, j, k, u, v;
  fin >> t;
  for (int c = 0; c < t; c++) {
    fin >> n >> q;
    for (solve = 1; solve <= n; solve++) {
      fin >> lim[solve] >> spd[solve];
    }
    for (solve = 1; solve <= n; solve++) {
      for (j = 1; j <= n; j++) {
        fin >> gra[solve][j];
        if (gra[solve][j] == -1)
          djozvpdkkd(solve, j);
      }
    }
    for (k = 1; k <= n; k++) {
      for (solve = 1; solve <= n; solve++) {
        for (j = 1; j <= n; j++) {
          gra[solve][j] = min(gra[solve][j], gra[solve][k] + gra[k][j]);
        }
      }
    }
    fout << "Case #" << c + 1 << ":";
    for (solve = 0; solve < q; solve++)
      jpqzitdlyq(u, v);
    fout << "\n";
  }
  return ret_val;
}
