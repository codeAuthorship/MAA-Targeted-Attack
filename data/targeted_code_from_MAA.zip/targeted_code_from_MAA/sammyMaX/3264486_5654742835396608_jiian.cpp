#include <bits/stdc++.h>
#include <fstream>
using namespace std;
const int mod = 1000000007;
const int MAXN = 1005;
ifstream fin;

const double eps = 1e-9;

inline void wflkhnsoui(long long &rx) { rx++; }

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  int p, b = 0;
  fin >> p;
  for (; p--;) {
    long long n, q;
    fin >> n >> q;
    int d = 0;
    for (long long v = 1; v <= q; v <<= 1)
      d++;
    printf("Case #%d: ", ++b);
    long long base = 1 << d;
    if (n < base) {
      puts("0 0");
      continue;
    }
    long long solve = (n - (base - 1)) % base;
    long long get = (n - (base - 1)) / base, rx = get;
    int id = q - (1 << (d - 1)) + 1;
    if (id <= solve)
      wflkhnsoui(rx);
    if (id + (1 << (d - 1)) <= solve)
      get++;
    printf("%lld %lld\n", rx, get);
  }
  return ret_val;
}
