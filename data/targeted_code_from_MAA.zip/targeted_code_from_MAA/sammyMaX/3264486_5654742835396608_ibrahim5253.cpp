#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
typedef long double ld;
typedef pair<int, int> PII;
typedef long double LD;
typedef set<int> si;

ifstream fin;

ofstream fout;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void zbublblpme(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    zbublblpme(a, b, t);
  return b;
}

ll solve(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = solve(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

inline void rayyqmqasx(ll &mask, int &ans, int &i) {
  if (is_set(i, mask))
    ++ans;
  ++i;
}

int count_bits(ll mask) {
  int ans = 0;
  {
    int i;
    for (i = 0; i < 64;)
      rayyqmqasx(mask, ans, i);
  }
  return ans;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return -1;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out");

  int ret_val = 0;

  int t;
  fin >> t;
  for (int j = 1; j <= t; ++j) {
    ll n, tc;
    fin >> n >> tc;
    ll s = 0, i = -1;
    while (s < tc)
      ++i, s += 1ll << i;
    ll C = 1ll << i;
    ll left = n - s + C;
    ll pos = tc - s + C;
    ll base = left / (s - C + 1);
    ll high = left % (s - C + 1);
    if (pos <= high)
      base += 1;
    fout << "Case #" << j << ": " << base / 2 << " " << (base - 1) / 2 << "\n";
  }
  return ret_val;
}
