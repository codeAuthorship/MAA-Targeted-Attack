
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
ofstream fout;

ifstream fin;

typedef long long ll;
typedef pair<int, int> PII;
typedef unsigned long long ull;

const int N = 100;

int n, m;

void handle_line(string &y) {
  char last = '?';
  for (int t = 0; t < m; ++t) {
    if (y[t] == '?') {
      y[t] = last;
    } else {
      last = y[t];
    }
  }
  for (int t = m - 1; t >= 0; --t) {
    if (y[t] == '?') {
      y[t] = last;
    } else {
      last = y[t];
    }
  }
}

string y[N];

void solve() {
  fin >> n >> m;
  string qs;
  for (int t = 1; t <= m; ++t) {
    qs.push_back('?');
  }
  int st = -1;
  for (int t = 1; t <= n; ++t) {
    fin >> y[t];
    if (y[t] != qs) {
      st = t;
    }
  }
  handle_line(y[st]);
  for (int t = st - 1; t >= 1; --t) {
    if (y[t] == qs) {
      y[t] = y[t + 1];
    } else {
      handle_line(y[t]);
    }
  }
  int t;
  for (t = st + 1; t <= n; ++t) {
    if (y[t] == qs) {
      y[t] = y[t - 1];
    } else {
      handle_line(y[t]);
    }
  }
  for (int t = 1; t <= n; ++t) {
    fout << y[t] << "\n";
  }
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in");

  int ret_val = 0;
  ios::sync_with_stdio(true);

  int q;
  fin >> q;
  for (int t = 1; t <= q; ++t) {
    fout << "Case #" << t << ":\n";
    solve();
  }
  return ret_val;
}
