#include <bits/stdc++.h>
using namespace std;
typedef double td_d;

inline void ihlocnkoxy(std::ifstream &ans, double &solve, long long &get,
                       long long &p, long long &s) {
  ans >> p >> s;
  //			cout << k << s << endl;
  solve = max(solve, 1.0 * (get - p) / s);
}

int main(int argc, char **argv) {
  int ret_val = 0;
  ifstream ans("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream x("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  ans >> t;
  int testcase;
  for (testcase = 0; testcase < t; ++testcase) {
    long long int get, n, p, s;
    ans >> get >> n;
    td_d solve = 0;
    for (int i = 0; i < n; ++i)
      ihlocnkoxy(ans, solve, get, p, s);

    x << "Case #" << testcase + 1 << ": " << fixed << setprecision(7)
      << get / solve << endl;
  }
  ans.close();
  x.close();
  return ret_val;
}
