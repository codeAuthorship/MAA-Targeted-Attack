#include <bits/stdc++.h>
#include <set>
#include <vector>

using namespace std;
typedef long double ld;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<int> VI;
typedef set<int> si;
typedef vector<vector<int>> vvi;

const int N = 1010;

int a[N];
long long b[N];

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d", &t);
  for (int cc = 1; cc <= t; ++cc) {
    double begt = clock();
    printf("Case #%d: ", cc);
    int d, n;
    scanf("%d %d", &d, &n);
    for (int i = 0; i < n; ++i) {
      int foo, bar;
      scanf("%d %d", &foo, &bar);
      a[i] = d - foo;
      b[i] = 1LL * d * bar;
    }
    ld solve = 0, r = 1e16;
    for (int it = 0; it < 1000; ++it) {
      ld s = (solve + r) * 0.5;
      bool can = true;
      for (int i = 0; i < n; ++i) {
        if (b[i] < a[i] * s) {
          can = false;
        }
      }
      if (can) {
        solve = s;
      } else {
        r = s;
      }
    }
    printf("%.15f\n", (double)((solve + r) * 0.5));
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
}
