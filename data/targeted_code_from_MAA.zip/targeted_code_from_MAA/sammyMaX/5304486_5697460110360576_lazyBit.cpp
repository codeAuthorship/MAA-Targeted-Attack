#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <unordered_map>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;

typedef double td_d;
typedef long double LD;
typedef set<int> si;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef pair<int, int> pii;
typedef vector<pii> vii;
typedef vector<string> vs;

typedef long long ll;          
typedef unsigned long long ULL; 
typedef unsigned uint;



struct debugger {
  template <typename T> debugger &get(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void solve(int *arr, int n) {
  printf("[");
  for (int i = 0; i < n; i++)
    printf("%d ", arr[i]);
  printf("]\n");
}

int req[110], lb[110], ub[110];
int q[110][110];
int main() {
  ios::sync_with_stdio(true);

  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/A-small-practice.in",
          "r", stdin);
  ;
  freopen("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out",
          "w", stdout);
  ;

  int n, i, j, y, b, m, t, s = 0, d, r, ans, p;
  scanf("%d", &t);
  ;
  int c = 1;
  while (t--) {
    memset((req), (0), sizeof(req));
    memset((lb), (0), sizeof(lb));
    memset((ub), (0), sizeof(ub));
    memset((q), (0), sizeof(q));
    scanf("%d", &n);
    ;
    scanf("%d", &p);
    ;
    for (i = 0; i < n; i++) {
      scanf("%d", &req[i]);
      ;
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < p; j++) {
        scanf("%d", &q[i][j]);
        ;
      }
    }
    for (i = 0; i < n; i++) {
      sort(q[i], q[i] + p);
    }
    for (i = 0; i < n; i++) {
      td_d nt = (9 * req[i]) / 10.0;
      lb[i] = (int)nt;
      if (lb[i] < nt)
        lb[i]++;
      ub[i] = (11 * req[i]) / 10;
    }
    int ns;
    ans = 0;
    bool vis[52][52];
    memset((vis), (0), sizeof(vis));

    for (i = 0; i < n; i++) {
      for (j = 0; j < p; j++) {
        if (q[i][j] < lb[i])
          continue;
        ns = q[i][j] / lb[i];
        int mx = q[i][j] / ub[i];
        if (mx * ub[i] < q[i][j]) {
          mx++;
        }
        swap(mx, ns);
        while (ns <= mx) {
          bool f = true;
        
          vector<pair<int, int>> v;
          v.clear();
          for (int m = i + 1; m < n; m++) {
            f = false;
            for (int o = 0; o < p; o++) {
             
              if (!vis[m][o] && ns * lb[m] <= q[m][o])
                if (ns * ub[m] >= q[m][o]) {
                  vis[m][o] = true;
                  v.push_back(make_pair(m, o));
                  f = true;
                  break;
                }
            }

            if (f == 0)
              break;
          }
          if (f == 0) {
            for (int o = 0; o < v.size(); o++) {
              vis[v[o].first][v[o].second] = false;
            }
          } else {
            ans++;

            break;
          }
          ns++;
        }
      }
      break;
    }
    printf("Case #%d: %d\n", c++, ans);
  }
  return (0);
}
