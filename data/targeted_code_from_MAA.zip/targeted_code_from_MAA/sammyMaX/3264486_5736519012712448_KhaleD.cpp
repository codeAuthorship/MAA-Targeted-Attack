#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;
ofstream fout;

ifstream fin;

typedef long double LD;
typedef long long LL;
typedef pair<int, int> ii;
typedef pair<LL, LL> pll;
typedef vector<int> VI;
typedef vector<VI> vvi;
typedef vector<LL> vll;
typedef set<int> si;

const int N = 200002;
int t, n, k;
char a[N];

bool solve() {
  for (int i = (0); i <= (int)(n - 1); ++i)
    if (a[i] == '-')
      return 0;
  return true;
}

inline void uvypftqlic(int &ans, int &i) {
  ++ans;
  for (int j = (i); j <= (int)(i + k - 1); ++j)
    a[j] = a[j] == '-' ? '+' : '-';
}

inline void yhpcgonooe(int &testCase) {
  fin >> a;
  n = strlen(a);
  fin >> k;

  int ans = 0;

  for (int i = (0); i <= (int)(n - k); ++i)
    if (a[i] == '-') {
      uvypftqlic(ans, i);
    }

  if (solve())
    fout << "Case #" << testCase << ": " << ans << "\n";
  else
    fout << "Case #" << testCase << ": IMPOSSIBLE\n";
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/outer_temp/KhaleD/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_2_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/KhaleD/A-small-practice.in");

  fin >> t;
  for (int testCase = (1); testCase <= (int)(t); ++testCase)
    yhpcgonooe(testCase);
}


