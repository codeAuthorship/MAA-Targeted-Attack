#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;
typedef long long int lli;

int tc;

int main() {
  scanf("%d ", &tc);
  int t;
  for (t = 1; t <= tc; t++) {
    int n, q;
    scanf("%d %d ", &n, &q);
    int e[109], s[109];
    for (int x = 1; x <= n; x++) {
      scanf("%d %d ", &e[x], &s[x]);
    }
    int adj[109][109];
    for (int x = 1; x <= n; x++) {
      for (int j = 1; j <= n; j++) {
        scanf("%d ", &adj[x][j]);
      }
    }
    int solve[109];

    for (int x = 1; x < n; x++) {
      solve[x] = adj[x][x + 1];
    }
    cout << "Case #" << t << ": ";
    for (int nq = 0; nq < q; nq++) {
      int u, v;
      scanf("%d %d ", &u, &v);
      double time_taken[109];
      for (int x = 1; x <= n; x++) {
        time_taken[x] = -1;
      }
      time_taken[1] = 0;
      for (int x = 1; x < n; x++) {
        
        int dist_left = e[x];
        int speed = s[x];
        double cur_time = time_taken[x];
        for (int j = x + 1; j <= n; j++) {

          dist_left -= solve[j - 1];
          if (dist_left < 0) {
            break;
          }
          cur_time += (solve[j - 1] + 0.0) / s[x];
         
          if (time_taken[j] < 0) {
            time_taken[j] = cur_time;
          } else {
            time_taken[j] = min(time_taken[j], cur_time);
          }
        }
      }
      cout << fixed << setprecision(7) << time_taken[v] << endl;
    }
  }
}
