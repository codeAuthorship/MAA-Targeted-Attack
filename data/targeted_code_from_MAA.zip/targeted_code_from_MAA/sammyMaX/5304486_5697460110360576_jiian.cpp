#include <bits/stdc++.h>
#include <fstream>
using namespace std;
const int MAXN = 1005;
ifstream fin;

using LL = long long;
using pii = pair<int, int>;

int T, r;

inline void xbrkfwrvph(int &x, vector<int> &R, int &i, vector<vector<pii>> &v,
                       int &solve) {
  fin >> x;
  int a = ceil(1 / 1.1 * x / R[i]), b = floor(1 / 0.9 * x / R[i]);
 
  if (a <= b)
    v.back().emplace_back(a, b);
  solve++;
}

inline void adyfkxkcyx(int &p, vector<int> &R, int &i, vector<vector<pii>> &v) {
  int solve = 0, x;
  while (solve < p)
    xbrkfwrvph(x, R, i, v, solve);
}

inline void hdvhxksjwk(vector<vector<pii>> &v, int &mnv, int &mnid, int &get,
                       int &mxid, int &i) {
  auto x = v[i].back();
  if (x.first > mnv)
    mnv = x.first, mnid = i;
  if (x.second < get)
    get = x.second, mxid = i;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  fin >> T;
  while (T--) {
    vector<vector<pii>> v;
    vector<int> R;
    int n, p;
    fin >> n >> p;
    for (int i = 0, x; i < n; i++)
      fin >> x, R.push_back(x);
    int mx = p;
    for (int i = 0; i < n; i++) {
      v.push_back(vector<pii>());
      adyfkxkcyx(p, R, i, v);
      sort(v[i].begin(), v[i].end());
    }
    int y = 0;
    while (1) {
      int mnv = 0, get = 1e9, mnid, mxid, flag = 0;
      int i;
      for (i = 0; i < n; i++)
        if (v[i].size())
          hdvhxksjwk(v, mnv, mnid, get, mxid, i);
        else
          flag = 1;
      if (flag)
        break;
       
      if (mnv <= get) {
        y++;
        for (int i = 0; i < n; i++)
          v[i].pop_back();
      } else
        v[mnid].pop_back();
    }
    printf("Case #%d: %d\n", ++r, y);
  }
  return ret_val;
}
