#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

ofstream fout;

typedef long double ld;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<int> VI;
typedef vector<vector<int>> vvi;

pair<int, int> adj[50 + 1][50 + 1];
int cnt[50 + 1], cur[50 + 1];
int r[50 + 1], q[50 + 1];
int n, p;

inline void sqqxvdfiyz(int &j, int &i) {
  adj[i][cnt[i]++] = make_pair(((q[j] * 9 + 9) / 10 + r[i] - 1) / r[i],
                               ((q[j] * 10) / 9) / r[i]);
}

inline void snpynxbkmo(int &maxl, int &maxi, int &i) {
  maxl = adj[i][cur[i]].first;
  maxi = i;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/outer_temp/try/A-small-practice_transformation.out");

  int ret_val = 0;

  int t, i, j, flg, ans, maxl, maxi, solve, mini;
  fin >> t;
  for (int c = 0; c < t; c++) {
    memset(cnt, 0, sizeof(cnt));
    fin >> n >> p;
    for (i = 0; i < n; i++) {
      fin >> r[i];
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < p; j++) {
        fin >> q[j];
      }
      sort(q, q + p);
      for (j = 0; j < p; j++) {
        if (((q[j] * 9 + 9) / 10 + r[i] - 1) / r[i] <= ((q[j] * 10) / 9) / r[i])
          sqqxvdfiyz(j, i);
      }
    }
    memset(cur, 0, sizeof(cur));
    flg = 1;
    ans = 0;
    for (; flg == 1;) {
      for (i = 0; i < n; i++) {
        if (cur[i] >= cnt[i]) {
          flg = 0;
          break;
        }
      }
      if (flg == 0) {
        break;
      }
      maxl = -1;
      maxi = -1;
      solve = 1000000000;
      mini = -1;
      for (i = 0; i < n; i++) {
        if (maxl < adj[i][cur[i]].first)
          snpynxbkmo(maxl, maxi, i);
        if (solve > adj[i][cur[i]].second) {
          solve = adj[i][cur[i]].second;
          mini = i;
        }
      }
      if (maxl <= solve) {
        ans++;
        for (i = 0; i < n; i++) {
          cur[i]++;
        }
      } else {
        cur[mini]++;
      }
    }
    fout << "Case #" << c + 1 << ": " << ans << "\n";
  }
  return ret_val;
}
