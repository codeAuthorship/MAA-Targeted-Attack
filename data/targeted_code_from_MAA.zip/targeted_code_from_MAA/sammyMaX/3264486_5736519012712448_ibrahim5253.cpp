#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
typedef long double ld;
typedef long long LL;
typedef pair<int, int> ii;

const int MOD = 1000000007;
ofstream fout;

ifstream fin;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

ll gcd(ll a, ll b) {
  ll t;
  for (; (t = a % b) != 0;) {
    a = b;
    b = t;
  }
  return b;
}

ll solve(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = solve(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (is_set(i, mask))
      ++ans;
  return ans;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return -1;
}

inline void myczpojtmp(int &f, int &j, int &k, std::string &s) {
  ++f;
  for (int l = j; l < j + k; ++l)
    s[l] = (s[l] == '+' ? '-' : '+');
}

inline void zdxerdoeqk(int &f, int &j, int &k, std::string &s) {
  if (s[j] == '-')
    myczpojtmp(f, j, k, s);
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out");

  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/A-small-practice.in");
  int t;
  fin >> t;
  for (int i = 1; i <= t; ++i) {
    string s;
    int k;
    fin >> s >> k;
    int f = 0, n = s.length();
    for (int j = 0; j < n - k + 1; ++j)
      zdxerdoeqk(f, j, k, s);
    for (int j = 0; j < n; ++j)
      if (s[j] == '-') {
        f = -1;
        break;
      }
    fout << "Case #" << i << ": ";
    if (f == -1)
      fout << "IMPOSSIBLE\n";
    else
      fout << f << "\n";
  }
  return ret_val;
}
