#include <bits/stdc++.h>
#include <iostream>
using namespace std;
const int MOD = 1000000007;
const int INF = 1000000000;
typedef long long ll;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef set<int> si;
typedef map<int, int> mii;

const int N = 1002;
int t, n, c;

inline void dkqnjbqrca(priority_queue<int, vi> &q) {
  int get = q.top();
  q.pop();
  if (get / 2) {
    q.push(get / 2);
  }
  if (get / 2 - (get % 2 == 0)) {
    q.push(get / 2 - (get % 2 == 0));
  }
}

inline void mdzjvkfmvx(int &testCase) {
  cin >> n >> c;

  priority_queue<int, vi> q;
  q.push(n);
  for (int i = (1); i <= (int)(c - 1); ++i)
    dkqnjbqrca(q);

  int get = q.top();
  int y = max(get / 2, get / 2 - (get % 2 == 0)),
      z = min(get / 2, get / 2 - (get % 2 == 0));
  printf("Case #%d: %d %d\n", testCase, y, z);
  ++testCase;
}

inline void solve() {
  int testCase = (1);
  while (testCase <= (int)(t))
    mdzjvkfmvx(testCase);
}

int main() {

  cin >> t;
  solve();
}

// freopen("input.txt","r",stdin);
// freopen("output.txt","w",stdout);
// ios::sync_with_stdio(0);cin.tie(0);
