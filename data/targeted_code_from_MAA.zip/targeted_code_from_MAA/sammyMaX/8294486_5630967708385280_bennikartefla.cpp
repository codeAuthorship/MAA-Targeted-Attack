#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef long long ll;
const int INF = ~(1 << 31);
const double pi = acos(-1);

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/A-small-practice.in");

  int ret_val = 0;

  ofstream fout("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_6_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/bennikartefla/outer_temp/bennikartefla/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int u = (0); u < (t); u++) {
    double n, m;
    fin >> n >> m;
    double t2 = 0;
    for (int solve = (0); solve < (m); solve++) {
      double a, b;
      fin >> a >> b;
      double t = (n - a) / b;
      t2 = max(t, t2);
    }
    fout << "Case #" << u + 1 << ": " << setprecision(10) << fixed << n / t2
         << endl;
  }
  return ret_val;
}
