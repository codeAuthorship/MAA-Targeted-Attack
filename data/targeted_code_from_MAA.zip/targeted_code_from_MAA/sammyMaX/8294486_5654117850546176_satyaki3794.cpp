 
#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream fin;

ofstream fout;

typedef pair<int, int> ii;
typedef pair<int, ii> iii;

long long pwr(long long base, long long p, long long mod = (1000000007LL)) {
  long long ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return ans;
}

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

int n, red, orange, yellow, green, blue, violet;
vector<string> q[5];

string yolo(int x) {
  string z = q[x].back();
  q[x].pop_back();
  return z;
}

string check(int x) {

  int y = -1, z = -1;
  int i;
  {
    i = 1;
    while (i <= 3) {
      if (i == x) {
        i++;
        continue;
      }
      if (y == -1)
        y = i;
      else
        z = i;
      i++;
    }
  }

  int xsz = (int)q[x].size(), ysz = (int)q[y].size(), zsz = (int)q[z].size();
  if (ysz + zsz < xsz)
    return "";
  if (ysz < zsz) {
    swap(y, z);
    swap(ysz, zsz);
  }

 

  if (ysz >= xsz) {
    int rem = ysz - xsz;
    if (rem > zsz)
      return "";
    zsz -= rem;
    string ans = "";
    for (int i = 0; i < xsz; i++) {
      ans += yolo(x) + yolo(y);
      if (i == 0) {
        while (rem--) {
          ans += yolo(z) + yolo(y);
        }
      }
      if (i < zsz)
        ans += yolo(z);
    }
    return ans;
  } else {
    int rem = zsz - (xsz - ysz);
    if (rem > ysz)
      return "";
    string ans = "";
    int i;
    for (i = 0; i < xsz; i++) {
      ans += yolo(x);
      if (i < ysz) {
        ans += yolo(y);
        if (i < rem)
          ans += yolo(z);
      } else
        ans += yolo(z);
    }
    return ans;
  }
  return "";
}

inline void enzopbhaam() {
  blue -= orange + 1;
  string str = "B";
  while (orange--)
    str += "OB";
  q[1].push_back(str);
}

inline void vddojrnxgh() {
  yellow -= violet + 1;
  string str = "Y";
  while (violet--)
    str += "VY";
  q[3].push_back(str);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");

  int ret_val = 0;

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    fin >> n >> red >> orange >> yellow >> green >> blue >> violet;

    orange = green = violet = 0;

    if (orange > 0 && blue < orange + 1) {
      fout << "Case #" << x++ << ": IMPOSSIBLE" << endl;
      continue;
    }

    if (green > 0 && red < green + 1) {
      fout << "Case #" << x++ << ": IMPOSSIBLE" << endl;
      continue;
    }

    if (violet > 0 && yellow < violet + 1) {
      fout << "Case #" << x++ << ": IMPOSSIBLE" << endl;
      continue;
    }

    q[1].clear();
    q[2].clear();
    q[3].clear();

    if (orange > 0)
      enzopbhaam();

    if (green > 0) {
      red -= green + 1;
      string str = "R";
      while (green--)
        str += "GR";
      q[2].push_back(str);
    }

    if (violet > 0)
      vddojrnxgh();

    while (blue--)
      q[1].push_back("B");
    while (red--)
      q[2].push_back("R");
    while (yellow--)
      q[3].push_back("Y");

    string ans = "";
    ans = check(1);
 
    if ((int)ans.length() == n) {
      fout << "Case #" << x++ << ": " << ans << endl;
      continue;
    }

    ans = check(2);
    if ((int)ans.length() == n) {
      fout << "Case #" << x++ << ": " << ans << endl;
      continue;
    }

    ans = check(3);
    if ((int)ans.length() == n) {
      fout << "Case #" << x++ << ": " << ans << endl;
      continue;
    }

    ans = "";
    if ((int)ans.length() != n) {
      fout << "Case #" << x++ << ": IMPOSSIBLE" << endl;
      continue;
    }
  }
  return ret_val;
}
