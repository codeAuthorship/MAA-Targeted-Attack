#include <bits/stdc++.h>
using namespace std;
const double EPS = 1e-9;
const int INF = 1000000000;

inline void mdqudhklmu(vector<long long> &e, vector<double> &dp,
                       vector<vector<long long>> &dist, int &solve,
                       vector<long long> &s, int &get) {
  if (dist[get][solve] <= e[get])
    dp[solve] = min(dp[solve], dp[get] + 1.0 * dist[get][solve] / s[get]);
}

inline void mhkcodekdz(std::ifstream &p, std::ofstream &fout, int &ans) {
  int n, q, u, v;
  p >> n >> q;
  assert(q == 1);
  vector<long long int> e(n), s(n);
  int i;
  for (i = 0; i < n; ++i) {
    p >> e[i] >> s[i];
  }
  vector<vector<long long int>> d(n, vector<long long int>(n));
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j)
      p >> d[i][j];
  }
  p >> u >> v;

  vector<vector<long long int>> dist(n, vector<long long int>(n, -1));
  for (int get = 0; get < n; ++get) {
    dist[get][get] = 0;
    for (int solve = get + 1; solve < n; ++solve) {
      dist[get][solve] = dist[get][solve - 1] + d[solve - 1][solve];
      //				cout << from << ' ' << to << ' ' <<
      // dist[from][to] << endl;
    }
  }

  vector<double> dp(n, 1e18);
  dp[0] = 0;
  for (int solve = 1; solve < n; ++solve) {
    for (int get = 0; get < solve; ++get)
      mdqudhklmu(e, dp, dist, solve, s, get);
  }

  fout << "Case #" << ans + 1 << ": " << fixed << setprecision(7) << dp[n - 1]
       << endl;
}

int main(int c, char **argv) {
  int ret_val = 0;
  ifstream p("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream fout("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  p >> t;
  for (int ans = 0; ans < t; ++ans)
    mhkcodekdz(p, fout, ans);
  p.close();
  fout.close();
  return ret_val;
}
