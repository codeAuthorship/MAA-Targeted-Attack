#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <queue>
#include <set>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;
const double EPS = 1e-9;
ifstream fin;

int solve(int cc) {
  int ret_val = 1;
  long long d, n, k, s;
  long double mt = 0;
  fin >> d >> n;
  for (int i = 0; i < n; i++) {
    fin >> k >> s;
    long double tt = (d - k);
    tt /= s;
    if (mt < tt) {
      mt = tt;
    } else if (i == 0) {
      mt = tt;
    }
  }
  cout << "Case #" << cc << ": " << fixed << d / mt << endl;
  return ret_val;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(false);
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/A-small-practice.in");
  int t;
  fin >> t;
  cout.precision(7);
  for (int i = 1; i <= t; i++) {
    solve(i);
  }
  return ret_val;
}
