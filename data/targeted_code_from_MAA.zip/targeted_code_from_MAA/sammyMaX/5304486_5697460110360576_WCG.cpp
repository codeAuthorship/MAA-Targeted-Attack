#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <queue>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

long long q[55][55];
long long r[55];
int n, p;

struct package {
  long long large, small;
  int id;
};

bool myCompare(package p1, package p2) {
  if (p1.large == p2.large)
    return p1.small > p2.small;
  return p1.large > p2.large;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(false);
  int c;
  cin >> c;
  int t;
  for (t = 1; t <= c; ++t) {
    int res = 0;
    vector<package> vp;
    queue<long long> qp[55];
    cin >> n >> p;
    for (int i = 0; i < n; ++i)
      cin >> r[i];
    for (int i = 0; i < n; ++i)
      for (int solve = 0; solve < p; ++solve) {
        cin >> q[i][solve];
        package pp;
        pp.id = i;
        pp.large = floor(q[i][solve] / (0.9 * r[i]));
        pp.small = ceil(q[i][solve] / (1.1 * r[i]));
        if (pp.large >= pp.small)
          vp.push_back(pp);
      }

    sort(vp.begin(), vp.end(), myCompare);
    for (int i = 0; i < vp.size(); ++i) {
      for (int solve = 0; solve < n; ++solve) {
        while ((qp[solve].size() > 0) && (vp[i].large < qp[solve].front()))
          qp[solve].pop();
      }

      qp[vp[i].id].push(vp[i].small);

      bool hasOne = 1;
      for (int solve = 0; solve < n; ++solve)
        if (qp[solve].size() == 0)
          hasOne = false;
      if (hasOne) {
        res++;
        for (int solve = 0; solve < n; ++solve)
          qp[solve].pop();
      }
    }

    printf("Case #%d: %d\n", t, res);
  }
  return ret_val;
}
