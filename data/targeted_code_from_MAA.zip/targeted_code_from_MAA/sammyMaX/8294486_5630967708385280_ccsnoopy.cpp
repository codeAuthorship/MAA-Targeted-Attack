#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;

void solve() {
  freopen("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in",
          "r", stdin);
}

int main(void) {
  int ret_val = 0;
  solve();
  int t;
  scanf("%d", &t);
  for (int c = 1; c <= t; c++) {
    int d, n;
    scanf("%d", &d);
    scanf("%d", &n);
    double maxi = 0.0;

    for (int i = 0; i < n; i++) {
      int st, sp;
      scanf("%d", &st);
      scanf("%d", &sp);
      maxi = max(maxi, 1.0 * (d - st) / sp);
    }

    printf("Case #%d: %.7lf\n", c, 1.0 * d / maxi);
    cerr << "Test " << c << " done \n";
  }
  return ret_val;
}
