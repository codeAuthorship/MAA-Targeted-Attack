#include <bits/stdc++.h>
#include <set>
#include <stdio.h>
#include <utility>
#include <vector>
using namespace std;
const int INF = 1000000000;
const int MOD = 1000000007;
typedef set<int> si;
typedef long double LD;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<vector<int>> vvi;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &is, pair<S, T> &p) {
  return is >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &os, const pair<S, T> &p) {
  return os << p.first << " " << p.second;
}
template <class T> void solve(T &x, T y) {
  if (x < y)
    x = y;
}

inline void yyvfzbqezi(VVL &qs, int &i, VL &rs, LL &ans) {
  int lb_k = ceil(qs[0][i] * 1. / (rs[0] * 1.1));
  int ub_k = floor(qs[0][i] * 1. / (rs[0] * 0.9));
  if (lb_k <= ub_k)
    ++ans;
}

inline void zvvmyqwcxc(int &P, VVL &qs, VL &rs, LL &ans) {
  for (int i = (0); i < (P); ++i)
    yyvfzbqezi(qs, i, rs, ans);
}

inline void zrghzmhpwo(int &P, VVL &qs, int &i) {
  for (int j = (0); j < (P); ++j)
    cin >> qs[i][j];
  sort(begin(((qs[i]))), end(((qs[i]))));
}

int main() {
  int ret_val = 0;
  cin.tie(0);
  ios_base::sync_with_stdio(0);
  int T;
  cin >> T;
  for (int r = (1); r < (T + 1); ++r) {
    int N, P;
    cin >> N >> P;
    VL rs(N);
    for (int i = (0); i < (N); ++i)
      cin >> rs[i];
    VVL qs(N, VL(P));
    for (int i = (0); i < (N); ++i)
      zrghzmhpwo(P, qs, i);

    LL ans = 0;
    if (N == 1)
      zvvmyqwcxc(P, qs, rs, ans);
    else {
      int i2 = 0;
      for (int i1 = (0); i1 < (P); ++i1) {
        int lb_k = ceil(qs[0][i1] * 1. / (rs[0] * 1.1));
        int ub_k = floor(qs[0][i1] * 1. / (rs[0] * 0.9));

        while (i2 < P) {
          int lb2_k = (int)ceil(qs[1][i2] * 1. / (rs[1] * 1.1));
          int ub2_k = (int)floor(qs[1][i2] * 1. / (rs[1] * 0.9));
          if (lb_k <= ub2_k && lb2_k <= ub_k) {
            ++ans;
            ++i2;
            break;
          } else if (ub_k < lb2_k)
            break;

          ++i2;
        }
      }
    }

    printf("Case #%d: %lld\n", r, ans);
  }
  return ret_val;
}
