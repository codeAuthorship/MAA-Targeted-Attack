#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <complex>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
const double eps = 1e-9;
ifstream fin;

int main() {
  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/A-small-practice.in");
  int tt;
  fin >> tt;
  int t;
  for (t = 1; t <= tt; ++t) {
    long long s;
    vector<int> v;
    fin >> s;

    while (s > 0) {
      v.push_back(s % 10);
      s = s / 10;
    }
    int solve = v.size() - 1;
    while (solve > 0 && (v[solve] <= v[solve - 1]))
      solve--;
    if (solve != 0) {
      v[solve]--;
      while (solve + 1 < v.size() && v[solve + 1] == v[solve] + 1) {
        v[solve]++;
        v[++solve]--;
      }
      while (solve > 0)
        v[--solve] = 9;
    }

    for (int i = v.size() - 1; i >= 0; --i)
      s = s * 10 + v[i];

    printf("Case #%d: %lld\n", t, s);
  }
  return ret_val;
}
