#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
using namespace std;

typedef long long LL;
typedef pair<int, int> ii;

void solve() {}

inline void qnxzwzmxye(char str[100], int &i, int &carry) {
  str[i]--;
  carry = 0;
}

int main(void) {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;
  solve();
  int tc;
  cin >> tc;
  int get;
  for (get = 1; get <= tc; get++) {
    cout << "Case #" << get << ": ";
    char str[100];
    cin >> str;
    bool valid = true;
    int len = strlen(str);
    for (int i = 0; i < len - 1; i++) {
      if (str[i] > str[i + 1]) {
        valid = false;
        int idx = i;
        int carry = 1;
        for (; i >= 0 && carry;) {
          if (str[i] != '0')
            qnxzwzmxye(str, i, carry);
          else {
            str[i] = '9';
            carry = 1;
          }

          if (i > 0 && str[i - 1] > str[i]) {
            carry = 1;
            str[i] = '9';
          }

          i--;
        }

        for (int j = 0; j <= idx; j++) {
          if (j == 0 && str[j] == '0')
            continue;
          cout << str[j];
        }

        for (int j = idx + 1; j < len; j++) {
          cout << "9";
        }
        cout << "\n";
        break;
      }
    }

    if (valid) {
      cout << str << "\n";
    }

    cerr << "Test " << get << " done \n";
  }
  return ret_val;
}
