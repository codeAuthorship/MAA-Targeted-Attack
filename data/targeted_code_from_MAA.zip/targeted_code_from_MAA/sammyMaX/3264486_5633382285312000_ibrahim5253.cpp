#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;

ofstream fout;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void zdqhhgakww(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    zdqhhgakww(a, b, t);
  return b;
}

ll solve(ll base, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = solve(base, n / 2, m);
  if (n % 2 == 0)
    return (t * t) % m;
  else
    return (((t * t) % m) * base) % m;
}

bool is_set(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (is_set(i, mask))
      ++ans;
  return ans;
}

int first_bit(ll mask) {
  int ret_val = -1;
  int i = 0;
  while (i < 64)
    if (is_set(i++, mask))
      return i - 1;
  return ret_val;
}

inline void puhkcigwwp(int &j, int &s, std::string &n) {
  int x = j + 1;
  while (x < s) {
    n[x] = '9';
    ++x;
  }
}

int main() {
  ios::sync_with_stdio(false);

  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out");

  int ret_val = 0;

  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    string n;
    cin >> n;
    char l = '0';
    int s = n.length();
    for (int j = 0; j < s; ++j) {
      if (n[j] < l) {
        --j;
        int N = j;
        while (N > 0 && n[N] == '1')
          n[N] = '9', --N;
        n[N] -= 1;
        while (N > 0 && n[N - 1] > n[N])
          n[N - 1] -= 1, n[N] = '9', --N;
        puhkcigwwp(j, s, n);
        break;
      }
      l = n[j];
    }
    int N = 0;
    while (n[N] == '0')
      ++N;
    fout << "Case #" << i << ": " << n.substr(N) << "\n";
  }
  return ret_val;
}
