
#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using namespace std;
typedef double td_d;

const int INF = 1000000000;
ifstream fin;

ofstream fout;

const int N = 110;

int e[N], s[N];
int n;
int dt[N];
int sum[N];

struct node {
  int v;
  double w;
  node(int _v = 0, double _w = 0) : v(_v), w(_w) {}
};

vector<node> adj[N];
bool vst[N];
double d[N];

void solve() {
  int qq;
  fin >> n >> qq;
  for (int i = 1; i <= n; ++i) {
    fin >> e[i] >> s[i];
  }
  sum[1] = 0;
  for (int t, i = 1; i <= n; ++i) {
    for (int j = 1; j <= n; ++j) {
      fin >> t;
      if (i + 1 == j) {
        dt[i + 1] = t;
        sum[i + 1] = sum[i] + dt[i + 1];
      }
    }
  }
  fin >> qq >> qq;
  for (int i = 1; i <= n; ++i) {
    adj[i].clear();
  }
  for (int i = 1; i < n; ++i) {
    for (int j = i + 1; j <= n; ++j) {
      if (sum[j] - sum[i] <= e[i]) {
        adj[i].push_back(node(j, (double)(sum[j] - sum[i]) / s[i]));
      } else {
        break;
      }
    }
  }
  queue<int> q;
  q.push(1);
  vst[1] = true;
  fill(d + 1, d + n + 1, 1e20);
  d[1] = 0;
  for (; !q.empty();) {
    int t = q.front();
    q.pop();
    vst[t] = false;
    for (int i = 0; i < (int)adj[t].size(); ++i) {
      int v = adj[t][i].v;
      td_d w = adj[t][i].w;
      if (d[v] > d[t] + w) {
        d[v] = d[t] + w;
        if (!vst[v]) {
          q.push(v);
          vst[v] = 1;
        }
      }
    }
  }
  fout << fixed << setprecision(9) << d[n] << endl;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out");

  ios::sync_with_stdio(true);

  int ret_val = 0;

  int q;
  fin >> q;
  for (int i = 1; i <= q; ++i) {
    fout << "Case #" << i << ": ";
    solve();
  }
  return ret_val;
}
