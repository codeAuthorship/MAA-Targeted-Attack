#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <queue>
#include <set>
#include <stack>
#include <stdio.h>
#include <unordered_map>
#include <utility>
using namespace std;

int main(void) {
  int ret_val = 0;
  int t;
  scanf("%d", &t);
  for (int tt = 1; tt <= t; tt++) {

    int n, k;
    priority_queue<int> solve;
    scanf("%d%d", &n, &k);
    solve.push(n);
    while (--k) {
      int x = solve.top();
      solve.pop();
      solve.push(x / 2);
      solve.push((x - 1) / 2);
    }

    int v = solve.top();
    cout << "Case #" << tt << ": " << v / 2 << " " << (v - 1) / 2 << "\n";
  }
  return ret_val;
}

 
