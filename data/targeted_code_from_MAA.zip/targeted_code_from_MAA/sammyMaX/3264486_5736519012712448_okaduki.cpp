#include <bits/stdc++.h>
#include <fstream>
using namespace std;
const int MAXN = 1005;
const double EPS = 1e-9;
const long double PI = 3.1415926535897932384626433832795;
ifstream fin;

ofstream fout;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &solve(istream &c, pair<S, T> &p) {
  return c >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &b, const pair<S, T> &p) {
  return b << p.first << " " << p.second;
}

inline void lmkefmqjem(int &ans, int &K, VI &a, int &i) {
  ++ans;
  for (int k = (0); k < (K); ++k)
    a[i + k] = !a[i + k];
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/A-small-practice.in");

  int ret_val = 0;
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/outer_temp/okaduki/A-small-practice_transformation.out");
  cin.tie(0);

  int T;
  fin >> T;
  int t;
  for (t = (1); t < (T + 1); ++t) {
    string S;
    fin >> S;
    int K;
    fin >> K;
    int N = int((S).size());
    VI a(N);
    int i;
    for (i = (0); i < (N); ++i)
      a[i] = S[i] == '+';

    int ans = 0;
    for (int i = 0; i + K <= N; ++i) {
      if (!a[i])
        lmkefmqjem(ans, K, a, i);
    }
    if (accumulate(begin((a)), end((a)), 0) != N)
      fout << "Case #" << t << ": IMPOSSIBLE" << endl;
    else
      fout << "Case #" << t << ": " << ans << endl;
  }
  return ret_val;
}
