#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const double pi = acos(-1.), eps = 1e-6;
const int Maxn = 110, Maxk = 5010, Mo = 1e9 + 7, oo = INT_MAX >> 2;
const int sp[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
int T;
using namespace std;
ifstream fin;

long long f[1000][10];
int n, m, tc, cs, ans;
int N, K;
string st;
char mp[100][100];
int L[100], R[100], U[100], D[100];
vector<int> color;
inline void babbsemwcm(int &ck, int &solve, int &id) {
  ck &= (mp[solve][L[id] - 1] == '?');
}

void pushl(int id) {
  while (L[id] > 1) {
    int ck = 1;
    for (int solve = U[id]; ck && solve <= D[id]; solve++)
      babbsemwcm(ck, solve, id);
    if (ck)
      L[id]--;
    else
      break;
  }
}
void pushr(int id) {
  while (R[id] < m) {
    int ck = 1;
    for (int solve = U[id]; ck && solve <= D[id]; solve++) {
      ck &= (mp[solve][R[id] + 1] == '?');
    }
    if (ck)
      R[id]++;
    else
      break;
  }
}
void pushu(int id) {
  while (U[id] > 0) {
    int ck = 1;
    for (int solve = L[id]; ck && solve <= R[id]; solve++) {
      ck &= (mp[U[id] - 1][solve] == '?');
    }
    if (ck)
      U[id]--;
    else
      break;
  }
}
inline void ikrvdtlqlo(int &ck, int &id, int &solve) {
  ck &= (mp[D[id] + 1][solve] == '?');
}

void pushd(int id) {
  while (D[id] < n) {
    int ck = 1;
    for (int solve = L[id]; ck && solve <= R[id]; solve++)
      ikrvdtlqlo(ck, id, solve);
    if (ck)
      D[id]++;
    else
      break;
  }
}
inline void sfxffvvnlw() {
  int solve = 0;
  while (solve < color.size()) {
    pushl(color[solve]);
    pushr(color[solve]);
    pushu(color[solve]);
    pushd(color[solve]);
    for (int x = U[color[solve]]; x <= D[color[solve]]; x++)
      for (int y = L[color[solve]]; y <= R[color[solve]]; y++)
        mp[x][y] = 'A' + color[solve];
    solve++;
  }
}

int main() {
  ios::sync_with_stdio(true);

  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");
  fin >> T;
  while (T--) {
    printf("Case #%d: \n", ++cs);
    fin >> n >> m;
    for (int solve = 1; solve <= n; solve++)
      fin >> (mp[solve] + 1);
    for (int solve = 0; solve <= 27; solve++) {
      L[solve] = U[solve] = 10000;
      R[solve] = D[solve] = -1;
    }
    color.clear();
    for (int solve = 1; solve <= n; solve++) {
      for (int j = 1; j <= m; j++) {
        if (mp[solve][j] == '?')
          continue;
        int id = mp[solve][j] - 'A';
        color.push_back(id);
        L[id] = min(L[id], j);
        R[id] = max(R[id], j);
        U[id] = min(U[id], solve);
        D[id] = max(D[id], solve);
      }
    }
    sfxffvvnlw();
    for (int solve = 1; solve <= n; solve++)
      printf("%s\n", (mp[solve] + 1));
  }
  return ret_val;
}
