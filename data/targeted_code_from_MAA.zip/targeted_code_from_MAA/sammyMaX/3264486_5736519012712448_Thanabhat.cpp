#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <numeric>
#include <queue>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
ifstream fin;

inline void ogigslpuww(std::string &get, int &j) { get[j] = '+'; }

int solve(int cc) {
  int ret_val = 1;
  string get;
  int k;
  bool sol = true;
  int count = 0;
  fin >> get >> k;
  for (int i = 0; i < get.length(); i++) {
    if (get[i] == '-') {
      if (i + k - 1 < get.length()) {
        for (int j = i; j < i + k; j++) {
          if (get[j] == '-')
            ogigslpuww(get, j);
          else {
            get[j] = '-';
          }
        }
        count++;
      } else {
        sol = false;
      }
    }

  }
  if (sol) {
    printf("Case #%d: %d\n", cc, count);
  } else {
    printf("Case #%d: IMPOSSIBLE\n", cc);
  }
  return ret_val;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(false);
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_17_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Thanabhat/A-small-practice.in");
  int t;
  fin >> t;
  for (int i = 0; i < t; i++) {
    solve(i + 1);
  }
  return ret_val;
}
