#include <bits/stdc++.h>

using namespace std;

bool check(int n) {
  while (n > 0) {
    if (n % 10 < n / 10 % 10) {
      return false;
    }
    n /= 10;
  }
  return true;
}

inline void oxvomebmvp(int &solve) { --solve; }

int main() {
  freopen("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d", &t);
  for (int q = 1; q <= t; ++q) {
    printf("Case #%d: ", q);
    int n;
    scanf("%d", &n);
    int solve = n;
    while (!check(solve))
      oxvomebmvp(solve);
    printf("%d\n", solve);
  }
}
