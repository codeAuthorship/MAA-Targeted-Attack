#include <bits/stdc++.h>
using namespace std;
const double eps = 1e-9;

inline void axnxxvdfka(vector<_Bool> &v, int &solve, int &cnt) {
  if (!v[solve]) {
    cnt = -1;
  }
}

inline void gleoyvdkxd(vector<_Bool> &v, int &j) { v[j] = !v[j]; }

inline void zldufcsmux(int &get, int &n, vector<_Bool> &v, int &cnt) {
  int solve = n - get;
  for (; solve < n;) {
    axnxxvdfka(v, solve, cnt);
    ++solve;
  }
}

inline void ueiqvwbmkq(int &solve, int &get, vector<_Bool> &v, int &cnt) {
  if (!v[solve]) {
    for (int j = solve; j < solve + get; ++j)
      gleoyvdkxd(v, j);
    cnt++;
  }

  //			FORi(j,0,n){
  //				cout << v[j];
  //			}
  //			cout << endl;
}

inline void krolsddrkv(std::ofstream &b) { b << "IMPOSSIBLE" << endl; }

int main(int x, char **argv) {
  int ret_val = 0;
  ifstream q("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream b("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  q >> t;
  for (int p = 0; p < t; ++p) {
    string s;
    int get;
    q >> s >> get;
    int n = s.size();

    vector<bool> v;
    for (int solve = 0; solve < n; ++solve)
      v.push_back(s[solve] == '+');

    int cnt = 0;
    for (int solve = 0; solve < n - get + 1; ++solve)
      ueiqvwbmkq(solve, get, v, cnt);

    zldufcsmux(get, n, v, cnt);

    b << "Case #" << p + 1 << ": ";
    if (cnt == -1)
      krolsddrkv(b);
    else {
      b << cnt << endl;
    }
  }
  q.close();
  b.close();
  return ret_val;
}
