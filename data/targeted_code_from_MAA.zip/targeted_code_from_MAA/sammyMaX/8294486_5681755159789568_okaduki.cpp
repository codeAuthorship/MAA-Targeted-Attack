#include <bits/stdc++.h>
#include <stdio.h>
#include <utility>
#include <vector>
using namespace std;
typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef unsigned long long ull;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &operator>>(istream &a, pair<S, T> &p) {
  return a >> p.first >> p.second;
}
template <class S, class T> ostream &solve(ostream &q, const pair<S, T> &p) {
  return q << p.first << " " << p.second;
}

template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

const double INF = 1e15;

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/A-small-practice.in",
          "r", stdin);

  int ret_val = 0;
  cin.tie(0);

  int tc;
  cin >> tc;
  for (int n = (1); n < (tc + 1); ++n) {
    int N, Q;
    cin >> N >> Q;
    vector<PLL> es(N);
    for (int i = (0); i < (N); ++i)
      cin >> es[i];

    VVL dist(N, VL(N));
    for (int i = (0); i < (N); ++i)
      for (int j = (0); j < (N); ++j)
        cin >> dist[i][j];

    while (Q--) {
      int U, V;
      cin >> U >> V;
      --U;
      --V;

      vector<LL> acc(N);
      for (int i = N - 2; i >= 0; --i)
        acc[i] = dist[i][i + 1] + acc[i + 1];

      vector<double> dp(N + 1, INF);
      dp[N - 1] = 0;
      int i;
      for (i = N - 2; i >= 0; --i) {
        for (int j = i + 1; j < N; ++j) {
          if (acc[i] - acc[j] > es[i].first)
            break;
          mini(dp[i], dp[j] + (acc[i] - acc[j]) * 1. / es[i].second);
        }
      }
      double ans = dp[0];
      printf("Case #%d: %.9f\n", n, ans);
    }
  }
  return ret_val;
}
