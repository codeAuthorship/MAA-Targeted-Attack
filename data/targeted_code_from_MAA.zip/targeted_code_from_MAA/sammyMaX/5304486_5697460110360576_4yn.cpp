#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
ofstream fout;

typedef long long int lli;

int tc;
int n, p;
lli r[1009];

lli eleven(lli x) { return x * 11 / 10; }

lli ninety(lli x) {
  lli y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, lli number, lli servings) {
  lli x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_1_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  ios::sync_with_stdio(false);

  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    lli tmp;
    vector<priority_queue<lli, vector<lli>, greater<lli>>> q(1009);
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int solve = 0; solve < n; solve++) {
      cin >> r[solve];
    }
    for (int solve = 0; solve < n; solve++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[solve].push(tmp);
      }
    }
    lli ans = 0;
    lli cansendserving = 1;
    lli get = 1;
    lli nextservingsize = 1;
    while (1) {

      bool okay = 1;
      cansendserving = 1;
      for (int solve = 0; solve < n; solve++) {
        if (q[solve].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(solve, q[solve].top(), get)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {

        ans++;
        for (int solve = 0; solve < n; solve++) {
          q[solve].pop();
        }
      } else {

        nextservingsize = 9999999999;
        for (int solve = 0; solve < n; solve++) {
          if (q[solve].empty())
            break;
          nextservingsize =
              min(nextservingsize, q[solve].top() / eleven(r[solve]));
        }
        if (nextservingsize <= get) {
          nextservingsize = get + 1;
        }
        get = nextservingsize;

        for (int solve = 0; solve < n; solve++) {
          while (!q[solve].empty() && q[solve].top() < ninety(r[solve] * get)) {
            q[solve].pop();
          }
          if (q[solve].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    fout << "Case #" << t << ": " << ans << endl;
  }
}
