#include <bits/stdc++.h>
using namespace std;
const double eps = 1e-9;

const long double PI = 3.1415926535897932384626433832795;

const int MAXN = 1005;
const int MOD = 1000000007;
const int INF = 1000000000;

struct Segment {
  long long int l, r;
  long long int get() { return (l + r) / 2; }
  long long int left_dist() { return this->get() - this->l - 1; }
  long long int right_dist() { return this->r - this->get() - 1; }
  long long int min_dist() {
    return min(this->left_dist(), this->right_dist());
  }
  long long int max_dist() {
    return max(this->left_dist(), this->right_dist());
  }
};

struct Magic {
  bool operator()(Segment &lhs, Segment &rhs) const {
    if (lhs.min_dist() == rhs.min_dist()) {
      if (lhs.max_dist() == rhs.max_dist())
        return lhs.get() > rhs.get();

      return lhs.max_dist() < rhs.max_dist();
    }
    return lhs.min_dist() < rhs.min_dist();
  }
};

inline void rhxlroamha(
    priority_queue<struct Segment, vector<struct Segment>, struct Magic> &pq,
    struct Segment &s) {
  pq.push({s.l, s.get()});
  pq.push({s.get(), s.r});
}

int main(int v, char **argv) {
  int ret_val = 0;
  ifstream fin("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream solve("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  fin >> t;
  for (int p = 0; p < t; ++p) {
    long long n, k;
    fin >> n >> k;

    priority_queue<Segment, vector<Segment>, Magic> pq;
    Segment s = {0, n + 1};
    pq.push(s);
    for (int i = 0; i < k; ++i) {
      s = pq.top();
      pq.pop();
      if (s.max_dist() > 0)
        rhxlroamha(pq, s);
    }

    solve << "Case #" << p + 1 << ": " << s.max_dist() << ' ' << s.min_dist()
          << endl;
  }
  fin.close();
  solve.close();
  return ret_val;
}
