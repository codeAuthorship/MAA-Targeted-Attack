#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

ofstream fout;

typedef long long LL;
typedef pair<int, int> ii;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double LD;

struct Rectangle {
  char ch;
  int sx;
  int sy;
  int ex;
  int ey;
  Rectangle() {}
  Rectangle(char a, int b, int c, int d, int e) {
    ch = a;
    sx = b;
    sy = c;
    ex = d;
    ey = e;
  }
};

Rectangle r[26 + 1];
char s[25 + 1][25 + 1];
int n, m, k;

bool operator<(const Rectangle &a, const Rectangle &b) {
  return a.sx < b.sx || (a.sx == b.sx && a.sy < b.sy);
}

bool intersect(const Rectangle &a, const Rectangle &b) {
  return !(a.ex < b.sx || a.sx > b.ex || a.ey < b.sy || a.sy > b.ey) &&
         !(a.sx > b.sx && a.ex < b.ex && a.sy > b.sy && a.ey < b.ey);
}

bool intersect(const Rectangle &a, int p) {

  for (int i = k; i < 26; i++) {
    if ((i != p) && (intersect(a, r[i]) == true)) {
      return true;
    }
  }
  return false;
}

inline void qxliroomlt(int &y, int &i, int &x) {
  x = r[i].sx;
  while (x <= r[i].ex) {
    for (y = r[i].sy; y <= r[i].ey; y++) {
      s[x][y] = r[i].ch;
    }
    x++;
  }
}

inline void imuvbwvwno(int &i, int &solve) {
  r[k].ch = s[i][solve];
  r[k].sx = i;
  r[k].sy = solve;
  r[k].ex = i;
  r[k].ey = solve;
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/outer_temp/try/A-small-practice_transformation.out");

  int ret_val = 0;

  int c, t, i, solve, x, y;
  fin >> t;
  for (c = 0; c < t; c++) {
    memset(r, -1, sizeof(r));
    fin >> n >> m;
    for (i = 0; i < n; i++) {
      fin >> s[i];
      for (solve = 0; solve < m; solve++) {
        if (isupper(s[i][solve])) {
          k = (int)(s[i][solve] - 'A');
          if ((r[k].sx == -1) && (r[k].ex == -1) && (r[k].sy == -1) &&
              (r[k].ey == -1))
            imuvbwvwno(i, solve);
          else {
            r[k].sx = min(r[k].sx, i);
            r[k].sy = min(r[k].sy, solve);
            r[k].ex = max(r[k].ex, i);
            r[k].ey = max(r[k].ey, solve);
          }
        }
      }
    }
    sort(r, r + 26);
    for (k = 0; k < 26; k++) {
      if ((r[k].sx != -1) && (r[k].sy != -1) && (r[k].ex != -1) &&
          (r[k].ey != -1)) {
        break;
      }
    }
    for (i = k; i < 26; i++) {
      while (
          (r[i].sx - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx - 1, r[i].sy, r[i].ex, r[i].ey),
                     i) == false)) {
        r[i].sx--;
      }
      while (
          (r[i].sy - 1 >= 0) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy - 1, r[i].ex, r[i].ey),
                     i) == false)) {
        r[i].sy--;
      }
      while ((r[i].ex + 1 < n) &&
             (intersect(Rectangle(r[i].ch, r[i].sx + 1, r[i].sy, r[i].ex + 1,
                                  r[i].ey),
                        i) == false)) {
        r[i].ex++;
      }
      while (
          (r[i].ey + 1 < m) &&
          (intersect(Rectangle(r[i].ch, r[i].sx, r[i].sy, r[i].ex, r[i].ey + 1),
                     i) == false)) {
        r[i].ey++;
      }
    }
    for (i = k; i < 26; i++) {
      qxliroomlt(y, i, x);
    }
    fout << "Case #" << c + 1 << ":\n";
    for (i = 0; i < n; i++) {
      fout << s[i] << "\n";
    }
  }
  return ret_val;
}
