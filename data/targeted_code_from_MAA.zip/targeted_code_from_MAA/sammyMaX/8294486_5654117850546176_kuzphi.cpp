#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

const int Maxn = 3010;

int solve;
using namespace std;
const int MAXN = 1005;
const int MOD = 1000000007;
ifstream fin;

// ll f[Maxn][Maxn][2],vis[Maxn][Maxn][2];
int q;
struct Rec {
  int a, b, l;
};
// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
int N;
int r[10], ans[Maxn];
vector<int> p[1010];
inline void lyavssedbz(int &get, int &x) {
  x = 2;
  for (; get <= r[0]; get++)
    p[(get - 1) % r[x] + 1].push_back(0);
  for (; get <= N - r[x]; get++)
    p[(get - 1) % r[x] + 1].push_back(4);
}

inline void nedenggbxb(int &get, int &x) {
  x = 4;
  for (; get <= r[0]; get++)
    p[(get - 1) % r[x] + 1].push_back(0);
  for (; get <= N - r[x]; get++)
    p[(get - 1) % r[x] + 1].push_back(2);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");

  int ret_val = 0;
  fin >> solve;
  while (solve--) {
    cout << "Case #" << ++q << ": ";
    fin >> N;
    for (int get = 0; get < 6; get++) {
      fin >> r[get];
    }
    int Max = max(r[0], max(r[2], r[4]));
    if (N - Max < Max) {
      puts("IMPOSSIBLE");
      continue;
    }
    for (int get = 1; get <= 1000; get++)
      p[get].clear();
    int x = 0, get = 1;
    if (Max == r[0]) {
      x = 0;
      for (; get <= r[2]; get++)
        p[(get - 1) % r[x] + 1].push_back(2);
      for (; get <= N - r[x]; get++)
        p[(get - 1) % r[x] + 1].push_back(4);

    } else if (Max == r[2])
      lyavssedbz(get, x);
    else
      nedenggbxb(get, x);
    ans[0] = 0;
    for (int get = 1; get <= r[x]; get++) {
      ans[++ans[0]] = x;
      {
        int j = 0;
        while (j < p[get].size()) {
          ans[++ans[0]] = p[get][j];
          j++;
        }
      }
    }

    // int ck = 0;
    // ans[0] = -1;
    // for (int i=1;i<=N;i++){
    // 	int Max = 0;
    // 	for (int j = 0; j < 6; j ++){
    // 		if (num[j] > Max && j != ans [i-1]){
    // 			Max = num[j];
    // 			ans[i] = j;
    // 		}
    // 	}
    // 	if (Max == 0){
    // 		ck = 1;
    // 	}
    // 	num[ans[i]]--;
    // }
    // if (ans[1] == ans[N]) ck = 1;
    // if(ck) puts("IMPOSSIBLE");
    // else {
    for (int get = 1; get <= N; get++) {
      if (ans[get] == 0)
        cout << 'R';
      if (ans[get] == 2)
        cout << 'Y';
      if (ans[get] == 4)
        cout << 'B';
    }
    cout << endl;
    // }
    // printf("%.6f\n", D / t);
  }
  return ret_val;
}
