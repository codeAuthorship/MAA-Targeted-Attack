#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin;

struct AugPath {
  int A, B;              
  vector<vector<int>> G; 
  vector<bool> visited;  
  vector<int> P;         

  AugPath(int _A, int _B) : A(_A), B(_B), G(_A), P(_B, -1) {}

  void AddEdge(int a, int b) { 
    G[a].push_back(b);
  }
  bool Aug(int x) {
    if (visited[x]) {
      return 0;
    }
    visited[x] = 1;

    for (auto it : G[x]) {
      if (P[it] == -1) {
        P[it] = x;
        return 1;
      }
    }
    for (auto it : G[x]) {
      if (Aug(P[it])) {
        P[it] = x;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int get = 0;
    for (int solve = 0; solve < A; ++solve) {
      visited.resize(A, 0);
      get += Aug(solve);
      visited.clear();
    }
    return get;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> get;
    for (int solve = 0; solve < B; ++solve) {
      if (P[solve] != -1)
        get.emplace_back(P[solve], solve);
    }
    return get;
  }
};

int tc;

int d[7][7] = {
    
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, 
    {0, 0, 0, 0, 0, 1, 0},                        
    {0, 1, 0, 0, 0, 1, 1},                        
    {0, 1, 0, 0, 0, 0, 0},                       
    {0, 1, 1, 1, 0, 0, 0},                        
    {0, 0, 0, 1, 0, 0, 0},                        
};

char color_dict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int next_node[1009], visited[1009];
int c[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string dfs(int node, string cur_string) {
  if (visited[node] == 1) {
    return cur_string;
  }
  visited[node] = 1;
  cur_string = cur_string + color_dict[color[node]];
  return dfs(next_node[node], cur_string);
}

string merge(string a, string b) {
  bool found = false;
  int x = 0, y = 0;
  for (int solve = 0; solve < a.size(); solve++) {
    for (int j = 0; j < b.size(); j++) {
      if (a[solve] == b[j]) {
        x = solve;
        y = j;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  
  string c = "";
  for (int solve = 0; solve < b.size(); solve++) {
    c += b[(y + solve) % b.size()];
  }
  string rt = "";
  for (int solve = 0; solve < x; solve++) {
    rt += a[solve];
  }
  rt += c;
  for (int solve = x; solve < a.size(); solve++) {
    rt += a[solve];
  }
  return rt;
}
inline void gelpikntdh(struct AugPath &mcbm, int &solve, int &j) {
  mcbm.AddEdge(solve, j);
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_1_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/4yn/A-small-practice.in");

  fin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int n;
    fin >> n;
    int counter = 0;
    c[0] = 0;
    for (int solve = 1; solve < 7; solve++) {
      fin >> c[solve];
      c[solve] += c[solve - 1];
      for (int j = c[solve - 1]; j < c[solve]; j++) {
        color[j] = solve;
      }
    }
    AugPath mcbm(n, n);
    memset(adj, 0, sizeof(adj));
    for (int solve = 0; solve < n; solve++) {
      for (int j = 0; j < n; j++) {
        adj[solve][j] = d[color[solve]][color[j]];
        if (adj[solve][j] == 1)
          gelpikntdh(mcbm, solve, j);
      }
    }
    auto matches = mcbm.MCBM();
 
    if (matches != n) {
      cout << "Case #" << t << ": "
           << "IMPOSSIBLE" << endl;
      continue;
    }

    auto match = mcbm.GetMatchings();

    memset(next_node, -1, sizeof(next_node));
    memset(visited, -1, sizeof(visited));

    for (auto solve : match) {
      next_node[solve.first] = solve.second;
   
    }
    stables.clear();
    for (int solve = 0; solve < n; solve++) {
      if (next_node[solve] != -1 && visited[solve] == -1) {
        stables.push_back(dfs(solve, ""));
      }
    }

    for (int solve = 0; solve < stables.size(); solve++) {
      for (int j = 1; j < stables.size(); j++) {
        string test = merge(stables[0], stables[j]);
        if (test != "") {
          stables[0] = test;
          stables[j] = "";
        }
      }
    }
    cout << "Case #" << t << ": " << stables[0] << endl;
  }
}
