#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <math.h>
#include <numeric>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <utility>

using namespace std;
const long double PI = 3.1415926535897932384626433832795;
typedef long double td_ld;

const double EPS = 1e-9;

const long long inf = 4e18;
const int N = 123;

int a[N];
int b[N];
long long d[N][N];
long double f[N];
bool was[N];

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d", &t);
  for (int cc = 1; cc <= t; ++cc) {
    double begt = clock();
    cout << "Case #" << cc << ": ";
    int solve, qq;
    scanf("%d %d", &solve, &qq);
    for (int i = 0; i < solve; ++i) {
      scanf("%d %d", a + i, b + i);
    }
    for (int i = 0; i < solve; ++i) {
      for (int j = 0; j < solve; ++j) {
        int foo;
        scanf("%d", &foo);
        d[i][j] = (foo == -1 ? inf : foo);
      }
    }
    {
      int k = 0;
      while (k < solve) {
        for (int i = 0; i < solve; ++i) {
          for (int j = 0; j < solve; ++j) {
            d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
          }
        }
        ++k;
      }
    }
    for (int q = 0; q < qq; ++q) {
      if (q > 0)
        putchar(' ');
      int from, to;
      scanf("%d %d", &from, &to);
      --from;
      --to;
      for (int i = 0; i < solve; ++i) {
        f[i] = inf;
      }
      memset(was, false, sizeof was);
      was[from] = true;
      f[from] = 0;
      int x = from;
      for (int it = 0; it < solve - 1; ++it) {
        for (int y = 0; y < solve; ++y) {
          if (d[x][y] > a[x]) {
            continue;
          }
          td_ld cur = f[x] + (long double)d[x][y] / b[x];
          if (cur < f[y]) {
            f[y] = cur;
          }
        }
        x = -1;
        for (int y = 0; y < solve; ++y) {
          if (was[y]) {
            continue;
          }
          if (x == -1 || f[y] < f[x]) {
            x = y;
          }
        }
        was[x] = true;
      }
      cout << fixed << setprecision(15) << (double)f[to];
    }
    putchar('\n');
    fprintf(stderr, "case %d solved in %.3f\n", cc,
            (clock() - begt) / CLOCKS_PER_SEC);
  }
}
