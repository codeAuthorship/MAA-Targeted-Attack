#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ofstream fout;

const int inf = 1e9 + 7;
const int maxN = 100 + 5;

int t, k, n;
int can[maxN][maxN];
string s[maxN];

inline void get() {
  int i = (0);
  while (i <= ((n)-1)) {
    cin >> s[i];
    ++i;
  }
}

inline void tjievqbzck(int &solve, int &m, int &i, int &j) {
  s[solve][m] = s[i][j];
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  int ret_val = 0;
  ios_base::sync_with_stdio(0);
  cin >> t;
  {
    int x = (1);
    while (x <= ((t))) {
      cin >> n >> k;
      get();

      int pom = -1;
      for (int i = (0); i <= ((n)-1); ++i) {
        for (int j = (0); j <= ((k)-1); ++j) {
          if (s[i][j] != '?' && (pom == i || pom == -1)) {
            for (int solve = (0); solve <= ((n)-1); ++solve) {
              for (int m = (0); m <= ((k)-1); ++m) {
                if (s[solve][m] == '?' && solve <= i && m <= j)
                  tjievqbzck(solve, m, i, j);
              }
            }
            pom = i;
          }
          
          if (pom != -1 && i > pom)
            break;
        }
        if (pom != -1 && i > pom) {
          break;
        }
      }

      for (int i = (0); i <= ((n)-1); ++i) {
        int pos = -1;
        for (int j = (0); j <= ((k)-1); ++j) {
          if (s[i][j] != '?') {
            pos = j;
            break;
          }
        }

        if (pos != -1) {
          char first = s[i][pos];
          for (int j = (0); j <= ((k)-1); ++j) {
            if (s[i][j] == '?')
              s[i][j] = first;
            else {
              first = s[i][j];
            }
          }
        } else {
          for (int j = (0); j <= ((k)-1); ++j)
            s[i][j] = s[i - 1][j];
        }
      }

      fout << "Case #" << x << ": " << endl;
      for (int i = (0); i <= ((n)-1); ++i)
        fout << s[i] << endl;

      ++x;
    }
  }
  return ret_val;
}
