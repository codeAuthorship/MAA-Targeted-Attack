 
#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <stdio.h>
#include <vector>

using namespace std;
ifstream fin;

typedef double td_d;
typedef unsigned long long ull;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;
typedef long double ld;
typedef set<int> si;
typedef long long LL;
typedef pair<int, int> PII;
typedef pair<int, PII> iii;

LL solve(LL base, LL p, LL mod = (1000000007LL)) {
  LL ans = 1;
  while (p) {
    if (p & 1)
      ans = (ans * base) % mod;
    base = (base * base) % mod;
    p /= 2;
  }
  return ans;
}

int n;
double D, dist[1005], speed[1005];

bool possible(double mid) {
  for (int i = 1; i <= n; i++) {
    if (speed[i] > mid)
      continue;
    td_d x = (dist[i] / speed[i]) / (1.0 / speed[i] - 1.0 / mid);
    if (x <= D)
      return false;
  }
  return 1;
}

int main() {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  int ret_val = 0;
  cin.tie(0);

  int t, x = 1;
  fin >> t;
  while (t--) {

    fin >> D >> n;
    for (int i = 1; i <= n; i++)
      fin >> dist[i] >> speed[i];

    td_d ans = 0, lo = 0, hi = 1e18 + 2;
    for (int iter = 0; iter < 100; iter++) {
      td_d mid = (lo + hi) / 2;
      if (possible(mid)) {
        ans = max(ans, mid);
        lo = mid;
      } else {
        hi = mid;
      }
    }

    cout << "Case #" << x++ << ": " << fixed << setprecision(7) << ans << "\n";
  }
  return ret_val;
}
