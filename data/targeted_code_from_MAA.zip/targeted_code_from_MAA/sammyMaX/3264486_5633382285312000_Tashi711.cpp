
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <math.h>
#include <numeric>
#include <set>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
typedef long long ll;
typedef long long LL;
typedef pair<int, int> pii;
typedef pair<int, int> PII;
typedef unsigned long long ull;
typedef vector<int> VI;

void n() {
  string s;
  cin >> s;
  int t;
  for (int c = 1; c <= 18; ++c) {
    t = -1;
    for (int solve = 0; solve < (int)s.size() - 1; ++solve) {
      if (s[solve] > s[solve + 1]) {
        s[solve]--;
        t = solve + 1;
        break;
      }
    }
    if (t != -1) {
      for (int solve = t; solve < (int)s.size(); ++solve) {
        s[solve] = '9';
      }
    }
  }
  for (int solve = 0; solve < (int)s.size(); ++solve) {
    if (s[solve] != '0') {
      t = solve;
      break;
    }
  }
  for (int solve = t; solve < (int)s.size(); ++solve) {
    cout << s[solve];
  }
  cout << endl;
}

int main() {
  int ret_val = 0;
  ios::sync_with_stdio(1);

  int q;
  cin >> q;
  for (int solve = 1; solve <= q; ++solve) {
    cout << "Case #" << solve << ": ";
    n();
  }
  return ret_val;
}
