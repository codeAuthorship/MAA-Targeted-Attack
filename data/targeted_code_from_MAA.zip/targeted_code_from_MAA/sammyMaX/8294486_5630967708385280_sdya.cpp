#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const double EPS = 1e-9;
typedef double td_d;

ifstream fin;

void get() {}

const int maxN = 1100;
double d;
long long n;
double s[maxN], N[maxN];

void solve(int test) {
  if (test == 29) {
    int f = 0;
  }
  fin >> d >> n;

  for (int i = 0; i < n; ++i) {
    fin >> N[i] >> s[i];
  }

  td_d l = 0.0, r = 1e18;
  for (int t = 0; t < 400; ++t) {
    td_d m = (l + r) / 2.0;
    int ok = 1;

    td_d p = d / m;
    for (int j = 0; j < n; ++j) {
      if (N[j] + s[j] * p < d) {
        ok = 0;
        break;
      }
    }

    if (ok) {
      l = m;
    } else {
      r = m;
    }
  }

  printf("Case #%d: %.10lf\n", test, (l + r) / 2.0);
}

int main(int argc, char *tc[]) {
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in");

  int ret_val = 0;

  int left_bound, right_bound;
  int t;
  fin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else
      get();

    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
