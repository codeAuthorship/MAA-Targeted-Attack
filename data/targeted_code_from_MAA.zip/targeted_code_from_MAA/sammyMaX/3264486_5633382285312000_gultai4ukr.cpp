#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1005;
const int INF = 1000000000;

inline bool ojgbimionh(_Bool &zizbj, _Bool &ojgbi) {
  zizbj = 0;
  ojgbi = 1;
  return true;
  return false;
}

inline bool zizbjiwkcj(int &d, int &get, _Bool &zizbj) {
  if (get % 10 > d) {
    _Bool ojgbi;
    if (ojgbimionh(zizbj, ojgbi))
      return ojgbi;
  }

  d = get % 10;
  get /= 10;
  return false;
}

bool is_tidy(int get) {
  int d = 9;
  for (; get;) {
    _Bool zizbj;
    if (zizbjiwkcj(d, get, zizbj)) {
      return zizbj;
    }
  }
  return 1;
}

int main(int j, char **x) {
  int ret_val = 0;
  ifstream fin("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/A-small-practice.in");
  ofstream fout("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_14_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/gultai4ukr/outer_temp/gultai4ukr/A-small-practice_transformation.out");
  int t;
  fin >> t;

  for (int testcase = 0; testcase < t; ++testcase) {
    long long int get;
    fin >> get;
    long long int solve = 1;
    for (int i = get; i > 1; --i) {
      if (is_tidy(i)) {
        solve = i;
        break;
      }
    }
    fout << "Case #" << testcase + 1 << ": " << solve << endl;
  }
  fin.close();
  fout.close();
  return ret_val;
}
