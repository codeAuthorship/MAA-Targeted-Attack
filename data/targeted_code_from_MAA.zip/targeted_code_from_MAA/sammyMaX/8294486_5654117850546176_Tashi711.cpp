
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
ifstream fin;

ofstream fout;

const int N = 1100;

int n, cnt[6];
int ans[N];
char cc[6] = {'R', 'O', 'Y', 'G', 'B', 'V'};

void pre() { ans[0] = -10000; }

bool nb(int c, int t) {
  int res = c - t;
  return (res == 1 || res == -1 || res == 5 || res == -5 || res == 0);
}

inline void axfocryccf(int &j) { fout << cc[ans[j]]; }

bool dfs(int p) {
  if (p == n + 1) {
    if (!nb(ans[1], ans[n])) {
      return true;
    } else {
      return false;
      for (int j = 1; j <= n; ++j)
        axfocryccf(j);
      fout << endl;
    }
  }
  vector<int> pos;
  int maxc = -10000;
  for (int j = 0; j < 6; ++j) {
    if (cnt[j] > maxc && !nb(j, ans[p - 1])) {
      pos.clear();
      pos.push_back(j);
      maxc = cnt[j];
    } else if (cnt[j] == maxc) {
      pos.push_back(j);
    }
  }
  if (maxc == -10000) {
    return false;
  }
  for (int j = 0; j < (int)pos.size(); ++j) {
    int c = pos[j];
    if (!nb(c, ans[p - 1])) {
      cnt[c]--;
      ans[p] = c;
      bool res = dfs(p + 1);
      if (res) {
        return 1;
      }
      cnt[c]++;
    }
  }
  return false;
}

void solve() {
  fin >> n;
  int maxc = 0;
  for (int j = 0; j < 6; ++j) {
    fin >> cnt[j];
    if (cnt[j] > maxc) {
      maxc = cnt[j];
    }
  }
  if (maxc > n / 2) {
    fout << "IMPOSSIBLE" << endl;
    return;
  }
  if (dfs(1)) {
    for (int j = 1; j <= n; ++j)
      fout << cc[ans[j]];

    fout << endl;
  } else {
    fout << "IMPOSSIBLE" << endl;
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out");

  int ret_val = 0;

  pre();
  int q;
  fin >> q;
  for (int j = 1; j <= q; ++j) {
    fout << "Case #" << j << ": ";
    solve();
  }
  return ret_val;
}
