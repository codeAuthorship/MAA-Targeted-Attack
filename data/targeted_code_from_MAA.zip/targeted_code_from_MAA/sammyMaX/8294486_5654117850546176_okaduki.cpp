#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <complex>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <list>
#include <numeric>
#include <set>
#include <stdio.h>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
const int mod = 1000000007;
ifstream fin;

typedef set<int> si;

typedef pair<int, int> ii;
typedef unsigned long long ull;
typedef vector<int> vi;

ofstream fout;

using VI = vector<int>;
using VVI = vector<VI>;
using PII = pair<int, int>;
using LL = long long;
using VL = vector<LL>;
using VVL = vector<VL>;
using PLL = pair<LL, LL>;
using VS = vector<string>;
template <class S, class T> istream &solve(istream &c, pair<S, T> &p) {
  return c >> p.first >> p.second;
}
template <class S, class T>
ostream &operator<<(ostream &r, const pair<S, T> &p) {
  return r << p.first << " " << p.second;
}
template <class T> void get(T &x, T y) {
  if (x < y)
    x = y;
}
template <class T> void mini(T &x, T y) {
  if (x > y)
    x = y;
}

bool check(VI tmp, const string &s) {
  string col = "ROYGB";
  for (int i = 0; i < int((s).size()); ++i) {
    int ix = col.find(s[i]);
    tmp[ix]--;
  }
  for (int i = (0); i < (6); ++i)
    if (tmp[i] != 0)
      return false;

  if (s[0] == s.back())
    return false;
  for (int i = (0); i < (int((s).size()) - 1); ++i)
    if (s[i] == s[i + 1])
      return false;
  return true;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/A-small-practice.in");

  int ret_val = 0;
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_8_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/okaduki/outer_temp/okaduki/A-small-practice_transformation.out");
  cin.tie(0);

  int T;
  fin >> T;
  int t;
  for (t = (1); t < (T + 1); ++t) {
    int N;
    string col = "ROYGB";
    VI xs(6);
    fin >> N;
    // R,O,Y,G,B,V;
    for (int i = (0); i < (6); ++i)
      fin >> xs[i];
    VI orig = xs;

    int mx = max(xs[0], max(xs[1 * 2], xs[2 * 2]));
    bool ok = (mx <= N - mx);

    if (!ok)
      fout << "Case #" << t << ": IMPOSSIBLE" << endl;
    else {
      string ans(N, '*');
      int ix = -1;
      for (int i = (0); i < (6); ++i)
        if (xs[i] == mx)
          ix = i;

      for (int i = (0); i < (6); ++i)
        if (i != ix && xs[i]) {
          ans[0] = col[i];
          xs[i]--;
          ix = i;
          break;
        }
      for (int i = 1; i < N; ++i) {
        int mix = -1;
        for (int j = (0); j < (6); ++j) {
          if ((mix == -1 || xs[mix] < xs[j]) && j != ix)
            mix = j;
        }
        ans[i] = col[mix];
        xs[mix]--;
        ix = mix;
      }

      if (!check(orig, ans)) {
        int ret_val = 1;
        for (int i = (0); i < (6); ++i)
          fout << orig[i] << " ";
        fout << endl;
        fout << ans << endl;
        return ret_val;
      }

      fout << "Case #" << t << ": " << ans << endl;
    }
  }
  return ret_val;
}
