
#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
#include <vector>

using namespace std;
ofstream fout;

ifstream fin;

typedef long long td_ll;

struct node {
  long long u, v;
  node(int _u = 0, int _v = 0) : u(_u), v(_v) {}
  bool operator<(const node &r) const { return u < r.u; }
};

void solve() {
  td_ll n, N;
  fin >> n >> N;
  map<long long, long long> f;
  f[n] = 1;
  td_ll sum = 0;
  td_ll l = (n - 1) / 2, r = n / 2;
  while (sum < N) {
    td_ll d = f.rbegin()->first, v = f.rbegin()->second;
    f.erase(d);
    sum += v;
    l = (d - 1) / 2;
    r = d / 2;
    f[l] += v;
    f[r] += v;
  }
  fout << r << ' ' << l << endl;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/outer_temp/Tashi711/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_4_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Tashi711/A-small-practice.in");

  ios::sync_with_stdio(true);

  int ret_val = 0;

  int q;
  fin >> q;
  for (int i = 1; i <= q; ++i) {
    fout << "Case #" << i << ": ";
    solve();
  }
  return ret_val;
}
