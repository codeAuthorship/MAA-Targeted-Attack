#include <bits/stdc++.h>
#include <iostream>
using namespace std;
typedef long long int lli;
typedef pair<lli, lli> pii;

int tc;

int main() {
  ios::sync_with_stdio(false);

  cin >> tc;
  int t;
  for (t = 1; t <= tc; t++) {
    int n, k;
    cin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, solve;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      y = t / 2 + (t % 2);
      solve = t / 2;
      pq.push(y);
      pq.push(solve);
    }
    printf("Case #%d: %d %d\n", t, y, solve);
  }
}
