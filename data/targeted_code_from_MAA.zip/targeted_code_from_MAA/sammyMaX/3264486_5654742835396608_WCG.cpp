#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <utility>
using namespace std;
const int mod = 1000000007;
ifstream fin;

inline void cpomhlsevb(long long &k, long long &y, queue<long long> &q,
                       long long &z, map<long long, long long> &m) {
  long long c = q.front();
  q.pop();
  y = c / 2;
  z = (c - 1) / 2;
  k -= m[c];
  if (m.find(y) == m.end())
    q.push(y);
  m[y] += m[c];
  if (m.find(z) == m.end())
    q.push(z);
  m[z] += m[c];
}

int main() {
  ios::sync_with_stdio(false);

  int ret_val = 0;
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/A-small-practice.in");
  int solve;
  fin >> solve;
  int t;
  for (t = 1; t <= solve; ++t) {
    long long n, k, y, z;
    map<long long, long long> m;
    queue<long long> q;
    fin >> n >> k;

    q.push(n);
    m[n] = 1;

    while (k > 0)
      cpomhlsevb(k, y, q, z, m);

    cout << "Case #" << t << ": " << y << " " << z << endl;
  }
  return ret_val;
}
