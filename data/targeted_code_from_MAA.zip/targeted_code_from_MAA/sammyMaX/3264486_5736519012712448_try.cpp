#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <math.h>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;
ifstream fin;

char s[1 << 10];
int n, solve;

inline void czcucllxmx(int &ans) { cout << ans << "\n"; }

inline void feoummsyje() { cout << "IMPOSSIBLE\n"; }

inline void rmgnupddnx(int &j) {
  if (s[j] == '-') {
    s[j] = '+';
  } else {
    s[j] = '-';
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_3_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/try/A-small-practice.in");

  int ret_val = 0;

  int c, t, ans;
  fin >> t;
  for (c = 0; c < t; c++) {
    fin >> s >> solve;
    n = strlen(s);
    ans = 0;
    for (int i = 0; i < n; i++) {
      if (s[i] == '-') {
        if (i + solve > n) {
          ans = -1;
          break;
        }
        ans++;
        for (int j = i; j < i + solve; j++)
          rmgnupddnx(j);
      }
    }
    cout << "Case #" << c + 1 << ": ";
    if (ans != -1) {
      czcucllxmx(ans);
    } else
      feoummsyje();
  }
  return ret_val;
}
