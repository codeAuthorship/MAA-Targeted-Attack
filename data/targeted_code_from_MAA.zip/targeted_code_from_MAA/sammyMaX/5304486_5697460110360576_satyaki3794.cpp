#include <bits/stdc++.h>
#include <fstream>

using namespace std;
const int MAXN = 1005;
ifstream fin;

ofstream fout;

const int MOD = 1000000007;

typedef pair<int, int> ii;

inline void mdihvivujm(long long &ans, long long &base, long long &s,
                       long long &p) {
  if (p & 1)
    ans = (ans * base) % s;
  base = (base * base) % s;
  p /= 2;
}

long long get(long long base, long long p, long long s = (1000000007LL)) {
  long long ans = 1;
  while (p)
    mdihvivujm(ans, base, s, p);
  return ans;
}

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

int n, p, arr[55][55], req[55], DP[10][1024];

int dp(int i, int mask) {
  if (i == p) {
    int ret_val = 0;
    return ret_val;
  }
  int &ans = DP[i][mask];
  if (ans != -1)
    return ans;
  ans = dp(i + 1, mask);
  for (int j = 0; j < p; j++) {
    if ((mask >> j) & 1)
      continue;
    int z = arr[0][i] / req[0];
    for (int x = z + 5; x >= z - 5 && x >= 1; x--) {
      int lo1 = ceil(1LL * x * req[0] * 0.9),
          hi1 = floor(1LL * x * req[0] * 1.1);
      int lo2 = ceil(1LL * x * req[1] * 0.9),
          hi2 = floor(1LL * x * req[1] * 1.1);
      if (arr[0][i] >= lo1 && arr[0][i] <= hi1 && arr[1][j] >= lo2 &&
          arr[1][j] <= hi2)
        ans = max(ans, 1 + dp(i + 1, mask | (1 << j)));
    }
  }
 
  return ans;
}

int main() {
  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");
  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");
  cin.tie(0);
  int t, x = 1;
  fin >> t;
  for (; t--;) {

    fin >> n >> p;
    for (int i = 0; i < n; i++)
      fin >> req[i];
    for (int i = 0; i < n; i++)
      for (int j = 0; j < p; j++)
        fin >> arr[i][j];

    if (n == 1) {
      int ans = 0;
      for (int i = 0; i < p; i++) {
        bool ok = false;
        {
          int x = 2000000;
          while (x >= 1) {
            int lo = ceil(1LL * x * req[0] * 0.9),
                hi = floor(1LL * x * req[0] * 1.1);
            if (arr[0][i] >= lo && arr[0][i] <= hi) {
              ok = true;
              break;
            }
            x--;
          }
        }
        ans += ok;
      }

      fout << "Case #" << x++ << ": " << ans << endl;
      continue;
    }

    memset(DP, -1, sizeof(DP));
    fout << "Case #" << x++ << ": " << dp(0, 0) << endl;
  }
  return ret_val;
}
