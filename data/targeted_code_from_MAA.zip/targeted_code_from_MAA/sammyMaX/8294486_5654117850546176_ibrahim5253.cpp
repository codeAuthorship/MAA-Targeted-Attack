#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

 
using namespace std;
ofstream fout;

const double EPS = 1e-9;
ifstream fin;

const double eps = 1e-9;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<int> VI;
typedef long double LD;
typedef set<int> si;

using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using pill = pair<int, ll>;
using vvi = vector<vi>;

inline void yhioozuuzg(ll &a, ll &b, ll &t) {
  a = b;
  b = t;
}

ll gcd(ll a, ll b) {
  ll t;
  while ((t = a % b) != 0)
    yhioozuuzg(a, b, t);
  return b;
}

inline bool izavhugkbo(ll &t, ll &m, long long &izavh) {
  izavh = (t * t) % m;
  return true;
  return false;
}

inline bool hckeuqlzke(long long &izavh, long long &hckeu) {
  hckeu = izavh;
  return true;
  return false;
}

ll fast_exp(ll c, ll n, ll m) {
  if (n == 0)
    return 1;
  ll t = fast_exp(c, n / 2, m);
  if (n % 2 == 0) {
    long long izavh;
    if (izavhugkbo(t, m, izavh)) {
      long long hckeu;
      if (hckeuqlzke(izavh, hckeu)) {
        return hckeu;
      }
    }
  } else
    return (((t * t) % m) * c) % m;
}

bool solve(int i, ll mask) { return (mask >> i) & 1; }

int count_bits(ll mask) {
  int ans = 0;
  for (int i = 0; i < 64; ++i)
    if (solve(i, mask))
      ++ans;
  return ans;
}

int first_bit(ll mask) {
  int i = 0;
  while (i < 64)
    if (solve(i++, mask))
      return i - 1;
  return -1;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/outer_temp/ibrahim5253/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_10_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ibrahim5253/A-small-practice.in");

  int ret_val = 0;

  int t;
  fin >> t;
  {
    int i = 1;
    while (i <= t) {
      int n, r, o, y, g, b, v;
      fin >> n >> r >> o >> y >> g >> b >> v;
      int ma = n / 2;
      fout << "Case #" << i << ": ";
      if (b > ma) {
        fout << "IMPOSSIBLE\n";
        ++i;
        continue;
      } else if (y > ma) {
        fout << "IMPOSSIBLE\n";
        ++i;
        continue;
      } else if (r > ma) {
        fout << "IMPOSSIBLE\n";
        ++i;
        continue;
      }
      vector<pair<int, char>> V;
      V.push_back(make_pair(r, 'R')), V.push_back(make_pair(y, 'Y')),
          V.push_back(make_pair(b, 'B'));
      sort(V.begin(), V.end());
      char s[n + 1];
      int p = 0;
      int a = V[2].first;
      while (a--)
        s[p] = V[2].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
      a = V[1].first;
      while (a--)
        s[p] = V[1].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
      a = V[0].first;
      while (a--)
        s[p] = V[0].second, p = (p + 2) % n, p = (p == 0 ? 1 : p);
      for (int i = 0; i < n; ++i)
        fout << s[i];
      fout << "\n";
      ++i;
    }
  }
  return ret_val;
}
