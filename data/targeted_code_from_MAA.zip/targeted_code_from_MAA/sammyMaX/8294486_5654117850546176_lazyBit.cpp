#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <complex>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include <algorithm>
#include <functional>
#include <list>
#include <map>
#include <numeric>
#include <utility>
#include <vector>


using namespace std;
ifstream fin;

const int mod = 1000000007;
ofstream fout;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;

typedef long long LL;           
typedef unsigned long long ULL; 
typedef unsigned uint;


const char colors[] = {'R', 'O', 'Y', 'G', 'B', 'V'};

struct debugger {
  template <typename T> debugger &solve(const T &v) {
    cerr << v << " ";
    return *this;
  }
};

void debugarr(int *arr, int n) {
  fout << "[";
  for (int i = 0; i < n; i++)
    fout << arr[i] << " ";
  fout << "]" << endl;
}


vector<pair<int, int>> v;
inline void qmzwhtbyin(int &c, int &d, int a[1010], int &i) {
  fout << "Case #" << c++ << ": ";
  for (i = 0; i < d; i++)
    fout << colors[a[i]];

  fout << endl;
}

inline void wmoncdxbdr(int a[1010], int &i, int b[1010], int &s) {
  b[s++] = a[i];
  if (v[0].first > 0)
    if (a[i + 1] != v[0].second) {
      b[s++] = v[0].second;
      v[0].first--;
    }

}

inline void yrqwimmsmq(int b[1010], int &i) { fout << colors[b[i]]; }

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_16_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/lazyBit/outer_temp/lazyBit/A-small-practice_transformation.out");

  ;
  

  int n, i, j, k, l, m, t, s = 0, d, p;
  fin >> t;
  ;
  int c = 1;
  while (t--) {
    fin >> n;
    ;
    int a[1010];
    int b[1010];
    v.clear();
    for (i = 0; i < 6; i++) {
      fin >> a[i];
      ;
    }
    d = 0;
    v.push_back(make_pair(a[0], 0));
    v.push_back(make_pair(a[2], 2));
    v.push_back(make_pair(a[4], 4));
    if (v[2].first > v[0].first + v[1].first) {
      fout << "Case #" << c++ << ": IMPOSSIBLE\n";
      continue;
    }
    sort(v.begin(), v.end());
    while (d < n) {
      if (v[2].first > 0) {
        a[d++] = v[2].second;
        v[2].first--;

        if (v[1].first > 0) {
          a[d++] = v[1].second;
          v[1].first--;
        } else {
          if (v[0].first > 0) {
            a[d++] = v[0].second;
            v[0].first--;
            if (v[2].first == 0)
              break;
          }
        }
      } else {
        break;
      }
 
    }
    s = 0;
    
    if (v[0].first > 0) {
      for (i = 0; i < d; i++)
        wmoncdxbdr(a, i, b, s);
      for (i = 0; i < s - 1; i++) {
        if (b[i] == b[i + 1]) {
          fout << "Case #" << c++ << ": IMPOSSIBLE\n";
          break;
        }
      }
      if (i != s - 1)
        continue;
      if (b[s - 1] == b[0]) {
        fout << "Case #" << c++ << ": IMPOSSIBLE\n";
        continue;
      }
      fout << "Case #" << c++ << ": ";
      for (i = 0; i < s; i++)
        yrqwimmsmq(b, i);
      fout << endl;
    } else if (a[d - 1] == a[0])
      fout << "Case #" << c++ << ": IMPOSSIBLE\n";
    else
      qmzwhtbyin(c, d, a, i);
  }
  return (0);
}
