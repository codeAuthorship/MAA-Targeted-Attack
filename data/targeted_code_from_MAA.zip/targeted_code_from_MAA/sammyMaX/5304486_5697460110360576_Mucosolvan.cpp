#include <bits/stdc++.h>
#include <fstream>
#include <vector>

using namespace std;
ofstream fout;

ifstream fin;

typedef float td_f;
typedef vector<vector<int>> vvi;
typedef vector<int> vi;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> ii;

const int inf = 1e9 + 7;
const int maxN = 50;
const int M = 50;
const int N = 50;

int t, n, p;
int req[maxN], minim[maxN][maxN], s[maxN][maxN], c[maxN][maxN];
bool graph[maxN][maxN];

bool przeciecie(int i, int j) {
  if (minim[1][i] == inf || minim[2][j] == inf)
    return false;
  if (minim[1][i] >= minim[2][j] && minim[1][i] <= c[2][j])
    return true;
  if (c[1][i] >= minim[2][j] && c[1][i] <= c[2][j])
    return true;
  return false;
}


bool bpm(bool bpGraph[M][N], int u, bool seen[], int matchR[]) {

  for (int v = 0; v < N; v++) {

    if (bpGraph[u][v] && !seen[v]) {
      seen[v] = true; 
      if (matchR[v] < 0 || bpm(bpGraph, matchR[v], seen, matchR)) {
        matchR[v] = u;
        return true;
      }
    }
  }
  return false;
}


int maxBPM(bool bpGraph[M][N]) {

  int matchR[N];


  memset(matchR, -1, sizeof(matchR));

  int result = 0; 
  for (int u = 0; u < M; u++) {
    
    bool seen[N];
    memset(seen, 0, sizeof(seen));


    if (bpm(bpGraph, u, seen, matchR))
      result++;
  }
  return result;
}

inline void mriwuckxwx(int &x, int &j, int &a) {
  minim[x][j] = min(minim[x][j], a);
  c[x][j] = a;
}

inline void mrjsyntqkm(int &j, float &weight, int &x, int &a) {
  if (s[x][j] >= 0.9 * weight && s[x][j] <= 1.1 * weight)
    mriwuckxwx(x, j, a);
  weight += req[x];
  a++;
}

inline void vhltgfzuls(int &i, int &j) {
  graph[i][j] = 0;
  minim[i][j] = c[i][j] = inf;
}

inline void qiaczpmbnt() {
  for (int i = (1); i <= ((p)); ++i)
    for (int j = (1); j <= ((p)); ++j)
      if (przeciecie(i, j)) {
        graph[i][j] = 1;
 
  fout << maxBPM(graph) << endl;
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/A-small-practice.in");

  int solve = 0;

  fin >> t;
  for (int test = (1); test <= ((t)); ++test) {
    fin >> n >> p;
    for (int i = (1); i <= ((n)); ++i) {
      fin >> req[i];
    }

    for (int x = (1); x <= ((n)); ++x)
      for (int j = (1); j <= ((p)); ++j) {
        minim[x][j] = c[x][j] = inf;
      }
    for (int i = (1); i <= ((40)); ++i) {
      for (int j = (1); j <= ((40)); ++j)
        vhltgfzuls(i, j);
    }
    for (int i = (1); i <= ((n)); ++i) {
      for (int j = (1); j <= ((p)); ++j)
        fin >> s[i][j];
    }

    int x;
    for (x = (1); x <= ((n)); ++x) {
      for (int j = (1); j <= ((p)); ++j) {
        td_f weight = req[x];
        int a = 1;
        while (weight <= 2 * s[x][j])
          mrjsyntqkm(j, weight, x, a);
      }
    }

    fout << "Case #" << test << ": ";
    if (n == 1) {
      int ans = 0;
      for (int j = (1); j <= ((p)); ++j) {
        if (minim[1][j] != inf)
          ans++;
      }
      fout << ans << endl;
    } else
      qiaczpmbnt();
  }
  return solve;
}
