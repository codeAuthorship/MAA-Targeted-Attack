#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
const int INF = 1000000000;
ofstream fout;

const int MAXN = 1005;
ifstream fin;

const double EPS = 1e-9;

inline void biqfmaidmd(std::string &s, vector<pair<int, std::string>> &x) {
  s += x[1].second;
  x[1].first--;
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/outer_temp/WCG/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_5_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/WCG/A-small-practice.in");

  int ret_val = 0;

  int i;
  fin >> i;
  for (int solve = 1; solve <= i; ++solve) {
    int n, get, o, y, ans, b, x;
    fin >> n >> get >> o >> y >> ans >> b >> x;
    string s = "";

    if ((get > n / 2) || (y > n / 2) || (b > n / 2))
      s = "IMPOSSIBLE";
    else {
      vector<pair<int, string>> x;
      x.push_back({get, "R"});
      x.push_back({y, "Y"});
      x.push_back({b, "B"});
      sort(x.begin(), x.end());
      reverse(x.begin(), x.end());
      for (; x[0].first > 0;) {
        s += x[0].second;
        x[0].first--;
        if (x[1].first > x[2].first) {
          s += x[1].second;
          x[1].first--;
        } else {
          s += x[2].second;
          x[2].first--;
        }
      }
      while ((x[1].first > 0) || (x[2].first > 0)) {
        if (x[1].first > x[2].first)
          biqfmaidmd(s, x);
        else {
          s += x[2].second;
          x[2].first--;
        }
      }
    }
    fout << "Case #" << solve << ": " << s << endl;
  }
  return ret_val;
}
