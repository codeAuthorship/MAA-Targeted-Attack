#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string>
#include <unordered_map>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
const double EPS = 1e-9;
const int MAXN = 1005;
ifstream fin;

ofstream fout;

const int MOD = 1000000007;
const int mod = 1000000007;
const int INF = 1000000000;

void get() {}

const int maxN = 60;
const int maxL = 2000000;
int n, p;
int a[maxN];
int b[maxN][maxN];

int d[maxN][maxN];
int q[maxL];

pair<int, int> c[maxN][maxN];
bool used[maxN][maxN];

pair<int, int> getPackages(int value, int t) {
  int r = (value * 10) / (9 * t);
  int l = (value * 10 + 11 * t - 1) / (11 * t);

  return make_pair(l, r);
}

inline void ycdwrrtzbo(int &k) { q[k] = true; }

void solve(int test) {
  fin >> n >> p;
  for (int i = 0; i < n; ++i) {
    fin >> a[i];
  }

  for (int i = 0; i < maxL; ++i) {
    q[i] = 0;
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < p; ++j) {
      fin >> b[i][j];
      c[i][j] = getPackages(b[i][j], a[i]);
      for (int k = c[i][j].first; k <= c[i][j].second; ++k)
        ycdwrrtzbo(k);
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < p; ++j) {
      used[i][j] = false;
    }
  }

  int res = 0;
  for (int k = 0; k < maxL; ++k) {
    if (!q[k]) {
      continue;
    }
    while (true) {
      bool good = 1;
      for (int i = 0; i < n; ++i) {
        bool have = false;
        for (int j = 0; j < p; ++j) {
          if (used[i][j]) {
            continue;
          }
          if (k >= c[i][j].first && k <= c[i][j].second) {
            have = true;
            break;
          }
        }
        if (!have) {
          good = false;
          break;
        }
      }
      if (!good) {
        break;
      }
      ++res;
      for (int i = 0; i < n; ++i) {
        for (int j = 0; j < p; ++j) {
          if (used[i][j]) {
            continue;
          }
          if (k >= c[i][j].first && k <= c[i][j].second) {
            used[i][j] = true;
            break;
          }
        }
      }
    }
  }

  fout << "Case #" << test << ": " << res << "\n";
}

int main(int argc, char *argv[]) {
  fin.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in");

  fout.open("/home/tom/project/ramdisk/blackbox_5304486_5697460110360576_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/outer_temp/sdya/A-small-practice_transformation.out");

  int ret_val = 0;

  int left_bound, right_bound;
  int t;
  fin >> t;
  left_bound = 1, right_bound = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= left_bound && i <= right_bound) {
      solve(i);
    } else
      get();

    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
