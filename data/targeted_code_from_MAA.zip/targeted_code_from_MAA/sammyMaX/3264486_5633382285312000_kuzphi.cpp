#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

int T;
using namespace std;
const double EPS = 1e-9;
ofstream fout;

ifstream fin;

int solve;

string t;
inline void iysxnrjege() {
  for (int i = 1; i < t.size(); i++)
    fout << t[i];
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out");

  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_3264486_5633382285312000_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");
  fin >> T;
  for (; T--;) {
    fout << "Case #" << ++solve << ": ";
    fin >> t;
    for (int w = 0; w < t.size(); w++) {
      if (t[0] == '0')
        break;
      for (int i = 1; i < t.size(); i++) {
        if (t[i] < t[i - 1]) {
          t[i - 1]--;
          for (int j = i; j < t.size(); j++)
            t[j] = '9';
          break;
        }
      }
    }
    if (t[0] == '0')
      iysxnrjege();
    else
      fout << t;
    fout << endl;
  }
  return ret_val;
}
