#include <bits/stdc++.h>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;

ofstream fout;

ifstream fin;

typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;

void solve() {}

int main(void) {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/outer_temp/ccsnoopy/A-small-practice_transformation.out");

  fin.open("/home/seal12/Downloads/ramdisk/blackbox_5304486_5760761888505856_7_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/ccsnoopy/A-small-practice.in");

  ios::sync_with_stdio(true);

  int ret_val = 0;
  solve();
  int tc;
  fin >> tc;
  for (int ct = 1; ct <= tc; ct++) {
    int r, c;
    fin >> r;
    fin >> c;
    string str[30];
    string ret[30];
    for (int i = 0; i < r; i++) {
      fin >> str[i];
      // if(ct == 74){
      // 	cerr << str[i] << endl;
      // }
      ret[i] = str[i];
    }

    for (int i = 0; i < r; i++) {
      for (int j = 0; j < c; j++) {
        if (str[i][j] == '?')
          continue;
        int minx, maxx;
        minx = maxx = i;
        int miny, maxy;
        miny = maxy = j;
        while (miny > 0 && str[i][miny - 1] == '?' && ret[i][miny - 1] == '?')
          miny--;
        while (maxy < c - 1 && str[i][maxy + 1] == '?' &&
               ret[i][maxy + 1] == '?')
          maxy++;
        while (minx > 0) {
          bool valid = true;
          {
            int get = miny;
            while (get <= maxy) {
              if (str[minx - 1][get] != '?' || ret[minx - 1][get] != '?') {
                valid = false;
                break;
              }
              get++;
            }
          }
          if (valid) {
            minx--;
          } else
            break;
        }
        int adabawah = false;
        for (int get = i + 1; get < r; get++) {
          for (int l = 0; l < c; l++) {
            if (str[get][l] != '?') {
              adabawah = true;
              break;
            }
          }
        }
        if (!adabawah) {
          maxx = r - 1;
        }

        for (int get = minx; get <= maxx; get++) {
          for (int l = miny; l <= maxy; l++) {
            ret[get][l] = str[i][j];
          }
        }
      }
    }

    fout << "Case #" << ct << ": \n";
    for (int i = 0; i < r; i++) {
      fout << ret[i] << "\n";
    }

    cerr << "Test " << ct << " done \n";
  }
  return ret_val;
}
