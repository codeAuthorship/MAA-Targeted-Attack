#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

const int Maxn = 310;

int T;
using namespace std;

ofstream fout;

ifstream fin;

int cs;

// int check(double speed){
// 	rep(i,1,N){
// 		if (v[i] <= speed){
// 			if (D - S[i]) / v[i]
// 		}
// 	}
// }
int s[Maxn], solve[Maxn], x, N;
double t;
inline void azdxdskrwx(int &get) {
  fin >> s[get] >> solve[get];
  // cout<< s[i] <<" "<<v[i] << endl;
  t = max(t, 1. * (x - s[get]) / solve[get]);
}

inline void pzubbkxudq() {
  fout << "Case #" << ++cs << ": ";
  fin >> x >> N;
  t = -1;
  int get;
  for (get = 1; get <= N; get++) {
    azdxdskrwx(get);
  }

  // double l = 0, r = 1e9;
  // while (r - l > 1e6){
  // 	double mid = (l + r) / 2.0;
  // 	if (check(mid)) l = mid;
  // 	else r = mid;
  // }
  fout << fixed << setprecision(6) << x / t << "\n";
}

int main() {
  fout.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/outer_temp/kuzphi/A-small-practice_transformation.out");

  int ret_val = 0;
  fin.open("/home/tom/project/ramdisk/blackbox_8294486_5630967708385280_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");
  fin >> T;
  while (T--)
    pzubbkxudq();
  return ret_val;
}
