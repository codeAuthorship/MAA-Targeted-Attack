#include <bits/stdc++.h>
#include <fstream>

using namespace std;
const int MAXN = 1005;
const long double PI = 3.1415926535897932384626433832795;
ofstream fout;

typedef vector<int> vi;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;

const int maxN = 1e6 + 5;

int t, r, o, solve, g, b, v, ans[maxN], sum;
set<pii, greater<pii>> s;

inline void vrxelrhjiv(int &i) {
  if (ans[i] == 1)
    fout << "R";
  if (ans[i] == 2)
    fout << "Y";
  if (ans[i] == 3)
    fout << "B";
}

inline void ggldbrldqm() {
  int i = (0);
  while (i <= ((sum)-1)) {
    vrxelrhjiv(i);
    ++i;
  }
}

inline void vwrrhbsxmn() {
  int test = (1);
  while (test <= ((t))) {
    cin >> sum >> r >> o >> solve >> g >> b >> v;
    s.clear();
    if (r > 0)
      s.insert(pii(r, 1));
    if (solve > 0)
      s.insert(pii(solve, 2));
    if (b > 0)
      s.insert(pii(b, 3));
    int tc = max(r, solve);
    tc = max(tc, b);
    fout << "Case #" << test << ": ";

    if (tc > sum / 2) {
      fout << "IMPOSSIBLE";
    } else {
      pii x = *s.begin();
      s.erase(s.begin());
      ans[0] = x.second;
      s.insert(pii(x.first - 1, x.second));

      int cnt = 1;
      while (cnt < sum) {
        pii x = *s.begin();
        if (x.second == ans[cnt - 1]) {
          pii tmp = x;
          s.erase(s.begin());
          x = *s.begin();
          ans[cnt] = x.second;
          s.erase(s.begin());
          if (x.first > 0)
            s.insert(pii(x.first - 1, x.second));
          s.insert(tmp);
        } else {

          ans[cnt] = x.second;
          s.erase(s.begin());
          if (x.first > 0)
            s.insert(pii(x.first - 1, x.second));
        }
        cnt++;
      }
      if (ans[sum - 1] == ans[0]) {
        swap(ans[sum - 1], ans[sum - 2]);
        if (ans[sum - 2] == ans[sum - 3])
          fout << "IMPOSSIBLE";
        else {
          ggldbrldqm();
        }
      } else {

        for (int i = (0); i <= ((sum)-1); ++i) {
          if (ans[i] == 1)
            fout << "R";
          if (ans[i] == 2)
            fout << "Y";
          if (ans[i] == 3)
            fout << "B";
        }
      }
    }
    fout << endl;
    ++test;
  }
}

int main() {
  fout.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5654117850546176_15_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/Mucosolvan/outer_temp/Mucosolvan/A-small-practice_transformation.out");

  int ret_val = 0;
  ios_base::sync_with_stdio(0);
  cin >> t;
  vwrrhbsxmn();
  return ret_val;
}
