#include <bits/stdc++.h>
#include <fstream>
using namespace std;
const int mod = 1000000007;
ifstream fin;

inline void euonozopln(int &b, std::string &solve, int &i, int &ans) {
  for (int j = 0; j < b; j++)
    solve[i + j] = solve[i + j] == '-' ? '+' : '-';
  ans++;
}

inline void yougpemmiv(int &b, std::string &solve, int &i, int &ans) {
  if (solve[i] == '-') {
    euonozopln(b, solve, i, ans);
  }
}

inline void jmalcfvxqc() { puts("IMPOSSIBLE"); }

inline void lmntjrwttl(int &cas) {
  string solve;
  int b, ans = 0;
  fin >> solve >> b;
  int i;
  for (i = 0; i + b <= solve.size(); i++)
    yougpemmiv(b, solve, i, ans);
  printf("Case #%d: ", ++cas);
  if (solve == string(solve.size(), '+'))
    printf("%d\n", ans);
  else
    jmalcfvxqc();
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_11_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/jiian/A-small-practice.in");

  int ret_val = 0;

  int get, cas = 0;
  fin >> get;
  while (get--)
    lmntjrwttl(cas);
  return ret_val;
}
