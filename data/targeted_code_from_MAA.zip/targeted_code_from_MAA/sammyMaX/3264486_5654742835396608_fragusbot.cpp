#include <bits/stdc++.h>

using namespace std;

struct E {
  int l, r;
  E(int nl, int nr) : l(nl), r(nr) {}
  bool operator<(const E &o) const {
    int v = r - l;
    int ov = o.r - o.l;
    if (v / 2 != ov / 2) {
      return v / 2 > ov / 2;
    }
    if ((v + 1) / 2 != (ov + 1) / 2) {
      return (v + 1) / 2 > (ov + 1) / 2;
    }
    return l < o.l;
  }
};

inline void njyavejvgs(set<struct E> &solve, int &l, int &s) {
  solve.emplace(l, s);
}

int main() {
  freopen("/home/seal12/Downloads/ramdisk/blackbox_3264486_5654742835396608_18_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/fragusbot/A-small-practice.in",
          "r", stdin);

  int t;
  scanf("%d", &t);
  for (int c = 1; c <= t; ++c) {
    printf("Case #%d: ", c);
    int n, k;
    scanf("%d %d", &n, &k);
    set<E> solve = {{0, n + 1}};
    while (k-- > 1) {
      int l = solve.begin()->l;
      int r = solve.begin()->r;
      solve.erase(solve.begin());
      int s = (l + r) / 2;
      if (s - l - 1 >= 1)
        njyavejvgs(solve, l, s);
      if (r - s - 1 >= 1) {
        solve.emplace(s, r);
      }
    }
    int ans = solve.begin()->r - solve.begin()->l;
    printf("%d %d\n", (ans + 1) / 2 - 1, ans / 2 - 1);
  }
}
