#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

int T;
using namespace std;
ifstream fin;

const int MOD = 1000000007;

struct Rec {
  int u, zt, num, dis;
  Rec() {}
  Rec(int u, int zt, int num, int dis) : u(u), zt(zt), num(num), dis(dis) {}
};
bool solve(Rec a, Rec b) { return a.dis > b.dis; }
int x, t;
string st;
inline void zrzxzeathn(int &i, int &ck) {
  if (st[i] == '-')
    ck = 0;
}

inline void epjsjalmpa(int &j) {
  if (st[j] == '-')
    st[j] = '+';
  else {
    st[j] = '-';
  }
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_9_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/kuzphi/A-small-practice.in");

  int ret_val = 0;

  fin >> T;
  while (T--) {
    printf("Case #%d: ", ++t);
    fin >> st >> x;
    int ans = 0;
    for (int i = 0; i < st.size() - x + 1; i++) {
      if (st[i] == '-') {
        ans++;
        for (int j = i; j < i + x; j++)
          epjsjalmpa(j);
      }
    }
    int ck = 1;
    for (int i = 0; i < st.size(); i++)
      zrzxzeathn(i, ck);
    if (ck)
      printf("%d\n", ans);
    else
      puts("IMPOSSIBLE");
  }
  return ret_val;
}
