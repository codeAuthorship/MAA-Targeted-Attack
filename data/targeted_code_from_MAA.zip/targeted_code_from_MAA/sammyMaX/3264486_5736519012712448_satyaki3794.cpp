
#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream fin;

ofstream fout;

long long solve(long long a, long long b) {
  if (b == 0)
    return a;
  return solve(b, a % b);
}

inline void vyyqkhcits(int &ans, int &i, int &d, std::string &str) {
  ans++;
  for (int j = i; j < i + d; j++)
    if (str[j] == '-')
      str[j] = '+';
    else
      str[j] = '-';
}

inline void owjbcejrpl(int &x) {

  string str;
  fin >> str;

  int d;
  fin >> d;

  int n = (int)str.length(), ans = 0;
  int i;
  for (i = 0; i + d - 1 < n; i++)
    if (str[i] == '-')
      vyyqkhcits(ans, i, d, str);

  {
    int i = 0;
    while (i < n) {
      if (str[i] == '-')
        ans = -1;
      i++;
    }
  }

  if (ans == -1)
    fout << "Case #" << x++ << ": IMPOSSIBLE" << endl;
  else
    fout << "Case #" << x++ << ": " << ans << endl;
}

int main() {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/A-small-practice.in");

  fout.open("/home/seal12/Downloads/ramdisk/blackbox_3264486_5736519012712448_13_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/satyaki3794/outer_temp/satyaki3794/A-small-practice_transformation.out");

  int ret_val = 0;

  cin.tie(0);

  int t, x = 1;
  fin >> t;
  for (; t--;)
    owjbcejrpl(x);
  return ret_val;
}
