#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cassert>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <utility>
#include <vector>
#pragma comment(linker, "/STACK:256000000")

using namespace std;
ifstream fin;

typedef long long LL;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<int> VI;

void readData() {}

const int maxN = 110;
const long long inf = 1000000000000000000LL;

int n, q;
long long d[maxN][maxN];
long long e[maxN], s[maxN];

long long a[maxN], b[maxN];

double c[maxN];

double solve(int u, int v) {
  --u;
  --v;

  for (int i = 0; i < n; ++i) {
    c[i] = 1e50;
  }
  c[u] = 0.0;

  for (int steps = 0; steps < 200; ++steps) {
    {
      int i = 0;
      while (i < n) {
        for (int j = 0; j < n; ++j) {
          if (e[i] < d[i][j]) {
            continue;
          } else if (i == j || d[i][j] == inf) {
            continue;
          }
          c[j] = min(c[j], c[i] + (double)(d[i][j]) / (double)(s[i]));
        }
        ++i;
      }
    }
  }
  return c[v];
}

void solve(int test) {
  fin >> n >> q;
  for (int i = 0; i < n; ++i) {
    fin >> e[i] >> s[i];
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      fin >> d[i][j];
      if (d[i][j] == -1) {
        d[i][j] = inf;
      }
    }
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {

      for (int p = 0; p < n; ++p) {
        d[j][p] = min(d[j][p], d[j][i] + d[i][p]);
      }
    }
  }

  vector<double> res;
  for (int i = 0; i < q; ++i) {
    int u, v;
    fin >> u >> v;
    res.push_back(solve(u, v));
  }

  cout << "Case #" << test << ":";
  for (int i = 0; i < q; ++i) {
    printf(" %.10lf", res[i]);
  }
  cout << "\n";
}

int main(int argc, char *argv[]) {
  fin.open("/home/seal12/Downloads/ramdisk/blackbox_8294486_5681755159789568_19_Usenix_RF_1.0_True_MCTS_Classic_True/sammyMaX/sdya/A-small-practice.in");

  int ret_val = 0;

  int tc, y;
  int t;
  fin >> t;
  tc = 1, y = t;
  for (int i = 1; i <= t; ++i) {
    if (i >= tc && i <= y) {
      solve(i);
    } else {
      readData();
    }
    cerr << i << ": " << clock() << endl;
  }
  return ret_val;
}
