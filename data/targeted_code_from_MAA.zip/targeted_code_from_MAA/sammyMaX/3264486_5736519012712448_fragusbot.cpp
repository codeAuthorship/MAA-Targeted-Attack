#include <bits/stdc++.h>
#include <iostream>

using namespace std;

char s[77];
int q[7777];
int d[7777];

int main() {
  ios::sync_with_stdio(false);

  int t;
  cin >> t;
  for (int cc = 1; cc <= t; ++cc) {
    printf("Case #%d: ", cc);
    int r;
    cin >> s >> r;
    int n = strlen(s);
    q[0] = 1 << n;
    int i;
    for (i = 0; i < n; ++i) {
      if (s[i] == '-') {
        q[0] |= 1 << (n - 1 - i);
      }
    }
    memset(d, -1, sizeof d);
    d[q[0]] = 0;
    for (int qh = 0, qt = 1; qh < qt; ++qh) {
      int solve = q[qh];
      for (int i = 0; i <= n - r; ++i) {
        int nx = solve ^ (((1 << r) - 1) << i);
        if (d[nx] == -1) {
          d[nx] = d[solve] + 1;
          q[qt++] = nx;
        }
      }
    }
    if (d[1 << n] == -1) {
      puts("IMPOSSIBLE");
    } else {
      printf("%d\n", d[1 << n]);
    }
  }
}
